using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using MuSven09M.Modules.Account;

namespace MuSven09M;

internal sealed class GothicAdminUiForm : Form
{
	private readonly WebView2 browser = new WebView2
	{
		Dock = DockStyle.Fill
	};

	private readonly GothicBackendBridge backend;

	private bool initialized;

	private static readonly JsonSerializerOptions WebJson = new JsonSerializerOptions(JsonSerializerDefaults.Web);

	public GothicAdminUiForm(SqlAccountLookupOptions? options, string configPath)
	{
		backend = new GothicBackendBridge(this, options, configPath);
		Text = "MU SVEN • Gothic Admin UI";
		base.StartPosition = FormStartPosition.CenterScreen;
		MinimumSize = new Size(1180, 760);
		base.Size = new Size(1680, 1000);
		base.WindowState = FormWindowState.Normal;
		BackColor = Color.FromArgb(9, 9, 9);
		base.Controls.Add(browser);
		base.Load += async delegate
		{
			await InitializeViewerAsync();
		};
	}

	private async Task InitializeViewerAsync()
	{
		if (initialized)
		{
			return;
		}
		initialized = true;
		try
		{
			ExtractEmbeddedUiFiles(Path.Combine(AppContext.BaseDirectory, "GothicUi"));
			string userDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MUSVEN Admin", "WebView2");
			Directory.CreateDirectory(userDataFolder);
			CoreWebView2Environment environment = await CoreWebView2Environment.CreateAsync(null, userDataFolder);
			await browser.EnsureCoreWebView2Async(environment);
			browser.CoreWebView2.Settings.IsStatusBarEnabled = false;
			browser.CoreWebView2.Settings.AreDevToolsEnabled = false;
			browser.CoreWebView2.SetVirtualHostNameToFolderMapping("musven-gothic.local", AppContext.BaseDirectory, CoreWebView2HostResourceAccessKind.Allow);
			browser.CoreWebView2.WebMessageReceived += async delegate(object? _, CoreWebView2WebMessageReceivedEventArgs eventArgs)
			{
				try
				{
					using JsonDocument message = JsonDocument.Parse(eventArgs.WebMessageAsJson);
					JsonElement root = message.RootElement;
					if (root.TryGetProperty("type", out var type) && (type.GetString()?.Equals("close", StringComparison.OrdinalIgnoreCase) ?? false))
					{
						Close();
						return;
					}
					if (!root.TryGetProperty("type", out type) || type.GetString() != "api-request" || !root.TryGetProperty("id", out var idElement) || !root.TryGetProperty("method", out var methodElement))
					{
						return;
					}
					string id = idElement.GetString() ?? string.Empty;
					string method = methodElement.GetString() ?? string.Empty;
					JsonElement argsElement;
					JsonElement args = (root.TryGetProperty("args", out argsElement) ? argsElement : default(JsonElement));
					try
					{
						object result = await backend.DispatchAsync(method, args);
						browser.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new
						{
							type = "api-response",
							id = id,
							ok = true,
							result = result
						}, WebJson));
					}
					catch (Exception ex2)
					{
						browser.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new
						{
							type = "api-response",
							id = id,
							ok = false,
							error = ex2.Message
						}, WebJson));
					}
				}
				catch (JsonException)
				{
				}
			};
			browser.Source = new Uri("https://musven-gothic.local/GothicUi/index.html");
		}
		catch (Exception ex)
		{
			base.Controls.Clear();
			base.Controls.Add(new Label
			{
				Dock = DockStyle.Fill,
				TextAlign = ContentAlignment.MiddleCenter,
				ForeColor = Color.FromArgb(238, 210, 158),
				BackColor = Color.FromArgb(12, 12, 12),
				Font = new Font("Segoe UI", 12f),
				Text = "Không mở được Gothic UI.\n\n" + ex.Message
			});
		}
	}

	private static void ExtractEmbeddedUiFiles(string directory)
	{
		string[] obj = new string[5] { "index.html", "styles.css", "options.js", "api.js", "app.js" };
		Directory.CreateDirectory(directory);
		Assembly assembly = Assembly.GetExecutingAssembly();
		string[] array = obj;
		foreach (string file in array)
		{
			string path = Path.Combine(directory, file);
			using Stream input = assembly.GetManifestResourceStream("MuSven.Resources.GothicUi." + file) ?? throw new FileNotFoundException("Thiếu tài nguyên giao diện Gothic: " + file);
			using FileStream output = File.Create(path);
			input.CopyTo(output);
		}
	}
}
