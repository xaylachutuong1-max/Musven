# MUSVEN Gothic Admin R20

## Cơ sở bản phát hành

- Dùng R17 làm chuẩn đầy đủ theo yêu cầu của người dùng.
- Khôi phục trực tiếp 99 tệp C# từ DLL R17 bằng ILSpy; R20 giữ lại toàn bộ các tệp đó trừ `ApplicationConfiguration.cs`, vì SDK Windows Forms tự sinh lớp này. Các thay đổi cần để biên dịch gồm chỉ rõ `System.Windows.Forms.Timer`, giữ tên cột tuple khi kiểm tra schema tạo tài khoản, và bỏ thuộc tính compiler-reserved do decompiler xuất ra.
- Không sửa thư mục, DLL, cấu hình hoặc checkpoint R17.
- Gothic UI giữ giao diện R17 đã nhúng; R20 bổ sung cuộn cho danh sách 14 thao tác nâng cao và trạng thái tải/lỗi/thử lại của trình sửa nhân vật.
- Giữ toàn bộ 924 ảnh vật phẩm, 2 mô hình 3D, catalog item từ resource R17, và các repository/guard nghiệp vụ đã có.
- Trên ứng dụng chính, nút `GOTHIC UI` nằm cạnh `KIỂM TRA KẾT NỐI`; không thay giao diện gốc thành Gothic.

## Kiểm tra đã chạy

- `dotnet build` Release thành công: 0 lỗi, 0 cảnh báo.
- `dotnet publish` self-contained `win-x86`, .NET 8.0.32 thành công từ feed package nội bộ.
- `node --check` qua `GothicUi/app.js`, `api.js`, `options.js`.
- Contract audit: 27 method UI, 27 route backend, 24 lời gọi trực tiếp trong UI; không có route thiếu khai báo hoặc thiếu trong tài liệu.
- Đối chiếu nguồn: đủ 99 tệp C# khôi phục từ R17, ngoài lớp `ApplicationConfiguration` do SDK sinh tự động.
- Đủ 924 ảnh item được đưa vào gói publish.

## Trạng thái nghiệm thu

- Bản R20 đã build và publish; cần mở đúng nút Gothic trong VM để xác nhận giao diện thực tế và WebView2 trên Windows Server 2019.
- Chưa dùng lệnh ghi SQL để thử. Kiểm tra dữ liệu thật chỉ đọc cần hoàn thành trong ứng dụng VM sau khi mở bản R20.
- Các tính năng ghi giữ nguyên kiểm tra schema, tài khoản offline, snapshot, transaction, xác nhận và feature flag riêng.
- Kick player, gửi thông báo broadcast, điều khiển GameServer/ConnectServer vẫn không được báo là đã xong: rà source hiện có không tìm thấy listener/protocol desktop được xác thực. `WZ_DISCONNECT_MEMB` chỉ cập nhật trường SQL, không ngắt socket. Không thêm hành vi giả hoặc lệnh dừng/khởi động server.
- Lưu stats tùy biến vào catalog item vẫn không có schema/API server được xác minh. Hiển thị danh mục và mã item đã có; không tự tạo cấu trúc ghi mới vào database.

## Khôi phục

Giữ nguyên và chạy R17 từ thư mục R17 nếu cần quay lại. R20 được đặt ở thư mục riêng; `work\backups\MUSVEN_Gothic_R20_checkpoint_20261031.zip` là checkpoint nguồn + binary, có SHA-256 ở file `.txt` cùng tên.
