# MU SVEN Gothic — hợp đồng giao diện, API và SQL

Tài liệu này ghép các yêu cầu WebView2 trong `GothicUi/api.js` với route trong `GothicBackendBridge.DispatchAsync`, repository C# và schema SQL thực tế. Chức năng chỉ được mở khi cả route, repository và hợp đồng schema tồn tại.

## RPC giao diện

| RPC | Dữ liệu / kết quả chính | Repository hoặc hành động | SQL / cờ |
| --- | --- | --- | --- |
| `getDashboard` | `configured`, database, trạng thái các cờ và trạng thái màn hình | Không truy vấn dữ liệu | `Config.ini` |
| `searchAccounts` | `prefix` → tối đa 200 tài khoản | `AccountRepository.Search` | `dbo.MEMB_INFO` |
| `listOnlineAccounts` | → tối đa 200 phiên online | `AccountSessionRepository.ListOnline` | `dbo.MEMB_STAT`, `ConnectStat=1` |
| `loadAccount` | `accountId` → tài khoản, phiên, nhân vật | account/session/character repositories | `MEMB_INFO`, `MEMB_STAT`, `dbo.Character` |
| `getItemCatalog` | danh mục item, section, ID, kích cỡ, ảnh | `ItemCatalog` | `Item.xml` được đóng gói |
| `getItemOptions` | `section` → excellent, harmony, socket | `ItemAttributeControls` | Không ghi SQL |
| `loadCharacterEditor` | `accountId`, `name` → snapshot/token, trường được phép sửa | `CharacterEditorRepository.Load` | `dbo.Character`, `dbo.MasterSkillTree` |
| `saveCharacterEditor` | `token`, map trường số → kết quả | `CharacterEditorRepository.Save` | Cờ `[MUSVEN_CHARACTER_WRITES]`; offline, transaction và snapshot |
| `loadCurrency` | `accountId` → WCoin C/P, Goblin Point và token | `CurrencyRepository.Load` | `dbo.CashShopData` |
| `saveCurrency` | `token`, số dư mới → kết quả | `CurrencyRepository.Save` | Cờ `[MUSVEN_CURRENCY_WRITES]`; offline và transaction |
| `loadCharacterDefaults` | cấu hình tạo mặc định + token | `CharacterCreationRepository.LoadDefaults` | `dbo.MUSVEN_CharacterCreateDefaults`; cờ tạo nhân vật |
| `saveCharacterDefaults` | token + 9 số cấu hình → kết quả | `CharacterCreationRepository.SaveDefaults` | Cùng bảng; Master Level/Point tối đa 400 |
| `loadInventory` | account, kho → 240 ô, item và quyền ghi | `WarehouseRepository` | `dbo.warehouse`, `dbo.ExtWarehouse` |
| `saveInventory` | snapshot/token và danh sách item đã đặt/sửa → kết quả | `WarehouseItemRepository` | Cờ `[MUSVEN_ITEM_WRITES]`; `dbo.MEMB_STAT`, kho, `dbo.WZ_GetItemSerial` |
| `openWarehouse` | account → mở form kho native cũ | Form kho hiện có | `Muonline` đã cấu hình |
| `openCharacterDelete` | account + tên → kết quả xóa/hủy | `CharacterDeletionForm` + repository | Cờ `[MUSVEN_CHARACTER_DELETE]`, `dbo.WZ_DeleteCharacter` |
| `openCharacterRename` | account + tên cũ → form nhập tên mới | `CharacterRenameForm` + `CharacterRenameRepository` | Cờ `[MUSVEN_CHARACTER_RENAME]`, `dbo.WZ_RenameCharacter`; offline, xác minh toàn bộ 28 UPDATE tham chiếu, transaction và kiểm tra kết quả |
| `openCharacterInventory` | account + tên → mở editor blob túi nhân vật | `CharacterInventoryEditorForm` + `CharacterInventoryRepository` | Cờ `[MUSVEN_CHARACTER_INVENTORY]`; `Character.Inventory varbinary(4080)`, MEMB_STAT offline, snapshot, giữ slot/serial, chỉ sửa item đã có trong catalog |
| `openCharacterQuestCounts` | account + tên → mở form số đếm quái nhiệm vụ | `CharacterQuestKillCountForm` + `CharacterQuestKillCountRepository` | Cờ `[MUSVEN_CHARACTER_QUEST_COUNTS]`; `dbo.QuestKillCount` schema kiểm tra runtime; chỉ cập nhật `KillCount1..5`, offline, transaction, snapshot và hậu kiểm; không tạo dòng thiếu |
| `openAccountMembership` | account → form cấp thành viên/hạn dùng | `AccountMembershipForm` + `AccountMembershipRepository` | Cờ `[MUSVEN_ACCOUNT_LEVEL]`, `dbo.WZ_SetAccountLevel`; snapshot, offline, xác minh chữ ký/body và hậu kiểm |
| `openAccountProfile` | account → sửa tên hiển thị/email | `AccountProfileForm` + `AccountProfileRepository` | Cờ `[MUSVEN_ACCOUNT_PROFILE]`; `MEMB_INFO.memb_name varchar(10)`, `mail_addr varchar(50)`, schema kiểm tra runtime, offline, snapshot, transaction và hậu kiểm |
| `openAccountCreate` | mở form tạo account với password trống | `AccountCreateForm` + `AccountCreateRepository` | Cờ `[MUSVEN_ACCOUNT_CREATE]`; kiểm schema `MEMB_INFO`, cột bắt buộc ngoài hợp đồng, ID trùng dưới khóa serializable, transaction và hậu kiểm password rỗng |
| `openAccountBan` | account → form khóa đến thời điểm đã chọn | `AccountBanForm` + `AccountBanRepository` | Cờ `[MUSVEN_ACCOUNT_BAN]`; `MEMB_INFO.bloc_code` / `bloc_expire`, schema kiểm tra runtime, offline, snapshot, tối đa 365 ngày, xác nhận và hậu kiểm |
| `openAccountUnban` | account → form gỡ khóa hết hạn | `AccountUnbanForm` + `AccountModerationRepository` | Cờ `[MUSVEN_ACCOUNT_MODERATION]`, `dbo.WZ_DesblocAccount` |
| `openRankingView` | mở trình duyệt ranking/event và reset ranking có whitelist | `RankingBrowserForm` + `RankingMaintenanceRepository` | Cờ `[MUSVEN_RANKING_WRITES]`; chỉ bảng `Ranking*` whitelist, preview, nhập đúng tên bảng, xác nhận kép, không còn người online, transaction; GameServer phải dừng thủ công |
| `openSqlBackup` | mở form backup | `SqlBackupForm` | Cờ `[MUSVEN_SQL_BACKUP]`, COPY_ONLY/CHECKSUM + VERIFYONLY |
| `openDataReset` | mở form preview/reset | `SqlDataResetForm` | Cờ `[MUSVEN_DATA_RESET]`, schema ghim, backup và xác nhận kép |

Các route mở form native trả về sau khi form đóng. Giao diện không được coi việc mở form là kết quả đã lưu/xóa/reset thành công.

## Payload RPC chính xác

Mỗi lời gọi dùng envelope WebView2 `{ type: "api-request", id: string, method: string, args: object }`; phản hồi là `{ type: "api-response", id, ok, result }` hoặc `{ type: "api-response", id, ok: false, error }`. Tên field dưới đây phân biệt hoa/thường và khớp với `GothicUi/api.js`, `GothicUi/app.js` và `GothicBackendBridge.DispatchAsync`.

| RPC | `args` bắt buộc / tùy chọn | Kết quả thành công |
| --- | --- | --- |
| `getDashboard` | `{}` | trạng thái `configured`, database, các cờ chức năng, gồm `characterQuestCountsEnabled` |
| `searchAccounts` | `{ prefix: string }` | `{ accounts: Account[] }`, tối đa 200 |
| `listOnlineAccounts` | `{}` | `{ accounts: Session[] }`, tối đa 200 |
| `loadAccount` | `{ accountId: string }` | `{ account, session, characters }` |
| `getItemCatalog` | `{}` | `Item[]`; mỗi item có section/localId/itemIndex/name/category/type/width/height/image |
| `getItemOptions` | `{ section: integer }` | `excellentOptions[]`, `harmonyOptions[]`, `socketOptions[]` với `{ id, label }` |
| `loadCharacterEditor` | `{ accountId: string, name: string }` | `{ token, accountId, name, fields[], notice, writeEnabled }` |
| `saveCharacterEditor` | `{ token: string, values: { [fieldKey]: number } }` | `{ ok, count, name }`; người vận hành xác nhận trong hộp thoại |
| `loadCurrency` | `{ accountId: string }` | `{ token, accountId, wcoinC, wcoinP, goblinPoint, writeEnabled }` |
| `saveCurrency` | `{ token: string, wcoinC: integer, wcoinP: integer, goblinPoint: integer }` | `{ ok, accountId }`; người vận hành xác nhận |
| `loadCharacterDefaults` | `{}` | `{ token, defaults, writeEnabled }` |
| `saveCharacterDefaults` | `{ token: string, values: { level, points, zen, reset, masterLevel, masterPoints, wcoinC, wcoinP, goblinPoint: integer } }` | `{ ok: true }`; người vận hành xác nhận |
| `loadInventory` | `{ accountId: string, number?: integer, isExtended?: boolean }` | `{ accountId, locations, location, snapshotToken, writeEnabled, placements[] }`; không có kho thì location là `null` |
| `saveInventory` | `{ accountId: string, snapshotToken: string, items: StagedItem[] }` | `{ ok, count, addedCount, editedCount, target }`; người vận hành xác nhận |
| `openWarehouse` | `{ accountId?: string }` | `{ ok: true }` khi form đóng |
| `openCharacterDelete` | `{ accountId: string, name: string }` | `{ ok: true, deleted, accountId, name }`; form yêu cầu xác nhận |
| `openCharacterRename` | `{ accountId: string, name: string }` | `{ ok: true, renamed, accountId, oldName, newName }`; form xác nhận, kiểm tra trùng và cập nhật các bảng liên quan trong transaction |
| `openCharacterInventory` | `{ accountId: string, name: string }` | `{ ok: true, accountId, name }` sau khi đóng editor; blob từ 1–255 record đủ 16 byte có thể xem; chỉ blob đúng 4080 byte mới cho sửa/lưu item có trong catalog và lưu khi offline |
| `openCharacterQuestCounts` | `{ accountId: string, name: string }` | `{ ok: true, saved, accountId, name }` sau khi đóng form; chỉ số đếm quái được sửa, MonsterClass/QuestIndex giữ nguyên |
| `openAccountMembership` | `{ accountId: string }` | `{ ok: true, updated, accountId }`; form đọc cấp/hạn hiện tại, yêu cầu tài khoản offline và xác nhận |
| `openAccountProfile` | `{ accountId: string }` | `{ ok: true, updated, accountId }`; chỉ sửa `memb_name` và `mail_addr`, yêu cầu offline, xác nhận, snapshot và hậu kiểm; mật khẩu/ID/câu trả lời khôi phục không đổi |
| `openAccountCreate` | `{}` | `{ ok: true, created, accountId }`; form yêu cầu AccountID, tên/email tùy chọn, xác nhận trước khi tạo; `memb__pwd` được lưu chuỗi trống, khả năng đăng nhập tùy GameServer |
| `openAccountBan` | `{ accountId: string }` | `{ ok: true, banned, accountId, expiresAt }`; form kiểm tra `bloc_code`/`bloc_expire`, từ chối online/khóa còn hạn, yêu cầu gõ đúng AccountID và xác nhận |
| `openAccountUnban` | `{ accountId: string }` | `{ ok: true, unbanned, accountId, accountBansCleared, characterBansCleared }`; form chỉ gỡ khóa đã hết hạn, yêu cầu offline, gõ chính xác AccountID và xác nhận |
| `openRankingView`, `openSqlBackup`, `openDataReset` | `{}` | `{ ok: true }` khi form tương ứng đóng; kết quả từng thao tác hiển thị trong form |

`StagedItem` có `itemIndex`, `slot`, `editExisting`, `level`, `optionValue`, `durability`, `skill`, `luck`, `excellent` (bitmask sáu bit), `setOption`, `harmonyValue`, và `sockets` (đúng năm byte). Item mới chỉ được ghi vào slot trống; sửa item giữ slot và serial. Các field bổ sung từ giao diện (ảnh xem trước, draft id, nhãn socket) bị loại trước khi gọi API.

Backend phải từ chối request có token hết hạn, cấu trúc sai hoặc cấu hình khóa; các RPC ghi cần account offline và kiểm tra snapshot. Các operation bị từ chối do schema/chưa hỗ trợ không được giả lập thành kết quả thành công.

## Hợp đồng schema trọng yếu

- Kết nối trong profile VM: Windows Authentication, `Server=localhost`, `Database=Muonline`, chứng chỉ self-signed được tin cậy trong VM.
- Tạo nhân vật: bảng một dòng `dbo.MUSVEN_CharacterCreateDefaults`; `ConfigID tinyint` là khóa chính; 9 trường cấu hình là `int`; `ModifiedAt datetime`; constraint kiểm soát giá trị. `dbo.WZ_CreateCharacter` phải có đúng ba tham số game `@AccountID varchar(10)`, `@Name varchar(10)`, `@Class tinyint` và marker V03.
- Sửa/xóa nhân vật: `dbo.Character` có `AccountID`, `Name`; Master nằm trong `dbo.MasterSkillTree` (`Name varchar(50)`, `MasterLevel`, `MasterPoint`, `MasterExperience`). Xóa yêu cầu `dbo.WZ_DeleteCharacter` đúng marker/chữ ký và các bảng phụ đã kiểm kê.
- Gỡ khóa hết hạn: `dbo.WZ_DesblocAccount` có đúng một tham số `@Account varchar(10)`. Định nghĩa được kiểm tra ở mỗi lần gọi và chỉ được chứa hai lệnh cập nhật: `MEMB_INFO.bloc_code=0` khi `bloc_code=1 AND bloc_expire<GETDATE()`, và `Character.CtlCode=0` khi `CtlCode=1 AND bloc_expire<GETDATE()`. Musven yêu cầu `MEMB_STAT.ConnectStat=0`, khóa giao dịch, nhập đúng AccountID và xác nhận. Không gỡ khóa còn hạn.
- Khóa tài khoản tạm thời: dùng đúng hai cột `MEMB_INFO.bloc_code` và `bloc_expire`, cũng được dùng trong procedure gỡ khóa đã rà soát. Metadata mỗi lần gọi phải xác nhận `memb___id varchar(10)`, `bloc_code` là `tinyint/smallint/int`, `bloc_expire` là `smalldatetime/datetime/datetime2`, và `MEMB_STAT.ConnectStat` là kiểu số nguyên. Chỉ đổi `bloc_code` từ 0 hoặc khóa đã hết hạn sang 1; không ghi đè khóa còn hạn/vĩnh viễn. Tài khoản phải offline; transaction so snapshot, giới hạn 365 ngày và hậu kiểm. Không cần migration SQL.
- Cấp thành viên: `MEMB_INFO.AccountLevel int` và `AccountExpireDate smalldatetime`; `WZ_SetAccountLevel(@Account varchar(10), @AccountLevel int, @AccountExpireTime int)`. Musven so khớp toàn bộ thân procedure đã đọc trên VM trước khi gọi. Procedure hiểu hạn dùng là số giây; cùng cấp cộng thời lượng vào hạn hiện tại, đổi cấp tính từ giờ SQL. Ghi trong transaction khi tài khoản offline và so sánh snapshot.
- Sửa hồ sơ tài khoản: legacy Titan và schema server xác nhận `MEMB_INFO.memb_name varchar(10)` và `mail_addr varchar(50)`. Musven chỉ sửa hai field này, không đọc/ghi mật khẩu hay câu hỏi/đáp án khôi phục. Mỗi lần tải/lưu kiểm kiểu/độ dài cột; lưu cần cờ `[MUSVEN_ACCOUNT_PROFILE]`, `MEMB_STAT.ConnectStat=0`, transaction, khóa dòng, so snapshot và hậu kiểm. Cần `SELECT` trên `MEMB_INFO`/`MEMB_STAT` và `UPDATE` giới hạn cột `memb_name`, `mail_addr`.
- Tạo tài khoản không mật khẩu: DDL đối chiếu xác nhận `memb_guid int IDENTITY`, `memb___id varchar(10)`, `memb__pwd varchar(10)`, `memb_name varchar(10)`, `sno__numb char(18)`, `bloc_code char(1)`, `ctl1_code char(1)`, `AccountLevel int`, `AccountExpireDate smalldatetime`, `Lock int`; các cột cần có đúng nullability/type/length. Ghi `memb__pwd=''`, tên mặc định là AccountID, `sno__numb='1'`, tài khoản cấp 0/chưa khóa/hạn 1900; email tùy chọn. Nếu có cột NOT NULL không identity/default chưa được hỗ trợ thì dừng. Cờ `[MUSVEN_ACCOUNT_CREATE]` riêng; cần `SELECT/INSERT` trên `dbo.MEMB_INFO`. Kiểm tra ID trùng dưới `SERIALIZABLE` + `UPDLOCK,HOLDLOCK`, xác nhận form, transaction và hậu kiểm. Không tự thêm `MEMB_STAT`/`AccountCharacter`; GameServer tạo session khi account kết nối và character khi người chơi tạo trong game. Không dùng `Encript`; password trống có đăng nhập được hay không phải do cấu hình xác thực GameServer.
- Đổi tên nhân vật: `WZ_RenameCharacter(@Account varchar(10), @OldName varchar(10), @NewName varchar(10))`. Musven so sánh đầy đủ 28 lệnh UPDATE trong whitelist, kiểm tra đủ các bảng/cột tham chiếu, tên cũ thuộc đúng tài khoản, tên mới chưa dùng, trạng thái offline và kết quả sau cập nhật; procedure chạy trong transaction bên ngoài để mọi bảng cùng rollback.
- Túi nhân vật: server contract là `dbo.Character.Inventory varbinary(4080)`; 4080 byte là 255 record item 16 byte. Blob có độ dài thực từ 1 đến 4080 byte, chia hết cho 16, được mở chỉ đọc để tránh làm mất dữ liệu; chỉ blob đúng 4080 byte mới bật sửa/lưu. Editor chỉ chỉnh thuộc tính record có ItemIndex trong catalog, giữ vị trí/serial và byte khác, không thêm/xóa/di chuyển; ghi cần offline, transaction và so snapshot toàn blob.
- Reset ranking: whitelist chỉ gồm `RankingBloodCastle`, `RankingBos`, `RankingChaosCastle`, `RankingDevilSquare`, `RankingDuel`, `RankingIllusionTemple`, `RankingKingGuild`, `RankingKingPlayer`, `RankingTvT`. Không nhận tên bảng từ request tự do; chặn nếu có trigger/FK hoặc MEMB_STAT còn online; preview row-count, yêu cầu nhập tên bảng và xác nhận lần cuối, DELETE trong transaction và hậu kiểm bảng rỗng. GameServer phải được người vận hành dừng trước thao tác.
- Kho: `dbo.warehouse` và `dbo.ExtWarehouse` có `Items varbinary(3840)`; `ExtWarehouse` còn `AccountID varchar(10)`, `Money int`, `Number int`. Việc lưu dùng serial từ `dbo.WZ_GetItemSerial`; chỉ ô trống được thêm, sửa item giữ serial/vị trí.
- Tiền/ngọc: WCoin/Goblin ở `dbo.CashShopData`; 10 loại ngọc ở `dbo.DATDAT_BANK`. Ghi yêu cầu offline và snapshot; không tạo dòng thiếu.
- Reset: target là SQL Server `WIN-L1CSPDF707L`, phiên bản 10.50.x, 63 bảng/76 procedure sau migration V03; 56 bảng dữ liệu, 7 bảng cấu hình được giữ. Chỉ preview là đọc; reset vẫn cần backup kiểm tra được, không còn session game/SSMS, nhập đúng câu xác nhận và xác nhận cuối.

## Các phần backend còn cần hợp đồng thực thi

Các mục sau đây vẫn chưa có hợp đồng đủ để bật chức năng ghi trong MUSVEN:

- **Kick player, broadcast và điều khiển GameServer/ConnectServer:** source hiện không có giao thức quản trị đang chạy ở server. `WZ_DISCONNECT_MEMB` chỉ cập nhật `MEMB_STAT.ConnectStat` và `DisConnectTM`; nó không chứng minh socket của GameServer đã bị đóng, nên không được dùng làm Kick giả. `WZ_WriteMail` là thư bạn bè có điều kiện `T_FriendMain`, không phải broadcast. Các nút start/stop cũng không được thêm vào client vì chưa có agent/protocol đã xác minh và quy tắc vận hành hiện tại cấm dừng/khởi động lại MU Server.
- **Xóa tài khoản, đổi AccountID và đặt/đổi mật khẩu:** thiếu danh sách đầy đủ bảng tham chiếu và quy trình xác thực/hash; Titan gọi `Encript` nhưng source SQL không chứa định nghĩa procedure. Không ghi password không trống trực tiếp vào `memb__pwd`.
- **Ghi trạng thái QuestWorld/event, sửa kỹ năng/hôn nhân/chuyển tài khoản:** chưa có schema/encoding và quy tắc cập nhật blob/phụ thuộc tương ứng. Riêng `QuestKillCount.KillCount1..5` đã có route `openCharacterQuestCounts`; các bảng này không nằm trong hợp đồng reset ranking.
- **Lưu chỉnh sửa chỉ số danh mục item:** danh mục đang dùng là `Item.xml` đóng gói để tra cứu, chưa có bảng/procedure nguồn để lưu ngược vào dữ liệu game.

`WZ_SetReward` được xác định là procedure cộng WCoinC/P theo quyền GM; nó không thay luồng chỉnh số dư hiện có, vốn kiểm tra snapshot và cập nhật cả kho currency đã biết. Các mục đã có repository/form và cờ VM riêng được liệt kê ở phần RPC phía trên, không nằm trong danh sách còn thiếu này.

Source đối chiếu bổ sung: `E:\MUSVEN_GOC_SOURCE\MUSVEN_TITAN_AUDIT_20261025\TitanEditor`, `E:\MUSVEN_GOC_SOURCE\SRCMainGS` và `E:\MuServer\MuServer\DB\SQL Server 2008 R2.sql`. Source cũ và DDL giúp chốt hợp đồng tạo password trống, hồ sơ `memb_name`/`mail_addr`; chúng không thay thế hợp đồng runtime cho đặt/đổi mật khẩu, đổi/xóa AccountID hay lệnh server. Xem `LEGACY_SOURCE_CONTRACT_AUDIT.md` để biết chi tiết đối chiếu và ranh giới còn lại.

## Rà soát đồng bộ

Mọi tên phương thức trong danh sách RPC phải có mặt đồng thời trong danh sách `methods` của `GothicUi/api.js` và switch của `GothicBackendBridge.DispatchAsync`. Khi thêm route, cập nhật cả ba: bridge, danh sách API và tài liệu này. Mọi thay đổi schema phải có migration guarded, mục kiểm kê schema và cập nhật phiên bản/reset baseline nếu ảnh hưởng số lượng bảng.
