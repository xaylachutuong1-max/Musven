﻿USE [Muonline];
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
DECLARE @CurrentDefinition nvarchar(max);
SET @CurrentDefinition = OBJECT_DEFINITION(OBJECT_ID(N'dbo.WZ_CreateCharacter'));
IF @CurrentDefinition LIKE N'%MU SVEN CHARACTER DEFAULTS V03%'
BEGIN
    /* The live database may already be at V03. Validate it and repair only the
       one missing defaults row; never alter the live game procedure again. */
    IF (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID(N'dbo.WZ_CreateCharacter') AND parameter_id>0) <> 3
       OR NOT EXISTS (SELECT 1 FROM sys.parameters AS p JOIN sys.types AS ty ON ty.user_type_id=p.user_type_id WHERE p.object_id=OBJECT_ID(N'dbo.WZ_CreateCharacter') AND p.parameter_id=1 AND p.name=N'@AccountID' AND ty.name=N'varchar' AND p.max_length=10 AND p.is_output=0)
       OR NOT EXISTS (SELECT 1 FROM sys.parameters AS p JOIN sys.types AS ty ON ty.user_type_id=p.user_type_id WHERE p.object_id=OBJECT_ID(N'dbo.WZ_CreateCharacter') AND p.parameter_id=2 AND p.name=N'@Name' AND ty.name=N'varchar' AND p.max_length=10 AND p.is_output=0)
       OR NOT EXISTS (SELECT 1 FROM sys.parameters AS p JOIN sys.types AS ty ON ty.user_type_id=p.user_type_id WHERE p.object_id=OBJECT_ID(N'dbo.WZ_CreateCharacter') AND p.parameter_id=3 AND p.name=N'@Class' AND ty.name=N'tinyint' AND p.max_length=1 AND p.is_output=0)
       OR @CurrentDefinition NOT LIKE N'%dbo.MUSVEN_CharacterCreateDefaults%'
       OR @CurrentDefinition NOT LIKE N'%dbo.MasterSkillTree%'
       OR @CurrentDefinition NOT LIKE N'%dbo.CashShopData%'
       OR @CurrentDefinition NOT LIKE N'%SELECT @Result AS Result%'
    BEGIN RAISERROR('V03 procedure signature/body does not match the reviewed contract; no changes were made.', 16, 1); RETURN; END;

    IF OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults', N'U') IS NULL
    BEGIN RAISERROR('WZ_CreateCharacter is V03 but the defaults table is missing; no changes were made.', 16, 1); RETURN; END;
    IF (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults')) <> 11
       OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults') AND name IN (N'ConfigID',N'StartLevel',N'StartPoints',N'StartZen',N'StartReset',N'MasterLevel',N'MasterPoints',N'WCoinC',N'WCoinP',N'GoblinPoint',N'ModifiedAt')) <> 11
       OR EXISTS
       (
           SELECT 1 FROM sys.columns AS c JOIN sys.types AS ty ON ty.user_type_id=c.user_type_id
           WHERE c.object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults')
             AND (c.is_nullable=1 OR c.is_identity=1
               OR (c.name=N'ConfigID' AND ty.name<>N'tinyint')
               OR (c.name IN (N'StartLevel',N'StartPoints',N'StartZen',N'StartReset',N'MasterLevel',N'MasterPoints',N'WCoinC',N'WCoinP',N'GoblinPoint') AND ty.name<>N'int')
               OR (c.name=N'ModifiedAt' AND ty.name<>N'datetime'))
       )
       OR NOT EXISTS
       (SELECT 1 FROM sys.key_constraints AS k JOIN sys.index_columns AS ic ON ic.object_id=k.parent_object_id AND ic.index_id=k.unique_index_id JOIN sys.columns AS c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
        WHERE k.parent_object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults') AND k.type=N'PK' AND c.name=N'ConfigID' AND ic.key_ordinal=1
          AND (SELECT COUNT(*) FROM sys.index_columns AS pkic WHERE pkic.object_id=k.parent_object_id AND pkic.index_id=k.unique_index_id AND pkic.key_ordinal>0)=1)
       OR NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE parent_object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults') AND name=N'CK_MUSVEN_CharacterCreateDefaults_Values' AND is_disabled=0 AND is_not_trusted=0)
       OR NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE parent_object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults') AND name=N'DF_MUSVEN_CharacterCreateDefaults_ModifiedAt')
    BEGIN RAISERROR('V03 defaults table does not match the reviewed schema; no changes were made.', 16, 1); RETURN; END;
    IF EXISTS
    (
        SELECT 1 FROM dbo.MUSVEN_CharacterCreateDefaults
        WHERE ConfigID=1 AND (StartLevel NOT BETWEEN 0 AND 400 OR StartPoints NOT BETWEEN 0 AND 100000000
          OR StartZen NOT BETWEEN 0 AND 2000000000 OR StartReset NOT BETWEEN 0 AND 1000000
          OR MasterLevel NOT BETWEEN 0 AND 400 OR MasterPoints NOT BETWEEN 0 AND 400
          OR WCoinC<0 OR WCoinP<0 OR GoblinPoint<0)
    )
    BEGIN RAISERROR('V03 defaults row contains invalid values; no changes were made.', 16, 1); RETURN; END;

    IF NOT EXISTS (SELECT 1 FROM dbo.MUSVEN_CharacterCreateDefaults WHERE ConfigID=1)
    BEGIN
        BEGIN TRY
            BEGIN TRANSACTION;
            IF NOT EXISTS (SELECT 1 FROM dbo.MUSVEN_CharacterCreateDefaults WITH (UPDLOCK, HOLDLOCK) WHERE ConfigID=1)
                INSERT INTO dbo.MUSVEN_CharacterCreateDefaults
                  (ConfigID,StartLevel,StartPoints,StartZen,StartReset,MasterLevel,MasterPoints,WCoinC,WCoinP,GoblinPoint)
                VALUES (1,400,100000,2000000000,500,400,400,100000000,100000000,100000000);
            COMMIT TRANSACTION;
            PRINT 'V03 was already installed; restored its missing default row without changing the procedure.';
        END TRY
        BEGIN CATCH
            IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
            RAISERROR('Could not restore the missing V03 defaults row; transaction rolled back.', 16, 1);
            RETURN;
        END CATCH;
    END
    ELSE PRINT 'V03 schema and defaults row already exist; no changes were made.';
    RETURN;
END;

IF @CurrentDefinition IS NULL OR @CurrentDefinition NOT LIKE N'%MU SVEN COMBINED DRAFT V02%'
BEGIN RAISERROR('WZ_CreateCharacter is not the reviewed V02 procedure; migration stopped before changes.', 16, 1); RETURN; END;
IF (SELECT COUNT(*) FROM sys.parameters WHERE object_id=OBJECT_ID(N'dbo.WZ_CreateCharacter') AND parameter_id>0) <> 3
   OR NOT EXISTS (SELECT 1 FROM sys.parameters AS p JOIN sys.types AS ty ON ty.user_type_id=p.user_type_id WHERE p.object_id=OBJECT_ID(N'dbo.WZ_CreateCharacter') AND p.parameter_id=1 AND p.name=N'@AccountID' AND ty.name=N'varchar' AND p.max_length=10 AND p.is_output=0)
   OR NOT EXISTS (SELECT 1 FROM sys.parameters AS p JOIN sys.types AS ty ON ty.user_type_id=p.user_type_id WHERE p.object_id=OBJECT_ID(N'dbo.WZ_CreateCharacter') AND p.parameter_id=2 AND p.name=N'@Name' AND ty.name=N'varchar' AND p.max_length=10 AND p.is_output=0)
   OR NOT EXISTS (SELECT 1 FROM sys.parameters AS p JOIN sys.types AS ty ON ty.user_type_id=p.user_type_id WHERE p.object_id=OBJECT_ID(N'dbo.WZ_CreateCharacter') AND p.parameter_id=3 AND p.name=N'@Class' AND ty.name=N'tinyint' AND p.max_length=1 AND p.is_output=0)
BEGIN RAISERROR('WZ_CreateCharacter signature is not @AccountID varchar(10), @Name varchar(10), @Class tinyint; migration stopped before changes.', 16, 1); RETURN; END;
BEGIN TRY
    BEGIN TRANSACTION;
    IF OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.MUSVEN_CharacterCreateDefaults
        (
            ConfigID tinyint NOT NULL CONSTRAINT PK_MUSVEN_CharacterCreateDefaults PRIMARY KEY,
            StartLevel int NOT NULL, StartPoints int NOT NULL, StartZen int NOT NULL, StartReset int NOT NULL,
            MasterLevel int NOT NULL, MasterPoints int NOT NULL, WCoinC int NOT NULL, WCoinP int NOT NULL, GoblinPoint int NOT NULL,
            ModifiedAt datetime NOT NULL CONSTRAINT DF_MUSVEN_CharacterCreateDefaults_ModifiedAt DEFAULT (GETDATE()),
            CONSTRAINT CK_MUSVEN_CharacterCreateDefaults_Values CHECK
            (ConfigID=1 AND StartLevel BETWEEN 0 AND 400 AND StartPoints BETWEEN 0 AND 100000000 AND
             StartZen BETWEEN 0 AND 2000000000 AND StartReset BETWEEN 0 AND 1000000 AND
             MasterLevel BETWEEN 0 AND 400 AND MasterPoints BETWEEN 0 AND 400 AND WCoinC>=0 AND WCoinP>=0 AND GoblinPoint>=0)
        );
    END;
    IF (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults')) <> 11
       OR (SELECT COUNT(*) FROM sys.columns WHERE object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults') AND name IN (N'ConfigID',N'StartLevel',N'StartPoints',N'StartZen',N'StartReset',N'MasterLevel',N'MasterPoints',N'WCoinC',N'WCoinP',N'GoblinPoint',N'ModifiedAt')) <> 11
        RAISERROR('MUSVEN_CharacterCreateDefaults exists with an unexpected schema; migration rolled back.', 16, 1);
    IF EXISTS
    (
        SELECT 1
        FROM sys.columns AS c
        JOIN sys.types AS ty ON ty.user_type_id=c.user_type_id
        WHERE c.object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults')
          AND (c.is_nullable=1 OR c.is_identity=1
            OR (c.name=N'ConfigID' AND ty.name<>N'tinyint')
            OR (c.name IN (N'StartLevel',N'StartPoints',N'StartZen',N'StartReset',N'MasterLevel',N'MasterPoints',N'WCoinC',N'WCoinP',N'GoblinPoint') AND ty.name<>N'int')
            OR (c.name=N'ModifiedAt' AND ty.name<>N'datetime'))
    )
        RAISERROR('MUSVEN_CharacterCreateDefaults has a column with an unexpected type; migration rolled back.', 16, 1);
    IF NOT EXISTS
       (SELECT 1 FROM sys.key_constraints AS k JOIN sys.index_columns AS ic ON ic.object_id=k.parent_object_id AND ic.index_id=k.unique_index_id JOIN sys.columns AS c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
        WHERE k.parent_object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults') AND k.type=N'PK' AND c.name=N'ConfigID' AND ic.key_ordinal=1
          AND (SELECT COUNT(*) FROM sys.index_columns AS pkic WHERE pkic.object_id=k.parent_object_id AND pkic.index_id=k.unique_index_id AND pkic.key_ordinal>0)=1)
       OR NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE parent_object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults') AND name=N'CK_MUSVEN_CharacterCreateDefaults_Values' AND is_disabled=0 AND is_not_trusted=0)
       OR NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE parent_object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults') AND name=N'DF_MUSVEN_CharacterCreateDefaults_ModifiedAt')
        RAISERROR('MUSVEN_CharacterCreateDefaults is missing its reviewed primary key or constraints; migration rolled back.', 16, 1);
    IF NOT EXISTS (SELECT 1 FROM dbo.MUSVEN_CharacterCreateDefaults WHERE ConfigID=1)
        INSERT INTO dbo.MUSVEN_CharacterCreateDefaults
          (ConfigID,StartLevel,StartPoints,StartZen,StartReset,MasterLevel,MasterPoints,WCoinC,WCoinP,GoblinPoint)
        VALUES (1,400,100000,2000000000,500,400,400,100000000,100000000,100000000);
    DECLARE @AlterScript nvarchar(max);
    SET @AlterScript =
        CAST(N'ALTER PROCEDURE [dbo].[WZ_CreateCharacter]' AS nvarchar(max)) + NCHAR(13) + NCHAR(10) +
        N'    @AccountID varchar(10),' + NCHAR(13) + NCHAR(10) +
        N'    @Name varchar(10),' + NCHAR(13) + NCHAR(10) +
        N'    @Class tinyint' + NCHAR(13) + NCHAR(10) +
        N'AS' + NCHAR(13) + NCHAR(10) +
        N'BEGIN' + NCHAR(13) + NCHAR(10) +
        N'    /* MU SVEN CHARACTER DEFAULTS V03 */' + NCHAR(13) + NCHAR(10) +
        N'    SET NOCOUNT ON;' + NCHAR(13) + NCHAR(10) +
        N'    SET XACT_ABORT ON;' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'    DECLARE @Result tinyint;' + NCHAR(13) + NCHAR(10) +
        N'    DECLARE @Slot int;' + NCHAR(13) + NCHAR(10) +
        N'    DECLARE @Rows int;' + NCHAR(13) + NCHAR(10) +
        N'    DECLARE @StartLevel int, @StartPoints int, @StartZen int, @StartReset int;' + NCHAR(13) + NCHAR(10) +
        N'    DECLARE @MasterLevel int, @MasterPoints int, @WCoinC int, @WCoinP int, @GoblinPoint int;' + NCHAR(13) + NCHAR(10) +
        N'    DECLARE @CashShopRows int;' + NCHAR(13) + NCHAR(10) +
        N'    SET @Result = 2;' + NCHAR(13) + NCHAR(10) +
        N'    SET @Slot = 0;' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'    IF @AccountID IS NULL OR LEN(LTRIM(RTRIM(@AccountID))) = 0' + NCHAR(13) + NCHAR(10) +
        N'       OR @Name IS NULL OR LEN(LTRIM(RTRIM(@Name))) = 0' + NCHAR(13) + NCHAR(10) +
        N'       OR @Class IS NULL' + NCHAR(13) + NCHAR(10) +
        N'    BEGIN' + NCHAR(13) + NCHAR(10) +
        N'        SELECT CAST(2 AS tinyint) AS Result;' + NCHAR(13) + NCHAR(10) +
        N'        RETURN;' + NCHAR(13) + NCHAR(10) +
        N'    END' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'    BEGIN TRY' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        SELECT @StartLevel=StartLevel, @StartPoints=StartPoints, @StartZen=StartZen, @StartReset=StartReset,' + NCHAR(13) + NCHAR(10) +
        N'               @MasterLevel=MasterLevel, @MasterPoints=MasterPoints, @WCoinC=WCoinC, @WCoinP=WCoinP, @GoblinPoint=GoblinPoint' + NCHAR(13) + NCHAR(10) +
        N'        FROM dbo.MUSVEN_CharacterCreateDefaults WITH (HOLDLOCK)' + NCHAR(13) + NCHAR(10) +
        N'        WHERE ConfigID=1;' + NCHAR(13) + NCHAR(10) +
        N'        IF @@ROWCOUNT <> 1 OR @StartLevel NOT BETWEEN 0 AND 400 OR @StartPoints NOT BETWEEN 0 AND 100000000' + NCHAR(13) + NCHAR(10) +
        N'           OR @StartZen NOT BETWEEN 0 AND 2000000000 OR @StartReset NOT BETWEEN 0 AND 1000000' + NCHAR(13) + NCHAR(10) +
        N'           OR @MasterLevel NOT BETWEEN 0 AND 400 OR @MasterPoints NOT BETWEEN 0 AND 400' + NCHAR(13) + NCHAR(10) +
        N'           OR @WCoinC < 0 OR @WCoinP < 0 OR @GoblinPoint < 0' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN' + NCHAR(13) + NCHAR(10) +
        N'            ROLLBACK TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'            SELECT CAST(2 AS tinyint) AS Result;' + NCHAR(13) + NCHAR(10) +
        N'            RETURN;' + NCHAR(13) + NCHAR(10) +
        N'        END' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        IF EXISTS (SELECT 1 FROM dbo.[Character] WITH (UPDLOCK, HOLDLOCK)' + NCHAR(13) + NCHAR(10) +
        N'                   WHERE [Name] = @Name)' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN' + NCHAR(13) + NCHAR(10) +
        N'            SET @Result = 0;' + NCHAR(13) + NCHAR(10) +
        N'            ROLLBACK TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'            SELECT @Result AS Result;' + NCHAR(13) + NCHAR(10) +
        N'            RETURN;' + NCHAR(13) + NCHAR(10) +
        N'        END' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        IF NOT EXISTS (SELECT 1 FROM dbo.DefaultClassType WHERE [Class] = @Class)' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN' + NCHAR(13) + NCHAR(10) +
        N'            ROLLBACK TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'            SELECT CAST(2 AS tinyint) AS Result;' + NCHAR(13) + NCHAR(10) +
        N'            RETURN;' + NCHAR(13) + NCHAR(10) +
        N'        END' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        IF NOT EXISTS (SELECT 1 FROM dbo.AccountCharacter WITH (UPDLOCK, HOLDLOCK)' + NCHAR(13) + NCHAR(10) +
        N'                       WHERE [Id] = @AccountID)' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN' + NCHAR(13) + NCHAR(10) +
        N'            INSERT INTO dbo.AccountCharacter' + NCHAR(13) + NCHAR(10) +
        N'                ([Id], GameID1, GameID2, GameID3, GameID4, GameID5, GameIDC)' + NCHAR(13) + NCHAR(10) +
        N'            VALUES (@AccountID, @Name, NULL, NULL, NULL, NULL, NULL);' + NCHAR(13) + NCHAR(10) +
        N'        END' + NCHAR(13) + NCHAR(10) +
        N'        ELSE' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN' + NCHAR(13) + NCHAR(10) +
        N'            SELECT @Slot = CASE' + NCHAR(13) + NCHAR(10) +
        N'                WHEN GameID1 IS NULL OR LEN(GameID1) = 0 THEN 1' + NCHAR(13) + NCHAR(10) +
        N'                WHEN GameID2 IS NULL OR LEN(GameID2) = 0 THEN 2' + NCHAR(13) + NCHAR(10) +
        N'                WHEN GameID3 IS NULL OR LEN(GameID3) = 0 THEN 3' + NCHAR(13) + NCHAR(10) +
        N'                WHEN GameID4 IS NULL OR LEN(GameID4) = 0 THEN 4' + NCHAR(13) + NCHAR(10) +
        N'                WHEN GameID5 IS NULL OR LEN(GameID5) = 0 THEN 5' + NCHAR(13) + NCHAR(10) +
        N'                ELSE 0 END' + NCHAR(13) + NCHAR(10) +
        N'            FROM dbo.AccountCharacter WITH (UPDLOCK, HOLDLOCK)' + NCHAR(13) + NCHAR(10) +
        N'            WHERE [Id] = @AccountID;' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'            IF @Slot = 0' + NCHAR(13) + NCHAR(10) +
        N'            BEGIN' + NCHAR(13) + NCHAR(10) +
        N'                ROLLBACK TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'                SELECT CAST(3 AS tinyint) AS Result;' + NCHAR(13) + NCHAR(10) +
        N'                RETURN;' + NCHAR(13) + NCHAR(10) +
        N'            END' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'            UPDATE dbo.AccountCharacter' + NCHAR(13) + NCHAR(10) +
        N'            SET GameID1 = CASE WHEN @Slot = 1 THEN @Name ELSE GameID1 END,' + NCHAR(13) + NCHAR(10) +
        N'                GameID2 = CASE WHEN @Slot = 2 THEN @Name ELSE GameID2 END,' + NCHAR(13) + NCHAR(10) +
        N'                GameID3 = CASE WHEN @Slot = 3 THEN @Name ELSE GameID3 END,' + NCHAR(13) + NCHAR(10) +
        N'                GameID4 = CASE WHEN @Slot = 4 THEN @Name ELSE GameID4 END,' + NCHAR(13) + NCHAR(10) +
        N'                GameID5 = CASE WHEN @Slot = 5 THEN @Name ELSE GameID5 END' + NCHAR(13) + NCHAR(10) +
        N'            WHERE [Id] = @AccountID;' + NCHAR(13) + NCHAR(10) +
        N'        END' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        /* Prevent a reused character name inheriting orphan master data. */' + NCHAR(13) + NCHAR(10) +
        N'        IF EXISTS (SELECT 1 FROM dbo.MasterSkillTree WITH (UPDLOCK, HOLDLOCK)' + NCHAR(13) + NCHAR(10) +
        N'                   WHERE [Name] = @Name)' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN' + NCHAR(13) + NCHAR(10) +
        N'            ROLLBACK TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'            SELECT CAST(2 AS tinyint) AS Result;' + NCHAR(13) + NCHAR(10) +
        N'            RETURN;' + NCHAR(13) + NCHAR(10) +
        N'        END' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        INSERT INTO dbo.[Character]' + NCHAR(13) + NCHAR(10) +
        N'        (' + NCHAR(13) + NCHAR(10) +
        N'            AccountID, [Name], cLevel, LevelUpPoint, [Class],' + NCHAR(13) + NCHAR(10) +
        N'            Experience, Strength, Dexterity, Vitality, Energy, Leadership,' + NCHAR(13) + NCHAR(10) +
        N'            Inventory, MagicList, Money, Life, MaxLife, Mana, MaxMana,' + NCHAR(13) + NCHAR(10) +
        N'            BP, MaxBP, Shield, MaxShield, MapNumber, MapPosX, MapPosY,' + NCHAR(13) + NCHAR(10) +
        N'            PkLevel, MDate, LDate, DbVersion, Quest,' + NCHAR(13) + NCHAR(10) +
        N'            ResetCount, MasterResetCount, EffectList' + NCHAR(13) + NCHAR(10) +
        N'        )' + NCHAR(13) + NCHAR(10) +
        N'        SELECT TOP (1)' + NCHAR(13) + NCHAR(10) +
        N'            @AccountID, @Name, @StartLevel, @StartPoints, @Class,' + NCHAR(13) + NCHAR(10) +
        N'            0, Strength, Dexterity, Vitality, Energy, Leadership,' + NCHAR(13) + NCHAR(10) +
        N'            Inventory, MagicList, @StartZen,' + NCHAR(13) + NCHAR(10) +
        N'            Life, MaxLife, Mana, MaxMana,' + NCHAR(13) + NCHAR(10) +
        N'            0, 0, 0, 0, MapNumber, MapPosX, MapPosY,' + NCHAR(13) + NCHAR(10) +
        N'            3, GETDATE(), GETDATE(), DbVersion, Quest,' + NCHAR(13) + NCHAR(10) +
        N'            @StartReset, 0, EffectList' + NCHAR(13) + NCHAR(10) +
        N'        FROM dbo.DefaultClassType' + NCHAR(13) + NCHAR(10) +
        N'        WHERE [Class] = @Class;' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        SET @Rows = @@ROWCOUNT;' + NCHAR(13) + NCHAR(10) +
        N'        IF @Rows <> 1' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN' + NCHAR(13) + NCHAR(10) +
        N'            ROLLBACK TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'            SELECT CAST(2 AS tinyint) AS Result;' + NCHAR(13) + NCHAR(10) +
        N'            RETURN;' + NCHAR(13) + NCHAR(10) +
        N'        END' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        /* Currency balances are account-wide; add the configured gift without replacing the existing balance. */' + NCHAR(13) + NCHAR(10) +
        N'        SELECT @CashShopRows=COUNT(*)' + NCHAR(13) + NCHAR(10) +
        N'        FROM dbo.CashShopData WITH (UPDLOCK, HOLDLOCK)' + NCHAR(13) + NCHAR(10) +
        N'        WHERE AccountID=@AccountID;' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        IF @CashShopRows = 0' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN' + NCHAR(13) + NCHAR(10) +
        N'            INSERT INTO dbo.CashShopData (AccountID, WCoinC, WCoinP, GoblinPoint)' + NCHAR(13) + NCHAR(10) +
        N'            VALUES (@AccountID, @WCoinC, @WCoinP, @GoblinPoint);' + NCHAR(13) + NCHAR(10) +
        N'        END' + NCHAR(13) + NCHAR(10) +
        N'        ELSE IF @CashShopRows = 1' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN' + NCHAR(13) + NCHAR(10) +
        N'            UPDATE dbo.CashShopData' + NCHAR(13) + NCHAR(10) +
        N'            SET WCoinC=ISNULL(WCoinC, 0)+@WCoinC,' + NCHAR(13) + NCHAR(10) +
        N'                WCoinP=ISNULL(WCoinP, 0)+@WCoinP,' + NCHAR(13) + NCHAR(10) +
        N'                GoblinPoint=ISNULL(GoblinPoint, 0)+@GoblinPoint' + NCHAR(13) + NCHAR(10) +
        N'            WHERE AccountID=@AccountID;' + NCHAR(13) + NCHAR(10) +
        N'            SET @Rows=@@ROWCOUNT;' + NCHAR(13) + NCHAR(10) +
        N'            IF @Rows <> 1' + NCHAR(13) + NCHAR(10) +
        N'            BEGIN' + NCHAR(13) + NCHAR(10) +
        N'                ROLLBACK TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'                SELECT CAST(2 AS tinyint) AS Result;' + NCHAR(13) + NCHAR(10) +
        N'                RETURN;' + NCHAR(13) + NCHAR(10) +
        N'            END' + NCHAR(13) + NCHAR(10) +
        N'        END' + NCHAR(13) + NCHAR(10) +
        N'        ELSE' + NCHAR(13) + NCHAR(10) +
        N'        BEGIN' + NCHAR(13) + NCHAR(10) +
        N'            ROLLBACK TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'            SELECT CAST(2 AS tinyint) AS Result;' + NCHAR(13) + NCHAR(10) +
        N'            RETURN;' + NCHAR(13) + NCHAR(10) +
        N'        END' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        INSERT INTO dbo.MasterSkillTree' + NCHAR(13) + NCHAR(10) +
        N'            ([Name], MasterLevel, MasterPoint, MasterExperience)' + NCHAR(13) + NCHAR(10) +
        N'        VALUES (@Name, @MasterLevel, @MasterPoints, 0);' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'        COMMIT TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'        SET @Result = 1;' + NCHAR(13) + NCHAR(10) +
        N'    END TRY' + NCHAR(13) + NCHAR(10) +
        N'    BEGIN CATCH' + NCHAR(13) + NCHAR(10) +
        N'        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;' + NCHAR(13) + NCHAR(10) +
        N'        SET @Result = 2;' + NCHAR(13) + NCHAR(10) +
        N'    END CATCH' + NCHAR(13) + NCHAR(10) +
        N'' + NCHAR(13) + NCHAR(10) +
        N'    SELECT @Result AS Result;' + NCHAR(13) + NCHAR(10) +
        N'END';
    EXEC sys.sp_executesql @AlterScript;
    COMMIT TRANSACTION;
    PRINT 'MUSVEN global character defaults installed. No character rows were created or changed.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    DECLARE @MigrationError nvarchar(4000), @MigrationSeverity int, @MigrationState int;
    SELECT @MigrationError=ERROR_MESSAGE(), @MigrationSeverity=ERROR_SEVERITY(), @MigrationState=ERROR_STATE();
    RAISERROR(@MigrationError, @MigrationSeverity, @MigrationState);
    RETURN;
END CATCH;
