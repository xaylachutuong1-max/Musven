USE [Muonline];
SET NOCOUNT ON;

/* Read-only verification of the V03 character-creation contract. */
SELECT @@SERVERNAME AS ServerName, DB_NAME() AS DatabaseName,
       CASE WHEN OBJECT_DEFINITION(OBJECT_ID(N'dbo.WZ_CreateCharacter')) LIKE N'%MU SVEN CHARACTER DEFAULTS V03%'
            THEN N'V03' ELSE N'NOT V03 / NOT VISIBLE' END AS ProcedureVersion,
       OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults', N'U') AS DefaultsTableObjectId;

SELECT p.parameter_id, p.name AS ParameterName, ty.name AS TypeName,
       p.max_length AS MaxLengthBytes, p.is_output AS IsOutput
FROM sys.parameters AS p
JOIN sys.types AS ty ON ty.user_type_id=p.user_type_id
WHERE p.object_id=OBJECT_ID(N'dbo.WZ_CreateCharacter') AND p.parameter_id>0
ORDER BY p.parameter_id;

SELECT c.column_id, c.name AS ColumnName, ty.name AS TypeName,
       c.max_length AS MaxLengthBytes, c.is_nullable AS IsNullable, c.is_identity AS IsIdentity
FROM sys.columns AS c
JOIN sys.types AS ty ON ty.user_type_id=c.user_type_id
WHERE c.object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults')
ORDER BY c.column_id;

SELECT k.name AS ConstraintName, k.type_desc AS ConstraintType, c.name AS KeyColumn
FROM sys.key_constraints AS k
LEFT JOIN sys.index_columns AS ic ON ic.object_id=k.parent_object_id AND ic.index_id=k.unique_index_id AND ic.key_ordinal=1
LEFT JOIN sys.columns AS c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
WHERE k.parent_object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults')
UNION ALL
SELECT cc.name, N'CHECK', cc.definition
FROM sys.check_constraints AS cc
WHERE cc.parent_object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults')
UNION ALL
SELECT dc.name, N'DEFAULT', dc.definition
FROM sys.default_constraints AS dc
WHERE dc.parent_object_id=OBJECT_ID(N'dbo.MUSVEN_CharacterCreateDefaults');

SELECT ConfigID, StartLevel, StartPoints, StartZen, StartReset,
       MasterLevel, MasterPoints, WCoinC, WCoinP, GoblinPoint, ModifiedAt
FROM dbo.MUSVEN_CharacterCreateDefaults
ORDER BY ConfigID;
