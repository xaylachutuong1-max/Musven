# MU SVEN 09Q — chức năng và trạng thái

## Chia mục giao diện

| Tab | Nhóm chức năng | Đang dùng được | Trạng thái phần còn lại |
| --- | --- | --- | --- |
| **Tài khoản** | Tìm và chọn tài khoản; tạo account không mật khẩu; xem nhân vật liên quan; xem trạng thái online; sửa tên/email; khóa tạm thời; gỡ khóa hết hạn; cấp thành viên | Tạo account bằng mật khẩu trống với cờ riêng, schema/ID trùng, transaction và hậu kiểm; sửa `memb_name`/`mail_addr` qua snapshot, offline gate, schema check, transaction và hậu kiểm; khóa bằng `bloc_code`/`bloc_expire`; gỡ qua `WZ_DesblocAccount`; cấp/hạn thành viên qua `WZ_SetAccountLevel` đã xác minh | Xóa tài khoản, đổi ID và đặt/đổi mật khẩu vẫn chưa có hợp đồng đầy đủ; login với password trống tùy cấu hình xác thực GameServer |
| **Nhân vật** | Tìm, xem, cấu hình quà mặc định lúc tạo trong game, sửa trường số, túi, số đếm nhiệm vụ, đổi tên và xóa | Form cấu hình toàn server; sửa trường số; đổi tên qua `WZ_RenameCharacter`; editor túi sửa item tại chỗ; editor nhiệm vụ chỉ cập nhật `QuestKillCount.KillCount1..5`, giữ nguyên QuestIndex/MonsterClass, offline, snapshot/transaction/hậu kiểm; xóa qua `WZ_DeleteCharacter` | Kỹ năng, blob QuestWorld/event và chuyển tài khoản chưa có quy tắc được xác minh |
| **Vật phẩm** | Tìm item theo nhóm/tên, tính và sao chép mã | Danh mục tên/kích thước từ `Item.xml` server; tự điền Type/ID/ItemIndex; tính thủ công vẫn có | Chỉnh trang bị trực tiếp trong nhân vật chưa bật; tạo đồ vào kho nằm ở tab Kho đồ |
| **Kho đồ** | Ngân hàng ngọc, tiền WCoin/Goblin, kho chính/kho mở rộng, tạo vật phẩm; sửa item bằng menu chuột phải | Đọc/sửa có điều kiện số dư `CashShopData` + `DATDAT_BANK`; tải 240 ô × 16 byte; danh mục/kích cỡ vật phẩm từ `Item.xml` server; thêm nhiều vật phẩm vào ô trống; sửa item hiện có giữ nguyên vị trí và serial | Ghi kho và tiền/ngọc dùng hai cờ riêng; yêu cầu tài khoản offline, dòng dữ liệu có sẵn, so sánh snapshot và quyền SQL riêng. Thêm mới không được đè ô đang có; sửa phải khớp item index và kích cỡ blob |
| **Quản lý** | Tài khoản, nhân vật, tiền/ngọc, xếp hạng, sự kiện, máy chủ, thành viên/VIP | Tra cứu tài khoản/nhân vật/tiền-ngọc; tạo account password trống có schema/transaction/hậu kiểm; khóa tạm thời, gỡ khóa hết hạn, cấp thành viên; duyệt ranking/event; reset riêng bảng Ranking* theo whitelist; sửa bộ đếm quái trong `QuestKillCount` | Chưa có ghi trạng thái QuestWorld/event; giao thức Kick/broadcast và điều khiển server; xóa/đổi ID và đặt/đổi mật khẩu tài khoản. |
| **Công cụ** | ItemIndex, backup SQL, xóa trắng dữ liệu, bảo trì file | ItemIndex chạy tại máy; backup thủ công qua form hiện có (có thể mở từ tab Gothic); reset dữ liệu có preview, backup+VERIFYONLY, transaction, xác minh 56 bảng và khôi phục MULTI_USER | Backup tự động và shrink file/log chưa bật |
| **Cài đặt** | Cấu hình kết nối, cờ ghi và schema hiện hành | Tạo/mở Config.ini; kiểm tra kết nối; kiểm kê bảng/cột, kiểu/độ dài, IDENTITY, chữ ký và marker procedure ở chế độ chỉ đọc | Quyền SQL phải được quản trị viên cấp riêng; schema audit không tự tạo DDL; profile VM bật reset riêng nhưng vẫn cần đủ điều kiện/xác nhận; shrink file/log vẫn khóa |

Trang **Cài đặt → Kiểm tra schema Musven** kiểm tra các cột thực tế của chức năng hiện có, bao gồm năm bộ đếm `QuestKillCount`, cùng bảng phụ xóa nhân vật; không đọc dòng tài khoản/nhân vật. Procedure create/delete được đối chiếu chữ ký và marker; `WZ_GetItemSerial` được kiểm tra sự tồn tại và không tham số. Bảng xếp hạng được coi là tùy chọn nếu thiếu. Không có DDL tự phát cho các bảng custom chưa được dùng.

## Cách tổ chức và trạng thái an toàn

Mỗi tác vụ được đặt trong tab theo mục đích. Truy vấn dùng tham số; danh sách tài khoản giới hạn 200 dòng; danh sách online đọc từ `MEMB_STAT`; truy vấn nhân vật dò tên cột từ metadata. Luồng tra cứu dùng `ApplicationIntent=ReadOnly`. Gói VM bật riêng các cờ ghi cho các thao tác đã triển khai; mẫu cấu hình source vẫn khóa ghi mặc định. Ghi kho/sửa dữ liệu dùng transaction, kiểm tra trạng thái offline, khóa dòng và so sánh snapshot khi cập nhật. Gỡ khóa hết hạn chỉ gọi procedure đã xác minh, kiểm tra trạng thái offline và giữ nguyên khóa còn hạn. Xóa trắng dữ liệu yêu cầu cờ riêng, đúng schema, backup kiểm tra được và xác nhận gõ lại. Shrink file/log vẫn khóa.

Thông tin trang bị và nhân vật 3D chỉ là hình xem độc lập, không đại diện cho dữ liệu thật trong inventory. Kho dùng 240 ô × 16 byte. Musven giải mã các vật phẩm hiện có bằng cùng quy tắc byte của source server và danh mục `Item.xml`; nếu item không có trong danh mục hoặc kích cỡ blob khác 3840 byte, tính năng ghi bị chặn để tránh đè nhầm.

## Schema Muonline đã được người vận hành xác nhận

- `dbo.DATDAT_BANK`: `AccountID varchar(10)` và các cột `Bless`, `Soul`, `Life`, `Creation`, `Guardian`, `Harmony`, `GemStone`, `Chaos`, `LowStone`, `HighStone` dạng `int`.
- `dbo.ExtWarehouse`: `AccountID varchar(10)`, `Items varbinary(3840)`, `Money int`, `Number int`.
- `dbo.warehouse`: bảng kho chính số 0; Musven chỉ cập nhật dòng đã tồn tại.
- `dbo.MEMB_STAT.ConnectStat`: kiểm tra tài khoản ngoại tuyến ngay trong giao dịch.
- `dbo.WZ_GetItemSerial`: cấp serial cho item mới; giao dịch bị hủy khi không có serial hợp lệ.
- `dbo.MasterSkillTree`: các trường Master dạng số được Musven cập nhật riêng theo Name; blob `MasterSkill` được giữ nguyên.
- `dbo.QuestKillCount`: Name varchar(10) là khóa; QuestIndex và năm cặp MonsterClass/KillCount là int nullable. MUSVEN chỉ sửa năm KillCount; nếu chưa có dòng thì editor không tạo mới.
- Trước migration, procedure đã rà có marker V02 và tham số `@AccountID varchar(10)`, `@Name varchar(10)`, `@Class tinyint`; migration guarded nâng hợp đồng tạo nhân vật lên V03 và thêm bảng mặc định. `AccountCharacter.Number` là `IDENTITY`; các blob `MagicList`/`Quest`/`EffectList` ở dòng hiện có và bảng class mẫu có độ dài giống nhau. Musven kiểm tra marker/chữ ký lại mỗi lần trước khi gọi.
- `MEMB_INFO` và `dbo.Character` có trong database; Musven xác minh các cột cần đọc khi truy vấn.

Các bảng tùy biến chưa có không được tự tạo. Tên bảng thiếu trong lần kiểm kê trước không đồng nghĩa tính năng cốt lõi cần chúng; muốn bật một mục quản trị phải xác minh bảng, cột, ràng buộc và chính sách sao lưu trước.

Rà soát bổ sung đã tìm được source Titan, source GameServer và SQL schema archived. Hồ sơ account `memb_name`/`mail_addr`, khóa tạm thời, reset ranking và bộ đếm quái `QuestKillCount` đã có hợp đồng riêng. Các phần còn bị giữ khóa là vòng đời account chưa đủ an toàn, blob skill/QuestWorld chưa có catalog/encoding tương thích ghim vào VM, và lệnh server chưa có listener desktop đã xác thực.


Kết quả `pincheck → JoinServer` được người vận hành chạy trong SSMS trên VM. Kết nối trực tiếp từ Musven trên máy chính tới VM chưa được xác minh; cần địa chỉ SQL có thể truy cập và quyền Windows phù hợp. Tra cứu trạng thái tài khoản đọc `dbo.MEMB_STAT` theo schema đã gửi; nếu tài khoản SQL thiếu quyền này, màn hình báo riêng và vẫn giữ luồng tra cứu nhân vật.

## Xóa trắng dữ liệu server

Reset này xóa mọi dòng trong 56 bảng dữ liệu của schema 09Q đã được rà để mở server mới: tài khoản, nhân vật, kho, currency, guild, sự kiện, quest và ranking. Giữ 7 bảng cấu hình (`DefaultClassType`, `GameServerInfo`, `MK_Server`, `MuCastle_DATA`, `MuCastle_NPC`, `WZ_CW_INFO`, `MUSVEN_CharacterCreateDefaults`); `MuCastle_DATA` được trả owner/tax/money/occupancy về mặc định. Không xóa database, không tạo DDL, không shrink file/log.

Cơ chế reset kiểm tra cờ riêng `[MUSVEN_DATA_RESET]`, hiện bật trong gói VM. Cần đúng tên SQL Server `WIN-L1CSPDF707L`, database `Muonline`, SQL Server 10.50.x, 63 bảng sau migration V03, 76 procedures, đúng hai FK, không có trigger bật, đúng seed system, không có session khác và thư mục backup có sẵn trên D:/E: hoặc đúng thư mục VM `C:\MUSVEN_TITAN_BACKUP`. Musven hiển thị số dòng từng bảng; khi chạy, kiểm tra lại snapshot, chuyển database qua SINGLE_USER, tạo COPY_ONLY/CHECKSUM backup và RESTORE VERIFYONLY, rồi xóa theo phụ thuộc FK trong một transaction. Chỉ commit nếu toàn bộ 56 bảng rỗng, bảy bảng cấu hình giữ số dòng cũ và thành trì đã reset; sau đó trả database về MULTI_USER. Nếu kiểm tra backup, schema hoặc xác minh sau xóa thất bại, transaction rollback. Cần SQL quyền đọc catalog/phiên server, ALTER DATABASE, BACKUP DATABASE và DELETE trên các bảng dữ liệu. Dừng game server và đóng kết nối SSMS tới Muonline trước khi chạy.


