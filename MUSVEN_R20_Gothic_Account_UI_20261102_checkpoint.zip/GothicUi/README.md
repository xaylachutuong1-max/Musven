# MUSVEN Gothic Admin UI

The Gothic WebView UI runs inside the existing WinForms application. `api.js` sends RPC messages to `GothicAdminUiForm`; `GothicBackendBridge` routes them through the existing schema-aware C# repositories. There is no preview fixture adapter and the UI does not synthesize account or inventory rows.

## Supported repository workflows

- Account lookup, character listing, and the explicit online refresh use the existing read-only repositories. The online list reads `dbo.MEMB_STAT` where `ConnectStat = 1` and does not infer character or GameServer status.
- The dashboard also opens the existing guarded forms for password-empty account creation, display-name/email editing, temporary account bans, expired-ban removal, and membership changes. Each write has its own config flag and repository checks.
- Character editing loads the numeric fields exposed by the current `CharacterEditorRepository`. Writes require the existing opt-in setting, a user confirmation, an offline account, an unchanged snapshot, and a successful transaction.
- Character rename, delete, inventory-item editing, and `QuestKillCount` editing open their existing guarded native forms. Quest editing changes only `KillCount1..5`; it does not create missing rows.
- Currency and character creation defaults use their existing snapshot/transaction safeguards. Master Level and Master Points are capped at 400.
- Item metadata comes from the embedded server item catalog. Socket and Harmony options come from `ItemAttributeControls`.
- Warehouse placement loads real `warehouse` / `ExtWarehouse` data. New items can be staged only in empty warehouse slots. Existing items can be edited in place without changing ItemIndex or serial. Both paths require the existing item-write setting, confirmation, an offline account, a matching snapshot, and a single transaction.
- SQL backup, the data-reset preview, and ranking/event review open the existing native forms. Backup creates a new COPY_ONLY + CHECKSUM backup and verifies it; reset and ranking writes retain their separate gates and confirmations.

## Implemented and still unavailable

The VM profile enables the character inventory editor for existing 16-byte items and the ranking browser's guarded reset for allowlisted `Ranking*` tables. These use separate write flags and their own repository/form safeguards. Account creation and profile editing are implemented; account deletion, AccountID changes, and non-empty password changes are not.

Character skill editing, QuestWorld/event blob editing, marriage/transfer changes, item-catalog stat persistence, player kick, broadcast, and GameServer/ConnectServer start/stop remain unavailable. The source does not include the required skill catalog/blob encoding, item-definition write target, or authenticated live game-server command protocol. In particular, `WZ_DISCONNECT_MEMB` only updates SQL session fields and is not a real kick. The interface must not report these actions as successful until an executing backend contract exists.

The SQL connection is not opened on UI startup. Read operations begin only after the user selects an operation. SQL writes remain controlled by the existing `[MUSVEN_*]` settings and are not tested by launching this UI.

## Files

- `index.html`: navigation and application shell.
- `styles.css`: Gothic layout, depth effects, and replaceable texture variables.
- `options.js`: stable category labels and presentation colors only.
- `api.js`: correlated WebView2 request/response transport.
- `app.js`: page rendering, ephemeral form state, and supported workflows.
- `../tools/Verify-GothicContracts.ps1`: checks that UI API declarations, backend routes, actual UI calls, and the schema/API contract document stay synchronized.

Set `--texture-frame`, `--texture-panel`, `--texture-inventory`, or `--texture-banner` in `styles.css` to add Photoshop textures. Item thumbnails load from the existing `Assets/ItemImages` directory. The current preview is the catalog thumbnail, not a 3D game model.
