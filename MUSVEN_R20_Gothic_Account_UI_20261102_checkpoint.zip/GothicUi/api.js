/* WebView2 RPC bridge. All data operations are handled by existing C# repositories. */
(function () {
  let nextId = 0;
  const pending = new Map();
  const webview = window.chrome?.webview;
  window.MUSVEN_API_PREVIEW = false;

  if (webview) {
    webview.addEventListener('message', event => {
      const message = event.data;
      if (!message || message.type !== 'api-response') return;
      const request = pending.get(message.id);
      if (!request) return;
      pending.delete(message.id);
      clearTimeout(request.timer);
      if (message.ok) request.resolve(message.result);
      else request.reject(new Error(message.error || 'Yêu cầu không thành công.'));
    });
  }

  function call(method, args = {}) {
    if (!webview) return Promise.reject(new Error('Giao diện này cần chạy bên trong MUSVEN Admin để kết nối nghiệp vụ.'));
    const id = String(++nextId);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error('Hết thời gian chờ MUSVEN. Hãy kiểm tra kết nối ứng dụng rồi thử lại.'));
      }, 30000);
      pending.set(id, { resolve, reject, timer });
      webview.postMessage({ type: 'api-request', id, method, args });
    });
  }

  const methods = [
    'getDashboard', 'searchAccounts', 'listOnlineAccounts', 'loadAccount', 'getItemCatalog', 'getItemOptions',
    'loadCharacterEditor', 'saveCharacterEditor', 'loadCurrency', 'saveCurrency',
    'loadCharacterDefaults', 'saveCharacterDefaults', 'loadInventory', 'saveInventory', 'openWarehouse',
    'openCharacterDelete', 'openCharacterRename', 'openCharacterInventory', 'openCharacterQuestCounts', 'openAccountMembership', 'openAccountProfile', 'openAccountCreate', 'openAccountBan', 'openAccountUnban', 'openRankingView', 'openSqlBackup', 'openDataReset'
  ];
  window.musvenApi = Object.fromEntries(methods.map(method => [method, args => call(method, args)]));
})();
