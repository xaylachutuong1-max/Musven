/* MUSVEN Gothic UI. Values are loaded from the existing C# repositories; drafts stay local until explicitly saved. */
(function () {
  const root = document.getElementById('page-root');
  const modalRoot = document.getElementById('modal-root');
  const serverStrip = document.getElementById('server-strip');
  const dragPreview = document.getElementById('drag-preview');
  const itemContextMenu = document.getElementById('item-context-menu');
  const $ = (selector, parent = document) => parent.querySelector(selector);
  const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const money = value => value == null ? '—' : Number(value).toLocaleString('en-US');
  const colors = window.MUSVEN_OPTIONS.socketColors;
  const state = {
    page: 'dashboard', modal: null, dashboard: null, catalog: [], itemOptions: null,
    accountSearch: '', accounts: [], activeAccount: null, session: null, characters: [],
    selectedCharacter: null, characterEditor: null, characterEditorLoading: false, characterEditorError: '',
    currency: null, defaults: null, onlineAccounts: [], onlineLoaded: false,
    itemSearch: '', itemCategory: 'all', selectedItem: null, itemForm: emptyItemForm(),
    locations: [], warehouse: null, warehouseWriteEnabled: false, warehouseNumber: 0, warehouseExtended: false,
    stagedItems: [], selectedSlot: null, selectedDraft: null, editingSlot: null, editingDraftId: null, onlineSearch: ''
  };

  function emptyItemForm() {
    return { level: 0, optionValue: 0, durability: 255, skill: false, luck: false, setOption: 0,
      excellent: Array(6).fill(false), sockets: Array(5).fill(255), socketLevels: Array(5).fill(1), socketRawOverrides: Array(5).fill(null), harmonyId: 0, harmonyLevel: 0 };
  }
  function selectedAccountId() { return state.activeAccount?.accountId || ''; }
  function itemById(id) { return state.catalog.find(item => Number(item.id) === Number(id)) || null; }
  function notify(message, tone = 'gold') {
    const region = $('#toast-region'); const toast = document.createElement('div');
    toast.className = `toast ${tone}`; toast.textContent = message; region.append(toast);
    setTimeout(() => toast.remove(), 3800);
  }
  async function api(method, args = {}) {
    try {
      const operation = window.musvenApi?.[method];
      if (typeof operation !== 'function') throw new Error(`API MUSVEN chưa khai báo hợp đồng '${method}'.`);
      return await operation(args);
    }
    catch (error) { notify(error.message || 'Không gọi được nghiệp vụ MUSVEN.', 'red'); throw error; }
  }
  function panel(title, body, extra = '') {
    return `<section class="gothic-panel ${extra}"><div class="panel-title"><span>${esc(title)}</span></div>${body}</section>`;
  }
  function heading(title, subtitle, right = '') {
    return `<div class="page-heading"><div><h1>${esc(title)}</h1><p>${esc(subtitle)}</p></div><div class="page-heading-right">${right}</div></div>`;
  }
  function setPage(page) {
    state.page = page;
    $$('.nav-tab').forEach(tab => tab.classList.toggle('is-active', tab.dataset.page === page));
    if (page === 'character-editor' && selectedAccountId() && state.selectedCharacter &&
        !state.characterEditor && !state.characterEditorLoading && !state.characterEditorError) {
      void loadCharacterEditor();
      return;
    }
    renderPage();
  }
  function renderServers() {
    const configured = Boolean(state.dashboard?.configured);
    const db = state.dashboard?.database || 'Chưa cấu hình';
    const serviceCard = (name, symbol) => `<div class="server-card" data-status="unknown" aria-label="${name}: không thể xác minh vì chưa cấu hình phép kiểm tra dịch vụ" title="Chưa có endpoint/probe đã xác minh cho dịch vụ này"><span class="server-seal" aria-hidden="true">${symbol}</span><div class="server-lines"><span class="server-name">${name}</span><span class="status-pill unknown">KHÔNG THỂ XÁC MINH</span><span class="server-detail">Chưa cấu hình tiến trình, cổng hoặc API kiểm tra</span></div></div>`;
    serverStrip.innerHTML = [
      serviceCard('GameServer', '✹'),
      serviceCard('DataServer', '◈'),
      serviceCard('ConnectServer', '✦'),
      `<div class="server-time"><span>Giờ máy này<br><small>Không phải giờ server</small></span><strong id="server-clock">--:--:--</strong></div>`
    ].join('');
    $('#footer-server').textContent = configured ? `SQL • ${db} • chỉ truy vấn khi yêu cầu` : 'SQL chưa cấu hình';
    $('#footer-mode').textContent = 'Repository C# • không dùng dữ liệu mẫu';
  }
  function renderAccountRows() {
    if (!state.accounts.length) return '<div class="empty-state account-empty">Chưa có kết quả. Nhập AccountID rồi bấm Tìm.</div>';
    return state.accounts.map(row => `<button class="account-result ${state.activeAccount?.accountId === row.accountId ? 'is-selected' : ''}" data-action="load-account" data-account="${esc(row.accountId)}"><strong>${esc(row.accountId)}</strong><span>${esc(row.displayName || '—')}</span></button>`).join('');
  }
  function renderOnlineRows() {
    const query = state.onlineSearch.trim().toLocaleLowerCase();
    const matches = state.onlineAccounts.filter(row =>
      !query || [row.accountId, row.serverName, row.connectTime, row.onlineHours]
        .some(value => String(value ?? '').toLocaleLowerCase().includes(query)));
    const rows = matches.map(row => `<tr><td><span class="online-dot">●</span> ${esc(row.accountId)}</td><td>${esc(row.serverName || '—')}</td><td>${esc(row.connectTime ? new Date(row.connectTime).toLocaleString('vi-VN') : '—')}</td><td>${row.onlineHours == null ? '—' : `${esc(row.onlineHours)} giờ`}</td></tr>`).join('');
    if (rows) return rows;
    const message = state.onlineLoaded
      ? (query ? 'Không tìm thấy tài khoản online phù hợp.' : 'Không có tài khoản online theo MEMB_STAT.')
      : state.dashboard?.configured ? 'Bấm tải lại để đọc danh sách online.' : 'SQL chưa được cấu hình.';
    return `<tr><td colspan="4" class="empty-state">${message}</td></tr>`;
  }
  function renderDashboard() {
    const account = state.activeAccount;
    const chars = state.characters;
    const accountInfo = account ? `
      <div class="panel-body account-fields">
        <label class="field-label"><span>Account ID</span><input class="inset-field" readonly value="${esc(account.accountId)}"></label>
        <label class="field-label"><span>Tên hiển thị</span><input class="inset-field" readonly value="${esc(account.displayName || '—')}"></label>
        <label class="field-label"><span>Trạng thái phiên</span><input class="inset-field" readonly value="${esc(state.session?.statusText || 'Chưa có trạng thái')}"></label>
        <div class="account-session-note">${esc(state.session?.detailText || 'MEMB_STAT không trả thông tin phiên cho tài khoản này.')}</div>
        <div class="toolbar account-actions"><button class="action-btn" data-action="open-account-profile" ${account ? '' : 'disabled'} title="Chỉ sửa tên hiển thị và email; mật khẩu giữ nguyên">✎ Sửa tên / email</button><button class="action-btn" data-action="open-currency">◉ Tiền / ngọc</button><button class="action-btn" data-action="open-membership" ${state.dashboard?.accountLevelEnabled ? '' : 'disabled'} title="Dùng procedure WZ_SetAccountLevel đã xác minh">♜ Cấp thành viên</button><button class="action-btn" data-action="open-inventory">▦ Mở kho đồ</button><button class="action-btn" data-action="edit-character" ${chars.length ? '' : 'disabled'}>✧ Sửa nhân vật</button><button class="action-btn" data-action="open-character-inventory" ${state.dashboard?.characterInventoryEnabled && state.selectedCharacter ? '' : 'disabled'} title="Sửa thuộc tính vật phẩm hiện có trong Character.Inventory">♙ Túi nhân vật</button><button class="action-btn red" data-action="ban-account" ${state.dashboard?.accountBanEnabled ? '' : 'disabled'} title="Khóa tài khoản đến giờ đã chọn; yêu cầu offline và xác nhận">⛔ Khóa tài khoản</button><button class="action-btn red" data-action="unban-expired" ${state.dashboard?.accountModerationEnabled ? '' : 'disabled'} title="Chỉ gỡ bloc đã hết hạn; yêu cầu offline và xác nhận">♧ Gỡ khóa hết hạn</button></div>
      </div>` : `<div class="panel-body no-account"><strong>${state.dashboard?.configured ? 'Chưa chọn tài khoản' : 'Chưa cấu hình kết nối SQL'}</strong><span>${state.dashboard?.configured ? 'Tìm AccountID để đọc thông tin và nhân vật từ database.' : 'Giao diện sẽ không tự tạo dữ liệu mẫu. Cần MUSVEN_READ_ONLY trong Config.ini.'}</span></div>`;
    const charRows = chars.length ? chars.map((character, index) => `<tr class="${state.selectedCharacter?.name === character.name ? 'is-selected' : ''}" data-action="select-character" data-index="${index}" tabindex="0" aria-label="Chọn nhân vật ${esc(character.name)}, cấp ${esc(character.level ?? 'không rõ')}, reset ${esc(character.resetCount ?? 'không rõ')}"><td>${esc(character.name)}</td><td>${esc(character.level ?? '—')}</td><td>${esc(character.resetCount ?? '—')}</td><td>${esc(character.zen == null ? '—' : money(character.zen))}</td><td><button class="icon-btn" data-action="edit-character-row" data-name="${esc(character.name)}" title="Chỉnh sửa" aria-label="Chỉnh sửa ${esc(character.name)}">✎</button></td><td><button class="icon-btn" data-action="rename-character" data-name="${esc(character.name)}" title="Đổi tên bằng WZ_RenameCharacter" aria-label="Đổi tên ${esc(character.name)}" ${state.dashboard?.characterRenameEnabled ? '' : 'disabled'}>↻</button></td><td><button class="icon-btn" data-action="open-character-quest-counts" data-name="${esc(character.name)}" title="Số đếm quái nhiệm vụ • chỉ sửa KillCount" aria-label="Mở số đếm nhiệm vụ của ${esc(character.name)}" ${state.dashboard?.characterQuestCountsEnabled ? '' : 'disabled'}>⚑</button></td><td><button class="icon-btn danger" data-action="delete-character" data-name="${esc(character.name)}" title="Xóa • yêu cầu offline và xác nhận lần cuối" aria-label="Xóa ${esc(character.name)}" ${state.dashboard?.characterDeletionEnabled ? '' : 'disabled'}>⌫</button></td></tr>`).join('') : `<tr><td colspan="8" class="empty-state">${account ? 'Tài khoản chưa có nhân vật hoặc chưa đọc được danh sách.' : 'Chọn tài khoản để đọc nhân vật.'}</td></tr>`;
    const charPanel = `<div class="panel-body" style="display:flex;flex-direction:column;min-height:0"><div class="table-scroll"><table class="character-table"><thead><tr><th scope="col">TÊN</th><th scope="col">LEVEL</th><th scope="col">RESET</th><th scope="col">ZEN</th><th scope="col" aria-label="Chỉnh sửa"></th><th scope="col" aria-label="Đổi tên"></th><th scope="col" aria-label="Nhiệm vụ"></th><th scope="col" aria-label="Xóa"></th></tr></thead><tbody>${charRows}</tbody></table></div><div class="panel-foot"><span>${chars.length} nhân vật • dữ liệu từ dbo.Character</span><span><button class="action-btn" data-action="open-character-defaults" aria-label="Cấu hình quà mặc định cho nhân vật mới" ${state.dashboard?.configured ? '' : 'disabled'}>✧ Mặc định tạo NV</button></span></div></div>`;
    const online = `<div class="panel-body" style="display:flex;flex-direction:column;min-height:0"><div class="online-search"><input class="inset-field" type="search" placeholder="Tìm tài khoản online…" aria-label="Tìm tài khoản online" data-bind="onlineSearch" value="${esc(state.onlineSearch)}" ${state.onlineLoaded ? '' : 'disabled'}><button class="icon-btn" data-action="load-online" aria-label="Tải lại danh sách tài khoản online" ${state.dashboard?.configured ? '' : 'disabled'} title="Tải lại từ dbo.MEMB_STAT">⟳</button></div><div class="online-source">Nguồn: dbo.MEMB_STAT • ConnectStat = 1</div><div class="online-table-wrap"><table class="online-table"><thead><tr><th scope="col">ACCOUNT</th><th scope="col">SERVER</th><th scope="col">KẾT NỐI</th><th scope="col">ONLINE</th></tr></thead><tbody>${renderOnlineRows()}</tbody></table></div><div class="panel-foot"><span>${state.onlineLoaded ? `${state.onlineAccounts.length} phiên online • tối đa 200` : 'Chưa tải danh sách'}</span></div></div>`;
    const hasAccount = Boolean(account);
    const selected = state.selectedCharacter;
    const selectedName = selected ? ` data-name="${esc(selected.name)}"` : '';
    const advancedTiles = [
      { tone: 'red', action: 'open-character-defaults', icon: '✧', title: 'Mặc định tạo NV', detail: 'Quà cho nhân vật mới', enabled: Boolean(state.dashboard?.configured) },
      { tone: 'gold', action: 'open-currency', icon: '◉', title: 'Tiền / ngọc', detail: 'Số dư tài khoản', enabled: hasAccount && Boolean(state.dashboard?.configured) },
      { tone: 'blue', action: 'open-inventory', icon: '▦', title: 'Kho tài khoản', detail: 'Kho và vật phẩm', enabled: hasAccount && Boolean(state.dashboard?.configured) },
      { tone: 'violet', page: 'item-editor', icon: '⚔', title: 'Danh mục item', detail: 'Catalog server • chỉ đọc', enabled: true },
      { tone: 'blue', action: 'open-sql-backup', icon: '▤', title: 'Sao lưu SQL', detail: 'Mở trình backup', enabled: Boolean(state.dashboard?.configured) },
      { tone: 'violet', action: 'open-ranking-view', icon: '♜', title: 'Xếp hạng / event', detail: 'Duyệt dữ liệu thật', enabled: Boolean(state.dashboard?.configured) },
      { tone: 'gold', action: 'open-account-profile', icon: '♙', title: 'Sửa hồ sơ', detail: 'Tên hiển thị / email', enabled: hasAccount },
      { tone: 'blue', action: 'open-membership', icon: '♛', title: 'Cấp thành viên', detail: 'Cấp account', enabled: hasAccount && Boolean(state.dashboard?.accountLevelEnabled) },
      { tone: 'red', action: 'edit-character', icon: '✎', title: 'Sửa nhân vật', detail: selected ? selected.name : 'Chọn nhân vật trước', enabled: Boolean(selected) },
      { tone: 'blue', action: 'open-character-inventory', icon: '♙', title: 'Túi nhân vật', detail: 'Sửa thuộc tính item', enabled: Boolean(selected && state.dashboard?.characterInventoryEnabled), name: selectedName },
      { tone: 'violet', action: 'rename-character', icon: '↻', title: 'Đổi tên nhân vật', detail: 'Yêu cầu nhân vật offline', enabled: Boolean(selected && state.dashboard?.characterRenameEnabled), name: selectedName },
      { tone: 'gold', action: 'open-character-quest-counts', icon: '⚑', title: 'Bộ đếm nhiệm vụ', detail: 'KillCount1–5', enabled: Boolean(selected && state.dashboard?.characterQuestCountsEnabled), name: selectedName },
      { tone: 'red', action: 'delete-character', icon: '⌫', title: 'Xóa nhân vật', detail: 'Có xác nhận cuối', enabled: Boolean(selected && state.dashboard?.characterDeletionEnabled), name: selectedName },
      { tone: 'red', action: 'ban-account', icon: '⛔', title: 'Khóa tài khoản', detail: 'Theo thời hạn', enabled: Boolean(hasAccount && state.dashboard?.accountBanEnabled) },
      { tone: 'green', action: 'unban-expired', icon: '♧', title: 'Gỡ khóa hết hạn', detail: 'Chỉ gỡ khóa đã hết hạn', enabled: Boolean(hasAccount && state.dashboard?.accountModerationEnabled) }
    ];
    const advancedContent = `<div class="advanced-grid">${advancedTiles.map(tile => `<button class="advanced-tile" data-tone="${tile.tone}" ${tile.page ? `data-page="${tile.page}"` : `data-action="${tile.action}"`}${tile.name || ''} ${tile.enabled ? '' : 'disabled'} title="${esc(tile.detail)}"><span class="tile-gem" aria-hidden="true">${tile.icon}</span><span class="tile-copy"><strong>${esc(tile.title)}</strong><small>${esc(tile.detail)}</small></span></button>`).join('')}</div>`;
    root.innerHTML = `${heading('DASHBOARD • QUẢN LÝ TÀI KHOẢN', 'Dữ liệu thực từ repository hiện có • thao tác ghi có kiểm tra riêng')}
      <div class="dashboard-grid live-dashboard">
        <aside class="side-rail"><div class="rail-label">MỤC QUẢN TRỊ</div><button class="rail-button is-active" data-page="dashboard"><span>♟</span>Tài khoản</button><button class="rail-button" data-page="character-editor"><span>♙</span>Chỉnh sửa nhân vật</button><button class="rail-button" data-page="item-editor"><span>⚔</span>Danh mục vật phẩm</button><button class="rail-button" data-page="inventory"><span>▦</span>Kho đồ</button><button class="rail-button" data-page="server-tools"><span>⚙</span>Cấu hình / công cụ</button><div class="rail-spacer"></div><div class="rail-brand">MU SVEN<br><small>ADMIN • 09Q</small></div></aside>
        <div class="account-panel">
          ${panel('TÌM TÀI KHOẢN', `<div class="panel-body"><div class="search-row"><input class="inset-field" placeholder="AccountID hoặc tiền tố…" aria-label="Tìm tài khoản theo AccountID hoặc tiền tố" data-bind="accountSearch" value="${esc(state.accountSearch)}" ${state.dashboard?.configured ? '' : 'disabled'}><button class="action-btn blue" data-action="search-accounts" aria-label="Tìm tài khoản" ${state.dashboard?.configured ? '' : 'disabled'}>Tìm</button><button class="action-btn green" data-action="create-account" aria-label="Tạo tài khoản" ${state.dashboard?.accountCreateEnabled ? '' : 'disabled'}>＋ Tạo</button></div><div class="account-results">${renderAccountRows()}</div></div>`, 'account-search-panel')}
          ${panel('ACCOUNT INFORMATION', accountInfo)}
          ${panel(`CHARACTERS (${chars.length})`, charPanel, 'character-list-panel')}
        </div>
        <div class="advanced-panel">${panel('TÁC VỤ QUẢN TRỊ • ROUTE BACKEND CÓ SẴN', advancedContent)}</div>
        <div class="online-column">${panel('TRẠNG THÁI ONLINE', online, 'online-table-panel')}${panel('QUICK TOOLS', `<div class="quick-tools"><p class="muted">Danh sách online và backup SQL đã nối. Kick, gửi thông báo và điều khiển GameServer chưa có giao thức backend đã xác minh.</p><button class="action-btn ${state.dashboard?.backupEnabled ? 'green' : ''}" data-action="open-sql-backup" ${state.dashboard?.configured ? '' : 'disabled'}>▣ Mở sao lưu SQL</button><button class="action-btn" data-action="close-ui">Đóng giao diện Gothic</button></div>`)}</div>
      </div>`;
  }
  function renderCharacterEditor() {
    const character = state.characterEditor;
    const accountId = selectedAccountId();
    if (!accountId || !state.selectedCharacter) {
      root.innerHTML = `${heading('CHỈNH SỬA NHÂN VẬT', 'Chọn tài khoản và nhân vật trước khi tải các trường từ database.')}${panel('CHƯA CHỌN NHÂN VẬT', `<div class="panel-body no-account"><strong>Chưa có nhân vật được chọn</strong><span>Quay về Tài khoản, tìm AccountID, chọn nhân vật rồi bấm Sửa.</span><button class="action-btn" data-page="dashboard">← Tài khoản</button></div>`)}`;
      return;
    }
    if (!character) {
      const loading = state.characterEditorLoading;
      const title = loading ? 'ĐANG TẢI' : state.characterEditorError ? 'KHÔNG TẢI ĐƯỢC DỮ LIỆU' : 'CHƯA TẢI DỮ LIỆU';
      const detail = loading
        ? 'Đọc schema và giá trị hiện tại từ dbo.Character / dbo.MasterSkillTree…'
        : state.characterEditorError
          ? `${esc(state.characterEditorError)}<button class="action-btn" data-action="edit-character">↻ Thử lại</button>`
          : 'Bấm tải dữ liệu nhân vật để xem các trường được hỗ trợ.';
      root.innerHTML = `${heading('CHỈNH SỬA NHÂN VẬT', `${accountId} • ${state.selectedCharacter.name}`)}${panel(title, `<div class="panel-body no-account">${detail}</div>`)}`;
      return;
    }
    const fields = character.fields || [];
    const groups = [
      ['Thông tin nhân vật', fields.filter(f => !String(f.tableName).toLowerCase().includes('master'))],
      ['Master Skill Tree', fields.filter(f => String(f.tableName).toLowerCase().includes('master'))]
    ].filter(([, entries]) => entries.length);
    const groupHtml = groups.map(([title, entries]) => panel(title.toUpperCase(), `<div class="character-fields">${entries.map(field => `<label class="field-label"><span>${esc(field.label)} <small>${esc(field.columnName)}</small></span><input class="inset-field character-value" type="number" step="any" data-character-key="${esc(field.key)}" value="${field.value == null ? '' : esc(field.value)}" min="${esc(field.minimum)}" max="${esc(field.maximum)}" ${character.writeEnabled && field.value != null ? '' : 'disabled'}></label>`).join('')}</div>`)).join('');
    root.innerHTML = `${heading('CHỈNH SỬA NHÂN VẬT', `Tài khoản ${accountId} • ${state.selectedCharacter.name}`, `<button class="action-btn" data-action="reload-character">⟳ Tải lại</button>`)}
      ${character.notice ? `<div class="notice-banner">${esc(character.notice)}</div>` : ''}
      <div class="character-editor-page">${groupHtml || panel('KHÔNG CÓ TRƯỜNG HỖ TRỢ', `<div class="panel-body">Repository không tìm thấy trường số an toàn trong schema hiện tại.</div>`)}
        ${panel('GIỚI HẠN CHỈNH SỬA', `<div class="panel-body character-limit"><p>Chỉ các trường số được repository nhận diện và hiển thị ở trên mới được phép lưu. Class, kỹ năng, nhiệm vụ, hôn nhân và inventory không được chỉnh trong màn hình này.</p><p>Tài khoản phải offline; trước khi cập nhật, repository kiểm tra lại schema, trạng thái và snapshot trong giao dịch. Save còn phụ thuộc cờ [MUSVEN_CHARACTER_WRITES].</p><button class="action-btn green" data-action="save-character" ${character.writeEnabled ? '' : 'disabled'}>▣ LƯU THAY ĐỔI</button><button class="action-btn" data-page="dashboard">← Quay lại</button><small>${character.writeEnabled ? 'Ghi được bật trong Config.ini; vẫn sẽ hỏi xác nhận trước khi lưu.' : 'Chế độ ghi đang khóa trong Config.ini.'}</small></div>`)}
      </div>`;
  }
  function itemMatches(item) {
    const term = state.itemSearch.trim().toLocaleLowerCase();
    return (state.itemCategory === 'all' || item.type === state.itemCategory) && (!term || `${item.name} ${item.id} ${item.localId} ${item.category}`.toLocaleLowerCase().includes(term));
  }
  function renderItemEditor() {
    const categories = window.MUSVEN_OPTIONS.categories;
    const items = state.catalog.filter(itemMatches);
    const selected = state.selectedItem || items[0] || null;
    const categoryTabs = categories.map(cat => `<button class="item-category ${state.itemCategory === cat.id ? 'is-active' : ''}" data-action="category" data-category="${cat.id}"><span>${cat.glyph}</span><span>${esc(cat.name)}</span></button>`).join('');
    const rows = items.map(item => `<tr class="${selected?.id === item.id ? 'is-selected' : ''}" data-action="select-catalog-item" data-id="${item.id}"><td>${item.section}:${item.localId}</td><td><span class="item-icon">⚔</span> ${esc(item.name)}</td><td>${esc(item.category)}</td><td>${item.width}×${item.height}</td></tr>`).join('');
    root.innerHTML = `${heading('ITEM DATABASE • DANH MỤC SERVER', `${state.catalog.length.toLocaleString()} vật phẩm được nạp từ ItemCatalog.xml • chỉ đọc`)}
      <div class="editor-layout live-item-layout">
        ${panel('ITEM LIST • SERVER CATALOG', `<div class="category-tabs"><button class="item-category ${state.itemCategory === 'all' ? 'is-active' : ''}" data-action="category" data-category="all"><span>✥</span><span>Tất cả</span></button>${categoryTabs}</div><div class="library-filters"><input class="inset-field" placeholder="Tìm tên, ID hoặc nhóm…" data-bind="itemSearch" value="${esc(state.itemSearch)}"><span class="catalog-count">${items.length} kết quả</span></div><div class="item-table-wrap"><table class="item-table"><thead><tr><th>SECTION:ID</th><th>TÊN</th><th>NHÓM</th><th>KÍCH THƯỚC</th></tr></thead><tbody>${rows || '<tr><td colspan="4" class="empty-state">Không tìm thấy vật phẩm.</td></tr>'}</tbody></table></div>`, 'item-library')}
        ${panel('THÔNG TIN DANH MỤC', selected ? `<div class="readonly-item-detail"><div class="weapon-stage"><span class="stage-name">${esc(selected.name)}</span><img src="${esc(selected.image)}" alt="${esc(selected.name)}" onerror="this.style.opacity='.2'"></div><div class="readonly-item-fields"><label class="field-label"><span>Tên vật phẩm</span><input class="inset-field" readonly value="${esc(selected.name)}"></label><label class="field-label"><span>Section / ID</span><input class="inset-field" readonly value="${selected.section} / ${selected.localId}"></label><label class="field-label"><span>ItemIndex</span><input class="inset-field" readonly value="${selected.id} (0x${Number(selected.id).toString(16).toUpperCase()})"></label><label class="field-label"><span>Kích thước kho</span><input class="inset-field" readonly value="${selected.width} × ${selected.height}"></label><label class="field-label"><span>Nhóm</span><input class="inset-field" readonly value="${esc(selected.category)}"></label><p class="muted">Danh mục chỉ cung cấp tên, nhóm và kích thước. Thuộc tính chiến đấu không tồn tại trong API danh mục hiện tại.</p><button class="action-btn blue" data-action="create-item" data-id="${selected.id}">✧ Chọn để thêm vào kho</button></div></div>` : `<div class="panel-body empty-state">Danh mục chưa tải hoặc không có kết quả.</div>`, 'editor-detail')}
      </div>`;
  }
  function refreshCatalogResults() {
    const items = state.catalog.filter(itemMatches);
    if (state.page === 'item-editor') {
      const body = $('.item-table tbody');
      if (body) body.innerHTML = items.map(item => `<tr class="${state.selectedItem?.id === item.id ? 'is-selected' : ''}" data-action="select-catalog-item" data-id="${item.id}"><td>${item.section}:${item.localId}</td><td><span class="item-icon">⚔</span> ${esc(item.name)}</td><td>${esc(item.category)}</td><td>${item.width}×${item.height}</td></tr>`).join('') || '<tr><td colspan="4" class="empty-state">Không tìm thấy vật phẩm.</td></tr>';
      const count = $('.catalog-count'); if (count) count.textContent = `${items.length} kết quả`;
    } else if (state.page === 'inventory') {
      const list = $('.catalog-mini-list');
      if (list) list.innerHTML = items.slice(0,350).map(item => `<button class="catalog-mini-item ${state.selectedItem?.id === item.id ? 'is-selected' : ''}" data-action="select-catalog-item" data-id="${item.id}"><span class="mini-item-glyph">⚔</span><span>${esc(item.name)}</span><small>${item.section}:${item.localId}</small></button>`).join('') || '<div class="empty-state">Danh mục không có kết quả.</div>';
      const count = $('.catalog-mini-heading'); if (count) count.textContent = `${items.length} KẾT QUẢ`;
    }
  }
  function selectedItemOptions() { return state.itemOptions || { socketOptions: [], harmonyOptions: [], excellentOptions: window.MUSVEN_OPTIONS.excellentOptions.map((label, id) => ({ id, label })) }; }
  function categoryList() {
    return `<button class="category-button ${state.itemCategory === 'all' ? 'is-active' : ''}" data-action="category" data-category="all"><span>✥</span>Tất cả</button>` + window.MUSVEN_OPTIONS.categories.map(cat => `<button class="category-button ${state.itemCategory === cat.id ? 'is-active' : ''}" data-action="category" data-category="${cat.id}"><span>${cat.glyph}</span>${esc(cat.name)}</button>`).join('');
  }
  function encodeSockets() {
    return state.itemForm.sockets.map((id, index) => Number(id) >= 254 ? Number(id) : Number(id) + 50 * (Number(state.itemForm.socketLevels[index] || 1) - 1));
  }
  function socketRows() {
    const options = selectedItemOptions().socketOptions || [];
    return state.itemForm.sockets.map((selected, index) => {
      const active = Number(selected) >= 0 && Number(selected) < 254;
      const unknown = Number(selected) < 0 ? `<option value="${selected}" selected>Giữ mã Socket ${-Number(selected) - 1}</option>` : '';
      return `<label class="socket-row"><span>Socket ${index + 1}</span><select class="inset-select" data-socket="${index}" aria-label="Socket ${index + 1}" ${state.selectedItem ? '' : 'disabled'}>${unknown}${options.map(option => `<option value="${option.id}" ${Number(option.id) === Number(selected) ? 'selected' : ''}>${esc(option.label)}</option>`).join('')}</select><select class="inset-select socket-level" data-socket-level="${index}" ${active && state.selectedItem ? '' : 'disabled'} aria-label="Cấp Socket ${index + 1}">${[1,2,3,4,5].map(level => `<option value="${level}" ${Number(state.itemForm.socketLevels[index]) === level ? 'selected' : ''}>Lv ${level}</option>`).join('')}</select><span class="socket-gem" style="--gem-color:${colors[selected] || '#b8a899'}">✧</span></label>`;
    }).join('');
  }
  function renderWarehouseGrid() {
    const editedSlots = new Set(state.stagedItems.filter(item => item.editExisting).map(item => Number(item.slot)));
    const persisted = (state.warehouse?.placements || []).filter(item => !editedSlots.has(Number(item.slot)));
    const placements = [...persisted, ...state.stagedItems.map(item => ({ ...item, pending: true }))];
    const cells = Array.from({ length: 240 }, (_, slot) => `<button class="bag-cell ${state.selectedSlot === slot ? 'is-target' : ''}" data-action="select-slot" data-slot="${slot}" aria-label="Ô kho ${slot + 1}"></button>`).join('');
    const overlays = placements.map(item => {
      const def = itemById(item.catalogId ?? item.itemIndex);
      const width = Number(item.width || def?.width || 1), height = Number(item.height || def?.height || 1);
      const row = Math.floor(Number(item.slot) / 8) + 1, col = (Number(item.slot) % 8) + 1;
      const id = item.draftId || `slot-${item.slot}`;
      return `<button class="bag-item ${item.pending ? `is-selected ${item.editExisting ? 'edited-item' : 'pending-item'}` : 'existing-item'}" data-action="select-warehouse-item" data-draft="${item.pending ? esc(id) : ''}" data-item-slot="${item.slot}" title="${esc(item.name || def?.name)} • ô ${item.slot + 1}" style="grid-column:${col}/span ${width};grid-row:${row}/span ${height}"><img src="${esc(item.image || def?.image || '')}" alt="${esc(item.name || def?.name)}" onerror="this.style.opacity='.25'"><span>${item.editExisting ? 'SỬA' : item.pending ? 'MỚI' : esc(item.name || def?.name)}</span></button>`;
    }).join('');
    return `<div class="bag-grid" data-grid-root="warehouse">${cells}${overlays}</div>`;
  }
  function renderInventory() {
    const selected = state.selectedItem;
    const matches = state.catalog.filter(itemMatches);
    const addedCount = state.stagedItems.filter(item => !item.editExisting).length;
    const editedCount = state.stagedItems.length - addedCount;
    const options = selectedItemOptions();
    const excellent = (options.excellentOptions || window.MUSVEN_OPTIONS.excellentOptions.map((label, id) => ({ label, id }))).map((option, index) => `<label class="check-row"><input type="checkbox" data-excellent="${index}" ${state.itemForm.excellent[index] ? 'checked' : ''}>${esc(option.label || option)}</label>`).join('');
    const harmonyDisabled = encodeSockets().some(value => value !== 255);
    const harmony = options.harmonyOptions || [];
    const harmonyId = Number(state.itemForm.harmonyId);
    const harmonyKnown = harmony.some(option => Number(option.id) === harmonyId);
    const harmonyRows = harmony.map(option => `<option value="${option.id}" ${Number(option.id) === harmonyId ? 'selected' : ''}>${esc(option.label)}</option>`).join('');
    const harmonyUnknown = harmonyId && !harmonyKnown ? `<option value="${harmonyId}" selected>Giữ thuộc tính Harmony ${harmonyId} chưa nhận diện</option>` : '';
    const harmonyRow = `<label class="harmony-row"><span>JEWEL OF HARMONY • ${selected ? esc(selected.category) : 'chọn item trước'}</span><select class="inset-select" data-bind="harmonyId" ${!selected || harmonyDisabled ? 'disabled' : ''}>${harmonyUnknown}${harmonyRows}</select></label>`;
    const catalogRows = matches.slice(0, 350).map(item => `<button class="catalog-mini-item ${selected?.id === item.id ? 'is-selected' : ''}" data-action="select-catalog-item" data-id="${item.id}"><span class="mini-item-glyph">⚔</span><span>${esc(item.name)}</span><small>${item.section}:${item.localId}</small></button>`).join('');
    const locations = state.locations.map(location => `<option value="${location.isExtended ? 'e' : 'm'}:${location.number}" ${state.warehouse && location.isExtended === state.warehouseExtended && Number(location.number) === Number(state.warehouseNumber) ? 'selected' : ''}>${esc(location.displayName)}</option>`).join('');
    root.innerHTML = `${heading('INVENTORY MANAGER • KHO TÀI KHOẢN', selectedAccountId() ? `Tài khoản ${selectedAccountId()} • chỉ ô trống được thêm mới` : 'Chọn tài khoản trước khi tải kho', `<button class="action-btn" data-action="dashboard">♟ Chọn tài khoản</button>`)}
      <div class="inventory-real-layout">
        <div class="warehouse-column">${panel(`KHO ĐỒ • ${esc(selectedAccountId() || 'CHƯA CHỌN TÀI KHOẢN')}`, `<div class="bag-meta"><label class="field-label"><span>Vị trí kho</span><select class="inset-select" data-action="warehouse-location" ${state.locations.length ? '' : 'disabled'}>${locations || '<option>Chưa tải kho</option>'}</select></label><span class="status-pill">240 Ô</span><button class="action-btn blue" data-action="load-inventory" ${selectedAccountId() ? '' : 'disabled'}>⟳ Tải kho</button></div><div class="warehouse-grid-scroll">${state.warehouse ? renderWarehouseGrid() : `<div class="no-account"><strong>${selectedAccountId() ? 'Kho chưa tải' : 'Chưa chọn tài khoản'}</strong><span>${selectedAccountId() ? 'Bấm Tải kho để đọc vị trí đã có trong database.' : 'Quay về tài khoản để tìm AccountID.'}</span></div>`}</div><div class="panel-foot"><span>${state.warehouse?.placements?.length || 0} vật phẩm hiện có • ${state.stagedItems.length} chờ thêm</span><span>${state.warehouse?.location?.displayName || ''}</span></div>`, 'bag-panel')}
          ${panel('TÚI NHÂN VẬT', `<div class="unsupported-inventory"><span class="tile-gem">♙</span><strong>${state.selectedCharacter ? esc(state.selectedCharacter.name) : 'Chưa chọn nhân vật'}</strong><p>Đọc blob dbo.Character.Inventory 4080 byte • hiển thị item theo slot • chỉ sửa thuộc tính tại chỗ • giữ nguyên serial, slot và byte không đổi. Yêu cầu tài khoản offline.</p><button class="action-btn blue" data-action="open-character-inventory" ${state.dashboard?.characterInventoryEnabled && state.selectedCharacter ? '' : 'disabled'}>Mở túi nhân vật</button></div>`, 'character-bag-disabled')}
        </div>
        ${panel('TẠO VẬT PHẨM • CHỌN TỪ ITEM CATALOG', `<div class="creator-real-layout"><aside class="category-list">${categoryList()}<input class="inset-field" placeholder="Tìm vật phẩm…" data-bind="itemSearch" value="${esc(state.itemSearch)}"><div class="catalog-mini-heading">${matches.length} KẾT QUẢ</div><div class="catalog-mini-list">${catalogRows || '<div class="empty-state">Danh mục không có kết quả.</div>'}</div></aside><div class="creator-real-form">${selected ? `<div class="creator-item-preview"><img src="${esc(selected.image)}" alt="${esc(selected.name)}" onerror="this.style.opacity='.2'"><strong>${esc(selected.name)}</strong><small>${selected.section}:${selected.localId} • ItemIndex ${selected.id} • ${selected.width}×${selected.height}</small></div>` : '<div class="creator-item-preview empty-state">Chọn vật phẩm từ danh sách bên trái.</div>'}
            <div class="creator-number-fields"><label class="field-label"><span>Level</span><select class="inset-select" data-bind="level">${Array.from({length:16},(_,n)=>`<option value="${n}" ${n===Number(state.itemForm.level)?'selected':''}>${n}</option>`).join('')}</select></label><label class="field-label"><span>Options</span><select class="inset-select" data-bind="optionValue">${Array.from({length:8},(_,n)=>`<option value="${n*4}" ${n*4===Number(state.itemForm.optionValue)?'selected':''}>${n ? '+'+n*4 : '0'}</option>`).join('')}</select></label><label class="field-label"><span>Độ bền</span><input class="inset-field" type="number" min="0" max="255" data-bind="durability" value="${state.itemForm.durability}"></label><label class="field-label"><span>Set Num</span><input class="inset-field" type="number" min="0" max="15" data-bind="setOption" value="${state.itemForm.setOption}"></label></div>
            <div class="creator-switches"><label class="switch-label"><input type="checkbox" data-check="skill" ${state.itemForm.skill?'checked':''}>Skill</label><label class="switch-label"><input type="checkbox" data-check="luck" ${state.itemForm.luck?'checked':''}>Luck</label></div>
            <div class="option-box"><h3>TÍNH NĂNG HOÀN HẢO (6)</h3><div class="excellent-list">${excellent}</div><div class="toolbar"><button class="action-btn blue" data-action="excellent-all">Chọn tất cả</button><button class="action-btn red" data-action="excellent-clear">Trống</button></div></div>
            <div class="option-box"><h3>HARMONY / SOCKET • TỐI ĐA 5</h3>${harmonyRow}${!harmonyDisabled ? `<label class="field-label harmony-level"><span>Cấp Harmony</span><input class="inset-field" type="number" min="0" max="15" data-bind="harmonyLevel" value="${state.itemForm.harmonyLevel}" ${selected ? '' : 'disabled'}></label>` : '<p class="muted">Có Socket: Harmony bị khóa vì byte thuộc tính được dùng cho bonus Socket.</p>'}<div class="socket-options">${socketRows()}</div></div>
            <button class="action-btn blue stage-item" data-action="stage-item" ${selected ? '' : 'disabled'}>＋ ${state.editingSlot != null || state.editingDraftId ? 'Điều chỉnh xong • bấm đúng ô đang chọn' : 'Chọn vật phẩm rồi bấm ô trống trong kho'}</button></div></div>`, 'item-creator-panel')}
        <div class="inventory-footer"><button class="action-btn" data-action="load-inventory" ${selectedAccountId() ? '' : 'disabled'}>⟳ Tải kho</button><button class="action-btn green" data-action="save-inventory" ${state.warehouseWriteEnabled && state.stagedItems.length ? '' : 'disabled'}>▣ Lưu ${addedCount} mới • ${editedCount} sửa</button><button class="action-btn red" data-action="remove-draft" ${state.selectedDraft ? '' : 'disabled'}>⌫ Bỏ vật phẩm chờ</button><button class="action-btn" data-action="clear-drafts" ${state.stagedItems.length ? '' : 'disabled'}>Xóa danh sách chờ</button><button class="action-btn" data-page="item-editor">⚔ Danh mục item</button></div>
      </div>`;
  }
  function renderServerTools() {
    root.innerHTML = `${heading('CẤU HÌNH & CÔNG CỤ', 'Các thao tác chỉ được bật khi có backend đã kiểm tra an toàn.')}
      <div class="tools-grid">${panel('CẤU HÌNH TẠO NHÂN VẬT', `<div class="panel-body tool-card"><p>Đọc và cập nhật MUSVEN_CharacterCreateDefaults thông qua repository hiện có. Master Level và Điểm Master giới hạn tối đa 400.</p><button class="action-btn" data-action="open-character-defaults" ${state.dashboard?.configured ? '' : 'disabled'}>Mở cấu hình</button></div>`)}${panel('BACKUP SQL', `<div class="panel-body tool-card"><p>Backup dùng COPY_ONLY + CHECKSUM và kiểm tra bằng RESTORE VERIFYONLY. Đường dẫn đích là thư mục trên máy SQL Server (VM nếu SQL chạy trong VM). Nút tạo file tiếp tục hỏi xác nhận.</p><button class="action-btn green" data-action="open-sql-backup" ${state.dashboard?.configured ? '' : 'disabled'}>Mở công cụ backup</button></div>`)}${panel('XẾP HẠNG / SỰ KIỆN', `<div class="panel-body tool-card"><p>Duyệt ranking/event tối đa 100 dòng; reset riêng bảng Ranking* có whitelist, preview, xác nhận kép và hậu kiểm. Server phải được dừng trước khi reset ranking.</p><button class="action-btn" data-action="open-ranking-view" ${state.dashboard?.configured ? '' : 'disabled'}>Mở ranking / sự kiện</button><small>${state.dashboard?.rankingWriteEnabled ? 'Reset ranking đã bật theo contract riêng.' : 'Reset ranking đang khóa trong Config.ini.'}</small></div>`)}${panel('RESET DỮ LIỆU MUONLINE', `<div class="panel-body tool-card"><p>Chỉ xem trước ở bước mở. Thao tác xóa yêu cầu đúng schema, backup được kiểm tra, dừng GameServer thủ công, nhập câu xác nhận và xác nhận lần cuối.</p><button class="action-btn red" data-action="open-data-reset" ${state.dashboard?.configured ? '' : 'disabled'}>Mở xem trước / reset</button><small>${state.dashboard?.dataResetEnabled ? 'Cờ riêng đang bật; kiểm tra schema vẫn có thể chặn.' : 'Cờ reset đang khóa trong Config.ini.'}</small></div>`)}${panel('TRẠNG THÁI / LỆNH SERVER', `<div class="panel-body tool-card"><p>Kick player, gửi thông báo và điều khiển GameServer chưa có API/backend đã xác minh. Các lệnh này vẫn khóa để không gửi lệnh giả.</p><button class="action-btn" data-action="close-ui">Về ứng dụng chính</button></div>`)}</div>`;
  }
  function renderPage() {
    renderServers();
    if (state.page === 'dashboard') renderDashboard();
    else if (state.page === 'character-editor') renderCharacterEditor();
    else if (state.page === 'inventory') renderInventory();
    else if (state.page === 'item-editor') renderItemEditor();
    else renderServerTools();
    $$('.nav-tab').forEach(tab => tab.classList.toggle('is-active', tab.dataset.page === state.page));
    $('#footer-clock').textContent = new Date().toLocaleTimeString('vi-VN', { hour12: false });
  }
  async function searchAccounts() {
    const result = await api('searchAccounts', { prefix: state.accountSearch.trim() });
    state.accounts = result.accounts || []; renderPage();
    if (!state.accounts.length) notify('Không tìm thấy AccountID phù hợp.');
  }
  async function loadAccount(accountId) {
    const data = await api('loadAccount', { accountId });
    state.activeAccount = data.account; state.session = data.session; state.characters = data.characters || [];
    state.selectedCharacter = state.characters[0] || null; state.characterEditor = null;
    state.characterEditorLoading = false; state.characterEditorError = '';
    state.warehouse = null; state.locations = []; state.stagedItems = [];
    renderPage();
  }
  async function loadCharacterEditor(name = state.selectedCharacter?.name) {
    if (!selectedAccountId() || !name) { notify('Chọn tài khoản và nhân vật trước.', 'red'); return; }
    if (state.characterEditorLoading) return;
    state.selectedCharacter = state.characters.find(x => x.name === name) || state.selectedCharacter;
    state.characterEditor = null; state.characterEditorError = ''; state.characterEditorLoading = true;
    state.page = 'character-editor'; renderPage();
    try {
      state.characterEditor = await api('loadCharacterEditor', { accountId: selectedAccountId(), name });
    } catch (error) {
      state.characterEditorError = error?.message || 'Không đọc được dữ liệu nhân vật.';
    } finally {
      state.characterEditorLoading = false;
      renderPage();
    }
  }
  async function loadCurrencyModal() {
    if (!selectedAccountId()) { notify('Tìm và chọn tài khoản trước.', 'red'); return; }
    state.currency = await api('loadCurrency', { accountId: selectedAccountId() });
    renderCurrencyModal();
  }
  async function loadDefaultsModal() {
    state.defaults = await api('loadCharacterDefaults', {});
    renderDefaultsModal();
  }
  function modalShell(title, body, footer) {
    modalRoot.innerHTML = `<div class="modal-backdrop"><section class="gothic-modal" role="dialog" aria-modal="true"><div class="modal-heading"><span>${esc(title)}</span><button class="modal-close" data-action="close-modal">×</button></div><div class="modal-body">${body}</div>${footer ? `<div class="modal-actions">${footer}</div>` : ''}</section></div>`;
  }
  function renderCurrencyModal() {
    const data = state.currency;
    if (!data) return;
    const entries = [['Tài khoản','accountId',data.accountId,'text'],['WCoinC','wcoinC',data.wcoinC,'number'],['WCoinP','wcoinP',data.wcoinP,'number'],['Goblin Coins','goblinPoint',data.goblinPoint,'number']];
    const body = `<div class="currency-form">${entries.map(([label,key,value,type]) => `<label class="currency-label">${esc(label)}</label><div class="currency-value"><input class="inset-field" type="${type}" data-currency="${key}" value="${esc(value)}" ${key === 'accountId' ? 'readonly' : 'min="0"'}>${type === 'number' ? `<div class="stepper"><button data-action="currency-step" data-key="${key}" data-delta="1">▲</button><button data-action="currency-step" data-key="${key}" data-delta="-1">▼</button></div>` : ''}</div>`).join('')}</div><p class="modal-note">Số liệu được đọc từ database. Lưu cần tài khoản offline, cờ ghi riêng và xác nhận ở bước tiếp theo.</p><p class="modal-note">Ngọc trong DATDAT_BANK được giữ nguyên bởi thao tác sửa ba loại tiền này.</p>`;
    modalShell('QUẢN LÝ TIỀN TỆ', body, `<button class="action-btn green" data-action="save-currency" ${data.writeEnabled ? '' : 'disabled'}>✓ Lưu</button><button class="action-btn ghost" data-action="close-modal">× Đóng</button>`);
  }
  function renderDefaultsModal() {
    const data = state.defaults;
    if (!data) return;
    const values = data.defaults;
    const left = [['level','Level khi mới tạo'],['points','Point tặng'],['zen','Zen tặng'],['reset','Reset tặng']];
    const right = [['masterLevel','Master Level tặng'],['masterPoints','Điểm Master tặng'],['wcoinC','WCoinC tặng'],['wcoinP','WCoinP tặng'],['goblinPoint','WCoinG tặng']];
    const row = ([key,label]) => `<label class="defaults-row"><span>${esc(label)}</span><input class="inset-field" type="number" min="0" ${key.startsWith('master') ? 'max="400"' : ''} data-default="${key}" value="${esc(values[key])}" ${key.startsWith('master') ? 'oninput="this.value=Math.min(400,Math.max(0,Number(this.value||0)))"' : ''}></label>`;
    const body = `<div class="defaults-grid"><div>${left.map(row).join('')}</div><div>${right.map(row).join('')}</div></div><p class="modal-note">Đây là cấu hình chung áp dụng khi người chơi tạo nhân vật mới trong game, không tạo nhân vật cho từng tài khoản.</p><p class="modal-note">Master Level và Điểm Master bị giới hạn ở 400.</p>`;
    modalShell('CẤU HÌNH TẠO NHÂN VẬT', body, `<button class="action-btn green" data-action="save-defaults" ${data.writeEnabled ? '' : 'disabled'}>▣ Lưu cấu hình</button><button class="action-btn ghost" data-action="close-modal">× Đóng</button>`);
  }
  function closeModal() { state.modal = null; modalRoot.innerHTML = ''; }
  async function saveCurrency() {
    const inputs = $$('[data-currency]', modalRoot);
    const payload = { token: state.currency.token, wcoinC: Number(inputs.find(x => x.dataset.currency === 'wcoinC')?.value), wcoinP: Number(inputs.find(x => x.dataset.currency === 'wcoinP')?.value), goblinPoint: Number(inputs.find(x => x.dataset.currency === 'goblinPoint')?.value) };
    const result = await api('saveCurrency', payload);
    if (result?.ok) { notify('Đã lưu tiền tệ qua transaction an toàn.'); closeModal(); }
    else if (result?.cancelled) notify('Đã hủy lưu, database không thay đổi.');
  }
  async function saveDefaults() {
    const values = Object.fromEntries($$('[data-default]', modalRoot).map(input => [input.dataset.default, Number(input.value || 0)]));
    const result = await api('saveCharacterDefaults', { token: state.defaults.token, values });
    if (result?.ok) { notify('Đã lưu cấu hình mặc định tạo nhân vật.'); closeModal(); }
    else if (result?.cancelled) notify('Đã hủy lưu, database không thay đổi.');
  }
  async function saveCharacter() {
    const loaded = state.characterEditor; if (!loaded) return;
    const values = {};
    for (const input of $$('.character-value')) {
      if (input.disabled) continue;
      const field = loaded.fields.find(x => x.key === input.dataset.characterKey);
      const value = input.value === '' ? null : Number(input.value);
      if (value == null || !Number.isFinite(value) || value < Number(field.minimum) || value > Number(field.maximum)) {
        notify(`${field.label}: giá trị nằm ngoài giới hạn ${field.minimum}–${field.maximum}.`, 'red'); return;
      }
      if (Number(value) !== Number(field.value)) values[field.key] = value;
    }
    if (!Object.keys(values).length) { notify('Không có trường nào được thay đổi.'); return; }
    const result = await api('saveCharacterEditor', { token: loaded.token, values });
    if (result?.ok) { notify('Đã lưu thay đổi nhân vật. Tải lại để xem giá trị mới.'); await loadCharacterEditor(loaded.name); }
    else if (result?.cancelled) notify('Đã hủy lưu, database không thay đổi.');
  }
  async function loadInventory() {
    if (!selectedAccountId()) { notify('Chọn tài khoản trước khi tải kho.', 'red'); return; }
    const data = await api('loadInventory', { accountId: selectedAccountId(), number: state.warehouseNumber, isExtended: state.warehouseExtended });
    state.locations = data.locations || []; state.warehouseWriteEnabled = Boolean(data.writeEnabled);
    if (data.location) { state.warehouseNumber = Number(data.location.number); state.warehouseExtended = Boolean(data.location.isExtended); }
    state.warehouse = data.location ? { ...data, placements: (data.placements || []).map(item => ({ ...item, itemId: `slot-${item.slot}` })) } : null;
    state.stagedItems = []; state.selectedDraft = null; state.selectedItem = null; state.itemOptions = null;
    state.itemForm = emptyItemForm(); state.editingSlot = null; state.editingDraftId = null; renderPage();
    if (!data.location) notify('Không tìm thấy kho nào cho tài khoản này.', 'red');
  }
  function makeSocketBytes() {
    return state.itemForm.sockets.map((value, index) => {
      const raw = state.itemForm.socketRawOverrides[index];
      if (raw != null) return Number(raw);
      value = Number(value);
      return value >= 254 ? value : value < 0 ? -value - 1 : value + 50 * (Number(state.itemForm.socketLevels[index] || 1) - 1);
    });
  }
  function occupiedAt(slot, newItem = null) {
    const all = [...(state.warehouse?.placements || []), ...state.stagedItems];
    const row = Math.floor(slot / 8), col = slot % 8;
    return all.find(item => {
      const definition = itemById(item.catalogId ?? item.itemIndex);
      const w = Number(item.width || definition?.width || 1), h = Number(item.height || definition?.height || 1);
      const ir = Math.floor(Number(item.slot) / 8), ic = Number(item.slot) % 8;
      return row >= ir && row < ir + h && col >= ic && col < ic + w;
    });
  }
  function stageAt(slot) {
    if (!state.warehouse) { notify('Tải kho trước khi đặt vật phẩm.', 'red'); return; }
    const item = state.selectedItem;
    if (!item) { const occupied = occupiedAt(slot); if (occupied) { state.selectedDraft = occupied.draftId || null; renderPage(); } else { state.selectedSlot = slot; renderPage(); } return; }
    const editingDraft = state.editingDraftId ? state.stagedItems.find(value => value.draftId === state.editingDraftId) : null;
    const isEditingExisting = state.editingSlot != null || Boolean(editingDraft?.editExisting);
    const targetSlot = state.editingSlot ?? (editingDraft ? Number(editingDraft.slot) : null);
    if (targetSlot != null && slot !== targetSlot) { notify(`Đang chỉnh sửa ô ${targetSlot + 1}; bấm lại đúng ô đó để áp dụng.`); return; }
    if (isEditingExisting) {
      const original = state.warehouse.placements.find(value => Number(value.slot) === Number(targetSlot));
      if (!original || Number(original.catalogId) !== Number(item.id)) { notify('ItemIndex hiện tại không khớp. Tải lại kho trước khi sửa.', 'red'); return; }
    }
    const row = Math.floor(slot / 8), col = slot % 8;
    if (col + item.width > 8 || row + item.height > 30) { notify('Vật phẩm vượt khỏi mép kho.', 'red'); return; }
    if (!isEditingExisting) {
      for (let y = row; y < row + item.height; y++) for (let x = col; x < col + item.width; x++) {
        const occupied = occupiedAt(y * 8 + x);
        if (occupied && occupied.draftId !== state.editingDraftId) { notify(`Ô ${y * 8 + x + 1} đã có vật phẩm; vùng ${item.width}×${item.height} phải trống.`, 'red'); return; }
      }
    }
    const socketBytes = makeSocketBytes();
    const harmonyValue = Number(state.itemForm.harmonyId) ? (Number(state.itemForm.harmonyId) << 4) | Number(state.itemForm.harmonyLevel) : 0;
    if (!isEditingExisting && socketBytes.some(value => value !== 255) && harmonyValue) { notify('Vật phẩm Socket dùng byte Harmony cho bonus Socket. Chọn Harmony = None.', 'red'); return; }
    const draftId = editingDraft?.draftId || `draft-${Date.now()}-${Math.random().toString(16).slice(2,7)}`;
    const excellent = state.itemForm.excellent.reduce((mask, checked, index) => mask | (checked ? 1 << index : 0), 0);
    const stagedItem = { draftId, editExisting: isEditingExisting, itemIndex: item.id, catalogId: item.id, name: item.name, image: item.image, width: item.width, height: item.height, slot,
      level: Number(state.itemForm.level), optionValue: Number(state.itemForm.optionValue), durability: Number(state.itemForm.durability), skill: Boolean(state.itemForm.skill), luck: Boolean(state.itemForm.luck), excellent,
      setOption: Number(state.itemForm.setOption), harmonyValue, sockets: socketBytes,
      socketChoices: [...state.itemForm.sockets], socketLevels: [...state.itemForm.socketLevels], socketRawOverrides: [...state.itemForm.socketRawOverrides] };
    state.stagedItems = state.stagedItems.filter(value => value.draftId !== draftId);
    state.stagedItems.push(stagedItem);
    state.selectedItem = null; state.itemOptions = null; state.selectedSlot = slot; state.selectedDraft = draftId;
    state.editingSlot = null; state.editingDraftId = null;
    state.itemForm = emptyItemForm(); renderPage(); updateDragPreview();
  }
  async function saveInventory() {
    if (!state.warehouse || !state.stagedItems.length) { notify('Chưa có thay đổi vật phẩm chờ lưu.', 'red'); return; }
    const payloadItems = state.stagedItems.map(({ draftId, name, image, width, height, catalogId, socketChoices, socketLevels, socketRawOverrides, ...data }) => data);
    const result = await api('saveInventory', { accountId: selectedAccountId(), snapshotToken: state.warehouse.snapshotToken, items: payloadItems });
    if (result?.ok) { notify(`Đã lưu ${result.addedCount || 0} vật phẩm mới và ${result.editedCount || 0} chỉnh sửa.`); await loadInventory(); }
    else if (result?.cancelled) notify('Đã hủy lưu, database không thay đổi.');
  }
  async function selectCatalogItem(id) {
    const item = itemById(id); if (!item) return;
    let editing = false;
    if (state.editingSlot != null || state.editingDraftId) {
      const targetItemId = state.editingDraftId
        ? state.stagedItems.find(value => value.draftId === state.editingDraftId)?.catalogId
        : state.warehouse?.placements.find(value => Number(value.slot) === Number(state.editingSlot))?.catalogId;
      if (Number(targetItemId) !== Number(item.id)) { notify('Khi sửa đồ hiện có, không thể đổi ItemIndex.'); return; }
      editing = true;
    } else {
      state.editingSlot = null;
      state.editingDraftId = null;
    }
    state.selectedItem = item; if (!editing) state.itemForm = emptyItemForm();
    state.itemOptions = await api('getItemOptions', { section: item.section }); renderPage();
  }
  function formFromOptions(options, socketIds, socketLevels, socketRaw) {
    return { level: Number(options.level), optionValue: Number(options.option) * 4, durability: Number(options.durability),
      skill: Boolean(options.skill), luck: Boolean(options.luck), setOption: Number(options.setOption),
      excellent: Array.from({ length: 6 }, (_, index) => (Number(options.excellent) & (1 << index)) !== 0),
      sockets: socketIds.map(Number), socketLevels: socketLevels.map(value => Math.min(5, Math.max(1, Number(value)))),
      socketRawOverrides: socketRaw.map(Number), harmonyId: Number(options.specialByte) >> 4, harmonyLevel: Number(options.specialByte) & 15 };
  }
  async function beginExistingEdit(slot) {
    const placement = state.warehouse?.placements.find(value => Number(value.slot) === Number(slot));
    const item = placement && itemById(placement.catalogId);
    if (!placement || !item || !placement.options || !placement.socketRaw) { notify('Không đọc đủ thuộc tính đồ hiện có. Tải lại kho rồi thử lại.', 'red'); return; }
    state.selectedItem = item;
    state.itemForm = formFromOptions(placement.options, placement.socketIds, placement.socketLevels, placement.socketRaw);
    state.selectedSlot = Number(slot); state.selectedDraft = null; state.editingSlot = Number(slot); state.editingDraftId = null;
    state.itemOptions = await api('getItemOptions', { section: item.section }); renderPage();
    notify(`Đang sửa ${item.name} tại ô ${Number(slot) + 1}. Điều chỉnh thuộc tính rồi bấm đúng ô đó để tạo bản chờ.`);
  }
  async function beginDraftEdit(draftId) {
    const staged = state.stagedItems.find(value => value.draftId === draftId);
    const item = staged && itemById(staged.catalogId);
    if (!staged || !item) { notify('Bản chờ không còn tồn tại.', 'red'); return; }
    state.selectedItem = item;
    state.itemForm = { level: staged.level, optionValue: staged.optionValue, durability: staged.durability, skill: staged.skill, luck: staged.luck,
      setOption: staged.setOption, excellent: Array.from({ length: 6 }, (_, index) => (Number(staged.excellent) & (1 << index)) !== 0),
      sockets: [...staged.socketChoices], socketLevels: [...staged.socketLevels], socketRawOverrides: [...staged.socketRawOverrides],
      harmonyId: Number(staged.harmonyValue) >> 4, harmonyLevel: Number(staged.harmonyValue) & 15 };
    state.selectedSlot = Number(staged.slot); state.selectedDraft = draftId;
    state.editingSlot = staged.editExisting ? Number(staged.slot) : null; state.editingDraftId = draftId;
    state.itemOptions = await api('getItemOptions', { section: item.section }); renderPage();
    notify(`Đang chỉnh bản chờ ${item.name} tại ô ${Number(staged.slot) + 1}. Bấm đúng ô đó để áp dụng.`);
  }
  function updateDragPreview(x, y) {
    if (state.page !== 'inventory' || !state.selectedItem) { dragPreview.classList.remove('is-visible'); dragPreview.replaceChildren(); return; }
    dragPreview.innerHTML = `<img src="${esc(state.selectedItem.image)}" alt="">`;
    if (Number.isFinite(x) && Number.isFinite(y)) { dragPreview.style.left = `${x}px`; dragPreview.style.top = `${y}px`; }
    dragPreview.classList.add('is-visible');
  }
  function showContext(event, button) {
    event.preventDefault(); const draftId = button.dataset.draft;
    state.selectedDraft = draftId || null;
    itemContextMenu.dataset.itemSlot = button.dataset.itemSlot || '';
    itemContextMenu.innerHTML = draftId ? '<button data-action="edit-draft-item">Chỉnh sửa thuộc tính</button><button data-action="remove-draft">Bỏ vật phẩm chờ</button><button data-action="close-context">Đóng</button>' : '<button data-action="edit-existing-item">Chỉnh sửa vật phẩm…</button><button data-action="close-context">Đóng</button>';
    itemContextMenu.style.left = `${Math.min(event.clientX, innerWidth - 190)}px`;
    itemContextMenu.style.top = `${Math.min(event.clientY, innerHeight - 100)}px`; itemContextMenu.hidden = false;
  }
  function closeContext() { itemContextMenu.hidden = true; }
  async function handleAction(button, event) {
    const action = button.dataset.action;
    if (button.dataset.page) { setPage(button.dataset.page); return; }
    if (action === 'dashboard') { setPage('dashboard'); return; }
    if (action === 'close-ui') { window.chrome?.webview?.postMessage({ type: 'close' }); return; }
    if (action === 'search-accounts') { await searchAccounts(); return; }
    if (action === 'create-account') {
      const result = await api('openAccountCreate', {});
      if (result.created && result.accountId) {
        state.accountSearch = result.accountId;
        await searchAccounts();
        await loadAccount(result.accountId);
        notify(`Đã tạo tài khoản ${result.accountId}. Mật khẩu để trống; đăng nhập phụ thuộc xác thực GameServer.`);
      }
      return;
    }
    if (action === 'load-online') { const result = await api('listOnlineAccounts', {}); state.onlineAccounts = result.accounts || []; state.onlineLoaded = true; renderPage(); notify(`Đã đọc ${state.onlineAccounts.length} phiên online từ MEMB_STAT.`); return; }
    if (action === 'load-account') { await loadAccount(button.dataset.account); return; }
    if (action === 'select-character') {
      const selected = state.characters[Number(button.dataset.index)] || null;
      if (selected?.name !== state.selectedCharacter?.name) { state.characterEditor = null; state.characterEditorError = ''; }
      state.selectedCharacter = selected; renderPage(); return;
    }
    if (action === 'edit-character' || action === 'edit-character-row') { const name = button.dataset.name || state.selectedCharacter?.name; await loadCharacterEditor(name); return; }
    if (action === 'delete-character') {
      const accountId = selectedAccountId(); const name = button.dataset.name;
      if (!accountId || !name) { notify('Chọn tài khoản và nhân vật trước.', 'red'); return; }
      const result = await api('openCharacterDelete', { accountId, name });
      if (result.deleted) { await loadAccount(accountId); notify(`Đã xóa nhân vật ${name}.`); }
      return;
    }
    if (action === 'rename-character') {
      const accountId = selectedAccountId(); const name = button.dataset.name;
      if (!accountId || !name) { notify('Chọn tài khoản và nhân vật trước.', 'red'); return; }
      const result = await api('openCharacterRename', { accountId, name });
      if (result.renamed) { await loadAccount(accountId); notify(`Đã đổi tên ${name} thành ${result.newName}.`); }
      return;
    }
    if (action === 'open-character-inventory') {
      const character = state.selectedCharacter;
      if (!selectedAccountId() || !character) { notify('Chọn tài khoản và nhân vật trước.', 'red'); return; }
      await api('openCharacterInventory', { accountId: selectedAccountId(), name: character.name });
      return;
    }
    if (action === 'open-character-quest-counts') {
      const accountId = selectedAccountId(); const name = button.dataset.name || state.selectedCharacter?.name;
      if (!accountId || !name) { notify('Chọn tài khoản và nhân vật trước.', 'red'); return; }
      const result = await api('openCharacterQuestCounts', { accountId, name });
      if (result.saved) notify(`Đã lưu số đếm nhiệm vụ của ${name}.`);
      return;
    }
    if (action === 'unban-expired') {
      const accountId = selectedAccountId();
      if (!accountId) { notify('Chọn tài khoản trước.', 'red'); return; }
      const result = await api('openAccountUnban', { accountId });
      if (result.unbanned) { await loadAccount(accountId); notify(`Đã gỡ ${result.accountBansCleared} khóa tài khoản và ${result.characterBansCleared} khóa nhân vật đã hết hạn.`); }
      return;
    }
    if (action === 'ban-account') {
      const accountId = selectedAccountId();
      if (!accountId) { notify('Chọn tài khoản trước.', 'red'); return; }
      const result = await api('openAccountBan', { accountId });
      if (result.banned) { await loadAccount(accountId); notify(`Đã khóa ${accountId} đến ${new Date(result.expiresAt).toLocaleString('vi-VN')}.`); }
      return;
    }
    if (action === 'reload-character') { await loadCharacterEditor(); return; }
    if (action === 'save-character') { await saveCharacter(); return; }
    if (action === 'open-currency') { await loadCurrencyModal(); return; }
    if (action === 'open-membership') { const accountId = selectedAccountId(); if (!accountId) { notify('Chọn tài khoản trước.', 'red'); return; } const result = await api('openAccountMembership', { accountId }); if (result.updated) notify(`Đã cập nhật cấp thành viên cho ${accountId}.`); return; }
    if (action === 'open-account-profile') { const accountId = selectedAccountId(); if (!accountId) { notify('Chọn tài khoản trước.', 'red'); return; } const result = await api('openAccountProfile', { accountId }); if (result.updated) { await loadAccount(accountId); notify(`Đã lưu tên hiển thị/email của ${accountId}.`); } return; }
    if (action === 'open-character-defaults') { await loadDefaultsModal(); return; }
    if (action === 'open-sql-backup') { await api('openSqlBackup', {}); return; }
    if (action === 'open-data-reset') { await api('openDataReset', {}); return; }
    if (action === 'open-ranking-view') { await api('openRankingView', {}); return; }
    if (action === 'open-inventory') { setPage('inventory'); return; }
    if (action === 'load-inventory') { await loadInventory(); return; }
    if (action === 'save-inventory') { await saveInventory(); return; }
    if (action === 'save-currency') { await saveCurrency(); return; }
    if (action === 'save-defaults') { await saveDefaults(); return; }
    if (action === 'close-modal') { closeModal(); return; }
    if (action === 'currency-step') { const input = $(`[data-currency="${button.dataset.key}"]`, modalRoot); if (input) input.value = Math.max(0, Number(input.value || 0) + Number(button.dataset.delta)); return; }
    if (action === 'category') { state.itemCategory = button.dataset.category; renderPage(); return; }
    if (action === 'select-catalog-item') { await selectCatalogItem(Number(button.dataset.id)); updateDragPreview(event.clientX, event.clientY); return; }
    if (action === 'create-item') { const id = Number(button.dataset.id || state.selectedItem?.id); if (id) { await selectCatalogItem(id); setPage('inventory'); } return; }
    if (action === 'stage-item') { notify(state.editingSlot != null || state.editingDraftId ? 'Điều chỉnh thuộc tính xong; bấm lại đúng ô đang sửa trong lưới.' : 'Chọn ô trống trong lưới kho để đặt vật phẩm.'); updateDragPreview(event.clientX, event.clientY); return; }
    if (action === 'select-slot') { stageAt(Number(button.dataset.slot)); return; }
    if (action === 'select-warehouse-item') { state.selectedDraft = button.dataset.draft || null; state.selectedSlot = Number(button.dataset.itemSlot); renderPage(); return; }
    if (action === 'edit-existing-item') { const slot = Number(itemContextMenu.dataset.itemSlot); closeContext(); await beginExistingEdit(slot); updateDragPreview(event.clientX, event.clientY); return; }
    if (action === 'edit-draft-item') { const draftId = state.selectedDraft; closeContext(); if (draftId) await beginDraftEdit(draftId); updateDragPreview(event.clientX, event.clientY); return; }
    if (action === 'excellent-all') { state.itemForm.excellent.fill(true); renderPage(); return; }
    if (action === 'excellent-clear') { state.itemForm.excellent.fill(false); renderPage(); return; }
    if (action === 'remove-draft') { state.stagedItems = state.stagedItems.filter(item => item.draftId !== state.selectedDraft); if (state.editingDraftId === state.selectedDraft) { state.editingDraftId = null; state.editingSlot = null; state.selectedItem = null; state.itemOptions = null; state.itemForm = emptyItemForm(); updateDragPreview(); } state.selectedDraft = null; closeContext(); renderPage(); return; }
    if (action === 'clear-drafts') { state.stagedItems = []; state.selectedDraft = null; renderPage(); return; }
    if (action === 'close-context') { closeContext(); return; }
    if (action === 'inspect-item') { closeContext(); notify('Vật phẩm đang có trong kho chỉ đọc.'); return; }
  }
  function bind() {
    document.addEventListener('click', async event => {
      const button = event.target.closest('[data-action], [data-page]'); if (!button) { if (event.target.classList.contains('modal-backdrop')) closeModal(); return; }
      try { await handleAction(button, event); } catch (_) { /* api() already showed the actual error */ }
    });
    document.addEventListener('contextmenu', event => { const item = event.target.closest('.bag-item'); if (item) showContext(event, item); });
    document.addEventListener('click', event => { if (!itemContextMenu.hidden && !event.target.closest('#item-context-menu')) closeContext(); });
    document.addEventListener('input', event => {
      const el = event.target;
      if (el.matches('[data-bind="accountSearch"]')) state.accountSearch = el.value;
      else if (el.matches('[data-bind="onlineSearch"]')) { state.onlineSearch = el.value; const body = $('.online-table tbody'); if (body) body.innerHTML = renderOnlineRows(); }
      else if (el.matches('[data-bind="itemSearch"]')) { state.itemSearch = el.value; refreshCatalogResults(); }
      else if (el.matches('[data-bind="level"], [data-bind="optionValue"], [data-bind="durability"], [data-bind="setOption"], [data-bind="harmonyLevel"]')) state.itemForm[el.dataset.bind] = Number(el.value || 0);
      if (el.matches('[data-character-key]')) el.classList.add('is-modified');
    });
    document.addEventListener('change', async event => {
      const el = event.target;
      if (el.matches('[data-check]')) { state.itemForm[el.dataset.check] = el.checked; return; }
      if (el.matches('[data-excellent]')) { state.itemForm.excellent[Number(el.dataset.excellent)] = el.checked; return; }
      if (el.matches('[data-socket]')) {
        const index = Number(el.dataset.socket), id = Number(el.value);
        if (id !== 255 && state.itemForm.sockets.slice(0, index).some(value => Number(value) === 255)) {
          notify('Hãy bố trí Socket liên tục từ vị trí số 1.', 'red'); renderPage(); return;
        }
        state.itemForm.sockets[index] = id; state.itemForm.socketRawOverrides[index] = null;
        if (id === 255) for (let later = index + 1; later < 5; later++) state.itemForm.sockets[later] = 255;
        renderPage(); return;
      }
      if (el.matches('[data-socket-level]')) { const index = Number(el.dataset.socketLevel); state.itemForm.socketLevels[index] = Number(el.value); state.itemForm.socketRawOverrides[index] = null; renderPage(); return; }
      if (el.matches('[data-bind="harmonyId"]')) { state.itemForm.harmonyId = Number(el.value); return; }
      if (el.matches('[data-action="warehouse-location"]')) {
        const [prefix, number] = el.value.split(':'); state.warehouseExtended = prefix === 'e'; state.warehouseNumber = Number(number); await loadInventory(); return;
      }
      if (el.matches('[data-bind="level"], [data-bind="optionValue"], [data-bind="durability"], [data-bind="setOption"], [data-bind="harmonyLevel"]')) state.itemForm[el.dataset.bind] = Number(el.value || 0);
    });
    document.addEventListener('keydown', async event => {
      const characterRow = event.target.closest?.('tr[data-action="select-character"]');
      if (characterRow && event.target === characterRow && (event.key === 'Enter' || event.key === ' ')) {
        event.preventDefault(); characterRow.click(); return;
      }
      if (event.key === 'Enter' && event.target.matches('[data-bind="accountSearch"]')) { event.preventDefault(); try { await searchAccounts(); } catch (_) {} }
    });
    document.addEventListener('pointermove', event => updateDragPreview(event.clientX, event.clientY));
  }
  async function init() {
    bind();
    try {
      const [dashboard, catalog] = await Promise.all([window.musvenApi.getDashboard({}), window.musvenApi.getItemCatalog({})]);
      state.dashboard = dashboard; state.catalog = catalog || []; renderPage();
      window.dispatchEvent(new CustomEvent('musven-ui-ready'));
    } catch (error) {
      root.innerHTML = `<div class="empty-state">Không khởi tạo được giao diện.<br>${esc(error.message)}</div>`;
    }
    setInterval(() => {
      const time = new Date().toLocaleTimeString('vi-VN', { hour12: false });
      const clock = $('#server-clock'); if (clock) clock.textContent = time;
      $('#footer-clock').textContent = time;
    }, 1000);
  }
  window.MUSVEN_UI_STATE = state;
  init();
})();
