/* Stable presentation metadata only. Account, item and inventory data come from C# repositories. */
window.MUSVEN_OPTIONS = {
  categories: [
    { id: 'sword', name: 'Kiếm', glyph: '⚔', sections: [0] },
    { id: 'axe', name: 'Rìu', glyph: '⚒', sections: [1] },
    { id: 'mace', name: 'Chùy', glyph: '✥', sections: [2] },
    { id: 'spear', name: 'Giáo', glyph: '➶', sections: [3] },
    { id: 'bow', name: 'Cung / nỏ', glyph: '➶', sections: [4] },
    { id: 'staff', name: 'Gậy', glyph: 'ϟ', sections: [5] },
    { id: 'shield', name: 'Khiên', glyph: '⬡', sections: [6] },
    { id: 'armor', name: 'Giáp', glyph: '♜', sections: [7, 8, 9, 10, 11] },
    { id: 'wing', name: 'Cánh', glyph: '✺', sections: [12] },
    { id: 'other', name: 'Khác', glyph: '✧', sections: [13, 14, 15] }
  ],
  excellentOptions: [
    'Tăng Zen +40% / hồi Mana÷8', 'Phản đòn +5% / tốc độ +7',
    'Tránh đòn +10% / hồi HP÷8', 'Mana +4% / yêu cầu Level÷20',
    'Giảm sát thương 4% / tăng sát thương 2%', 'HP +4% / sát thương hoàn hảo +10%'
  ],
  socketColors: { 255: '#8b8379', 254: '#b8a899', 0: '#ff633e', 1: '#ffae52', 2: '#ffdf67', 3: '#f3f6ff', 4: '#ff4d49', 5: '#ff648d', 10: '#47a8ff', 11: '#75c8ff', 12: '#5ea7ff', 13: '#8bcaff', 14: '#6fb8ff', 16: '#d7e8ff', 17: '#b5d9ff', 18: '#70cfff', 19: '#9dd8ff', 20: '#a6d7ff', 21: '#5fd6ff', 22: '#85d6ff', 23: '#a1e9ff', 24: '#83deff', 25: '#8beaff', 26: '#eb82ff', 29: '#eb82ff', 30: '#79e59b', 31: '#7deab0', 32: '#93e59d', 34: '#b891ff', 35: '#df8fff', 36: '#f4c675', 37: '#d4a9ff' }
};
