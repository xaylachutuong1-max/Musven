# Rà soát hợp đồng từ source Titan và GameServer

Ngày rà soát: 2026-10-31  
Source đối chiếu: `E:\MUSVEN_GOC_SOURCE\MUSVEN_TITAN_AUDIT_20261025` và `E:\MUSVEN_GOC_SOURCE\SRCMainGS`.

## Kết quả đã chuyển thành code

- `TitanEditor.Account\Account.cs` và DDL `E:\MuServer\MuServer\DB\SQL Server 2008 R2.sql` xác nhận `MEMB_INFO.memb_name varchar(10)` / `mail_addr varchar(50)`. Musven đã nối sửa hai trường này với schema/runtime check, offline gate, snapshot, transaction và hậu kiểm. Mật khẩu và câu hỏi/đáp án khôi phục không bị đọc hay ghi.
- DDL `MEMB_INFO` xác nhận hợp đồng tạo account tối thiểu: `memb_guid` identity; AccountID/password/name/serial number, trạng thái khóa và cấp tài khoản có kiểu/độ dài cố định. Musven tạo account mới với `memb__pwd=''`, tên hiển thị mặc định là AccountID, kiểm tra cột bắt buộc chưa hỗ trợ, ID trùng và hậu kiểm trong transaction. Mật khẩu trống chỉ đăng nhập được nếu GameServer chấp nhận.
- `TitanEditor.KhoaTK\Khoa_TK.cs` xác nhận cách khóa cũ chỉ đặt `MEMB_INFO.bloc_code` thành 0/1. MUSVEN đã thay hành vi đó bằng khóa tạm thời có thời hạn: kiểm tra kiểu cột khi chạy, chặn tài khoản online, so snapshot, không ghi đè khóa đang còn hạn/vĩnh viễn, thời hạn tối đa 365 ngày, transaction và hậu kiểm. Cờ riêng `[MUSVEN_ACCOUNT_BAN]` được bật trong cấu hình VM.
- Gỡ khóa dùng `dbo.WZ_DesblocAccount` đã được kiểm tra thân procedure; không gọi cách ghi trực tiếp đơn giản của Titan.
- Xếp hạng có whitelist và luồng reset riêng trong MUSVEN; thao tác yêu cầu GameServer được người vận hành dừng thủ công trước khi thực hiện.
- DDL xác nhận `dbo.QuestKillCount`: `Name varchar(10)` là khóa; `QuestIndex`, năm `MonsterClass` và năm `KillCount` là `int` nullable. GameServer đọc/ghi năm bộ đếm theo tên nhân vật. MUSVEN đã thêm form chỉ sửa `KillCount1..5`, xác minh schema/nhân vật/offline, kiểm snapshot và hậu kiểm trong transaction; không insert dòng thiếu, không sửa QuestIndex/MonsterClass.

## Source cũ có dữ liệu tham khảo nhưng không an toàn để port nguyên trạng

- `TitanEditor.Account\Account.cs` cho biết form cũ sửa `memb_name`, `mail_addr`, `fpas_ques`, `fpas_answ`; khi đặt mật khẩu ở cấu hình MD5, nó gọi `EXEC Encript @password, @account` theo dạng chuỗi ghép. Không tìm thấy định nghĩa procedure `Encript` trong source SQL được lưu cùng máy. Musven không đặt/đổi mật khẩu khác rỗng và không gọi `Encript`; luồng tạo account chỉ lưu password trống theo yêu cầu người vận hành.
- `TitanEditor.Doitaikhoan\Doi_TK.cs` chỉ đổi AccountID ở `AccountCharacter`, `Character`, `MEMB_INFO`, `MEMB_STAT` và `warehouse`. Nó không cập nhật các bảng kho/money/jewel mở rộng hoặc mọi bảng phụ của nhân vật, cũng không có transaction/kiểm tra offline. Không port luồng đổi AccountID này.
- `INTEGRATION_13E\SOURCE\TitanEditor\TitanEditor\EG_CleanID.cs` xóa nhiều bảng bằng các câu lệnh rời nhau, không có transaction bao trọn và không giữ đủ mọi bảng phụ. Đây không phải hợp đồng an toàn cho chức năng xóa tài khoản.
- `TitanEditor.Character\SkillsEdition.cs` cho thấy định dạng cũ dùng `Character.MagicList` 180 byte và tối đa 45 mục, mỗi mục đọc hai byte ID. Danh mục skill được lấy từ cơ sở dữ liệu MDB ngoài (`SKILLS`), không có phiên bản/hash và schema MDB đi kèm source đang chạy của MUSVEN; chưa thể xác định ID hợp lệ theo đúng client/server đang cài. Không ghi blob skill theo dữ liệu này.
- Trong `SRCMainGS`, các hàm như `gNotice.GCNoticeSendToAll` và `gObjCloseSet` là lời gọi trong bộ nhớ của GameServer. Chưa tìm thấy listener quản trị từ xa, transport, xác thực, mã lệnh hay kết quả phản hồi cho app desktop. `dbo.WZ_DISCONNECT_MEMB` chỉ đổi `MEMB_STAT.ConnectStat` và `DisConnectTM`; nó không đóng socket/session trong GameServer. Không dùng các cách này để giả lập Kick hoặc broadcast.
- `QuestWorld.QuestWorldList` là blob riêng chưa có quy tắc bit/offset được xác minh. MUSVEN chỉ sửa bộ đếm `QuestKillCount`; không ghi `Character.Quest` hay `QuestWorldList` bằng suy đoán.

## Việc còn chưa thể hoàn thiện bằng code desktop hiện có

Các mục dưới đây cần hợp đồng bổ sung trong chính GameServer/database đang chạy trước khi mở ghi: xác thực mật khẩu khác rỗng/procedure `Encript` đã kiểm chứng; danh sách đầy đủ bảng phụ cho xóa/đổi AccountID; danh mục skill khớp bản server/client; encoding blob QuestWorld/event; cùng một kênh quản trị GameServer có xác thực và phản hồi cho Kick/broadcast. Bộ đếm quái `QuestKillCount` đã có editor riêng và không bao gồm blob QuestWorld/event.

Không có câu lệnh SQL, migration, restart hoặc stop GameServer nào được chạy trong lần rà soát này.
