using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MuSven09M;

internal sealed class EquipmentSlot : Control
{
	private bool enable3DToggle;

	private bool previewVisible = true;

	private string? unavailableHint;

	private readonly string name;

	private bool hovered;

	public bool Enable3DToggle
	{
		get
		{
			return enable3DToggle;
		}
		set
		{
			enable3DToggle = value;
			Invalidate();
		}
	}

	public bool PreviewVisible => previewVisible;

	public string PreviewStateText => name + " " + (previewVisible ? "đang hiện" : "đang ẩn");

	public EquipmentSlot(string name)
	{
		this.name = name;
		DoubleBuffered = true;
		Cursor = Cursors.Hand;
		Font = new Font("Segoe UI", 9f, FontStyle.Bold);
		base.MouseEnter += delegate
		{
			hovered = true;
			Invalidate();
		};
		base.MouseLeave += delegate
		{
			hovered = false;
			Invalidate();
		};
		base.EnabledChanged += delegate
		{
			Cursor = (base.Enabled ? Cursors.Hand : Cursors.Default);
			Invalidate();
		};
	}

	public void SetPreviewVisible(bool visible)
	{
		previewVisible = visible;
		Invalidate();
	}

	public void SetUnavailableHint(string hint)
	{
		unavailableHint = hint;
		Invalidate();
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics g = e.Graphics;
		g.SmoothingMode = SmoothingMode.AntiAlias;
		Rectangle rect = new Rectangle(1, 1, Math.Max(1, base.Width - 3), Math.Max(1, base.Height - 3));
		Color start = ((!base.Enabled) ? Color.FromArgb(22, 31, 43) : (hovered ? Color.FromArgb(31, 81, 130) : Color.FromArgb(16, 43, 77)));
		Color end = ((!base.Enabled) ? Color.FromArgb(15, 22, 32) : Color.FromArgb(7, 19, 39));
		using LinearGradientBrush fill = new LinearGradientBrush(rect, start, end, 90f);
		using Pen border = new Pen((!base.Enabled) ? Color.FromArgb(54, 65, 78) : (hovered ? Color.FromArgb(123, 231, 255) : Color.FromArgb(46, 111, 165)), (hovered && base.Enabled) ? 2f : 1f);
		g.FillRectangle(fill, rect);
		g.DrawRectangle(border, rect);
		string label = (Enable3DToggle ? ((previewVisible ? "Ẩn " : "Hiện ") + name) : ((unavailableHint == null) ? name : (name + Environment.NewLine + unavailableHint)));
		Color text = ((!base.Enabled) ? Color.FromArgb(113, 126, 141) : (previewVisible ? Color.FromArgb(190, 235, 255) : Color.FromArgb(255, 211, 116)));
		Font hintFont = ((unavailableHint == null) ? null : new Font(Font.FontFamily, Math.Max(7f, Font.Size - 1.5f), FontStyle.Bold));
		try
		{
			TextRenderer.DrawText(g, label, hintFont ?? Font, rect, text, TextFormatFlags.EndEllipsis | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak);
		}
		finally
		{
			hintFont?.Dispose();
		}
	}
}
