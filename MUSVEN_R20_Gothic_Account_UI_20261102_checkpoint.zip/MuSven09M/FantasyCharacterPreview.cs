using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MuSven09M;

internal sealed class FantasyCharacterPreview : Control
{
	private readonly System.Windows.Forms.Timer pulse = new System.Windows.Forms.Timer
	{
		Interval = 40
	};

	private float phase;

	public FantasyCharacterPreview()
	{
		DoubleBuffered = true;
		BackColor = Color.FromArgb(6, 16, 34);
		pulse.Tick += delegate
		{
			phase += 0.055f;
			Invalidate();
		};
		pulse.Start();
		base.Disposed += delegate
		{
			pulse.Dispose();
		};
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Graphics g = e.Graphics;
		g.SmoothingMode = SmoothingMode.AntiAlias;
		int w = base.Width;
		int h = base.Height;
		if (w < 80 || h < 100)
		{
			return;
		}
		float scale = Math.Min((float)w / 340f, (float)h / 340f);
		GraphicsState state = g.Save();
		g.TranslateTransform((float)w / 2f, (float)h / 2f + 10f * scale);
		g.ScaleTransform(scale, scale);
		PathGradientBrush pathGradientBrush = new PathGradientBrush(new PointF[4]
		{
			new PointF(-145f, -135f),
			new PointF(145f, -135f),
			new PointF(145f, 150f),
			new PointF(-145f, 150f)
		});
		pathGradientBrush.CenterPoint = new PointF(0f, 0f);
		pathGradientBrush.CenterColor = Color.FromArgb(60 + (int)(15.0 * Math.Sin(phase)), 31, 125, 255);
		pathGradientBrush.SurroundColors = new Color[1] { Color.Transparent };
		using PathGradientBrush aura = pathGradientBrush;
		g.FillRectangle(aura, -150, -155, 300, 310);
		using Pen ring = new Pen(Color.FromArgb(90, 45, 169, 255), 2f);
		g.DrawEllipse(ring, -105, 111, 210, 38);
		g.DrawEllipse(ring, -80, 120, 160, 22);
		DrawCrystal(g, new PointF(-25f, -55f), new PointF(-130f, -145f), new PointF(-108f, 5f), 85);
		DrawCrystal(g, new PointF(-32f, -12f), new PointF(-151f, -48f), new PointF(-88f, 75f), 70);
		DrawCrystal(g, new PointF(25f, -55f), new PointF(130f, -145f), new PointF(108f, 5f), 85);
		DrawCrystal(g, new PointF(32f, -12f), new PointF(151f, -48f), new PointF(88f, 75f), 70);
		using SolidBrush dark = new SolidBrush(Color.FromArgb(12, 27, 54));
		using SolidBrush steel = new SolidBrush(Color.FromArgb(91, 153, 211));
		using Pen bright = new Pen(Color.FromArgb(143, 222, 255), 2f);
		using Pen gold = new Pen(Color.FromArgb(242, 187, 75), 3f);
		g.FillPolygon(dark, new PointF[4]
		{
			new PointF(-44f, 15f),
			new PointF(-14f, 15f),
			new PointF(-17f, 132f),
			new PointF(-54f, 128f)
		});
		g.FillPolygon(dark, new PointF[4]
		{
			new PointF(44f, 15f),
			new PointF(14f, 15f),
			new PointF(17f, 132f),
			new PointF(54f, 128f)
		});
		g.DrawLine(bright, -42, 37, -44, 119);
		g.DrawLine(bright, 42, 37, 44, 119);
		g.FillPolygon(steel, new PointF[6]
		{
			new PointF(-59f, -73f),
			new PointF(0f, -98f),
			new PointF(59f, -73f),
			new PointF(44f, 26f),
			new PointF(0f, 49f),
			new PointF(-44f, 26f)
		});
		g.FillPolygon(dark, new PointF[6]
		{
			new PointF(-48f, -62f),
			new PointF(0f, -83f),
			new PointF(48f, -62f),
			new PointF(34f, 18f),
			new PointF(0f, 33f),
			new PointF(-34f, 18f)
		});
		g.DrawLine(gold, -35, -46, 0, -14);
		g.DrawLine(gold, 35, -46, 0, -14);
		using SolidBrush gem = new SolidBrush(Color.FromArgb(76, 223, 255));
		g.FillPolygon(gem, new PointF[4]
		{
			new PointF(0f, -48f),
			new PointF(12f, -19f),
			new PointF(0f, 1f),
			new PointF(-12f, -19f)
		});
		g.FillPolygon(steel, new PointF[4]
		{
			new PointF(-52f, -78f),
			new PointF(-99f, -85f),
			new PointF(-78f, -38f),
			new PointF(-48f, -34f)
		});
		g.FillPolygon(steel, new PointF[4]
		{
			new PointF(52f, -78f),
			new PointF(99f, -85f),
			new PointF(78f, -38f),
			new PointF(48f, -34f)
		});
		g.FillPolygon(dark, new PointF[4]
		{
			new PointF(-77f, -38f),
			new PointF(-53f, -32f),
			new PointF(-67f, 44f),
			new PointF(-88f, 38f)
		});
		g.FillPolygon(dark, new PointF[4]
		{
			new PointF(77f, -38f),
			new PointF(53f, -32f),
			new PointF(67f, 44f),
			new PointF(88f, 38f)
		});
		g.DrawLine(bright, -86, -27, -73, 36);
		g.DrawLine(bright, 86, -27, 73, 36);
		g.FillPolygon(steel, new PointF[6]
		{
			new PointF(-30f, -102f),
			new PointF(-35f, -139f),
			new PointF(0f, -157f),
			new PointF(35f, -139f),
			new PointF(30f, -102f),
			new PointF(0f, -87f)
		});
		g.FillPolygon(dark, new PointF[4]
		{
			new PointF(-23f, -121f),
			new PointF(0f, -143f),
			new PointF(23f, -121f),
			new PointF(0f, -99f)
		});
		g.FillPolygon(steel, new PointF[4]
		{
			new PointF(-27f, -130f),
			new PointF(-62f, -172f),
			new PointF(-36f, -152f),
			new PointF(-20f, -139f)
		});
		g.FillPolygon(steel, new PointF[4]
		{
			new PointF(27f, -130f),
			new PointF(62f, -172f),
			new PointF(36f, -152f),
			new PointF(20f, -139f)
		});
		using Pen eyes = new Pen(Color.FromArgb(104, 243, 255), 3f);
		g.DrawLine(eyes, -18, -120, -4, -116);
		g.DrawLine(eyes, 18, -120, 4, -116);
		g.FillPolygon(steel, new PointF[4]
		{
			new PointF(95f, -95f),
			new PointF(108f, -167f),
			new PointF(115f, -94f),
			new PointF(105f, 43f)
		});
		g.DrawLine(gold, 81, -92, 123, -92);
		g.DrawLine(bright, 105, -152, 105, 20);
		g.Restore(state);
		using Font label = new Font("Segoe UI", 8f, FontStyle.Bold);
		using SolidBrush brush = new SolidBrush(Color.FromArgb(148, 216, 250));
		g.DrawString("MU SVEN  |  FANTASY ARMOR PREVIEW", label, brush, new PointF(9f, 8f));
		g.DrawString("2D animated concept  •  demo only", new Font("Segoe UI", 8f), brush, new PointF(9f, h - 22));
	}

	private static void DrawCrystal(Graphics g, PointF root, PointF tip, PointF edge, int alpha)
	{
		using SolidBrush fill = new SolidBrush(Color.FromArgb(alpha, 34, 135, 247));
		using Pen pen = new Pen(Color.FromArgb(160, 110, 222, 255), 1.7f);
		PointF[] points = new PointF[3] { root, tip, edge };
		g.FillPolygon(fill, points);
		g.DrawPolygon(pen, points);
	}
}
