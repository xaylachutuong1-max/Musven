using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MuSven09M;

internal sealed class FantasyMenuHeader : PictureBox
{
	private const float SourceWidth = 1600f;

	private const float SourceHeight = 260f;

	private const float TabLeft = 25f;

	private const float TabRight = 1130f;

	private const float TabTop = 172f;

	private const float TabBottom = 258f;

	private static readonly string[] Names = new string[7] { "Tài khoản", "Nhân vật", "Vật phẩm", "Kho đồ", "Quản lý", "Công cụ", "Cài đặt" };

	private readonly ToolTip tip = new ToolTip
	{
		InitialDelay = 250,
		ReshowDelay = 100
	};

	private readonly System.Windows.Forms.Timer animation = new System.Windows.Forms.Timer
	{
		Interval = 16
	};

	private int pressed = -1;

	private int activeIndex;

	private PointF burstCenter;

	private long burstStart;

	private bool bursting;

	private const int DurationMs = 560;

	public int ActiveIndex
	{
		get
		{
			return activeIndex;
		}
		set
		{
			activeIndex = Math.Clamp(value, 0, Names.Length - 1);
		}
	}

	public event Action<int>? TabSelected;

	public FantasyMenuHeader()
	{
		DoubleBuffered = true;
		SetStyle(ControlStyles.ResizeRedraw | ControlStyles.OptimizedDoubleBuffer, value: true);
		animation.Tick += delegate
		{
			if (Environment.TickCount64 - burstStart >= 560)
			{
				bursting = false;
				animation.Stop();
			}
			Invalidate();
		};
	}

	private int HitTest(Point p)
	{
		if (base.Width <= 0 || base.Height <= 0)
		{
			return -1;
		}
		float x = (float)p.X * 1600f / (float)base.Width;
		float y = (float)p.Y * 260f / (float)base.Height;
		if (x < 25f || x >= 1130f || y < 172f || y >= 258f)
		{
			return -1;
		}
		int index = (int)((x - 25f) / (1105f / (float)Names.Length));
		if (index < 0 || index >= Names.Length)
		{
			return -1;
		}
		return index;
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		int hit = HitTest(e.Location);
		Cursor = ((hit >= 0) ? Cursors.Hand : Cursors.Default);
		tip.SetToolTip(this, (hit >= 0) ? Names[hit] : "");
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		base.OnMouseLeave(e);
		Cursor = Cursors.Default;
		pressed = -1;
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		if (e.Button == MouseButtons.Left)
		{
			pressed = HitTest(e.Location);
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		int hit = HitTest(e.Location);
		bool num = e.Button == MouseButtons.Left && hit >= 0 && hit == pressed;
		pressed = -1;
		if (num)
		{
			burstCenter = e.Location;
			burstStart = Environment.TickCount64;
			bursting = true;
			animation.Start();
			ActiveIndex = hit;
			this.TabSelected?.Invoke(hit);
			Invalidate();
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		if (!bursting)
		{
			return;
		}
		float progress = Math.Clamp((float)(Environment.TickCount64 - burstStart) / 560f, 0f, 1f);
		float fade = (1f - progress) * (1f - progress);
		if (fade <= 0.002f)
		{
			return;
		}
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		GraphicsState state = e.Graphics.Save();
		e.Graphics.SetClip(new RectangleF(0f, 172f * (float)base.Height / 260f, base.Width, 86f * (float)base.Height / 260f));
		float scale = Math.Min((float)base.Width / 1600f, (float)base.Height / 260f);
		float radius = (13f + progress * 92f) * Math.Max(0.65f, scale);
		int glowAlpha = (int)(85f * fade);
		if (radius > 0f)
		{
			using GraphicsPath path = new GraphicsPath();
			path.AddEllipse(burstCenter.X - radius, burstCenter.Y - radius, radius * 2f, radius * 2f);
			PathGradientBrush pathGradientBrush = new PathGradientBrush(path);
			pathGradientBrush.CenterColor = Color.FromArgb(glowAlpha, 155, 235, 255);
			pathGradientBrush.SurroundColors = new Color[1] { Color.FromArgb(0, 80, 190, 255) };
			using PathGradientBrush glow = pathGradientBrush;
			e.Graphics.FillPath(glow, path);
		}
		for (int i = 0; i < 18; i++)
		{
			float angle = (float)((double)i * Math.PI * 2.0 / 18.0 + (double)(i % 3) * 0.13);
			float distance = (9f + progress * (34f + (float)(i * 17 % 43))) * Math.Max(0.65f, scale);
			float x = burstCenter.X + (float)Math.Cos(angle) * distance;
			float y = burstCenter.Y + (float)Math.Sin(angle) * distance * 0.52f;
			float length = (5f + (float)(i % 4) * 3f) * Math.Max(0.65f, scale) * (0.5f + fade);
			int alpha = Math.Clamp((int)(205f * fade), 0, 255);
			using Pen ray = new Pen(Color.FromArgb(alpha, (i % 3 == 0) ? Color.White : Color.FromArgb(121, 216, 255)), 1.1f + fade);
			e.Graphics.DrawLine(ray, x, y, x + (float)Math.Cos(angle) * length, y + (float)Math.Sin(angle) * length);
			if (i % 3 == 0)
			{
				float r = 1.5f + 1.5f * fade;
				using SolidBrush flake = new SolidBrush(Color.FromArgb(alpha, 207, 245, 255));
				e.Graphics.FillEllipse(flake, x - r, y - r, 2f * r, 2f * r);
			}
		}
		e.Graphics.Restore(state);
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			animation.Stop();
			animation.Dispose();
			tip.Dispose();
		}
		base.Dispose(disposing);
	}
}
