using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;
using MuSven09M.Modules.Character;
using MuSven09M.Modules.Management;
using MuSven09M.Modules.Warehouse;

namespace MuSven09M;

internal sealed class GothicBackendBridge
{
	private readonly Form owner;

	private readonly SqlAccountLookupOptions? options;

	private readonly string configPath;

	private readonly ConcurrentDictionary<string, CharacterEditSnapshot> characterSnapshots = new ConcurrentDictionary<string, CharacterEditSnapshot>(StringComparer.Ordinal);

	private readonly ConcurrentDictionary<string, CurrencyBalanceSnapshot> currencySnapshots = new ConcurrentDictionary<string, CurrencyBalanceSnapshot>(StringComparer.Ordinal);

	private readonly ConcurrentDictionary<string, CharacterCreationDefaults> defaultsSnapshots = new ConcurrentDictionary<string, CharacterCreationDefaults>(StringComparer.Ordinal);

	private readonly ConcurrentDictionary<string, WarehouseSnapshot> warehouseSnapshots = new ConcurrentDictionary<string, WarehouseSnapshot>(StringComparer.Ordinal);

	public GothicBackendBridge(Form owner, SqlAccountLookupOptions? options, string configPath)
	{
		this.owner = owner;
		this.options = options;
		this.configPath = configPath;
	}

	public async Task<object?> DispatchAsync(string method, JsonElement args)
	{
		return method switch
		{
			"getDashboard" => GetDashboard(), 
			"searchAccounts" => await SearchAccountsAsync(args), 
			"listOnlineAccounts" => await ListOnlineAccountsAsync(), 
			"loadAccount" => await LoadAccountAsync(args), 
			"getItemCatalog" => GetItemCatalog(), 
			"getItemOptions" => GetItemOptions(args), 
			"loadCharacterEditor" => await LoadCharacterEditorAsync(args), 
			"saveCharacterEditor" => await SaveCharacterEditorAsync(args), 
			"loadCurrency" => await LoadCurrencyAsync(args), 
			"saveCurrency" => await SaveCurrencyAsync(args), 
			"loadCharacterDefaults" => await LoadCharacterDefaultsAsync(), 
			"saveCharacterDefaults" => await SaveCharacterDefaultsAsync(args), 
			"loadInventory" => await LoadInventoryAsync(args), 
			"saveInventory" => await SaveInventoryAsync(args), 
			"openWarehouse" => OpenWarehouse(args), 
			"openCharacterDelete" => OpenCharacterDelete(args), 
			"openCharacterRename" => OpenCharacterRename(args), 
			"openCharacterInventory" => OpenCharacterInventory(args), 
			"openCharacterQuestCounts" => OpenCharacterQuestCounts(args), 
			"openAccountMembership" => OpenAccountMembership(args), 
			"openAccountProfile" => OpenAccountProfile(args), 
			"openAccountCreate" => OpenAccountCreate(), 
			"openAccountBan" => OpenAccountBan(args), 
			"openAccountUnban" => OpenAccountUnban(args), 
			"openRankingView" => OpenRankingView(), 
			"openSqlBackup" => OpenSqlBackup(), 
			"openDataReset" => OpenDataReset(), 
			_ => throw new InvalidOperationException("Chức năng '" + method + "' chưa được nối với nghiệp vụ hiện có."), 
		};
	}

	private object GetDashboard()
	{
		return new
		{
			configured = (options != null),
			database = (options?.Database ?? string.Empty),
			backupEnabled = SqlBackupOptions.Load(configPath).Enabled,
			accountModerationEnabled = (options != null && SqlAccountLookupOptions.AccountModerationEnabled(configPath)),
			characterDeletionEnabled = (options != null && SqlAccountLookupOptions.CharacterDeletionEnabled(configPath)),
			characterRenameEnabled = (options != null && SqlAccountLookupOptions.CharacterRenameEnabled(configPath)),
			accountLevelEnabled = (options != null && SqlAccountLookupOptions.AccountLevelWritesEnabled(configPath)),
			accountProfileWriteEnabled = (options != null && SqlAccountLookupOptions.AccountProfileWritesEnabled(configPath)),
			accountCreateEnabled = (options != null && SqlAccountLookupOptions.AccountCreationEnabled(configPath)),
			accountBanEnabled = (options != null && SqlAccountLookupOptions.AccountBanEnabled(configPath)),
			characterInventoryEnabled = (options != null && SqlAccountLookupOptions.CharacterInventoryWritesEnabled(configPath)),
			characterQuestCountsEnabled = (options != null && SqlAccountLookupOptions.CharacterQuestCountsEnabled(configPath)),
			rankingWriteEnabled = (options != null && SqlAccountLookupOptions.RankingWritesEnabled(configPath)),
			dataResetEnabled = (options != null && SqlDataResetOptions.Load(configPath).Enabled),
			account = (object)null,
			characters = Array.Empty<object>(),
			servers = Array.Empty<object>(),
			onlineAccounts = Array.Empty<object>(),
			status = ((options == null) ? "SQL chưa cấu hình" : "Chưa tải tài khoản")
		};
	}

	private async Task<object> SearchAccountsAsync(JsonElement args)
	{
		MuSvenDatabase database = RequireDatabase();
		string prefix = StringArg(args, "prefix");
		if (prefix.Length > 10)
		{
			throw new InvalidOperationException("AccountID tối đa 10 ký tự.");
		}
		return new
		{
			accounts = await Task.Run(() => new AccountRepository(database).Search(prefix))
		};
	}

	private async Task<object> ListOnlineAccountsAsync()
	{
		MuSvenDatabase database = RequireDatabase();
		return new
		{
			accounts = await Task.Run(() => new AccountSessionRepository(database).ListOnline())
		};
	}

	private async Task<object> LoadAccountAsync(JsonElement args)
	{
		MuSvenDatabase database = RequireDatabase();
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		return await Task.Run((Func<object>)delegate
		{
			AccountInfo accountInfo = new AccountRepository(database).FindById(accountId) ?? throw new InvalidOperationException("Không tìm thấy tài khoản trong MEMB_INFO.");
			AccountSessionInfo session = new AccountSessionRepository(database).FindByAccountId(accountId);
			IReadOnlyList<CharacterSummary> characters = new CharacterRepository(database).ListByAccount(accountId);
			return new
			{
				account = new
				{
					accountId = accountInfo.AccountId,
					displayName = accountInfo.DisplayName
				},
				session = session,
				characters = characters
			};
		});
	}

	private object GetItemCatalog()
	{
		return ItemCatalog.All.Select(delegate(ItemDefinition item)
		{
			int section = item.Section;
			int id = item.Id;
			int itemIndex = item.ItemIndex;
			int itemIndex2 = item.ItemIndex;
			string name = item.Name;
			string category = item.Category;
			string type;
			switch (item.Section)
			{
			case 0:
				type = "sword";
				break;
			case 1:
				type = "axe";
				break;
			case 2:
				type = "mace";
				break;
			case 3:
				type = "spear";
				break;
			case 4:
				type = "bow";
				break;
			case 5:
				type = "staff";
				break;
			case 6:
				type = "shield";
				break;
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
				type = "armor";
				break;
			case 12:
				type = "wing";
				break;
			default:
				type = "other";
				break;
			}
			return new
			{
				section = section,
				localId = id,
				id = itemIndex,
				itemIndex = itemIndex2,
				name = name,
				category = category,
				type = type,
				width = item.Width,
				height = item.Height,
				size = new int[2] { item.Width, item.Height },
				image = $"/Assets/ItemImages/{item.Section}/{item.Id}.jpg"
			};
		}).ToArray();
	}

	private static object GetItemOptions(JsonElement args)
	{
		int section = IntArg(args, "section");
		var socketOptions = Enumerable.Select(ItemAttributeControls.GetSocketOptions(), ((int Id, string Name) option) => new
		{
			id = option.Id,
			label = option.Name
		}).ToArray();
		var harmonyOptions = Enumerable.Select(ItemAttributeControls.GetHarmonyOptions(section), ((int Id, string Name) option) => new
		{
			id = option.Id,
			label = option.Name
		}).ToArray();
		return new
		{
			excellentOptions = new string[6] { "Zen +40% / Mana÷8", "Phản dame +5% / Speed +7", "Tránh đòn +10% / HP÷8", "Mana +4% / Level÷20", "Giảm sát thương 4% / Damage +2%", "HP +4% / STHH +10%" },
			socketOptions = socketOptions,
			harmonyOptions = harmonyOptions
		};
	}

	private async Task<object> LoadCharacterEditorAsync(JsonElement args)
	{
		MuSvenDatabase database = RequireDatabase();
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		string name = StringArg(args, "name").Trim();
		int length = name.Length;
		if ((length < 1 || length > 10) ? true : false)
		{
			throw new InvalidOperationException("Tên nhân vật phải có từ 1 đến 10 ký tự.");
		}
		CharacterEditSnapshot snapshot = await Task.Run(() => new CharacterEditorRepository(database).Load(accountId, name));
		string token = Guid.NewGuid().ToString("N");
		characterSnapshots[token] = snapshot;
		return new
		{
			token = token,
			accountId = snapshot.AccountId,
			name = snapshot.Name,
			fields = snapshot.Fields,
			notice = snapshot.Notice,
			writeEnabled = SqlAccountLookupOptions.CharacterWritesEnabled(configPath)
		};
	}

	private async Task<object> SaveCharacterEditorAsync(JsonElement args)
	{
		if (!SqlAccountLookupOptions.CharacterWritesEnabled(configPath))
		{
			throw new InvalidOperationException("Sửa nhân vật đang khóa. Cần bật [MUSVEN_CHARACTER_WRITES] sau khi cấp quyền SQL phù hợp.");
		}
		string token = StringArg(args, "token");
		if (!characterSnapshots.TryGetValue(token, out CharacterEditSnapshot snapshot))
		{
			throw new InvalidOperationException("Phiên chỉnh sửa đã hết hạn. Hãy tải lại thông tin nhân vật.");
		}
		Dictionary<string, decimal> changed = ReadDecimalMap(Property(args, "values"));
		if (changed.Count == 0)
		{
			throw new InvalidOperationException("Không có trường nào được thay đổi.");
		}
		string summary = string.Join(Environment.NewLine, changed.Select<KeyValuePair<string, decimal>, string>((KeyValuePair<string, decimal> pair) => "• " + (snapshot.Fields.FirstOrDefault((CharacterField x) => x.Key.Equals(pair.Key, StringComparison.OrdinalIgnoreCase))?.Label ?? pair.Key) + ": " + pair.Value.ToString(CultureInfo.InvariantCulture)));
		if (MessageBox.Show(owner, $"Lưu các thay đổi sau cho {snapshot.Name} (tài khoản {snapshot.AccountId})?\n\n{summary}\n\nTài khoản phải ngoại tuyến. Inventory và kỹ năng không bị sửa.", "MU SVEN • Xác nhận chỉnh sửa nhân vật", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return new
			{
				ok = false,
				cancelled = true
			};
		}
		MuSvenDatabase database = RequireDatabase(readOnly: false);
		int count = await Task.Run(() => new CharacterEditorRepository(database).Save(snapshot, changed));
		characterSnapshots.TryRemove(token, out CharacterEditSnapshot _);
		return new
		{
			ok = true,
			count = count,
			name = snapshot.Name
		};
	}

	private async Task<object> LoadCurrencyAsync(JsonElement args)
	{
		MuSvenDatabase database = RequireDatabase();
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		CurrencyBalanceSnapshot snapshot = await Task.Run(() => new CurrencyRepository(database).Load(accountId));
		string token = Guid.NewGuid().ToString("N");
		currencySnapshots[token] = snapshot;
		return new
		{
			token = token,
			accountId = snapshot.AccountId,
			wcoinC = snapshot.WCoinC,
			wcoinP = snapshot.WCoinP,
			goblinPoint = snapshot.GoblinPoint,
			writeEnabled = SqlAccountLookupOptions.CurrencyWritesEnabled(configPath)
		};
	}

	private async Task<object> SaveCurrencyAsync(JsonElement args)
	{
		if (!SqlAccountLookupOptions.CurrencyWritesEnabled(configPath))
		{
			throw new InvalidOperationException("Sửa tiền/ngọc đang khóa. Cần bật [MUSVEN_CURRENCY_WRITES] sau khi cấp quyền SQL phù hợp.");
		}
		string token = StringArg(args, "token");
		if (!currencySnapshots.TryGetValue(token, out CurrencyBalanceSnapshot original))
		{
			throw new InvalidOperationException("Số dư chưa được tải hoặc phiên đã hết hạn. Hãy tải lại.");
		}
		CurrencyBalanceSnapshot updated = original with
		{
			WCoinC = IntArg(args, "wcoinC"),
			WCoinP = IntArg(args, "wcoinP"),
			GoblinPoint = IntArg(args, "goblinPoint")
		};
		if (MessageBox.Show(owner, "Cập nhật WCoin C/P và Goblin Point cho tài khoản " + original.AccountId + "? Tài khoản phải ngoại tuyến.", "MU SVEN • Xác nhận sửa tiền", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return new
			{
				ok = false,
				cancelled = true
			};
		}
		MuSvenDatabase database = RequireDatabase(readOnly: false);
		await Task.Run(delegate
		{
			new CurrencyRepository(database).Save(original, updated, writesEnabled: true);
		});
		currencySnapshots.TryRemove(token, out CurrencyBalanceSnapshot _);
		return new
		{
			ok = true,
			accountId = original.AccountId
		};
	}

	private async Task<object> LoadCharacterDefaultsAsync()
	{
		MuSvenDatabase database = RequireDatabase();
		CharacterCreationDefaults defaults = await Task.Run(() => new CharacterCreationRepository(database).LoadDefaults());
		string token = Guid.NewGuid().ToString("N");
		defaultsSnapshots[token] = defaults;
		return new
		{
			token = token,
			defaults = defaults,
			writeEnabled = SqlAccountLookupOptions.CharacterCreationEnabled(configPath)
		};
	}

	private async Task<object> SaveCharacterDefaultsAsync(JsonElement args)
	{
		if (!SqlAccountLookupOptions.CharacterCreationEnabled(configPath))
		{
			throw new InvalidOperationException("Cấu hình mặc định đang khóa. Cần bật [MUSVEN_CHARACTER_CREATE] sau khi kiểm tra script V03.");
		}
		string token = StringArg(args, "token");
		if (!defaultsSnapshots.TryGetValue(token, out CharacterCreationDefaults original))
		{
			throw new InvalidOperationException("Chưa tải cấu hình hiện tại hoặc phiên đã hết hạn. Hãy tải lại.");
		}
		JsonElement values = Property(args, "values");
		CharacterCreationDefaults updated = new CharacterCreationDefaults(IntArg(values, "level"), IntArg(values, "points"), IntArg(values, "zen"), IntArg(values, "reset"), IntArg(values, "masterLevel"), IntArg(values, "masterPoints"), IntArg(values, "wcoinC"), IntArg(values, "wcoinP"), IntArg(values, "goblinPoint"));
		updated.Validate();
		if (await Task.Run((Func<CharacterCreationDefaults>)new CharacterCreationRepository(RequireDatabase()).LoadDefaults) != original)
		{
			throw new InvalidOperationException("Cấu hình đã thay đổi sau khi tải. Chưa ghi gì; hãy tải lại rồi thử.");
		}
		if (MessageBox.Show(owner, "Lưu mặc định áp dụng cho nhân vật mới được tạo trong game?", "MU SVEN • Xác nhận cấu hình", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return new
			{
				ok = false,
				cancelled = true
			};
		}
		MuSvenDatabase writeDatabase = RequireDatabase(readOnly: false);
		await Task.Run(delegate
		{
			new CharacterCreationRepository(writeDatabase).SaveDefaults(updated);
		});
		defaultsSnapshots.TryRemove(token, out CharacterCreationDefaults _);
		return new
		{
			ok = true
		};
	}

	private async Task<object> LoadInventoryAsync(JsonElement args)
	{
		MuSvenDatabase database = RequireDatabase();
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		int requestedNumber = IntArg(args, "number", -1);
		bool requestedExtended = BoolArg(args, "isExtended", requestedNumber > 0);
		return await Task.Run((Func<object>)delegate
		{
			WarehouseItemRepository warehouseItemRepository = new WarehouseItemRepository(database);
			IReadOnlyList<WarehouseLocation> readOnlyList = warehouseItemRepository.ListLocations(accountId);
			WarehouseLocation warehouseLocation = readOnlyList.FirstOrDefault((WarehouseLocation x) => x.IsExtended == requestedExtended && x.Number == requestedNumber) ?? readOnlyList.FirstOrDefault();
			if ((object)warehouseLocation == null)
			{
				return new
				{
					accountId = accountId,
					locations = readOnlyList,
					location = (object)null,
					placements = Array.Empty<object>(),
					snapshotToken = string.Empty,
					writeEnabled = false
				};
			}
			WarehouseSnapshot snapshot = warehouseItemRepository.Load(accountId, warehouseLocation);
			IReadOnlyList<WarehousePlacement> source = warehouseItemRepository.DecodePlacements(snapshot.Items);
			string text = Guid.NewGuid().ToString("N");
			warehouseSnapshots[text] = snapshot;
			return new
			{
				accountId = accountId,
				locations = readOnlyList,
				location = warehouseLocation,
				snapshotToken = text,
				writeEnabled = SqlAccountLookupOptions.ItemWritesEnabled(configPath),
				placements = source.Select((WarehousePlacement placement) => new
				{
					slot = placement.Slot,
					catalogId = placement.Item.ItemIndex,
					name = placement.Item.Name,
					width = placement.Item.Width,
					height = placement.Item.Height,
					section = placement.Item.Section,
					id = placement.Item.Id,
					image = $"/Assets/ItemImages/{placement.Item.Section}/{placement.Item.Id}.jpg",
					options = WarehouseItemFormat.DecodeOptions(snapshot.Items.AsSpan(placement.Slot * 16, 16)),
					socketIds = DecodeSocketIds(snapshot.Items.AsSpan(placement.Slot * 16 + 11, 5)),
					socketLevels = DecodeSocketLevels(snapshot.Items.AsSpan(placement.Slot * 16 + 11, 5)),
					socketRaw = snapshot.Items.AsSpan(placement.Slot * 16 + 11, 5).ToArray(),
					harmonyId = snapshot.Items[placement.Slot * 16 + 10] >> 4,
					harmonyLevel = (snapshot.Items[placement.Slot * 16 + 10] & 0xF)
				}).ToArray()
			};
		});
	}

	private async Task<object> SaveInventoryAsync(JsonElement args)
	{
		if (!SqlAccountLookupOptions.ItemWritesEnabled(configPath))
		{
			throw new InvalidOperationException("Ghi vật phẩm đang khóa. Cần bật [MUSVEN_ITEM_WRITES] sau khi cấp quyền SQL phù hợp.");
		}
		string token = StringArg(args, "snapshotToken");
		if (!warehouseSnapshots.TryGetValue(token, out WarehouseSnapshot snapshot))
		{
			throw new InvalidOperationException("Ảnh chụp kho đã hết hạn. Hãy tải lại kho trước khi lưu.");
		}
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		if (!accountId.Equals(snapshot.AccountId, StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("AccountID đã đổi sau khi tải kho. Hãy tải lại kho.");
		}
		IReadOnlyList<WarehouseItemChange> changes = ReadStagedItems(Property(args, "items"));
		if (changes.Count == 0)
		{
			throw new InvalidOperationException("Chưa có thay đổi vật phẩm nào để lưu.");
		}
		int editedCount = changes.Count((WarehouseItemChange change) => change.EditExisting);
		int addedCount = changes.Count - editedCount;
		string target = snapshot.AccountId + " • " + snapshot.Location.DisplayName;
		if (MessageBox.Show(owner, $"Lưu thay đổi kho cho {target}?\n\nThêm mới: {addedCount}\nChỉnh sửa tại chỗ: {editedCount}\n\nMón mới chỉ vào ô trống; món sửa giữ nguyên ItemIndex và serial. Tài khoản phải ngoại tuyến. Giao dịch kiểm tra lại toàn bộ dữ liệu kho trước khi ghi.", "MU SVEN • Xác nhận ghi kho", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return new
			{
				ok = false,
				cancelled = true
			};
		}
		MuSvenDatabase database = RequireDatabase(readOnly: false);
		int count = await Task.Run(() => new WarehouseItemRepository(database).SaveChanges(accountId, snapshot, changes));
		warehouseSnapshots.TryRemove(token, out WarehouseSnapshot _);
		return new
		{
			ok = true,
			count = count,
			addedCount = addedCount,
			editedCount = editedCount,
			target = target
		};
	}

	private object OpenWarehouse(JsonElement args)
	{
		string accountId = StringArg(args, "accountId");
		using WarehouseItemEditorForm editor = new WarehouseItemEditorForm(options ?? new SqlAccountLookupOptions(string.Empty, string.Empty), options != null && SqlAccountLookupOptions.ItemWritesEnabled(configPath), accountId, options != null);
		editor.ShowDialog(owner);
		return new
		{
			ok = true
		};
	}

	private object OpenCharacterDelete(JsonElement args)
	{
		SqlAccountLookupOptions? obj = options ?? throw new InvalidOperationException("SQL chưa được cấu hình.");
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		string name = StringArg(args, "name").Trim();
		int length = name.Length;
		if ((length < 1 || length > 10) ? true : false)
		{
			throw new InvalidOperationException("Tên nhân vật phải có từ 1 đến 10 ký tự.");
		}
		using CharacterDeletionForm form = new CharacterDeletionForm(obj, accountId, name, SqlAccountLookupOptions.CharacterDeletionEnabled(configPath));
		bool deleted = form.ShowDialog(owner) == DialogResult.OK;
		return new
		{
			ok = true,
			deleted = deleted,
			accountId = accountId,
			name = name
		};
	}

	private object OpenCharacterRename(JsonElement args)
	{
		SqlAccountLookupOptions? obj = options ?? throw new InvalidOperationException("SQL chưa được cấu hình.");
		bool renameEnabled = SqlAccountLookupOptions.CharacterRenameEnabled(configPath);
		if (!renameEnabled)
		{
			throw new InvalidOperationException("Đổi tên nhân vật đang khóa. Bật [MUSVEN_CHARACTER_RENAME] Enabled=1 trong Config.ini.");
		}
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		string oldName = StringArg(args, "name").Trim();
		int length = oldName.Length;
		if ((length < 1 || length > 10) ? true : false)
		{
			throw new InvalidOperationException("Tên nhân vật phải có từ 1 đến 10 ký tự.");
		}
		using CharacterRenameForm form = new CharacterRenameForm(obj, accountId, oldName, renameEnabled);
		bool renamed = form.ShowDialog(owner) == DialogResult.OK && form.WasRenamed;
		return new
		{
			ok = true,
			renamed = renamed,
			accountId = accountId,
			oldName = oldName,
			newName = form.NewCharacterName
		};
	}

	private object OpenCharacterInventory(JsonElement args)
	{
		SqlAccountLookupOptions? obj = options ?? throw new InvalidOperationException("SQL chưa được cấu hình.");
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		string name = StringArg(args, "name").Trim();
		int length = name.Length;
		if ((length < 1 || length > 10) ? true : false)
		{
			throw new InvalidOperationException("Tên nhân vật phải có từ 1 đến 10 ký tự.");
		}
		using CharacterInventoryEditorForm form = new CharacterInventoryEditorForm(obj, accountId, name, SqlAccountLookupOptions.CharacterInventoryWritesEnabled(configPath));
		form.ShowDialog(owner);
		return new
		{
			ok = true,
			accountId = accountId,
			name = name
		};
	}

	private object OpenCharacterQuestCounts(JsonElement args)
	{
		SqlAccountLookupOptions? obj = options ?? throw new InvalidOperationException("SQL chưa được cấu hình.");
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		string name = StringArg(args, "name").Trim();
		int length = name.Length;
		if ((length < 1 || length > 10) ? true : false)
		{
			throw new InvalidOperationException("Tên nhân vật phải có từ 1 đến 10 ký tự.");
		}
		bool writeEnabled = SqlAccountLookupOptions.CharacterQuestCountsEnabled(configPath);
		using CharacterQuestKillCountForm form = new CharacterQuestKillCountForm(obj, accountId, name, writeEnabled);
		form.ShowDialog(owner);
		return new
		{
			ok = true,
			saved = form.WasSaved,
			accountId = accountId,
			name = name
		};
	}

	private object OpenAccountMembership(JsonElement args)
	{
		SqlAccountLookupOptions? obj = options ?? throw new InvalidOperationException("SQL chưa được cấu hình.");
		bool writeEnabled = SqlAccountLookupOptions.AccountLevelWritesEnabled(configPath);
		if (!writeEnabled)
		{
			throw new InvalidOperationException("Cập nhật cấp thành viên đang khóa. Bật [MUSVEN_ACCOUNT_LEVEL] Enabled=1 trong Config.ini.");
		}
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		using AccountMembershipForm form = new AccountMembershipForm(obj, accountId, writeEnabled);
		bool updated = form.ShowDialog(owner) == DialogResult.OK && form.WasUpdated;
		return new
		{
			ok = true,
			updated = updated,
			accountId = accountId
		};
	}

	private object OpenAccountUnban(JsonElement args)
	{
		SqlAccountLookupOptions? obj = options ?? throw new InvalidOperationException("SQL chưa được cấu hình.");
		bool writeEnabled = SqlAccountLookupOptions.AccountModerationEnabled(configPath);
		if (!writeEnabled)
		{
			throw new InvalidOperationException("Gỡ khóa đang khóa. Bật [MUSVEN_ACCOUNT_MODERATION] Enabled=1 trong Config.ini sau khi xác minh hợp đồng SQL.");
		}
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		using AccountUnbanForm form = new AccountUnbanForm(obj, accountId, writeEnabled);
		bool unbanned = form.ShowDialog(owner) == DialogResult.OK && form.WasUnbanned;
		return new
		{
			ok = true,
			unbanned = unbanned,
			accountId = accountId,
			accountBansCleared = form.AccountBansCleared,
			characterBansCleared = form.CharacterBansCleared
		};
	}

	private object OpenAccountProfile(JsonElement args)
	{
		SqlAccountLookupOptions? obj = options ?? throw new InvalidOperationException("SQL chưa được cấu hình.");
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		bool writeEnabled = SqlAccountLookupOptions.AccountProfileWritesEnabled(configPath);
		using AccountProfileForm form = new AccountProfileForm(obj, accountId, writeEnabled);
		bool updated = form.ShowDialog(owner) == DialogResult.OK && form.WasUpdated;
		return new
		{
			ok = true,
			updated = updated,
			accountId = accountId
		};
	}

	private object OpenAccountCreate()
	{
		SqlAccountLookupOptions? obj = options ?? throw new InvalidOperationException("SQL chưa được cấu hình.");
		bool writeEnabled = SqlAccountLookupOptions.AccountCreationEnabled(configPath);
		using AccountCreateForm form = new AccountCreateForm(obj, writeEnabled);
		bool created = form.ShowDialog(owner) == DialogResult.OK && form.WasCreated;
		return new
		{
			ok = true,
			created = created,
			accountId = form.CreatedAccountId
		};
	}

	private object OpenAccountBan(JsonElement args)
	{
		SqlAccountLookupOptions? obj = options ?? throw new InvalidOperationException("SQL chưa được cấu hình.");
		bool writeEnabled = SqlAccountLookupOptions.AccountBanEnabled(configPath);
		if (!writeEnabled)
		{
			throw new InvalidOperationException("Khóa tài khoản đang khóa. Bật [MUSVEN_ACCOUNT_BAN] Enabled=1 trong Config.ini.");
		}
		string accountId = RequiredAccount(StringArg(args, "accountId"));
		using AccountBanForm form = new AccountBanForm(obj, accountId, writeEnabled);
		bool banned = form.ShowDialog(owner) == DialogResult.OK && form.WasBanned;
		return new
		{
			ok = true,
			banned = banned,
			accountId = accountId,
			expiresAt = form.BanExpiresAt
		};
	}

	private object OpenRankingView()
	{
		using RankingBrowserForm form = new RankingBrowserForm(options ?? throw new InvalidOperationException("SQL chưa được cấu hình."), SqlAccountLookupOptions.RankingWritesEnabled(configPath));
		form.ShowDialog(owner);
		return new
		{
			ok = true
		};
	}

	private object OpenSqlBackup()
	{
		if (options == null)
		{
			throw new InvalidOperationException("SQL chưa được cấu hình.");
		}
		using SqlBackupForm form = new SqlBackupForm(options, SqlBackupOptions.Load(configPath));
		form.ShowDialog(owner);
		return new
		{
			ok = true
		};
	}

	private object OpenDataReset()
	{
		using SqlDataResetForm form = new SqlDataResetForm(options ?? throw new InvalidOperationException("SQL chưa được cấu hình."), SqlDataResetOptions.Load(configPath), configPath);
		form.ShowDialog(owner);
		return new
		{
			ok = true
		};
	}

	private IReadOnlyList<WarehouseItemChange> ReadStagedItems(JsonElement values)
	{
		if (values.ValueKind != JsonValueKind.Array)
		{
			throw new InvalidOperationException("Danh sách vật phẩm chờ lưu không hợp lệ.");
		}
		List<WarehouseItemChange> result = new List<WarehouseItemChange>();
		foreach (JsonElement item in values.EnumerateArray())
		{
			int itemIndex = IntArg(item, "itemIndex");
			if (!ItemCatalog.ByIndex.TryGetValue(itemIndex, out ItemDefinition definition))
			{
				throw new InvalidOperationException($"ItemIndex {itemIndex} không thuộc danh mục server hiện tại.");
			}
			int optionValue = IntArg(item, "optionValue");
			bool flag = ((optionValue < 0 || optionValue > 28) ? true : false);
			if (flag || optionValue % 4 != 0)
			{
				throw new InvalidOperationException("Option phải là bội số của 4 từ 0 đến 28.");
			}
			JsonElement socketElement = Property(item, "sockets");
			if (socketElement.ValueKind != JsonValueKind.Array || socketElement.GetArrayLength() != 5)
			{
				throw new InvalidOperationException("Vật phẩm cần đúng năm vị trí Socket.");
			}
			byte[] sockets = socketElement.EnumerateArray().Select(delegate(JsonElement value)
			{
				int value2;
				bool flag2 = !value.TryGetInt32(out value2);
				if (!flag2)
				{
					bool flag3 = ((value2 < 0 || value2 > 255) ? true : false);
					flag2 = flag3;
				}
				if (flag2)
				{
					throw new InvalidOperationException("Mã Socket không hợp lệ.");
				}
				return (byte)value2;
			}).ToArray();
			byte excellent = (byte)IntArg(item, "excellent");
			if ((excellent & 0xC0) != 0)
			{
				throw new InvalidOperationException("Excellent chỉ hỗ trợ sáu thuộc tính hiện có.");
			}
			int specialByte = IntArg(item, "harmonyValue");
			bool editExisting = BoolArg(item, "editExisting");
			if (!editExisting && sockets.Any((byte value) => value != byte.MaxValue) && specialByte != 0)
			{
				throw new InvalidOperationException("Vật phẩm Socket dùng byte Harmony cho bonus Socket. Chọn Harmony = None khi tạo vật phẩm Socket.");
			}
			ItemCreationOptions itemOptions = new ItemCreationOptions(IntArg(item, "level"), optionValue / 4, IntArg(item, "durability", 255), BoolArg(item, "skill"), BoolArg(item, "luck"), excellent, IntArg(item, "setOption"), specialByte, sockets);
			result.Add(new WarehouseItemChange(new StagedWarehouseItem(definition, itemOptions, IntArg(item, "slot", -1)), editExisting));
		}
		return result;
	}

	private static int[] DecodeSocketIds(ReadOnlySpan<byte> sockets)
	{
		return (from value in sockets.ToArray()
			select (value < 250 || value > 253) ? ((value < 254) ? (value % 50) : value) : (-value - 1)).ToArray();
	}

	private static int[] DecodeSocketLevels(ReadOnlySpan<byte> sockets)
	{
		return (from value in sockets.ToArray()
			select (value >= 250) ? 1 : Math.Clamp(value / 50 + 1, 1, 5)).ToArray();
	}

	private MuSvenDatabase RequireDatabase(bool readOnly = true)
	{
		if (options == null)
		{
			throw new InvalidOperationException("SQL chưa được cấu hình. Thiết lập [MUSVEN_READ_ONLY] trong Config.ini rồi mở lại ứng dụng.");
		}
		return new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString(readOnly));
	}

	private static string RequiredAccount(string accountId)
	{
		string text = accountId.Trim();
		int length = text.Length;
		if ((length < 1 || length > 10) ? true : false)
		{
			throw new InvalidOperationException("AccountID phải có từ 1 đến 10 ký tự.");
		}
		return text;
	}

	private static JsonElement Property(JsonElement element, string name)
	{
		if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(name, out var value))
		{
			return default(JsonElement);
		}
		return value;
	}

	private static string StringArg(JsonElement element, string name)
	{
		if (Property(element, name).ValueKind != JsonValueKind.String)
		{
			return string.Empty;
		}
		return Property(element, name).GetString() ?? string.Empty;
	}

	private static int IntArg(JsonElement element, string name, int fallback = 0)
	{
		JsonElement value = Property(element, name);
		if (value.ValueKind != JsonValueKind.Number || !value.TryGetInt32(out var parsed))
		{
			return fallback;
		}
		return parsed;
	}

	private static bool BoolArg(JsonElement element, string name, bool fallback = false)
	{
		JsonElement value = Property(element, name);
		JsonValueKind valueKind = value.ValueKind;
		if (valueKind - 5 > JsonValueKind.Object)
		{
			return fallback;
		}
		return value.GetBoolean();
	}

	private static Dictionary<string, decimal> ReadDecimalMap(JsonElement element)
	{
		if (element.ValueKind != JsonValueKind.Object)
		{
			throw new InvalidOperationException("Dữ liệu chỉnh sửa nhân vật không hợp lệ.");
		}
		Dictionary<string, decimal> values = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);
		foreach (JsonProperty property in element.EnumerateObject())
		{
			if (property.Value.ValueKind != JsonValueKind.Number || !property.Value.TryGetDecimal(out var value))
			{
				throw new InvalidOperationException("Giá trị " + property.Name + " phải là số.");
			}
			values.Add(property.Name, value);
		}
		return values;
	}
}
