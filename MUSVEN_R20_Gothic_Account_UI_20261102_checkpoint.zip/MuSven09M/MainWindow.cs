using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;
using MuSven09M.Modules.Character;
using MuSven09M.Modules.Management;
using MuSven09M.Modules.Warehouse;

namespace MuSven09M;

internal sealed class MainWindow : Form
{
	private static readonly Color Bg = Color.FromArgb(11, 17, 27);

	private static readonly Color Sidebar = Color.FromArgb(13, 21, 33);

	private static readonly Color Surface = Color.FromArgb(19, 29, 44);

	private static readonly Color SurfaceRaised = Color.FromArgb(25, 39, 57);

	private static readonly Color Border = Color.FromArgb(43, 59, 78);

	private static readonly Color Gold = Color.FromArgb(237, 190, 95);

	private static readonly Color Ice = Color.FromArgb(132, 193, 216);

	private static readonly Color MainText = Color.FromArgb(231, 237, 244);

	private static readonly Color MutedText = Color.FromArgb(154, 169, 185);

	private static readonly string[] Tabs = new string[7] { "Tài khoản", "Nhân vật", "Vật phẩm", "Kho đồ", "Quản lý", "Công cụ", "Cài đặt" };

	private readonly Panel body = new Panel
	{
		Dock = DockStyle.Fill,
		BackColor = Bg,
		Padding = new Padding(10, 7, 10, 8)
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		TextAlign = ContentAlignment.MiddleLeft,
		ForeColor = MutedText,
		Padding = new Padding(16, 0, 8, 0),
		Text = "SQL chưa cấu hình"
	};

	private readonly Label pageTitle = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = MainText,
		Font = new Font("Segoe UI", 21f, FontStyle.Bold),
		TextAlign = ContentAlignment.BottomLeft
	};

	private readonly Label pageSubtitle = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = MutedText,
		Font = new Font("Segoe UI", 9.5f),
		TextAlign = ContentAlignment.TopLeft
	};

	private readonly Button[] navButtons = new Button[Tabs.Length];

	private string active = Tabs[0];

	private readonly SqlAccountLookupOptions? databaseOptions;

	private readonly string configPath = Path.Combine(AppContext.BaseDirectory, "Config.ini");

	private TextBox? accountSearchBox;

	private TextBox? characterAccountBox;

	private string? selectedAccountId;

	private GothicAdminUiForm? gothicUiWindow;

	public MainWindow()
	{
		Text = "MU SVEN ADMIN - Server 09Q";
		base.StartPosition = FormStartPosition.CenterScreen;
		MinimumSize = new Size(1180, 720);
		base.Size = new Size(1440, 850);
		base.WindowState = FormWindowState.Maximized;
		BackColor = Bg;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 10f);
		DoubleBuffered = true;
		databaseOptions = SqlAccountLookupOptions.Load(configPath);
		if (databaseOptions != null)
		{
			List<string> writeModes = new List<string>();
			if (SqlAccountLookupOptions.AccountModerationEnabled(configPath))
			{
				writeModes.Add("GỠ KHÓA HẾT HẠN BẬT");
			}
			if (SqlAccountLookupOptions.ItemWritesEnabled(configPath))
			{
				writeModes.Add("GHI KHO BẬT");
			}
			if (SqlAccountLookupOptions.CurrencyWritesEnabled(configPath))
			{
				writeModes.Add("SỬA TIỀN/NGỌC BẬT");
			}
			if (SqlAccountLookupOptions.CharacterWritesEnabled(configPath))
			{
				writeModes.Add("SỬA NHÂN VẬT BẬT");
			}
			if (SqlAccountLookupOptions.CharacterCreationEnabled(configPath))
			{
				writeModes.Add("TẠO NHÂN VẬT BẬT");
			}
			if (SqlAccountLookupOptions.CharacterDeletionEnabled(configPath))
			{
				writeModes.Add("XÓA NHÂN VẬT BẬT");
			}
			if (SqlBackupOptions.Load(configPath).Enabled)
			{
				writeModes.Add("BACKUP SQL BẬT");
			}
			status.Text = "MU SVEN 09Q | SQL CHỈ ĐỌC" + ((writeModes.Count == 0) ? string.Empty : (" • " + string.Join(" / ", writeModes))) + " | " + databaseOptions.Database;
		}
		TableLayoutPanel main = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			RowCount = 4,
			ColumnCount = 1,
			Margin = Padding.Empty,
			BackColor = Bg
		};
		main.RowStyles.Add(new RowStyle(SizeType.Absolute, 190f));
		main.RowStyles.Add(new RowStyle(SizeType.Absolute, 78f));
		main.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		main.RowStyles.Add(new RowStyle(SizeType.Absolute, 38f));
		main.Controls.Add(BuildHeroNavigation(), 0, 0);
		main.Controls.Add(BuildPageHeader(), 0, 1);
		main.Controls.Add(body, 0, 2);
		main.Controls.Add(BuildStatusBar(), 0, 3);
		main.Resize += delegate
		{
			main.RowStyles[0].Height = Math.Clamp((float)main.ClientSize.Width * 0.16f, 132f, 220f);
		};
		base.Controls.Add(main);
		Render();
	}

	private Control BuildHeroNavigation()
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(7, 15, 27),
			BackgroundImageLayout = ImageLayout.Stretch
		};
		using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("MuSven.Resources.Assets.banner.jpg"))
		{
			if (stream != null)
			{
				using Image source = Image.FromStream(stream);
				panel.BackgroundImage = new Bitmap(source);
			}
		}
		TableLayoutPanel navigation = new TableLayoutPanel
		{
			BackColor = Sidebar,
			ColumnCount = Tabs.Length,
			RowCount = 1,
			Margin = Padding.Empty,
			Padding = new Padding(3),
			Anchor = (AnchorStyles.Bottom | AnchorStyles.Left)
		};
		for (int i = 0; i < Tabs.Length; i++)
		{
			navigation.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / (float)Tabs.Length));
		}
		string[] labels = new string[7] { "♟  Tài khoản", "♜  Nhân vật", "✦  Vật phẩm", "▣  Kho đồ", "▤  Quản lý", "⚒  Công cụ", "⚙  Cài đặt" };
		for (int j = 0; j < Tabs.Length; j++)
		{
			int selected = j;
			Button button = new Button
			{
				Text = labels[j],
				Dock = DockStyle.Fill,
				FlatStyle = FlatStyle.Flat,
				BackColor = Sidebar,
				ForeColor = MutedText,
				Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
				TextAlign = ContentAlignment.MiddleCenter,
				Cursor = Cursors.Hand,
				Margin = new Padding(2),
				UseVisualStyleBackColor = false
			};
			button.FlatAppearance.BorderColor = Border;
			button.FlatAppearance.BorderSize = 1;
			button.FlatAppearance.MouseOverBackColor = SurfaceRaised;
			button.Click += delegate
			{
				active = Tabs[selected];
				Render();
			};
			navButtons[j] = button;
			navigation.Controls.Add(button, j, 0);
		}
		panel.Controls.Add(navigation);
		panel.Resize += delegate
		{
			PlaceNavigation();
		};
		PlaceNavigation();
		return panel;
		void PlaceNavigation()
		{
			int width = (int)((double)panel.ClientSize.Width * 0.73);
			int height = Math.Max(46, (int)((double)panel.ClientSize.Height * 0.37));
			navigation.SetBounds(0, panel.ClientSize.Height - height, width, height);
		}
	}

	private Control BuildBrandHeader()
	{
		Panel obj = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Sidebar,
			Padding = new Padding(14, 18, 12, 12)
		};
		TableLayoutPanel layout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = Padding.Empty
		};
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 48f));
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		Label mark = new Label
		{
			Text = "MS",
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(48, 42, 30),
			ForeColor = Gold,
			Font = new Font("Segoe UI", 15f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleCenter,
			Margin = new Padding(0, 3, 10, 3)
		};
		TableLayoutPanel brandText = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 2,
			Margin = Padding.Empty
		};
		brandText.RowStyles.Add(new RowStyle(SizeType.Percent, 58f));
		brandText.RowStyles.Add(new RowStyle(SizeType.Percent, 42f));
		brandText.Controls.Add(new Label
		{
			Text = "MUSVEN",
			Dock = DockStyle.Fill,
			ForeColor = MainText,
			Font = new Font("Segoe UI", 14f, FontStyle.Bold),
			TextAlign = ContentAlignment.BottomLeft
		}, 0, 0);
		brandText.Controls.Add(new Label
		{
			Text = "SERVER ADMIN  •  09Q",
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			Font = new Font("Segoe UI", 7.5f, FontStyle.Bold),
			TextAlign = ContentAlignment.TopLeft
		}, 0, 1);
		layout.Controls.Add(mark, 0, 0);
		layout.Controls.Add(brandText, 1, 0);
		obj.Controls.Add(layout);
		return obj;
	}

	private Control BuildNavigation()
	{
		TableLayoutPanel nav = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = Tabs.Length + 1,
			BackColor = Sidebar,
			Padding = new Padding(10, 12, 10, 10),
			Margin = Padding.Empty
		};
		nav.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		nav.RowStyles.Add(new RowStyle(SizeType.Absolute, 34f));
		nav.Controls.Add(new Label
		{
			Text = "CÁC MỤC CHÍNH",
			Dock = DockStyle.Fill,
			ForeColor = MutedText,
			Font = new Font("Segoe UI", 8f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(11, 0, 0, 0)
		}, 0, 0);
		for (int i = 0; i < Tabs.Length; i++)
		{
			nav.RowStyles.Add(new RowStyle(SizeType.Absolute, 48f));
			int selected = i;
			Button button = new Button
			{
				Text = "◆   " + Tabs[i],
				Dock = DockStyle.Fill,
				FlatStyle = FlatStyle.Flat,
				BackColor = Color.Transparent,
				ForeColor = MutedText,
				Font = new Font("Segoe UI", 10f, FontStyle.Bold),
				TextAlign = ContentAlignment.MiddleLeft,
				Padding = new Padding(14, 0, 6, 0),
				Cursor = Cursors.Hand,
				Margin = new Padding(2, 2, 2, 3),
				UseVisualStyleBackColor = false
			};
			button.FlatAppearance.BorderSize = 0;
			button.FlatAppearance.MouseOverBackColor = SurfaceRaised;
			button.Click += delegate
			{
				active = Tabs[selected];
				Render();
			};
			navButtons[i] = button;
			nav.Controls.Add(button, 0, i + 1);
		}
		return nav;
	}

	private Control BuildSidebar()
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Sidebar
		};
		TableLayoutPanel layout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 3,
			Margin = Padding.Empty
		};
		layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 88f));
		layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 92f));
		layout.Controls.Add(BuildBrandHeader(), 0, 0);
		layout.Controls.Add(BuildNavigation(), 0, 1);
		Panel connection = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Sidebar,
			Padding = new Padding(14, 8, 14, 14)
		};
		Panel connectionCard = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			Padding = new Padding(10, 8, 10, 8)
		};
		TableLayoutPanel connectionLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 2,
			Margin = Padding.Empty
		};
		connectionLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 22f));
		connectionLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		connectionLayout.Controls.Add(new Label
		{
			Text = ((databaseOptions == null) ? "KẾT NỐI SQL" : "DATABASE ĐANG CHỌN"),
			Dock = DockStyle.Fill,
			ForeColor = MutedText,
			Font = new Font("Segoe UI", 7.5f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		connectionLayout.Controls.Add(new Label
		{
			Text = ((databaseOptions == null) ? "Chưa cấu hình" : (databaseOptions.Database + "  •  chỉ đọc")),
			Dock = DockStyle.Fill,
			ForeColor = ((databaseOptions == null) ? Gold : Ice),
			Font = new Font("Segoe UI", 9f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft,
			AutoEllipsis = true
		}, 0, 1);
		connectionCard.Controls.Add(connectionLayout);
		connection.Controls.Add(connectionCard);
		layout.Controls.Add(connection, 0, 2);
		panel.Controls.Add(layout);
		panel.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border);
			e.Graphics.DrawLine(pen, panel.Width - 1, 0, panel.Width - 1, panel.Height);
		};
		return panel;
	}

	private Control BuildPageHeader()
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Bg,
			Padding = new Padding(20, 12, 20, 10)
		};
		TableLayoutPanel layout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = Padding.Empty
		};
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 144f));
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 184f));
		TableLayoutPanel titleLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 2,
			Margin = Padding.Empty
		};
		titleLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 59f));
		titleLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 41f));
		titleLayout.Controls.Add(pageTitle, 0, 0);
		titleLayout.Controls.Add(pageSubtitle, 0, 1);
		Button checkSql = Action("KIỂM TRA KẾT NỐI", enabled: true, gold: true);
		checkSql.Margin = new Padding(8, 8, 0, 8);
		checkSql.Click += async delegate
		{
			await CheckSqlConnectionAsync();
		};
		Button gothicUi = Action("GOTHIC UI");
		gothicUi.Margin = new Padding(8, 8, 0, 8);
		gothicUi.Click += delegate
		{
			OpenGothicUi();
		};
		layout.Controls.Add(titleLayout, 0, 0);
		layout.Controls.Add(gothicUi, 1, 0);
		layout.Controls.Add(checkSql, 2, 0);
		panel.Controls.Add(layout);
		panel.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border);
			e.Graphics.DrawLine(pen, 18, panel.Height - 1, panel.Width - 18, panel.Height - 1);
		};
		return panel;
	}

	private void OpenGothicUi()
	{
		if (gothicUiWindow != null && !gothicUiWindow.IsDisposed)
		{
			if (gothicUiWindow.WindowState == FormWindowState.Minimized)
			{
				gothicUiWindow.WindowState = FormWindowState.Maximized;
			}
			gothicUiWindow.BringToFront();
		}
		else
		{
			gothicUiWindow = new GothicAdminUiForm(databaseOptions, configPath);
			gothicUiWindow.FormClosed += delegate
			{
				gothicUiWindow = null;
			};
			gothicUiWindow.Show(this);
		}
	}

	private Control BuildStatusBar()
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(15, 23, 35),
			Padding = new Padding(4, 0, 12, 0)
		};
		panel.Controls.Add(status);
		panel.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border);
			e.Graphics.DrawLine(pen, 0, 0, panel.Width, 0);
		};
		return panel;
	}

	private void UpdateNavigation()
	{
		int activeIndex = Array.IndexOf(Tabs, active);
		for (int i = 0; i < navButtons.Length; i++)
		{
			bool selected = i == activeIndex;
			navButtons[i].BackColor = (selected ? Color.FromArgb(52, 56, 43) : Sidebar);
			navButtons[i].ForeColor = (selected ? Gold : MutedText);
			navButtons[i].FlatAppearance.BorderSize = ((!selected) ? 1 : 2);
			navButtons[i].FlatAppearance.BorderColor = (selected ? Gold : Border);
			navButtons[i].Invalidate();
		}
	}

	private void UpdatePageHeader()
	{
		pageTitle.Text = active;
		Label label = pageSubtitle;
		label.Text = active switch
		{
			"Tài khoản" => "Tra cứu tài khoản, phiên đăng nhập và nhân vật liên quan", 
			"Nhân vật" => "Tìm nhân vật, cấu hình quà tạo mới và chỉnh thông tin an toàn", 
			"Vật phẩm" => "Tra danh mục server và tính ItemIndex nhanh", 
			"Kho đồ" => "Xem kho, ngân hàng ngọc và số dư tài khoản", 
			"Quản lý" => "Các trang quản trị và tra cứu dữ liệu server", 
			"Công cụ" => "Tiện ích vận hành có kiểm soát", 
			"Cài đặt" => "Kết nối SQL, quyền ghi và kiểm tra schema", 
			_ => "Bảng điều khiển MUSVEN", 
		};
	}

	private static Panel Frame(string heading)
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			Margin = new Padding(6),
			Padding = new Padding(14, 48, 14, 14)
		};
		panel.Resize += delegate
		{
			SetRoundedRegion(panel, 9);
		};
		Label title = new Label
		{
			Text = heading.ToUpperInvariant(),
			Location = new Point(14, 7),
			Size = new Size(360, 34),
			Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right),
			ForeColor = Gold,
			Font = new Font("Segoe UI", 9.5f, FontStyle.Bold)
		};
		panel.Controls.Add(title);
		StyleCard(panel);
		return panel;
	}

	private static void StyleCard(Panel panel)
	{
		panel.Resize += delegate
		{
			SetRoundedRegion(panel, 9);
		};
		panel.Paint += delegate(object? _, PaintEventArgs e)
		{
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			using Pen pen = new Pen(Border, 1f);
			using GraphicsPath path = RoundedPath(new Rectangle(0, 0, Math.Max(1, panel.Width - 1), Math.Max(1, panel.Height - 1)), 9);
			e.Graphics.DrawPath(pen, path);
		};
	}

	private static GraphicsPath RoundedPath(Rectangle bounds, int radius)
	{
		int diameter = Math.Max(1, Math.Min(radius * 2, Math.Min(bounds.Width, bounds.Height)));
		GraphicsPath graphicsPath = new GraphicsPath();
		graphicsPath.AddArc(bounds.Left, bounds.Top, diameter, diameter, 180f, 90f);
		graphicsPath.AddArc(bounds.Right - diameter, bounds.Top, diameter, diameter, 270f, 90f);
		graphicsPath.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0f, 90f);
		graphicsPath.AddArc(bounds.Left, bounds.Bottom - diameter, diameter, diameter, 90f, 90f);
		graphicsPath.CloseFigure();
		return graphicsPath;
	}

	private static void SetRoundedRegion(Control control, int radius)
	{
		if (control.Width >= radius * 2 && control.Height >= radius * 2)
		{
			Region? region = control.Region;
			control.Region = new Region(RoundedPath(new Rectangle(0, 0, control.Width, control.Height), radius));
			region?.Dispose();
		}
	}

	private static Button Action(string text, bool enabled = true, bool gold = false)
	{
		Button obj = new Button
		{
			Text = text,
			Height = 37,
			Dock = DockStyle.Fill,
			FlatStyle = FlatStyle.Flat,
			Margin = new Padding(3),
			Font = new Font("Segoe UI", 9f, FontStyle.Bold),
			UseVisualStyleBackColor = false
		};
		SetActionState(obj, enabled, gold);
		return obj;
	}

	private static void SetActionState(Button button, bool enabled, bool gold = false)
	{
		button.Enabled = enabled;
		button.BackColor = ((!enabled) ? Color.FromArgb(30, 42, 57) : (gold ? Gold : Color.FromArgb(28, 68, 103)));
		button.ForeColor = ((!enabled) ? MutedText : (gold ? Color.Black : MainText));
		button.Cursor = (enabled ? Cursors.Hand : Cursors.Default);
		button.FlatAppearance.BorderSize = ((!(enabled && gold)) ? 1 : 0);
		button.FlatAppearance.BorderColor = ((enabled && gold) ? Gold : Border);
		button.FlatAppearance.MouseOverBackColor = ((!enabled) ? button.BackColor : (gold ? Color.FromArgb(255, 214, 119) : Color.FromArgb(37, 87, 128)));
		button.UseVisualStyleBackColor = false;
	}

	private Control BuildQuickActions(params (string label, string feature)[] actions)
	{
		int columns = Math.Min(actions.Length, (actions.Length > 4) ? 6 : 4);
		int rows = (actions.Length + columns - 1) / columns;
		TableLayoutPanel row = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = columns,
			RowCount = rows,
			Margin = Padding.Empty
		};
		for (int column = 0; column < columns; column++)
		{
			row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / (float)columns));
		}
		for (int r = 0; r < rows; r++)
		{
			row.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / (float)rows));
		}
		for (int i = 0; i < actions.Length; i++)
		{
			(string label, string feature) action = actions[i];
			Button button = Action(action.label, IsNativeFeatureAvailable(action.feature));
			ToolTip tooltip = new ToolTip();
			tooltip.SetToolTip(button, IsNativeFeatureAvailable(action.feature) ? "Mở mục tương ứng trong giao diện Musven." : "Tác vụ ghi đang khóa cho đến khi schema và quyền SQL được xác nhận.");
			button.Disposed += delegate
			{
				tooltip.Dispose();
			};
			button.Click += delegate
			{
				OpenMusvenFeature(action.feature);
			};
			row.Controls.Add(button, i % columns, i / columns);
		}
		return row;
	}

	private static TextBox Field(string value = "", bool readOnly = true)
	{
		return new TextBox
		{
			Text = value,
			ReadOnly = readOnly,
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(22, 36, 54),
			ForeColor = MainText,
			BorderStyle = BorderStyle.FixedSingle,
			Font = new Font("Segoe UI", 10f),
			Margin = new Padding(4, 6, 4, 6)
		};
	}

	private static TableLayoutPanel Rows(int count)
	{
		TableLayoutPanel t = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = count,
			Margin = Padding.Empty
		};
		for (int i = 0; i < count; i++)
		{
			t.RowStyles.Add(new RowStyle((i != count - 1) ? SizeType.Absolute : SizeType.Percent, (i == count - 1) ? 100 : 43));
		}
		return t;
	}

	private static ListBox List(params string[] values)
	{
		ListBox obj = new ListBox
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			ForeColor = MainText,
			BorderStyle = BorderStyle.None,
			Font = new Font("Segoe UI", 10.5f),
			IntegralHeight = false
		};
		obj.Items.AddRange(values);
		return obj;
	}

	private void Render()
	{
		UpdateNavigation();
		UpdatePageHeader();
		Control[] array = body.Controls.Cast<Control>().ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].Dispose();
		}
		body.Controls.Clear();
		if (active == "Nhân vật")
		{
			RenderCharacterPage();
			UiTheme.ApplyToChildren(body.Controls);
		}
		else if (active == "Vật phẩm")
		{
			RenderItemIndexPage();
			UiTheme.ApplyToChildren(body.Controls);
		}
		else if (active == "Kho đồ")
		{
			RenderWarehousePage();
			UiTheme.ApplyToChildren(body.Controls);
		}
		else if (active == "Quản lý")
		{
			RenderFeatureHub("Quản lý", "Nhóm theo dữ liệu quản trị. Các nút đang hoạt động mở trang Musven tương ứng; chức năng ghi chờ bật quyền quản trị an toàn.", new(string, string, string, string)[6]
			{
				("Tài khoản", "Tra cứu trong danh sách tài khoản. Sửa, khóa và xóa chỉ bật khi có quyền ghi được cấu hình riêng.", "MỞ TRANG TÀI KHOẢN", "account-page"),
				("Nhân vật", "Tìm nhân vật theo tài khoản; các trường đọc dựa trên schema thực tế của dbo.Character.", "MỞ TRANG NHÂN VẬT", "character-page"),
				("Tiền tệ / ngân hàng ngọc", "WCoin, Goblin Point và 10 loại ngọc đọc từ CashShopData/DATDAT_BANK; ghi có cờ riêng.", "MỞ TRANG KHO ĐỒ", "warehouse-page"),
				("Xếp hạng / sự kiện", "Xem các bảng ranking và sự kiện đã có; truy vấn chỉ đọc, giới hạn 100 dòng. Xóa/reset vẫn khóa.", "MỞ BẢNG / SỰ KIỆN", "ranking-view"),
				("Công thành / máy chủ", "Công cụ quản lý máy chủ cần bảng/cấu hình vận hành riêng.", "CHƯA BẬT", "pending-server"),
				("VIP / mốc nạp", "Chưa bật vì chưa có schema các cột tùy biến trên Muonline.", "CHƯA BẬT", "pending-custom")
			});
			UiTheme.ApplyToChildren(body.Controls);
		}
		else if (active == "Công cụ")
		{
			RenderFeatureHub("Công cụ", "Công cụ được nhóm riêng để tránh nhầm lệnh vận hành với chức năng quản trị thường ngày.", new(string, string, string, string)[6]
			{
				("ItemIndex", "Tính Type × 512 + ID ngay trong Musven, không cần kết nối SQL.", "MỞ CÔNG CỤ ITEMINDEX", "item-page"),
				("Sao lưu SQL", "Tạo bản COPY_ONLY, CHECKSUM và xác minh media; cần quyền BACKUP và thư mục trên SQL Server.", "MỞ SAO LƯU SQL", "sql-backup"),
				("Sao lưu tự động", "Chưa bật; cần cấu hình lịch chạy bền vững ngoài vòng đời của Musven.", "CHƯA BẬT", "pending-backup-auto"),
				("Dọn log", "Lệnh thay đổi file database/log cần bản sao lưu và cấu hình an toàn riêng.", "CHƯA BẬT", "pending-log"),
				("Xóa trắng dữ liệu server", "Xem trước số dòng; backup + VERIFYONLY trước khi xóa tài khoản, nhân vật, kho, tiền, guild, sự kiện và ranking. Giữ bảy bảng cấu hình sau migration V03.", "MỞ KIỂM TRA / XÓA TRẮNG", "data-reset"),
				("Thu hồi dung lượng file SQL", "Chưa bật thao tác shrink log/file vì cần quy trình sao lưu và kiểm tra dung lượng riêng.", "CHƯA BẬT", "pending-log-shrink")
			});
			UiTheme.ApplyToChildren(body.Controls);
		}
		else if (active == "Cài đặt")
		{
			RenderSettingsPage();
			UiTheme.ApplyToChildren(body.Controls);
		}
		else
		{
			if (active != "Tài khoản")
			{
				return;
			}
			TableLayoutPanel grid = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 4,
				RowCount = 1,
				Margin = Padding.Empty
			};
			grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20f));
			grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18f));
			grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 23f));
			grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 39f));
			body.Controls.Add(grid);
			Panel accounts = Frame("Danh sách tài khoản");
			TableLayoutPanel aLayout = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 1,
				RowCount = 4,
				Margin = Padding.Empty
			};
			aLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
			aLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
			aLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 50f));
			aLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
			TextBox search = Field("", readOnly: false);
			accountSearchBox = search;
			search.PlaceholderText = ((databaseOptions == null) ? "Cấu hình SQL để tìm tài khoản" : "Nhập tiền tố ID / để trống xem danh sách");
			ListBox accountList = List();
			accountList.DisplayMember = "DisplayText";
			TableLayoutPanel searchRow = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 2,
				RowCount = 1,
				Margin = Padding.Empty
			};
			searchRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 68f));
			searchRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32f));
			Button lookupButton = Action("TÌM", databaseOptions != null, gold: true);
			searchRow.Controls.Add(search, 0, 0);
			searchRow.Controls.Add(lookupButton, 1, 0);
			aLayout.Controls.Add(searchRow, 0, 0);
			Label hint = new Label
			{
				Text = ((databaseOptions == null) ? "CHƯA CẤU HÌNH • Không hiển thị dữ liệu mẫu" : ("CHỈ ĐỌC • " + databaseOptions.Database)),
				Dock = DockStyle.Fill,
				ForeColor = Ice,
				TextAlign = ContentAlignment.MiddleLeft,
				Font = new Font("Segoe UI", 8f)
			};
			aLayout.Controls.Add(hint, 0, 1);
			aLayout.Controls.Add(BuildQuickActions(("Tạo", "account-add"), ("Xóa", "account-delete"), ("Sửa", "account-edit")), 0, 2);
			aLayout.Controls.Add(accountList, 0, 3);
			Panel sessionPanel = new Panel
			{
				Dock = DockStyle.Fill,
				BackColor = Color.FromArgb(8, 20, 35),
				Padding = new Padding(8, 4, 8, 2),
				Margin = new Padding(0, 4, 0, 0)
			};
			TableLayoutPanel sessionLayout = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 1,
				RowCount = 2,
				Margin = Padding.Empty
			};
			sessionLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 25f));
			sessionLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
			Label sessionStatus = new Label
			{
				Text = "TRẠNG THÁI TÀI KHOẢN",
				Dock = DockStyle.Fill,
				ForeColor = Gold,
				Font = new Font("Segoe UI", 8f, FontStyle.Bold),
				TextAlign = ContentAlignment.MiddleLeft
			};
			Label sessionDetails = new Label
			{
				Text = "Chọn tài khoản để tải phiên đăng nhập.",
				Dock = DockStyle.Fill,
				ForeColor = Color.Gainsboro,
				Font = new Font("Segoe UI", 8f),
				TextAlign = ContentAlignment.MiddleLeft,
				AutoEllipsis = true
			};
			sessionLayout.Controls.Add(sessionStatus, 0, 0);
			sessionLayout.Controls.Add(sessionDetails, 0, 1);
			sessionPanel.Controls.Add(sessionLayout);
			lookupButton.Click += async delegate
			{
				if (databaseOptions == null)
				{
					hint.Text = "Mở Cài đặt và khai báo SQL trước.";
					return;
				}
				SetActionState(lookupButton, enabled: false, gold: true);
				hint.Text = "ĐANG TRA CỨU...";
				accountList.Items.Clear();
				try
				{
					SqlAccountLookupOptions options = databaseOptions;
					string connectionString = options.CreateConnectionString();
					IReadOnlyList<AccountInfo> matches = await Task.Run(() => new AccountRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).Search(search.Text.Trim()));
					foreach (AccountInfo account in matches)
					{
						accountList.Items.Add(account);
					}
					if (matches.Count == 0)
					{
						hint.Text = "Không tìm thấy tài khoản phù hợp.";
						status.Text = "SQL LOOKUP • READ-ONLY | " + options.Database + " | 0 KẾT QUẢ";
					}
					else
					{
						hint.Text = $"TẢI {matches.Count} TÀI KHOẢN • Tối đa 200";
						status.Text = "SQL LOOKUP • READ-ONLY | " + options.Database + " | " + matches.Count + " KẾT QUẢ";
						accountList.SelectedIndex = 0;
					}
				}
				catch (Exception ex)
				{
					hint.Text = "Tra cứu thất bại. Kiểm tra cấu hình/kết nối SQL.";
					status.Text = "SQL LOOKUP ERROR | READ-ONLY";
					string detail = ex.GetBaseException().Message;
					if (detail.Length > 500)
					{
						detail = detail.Substring(0, 500) + "…";
					}
					MessageBox.Show("Tra cứu không thành công. Chi tiết SQL: " + detail + "\n\nKhông hiển thị mật khẩu hoặc chuỗi kết nối.", "MU SVEN • Tra cứu SQL", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				finally
				{
					SetActionState(lookupButton, databaseOptions != null, gold: true);
				}
			};
			search.KeyDown += delegate(object? _, KeyEventArgs e)
			{
				if (e.KeyCode == Keys.Return)
				{
					e.SuppressKeyPress = true;
					lookupButton.PerformClick();
				}
			};
			accounts.Controls.Add(aLayout);
			grid.Controls.Add(accounts, 0, 0);
			Panel chars = Frame("Danh sách nhân vật");
			TableLayoutPanel cLayout = Rows(4);
			cLayout.Controls.Add(new Label
			{
				Text = "Nhân vật của tài khoản đã chọn",
				Dock = DockStyle.Fill,
				ForeColor = Ice,
				TextAlign = ContentAlignment.MiddleLeft
			}, 0, 0);
			ListBox charList = List();
			charList.DisplayMember = "Name";
			cLayout.Controls.Add(BuildQuickActions(("Tạo", "char-add"), ("Xóa", "char-delete"), ("Sửa", "char-edit"), ("Tìm", "char-find")), 0, 2);
			cLayout.Controls.Add(charList, 0, 3);
			Label cHint = new Label
			{
				Text = ((databaseOptions == null) ? "Cấu hình SQL để tải nhân vật" : "Chọn tài khoản để tải nhân vật"),
				Dock = DockStyle.Fill,
				ForeColor = Gold,
				TextAlign = ContentAlignment.MiddleLeft,
				Font = new Font("Segoe UI", 9f)
			};
			cLayout.Controls.Add(cHint, 0, 1);
			chars.Controls.Add(cLayout);
			grid.Controls.Add(chars, 1, 0);
			Panel characterInfo = Frame("Thông tin nhân vật");
			TableLayoutPanel infoLayout = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 2,
				RowCount = 7,
				Margin = Padding.Empty,
				Padding = new Padding(4, 0, 4, 4)
			};
			infoLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 39f));
			infoLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 61f));
			for (int i2 = 0; i2 < 6; i2++)
			{
				infoLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 47f));
			}
			infoLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
			string[] infoLabels = new string[6] { "Tài khoản", "Nhân vật", "Level", "Reset", "Zen", "Điểm dư" };
			TextBox[] infoValues = (from _ in Enumerable.Range(0, infoLabels.Length)
				select Field("—")).ToArray();
			for (int i3 = 0; i3 < infoLabels.Length; i3++)
			{
				infoLayout.Controls.Add(new Label
				{
					Text = infoLabels[i3],
					Dock = DockStyle.Fill,
					ForeColor = Gold,
					Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
					TextAlign = ContentAlignment.MiddleLeft
				}, 0, i3);
				infoLayout.Controls.Add(infoValues[i3], 1, i3);
			}
			infoLayout.Controls.Add(sessionPanel, 0, 6);
			infoLayout.SetColumnSpan(sessionPanel, 2);
			characterInfo.Controls.Add(infoLayout);
			grid.Controls.Add(characterInfo, 2, 0);
			int accountSelectionVersion = 0;
			accountList.SelectedIndexChanged += async delegate
			{
				int selectionVersion = ++accountSelectionVersion;
				object selectedItem = accountList.SelectedItem;
				AccountInfo selected = selectedItem as AccountInfo;
				if ((object)selected == null)
				{
					selectedAccountId = null;
					charList.Items.Clear();
					cHint.Text = "Chọn tài khoản để tải nhân vật";
					sessionStatus.Text = "TRẠNG THÁI TÀI KHOẢN";
					sessionStatus.ForeColor = Gold;
					sessionDetails.Text = "Chọn tài khoản để tải phiên đăng nhập.";
					return;
				}
				selectedAccountId = selected.AccountId;
				charList.Items.Clear();
				cHint.Text = "ĐANG TẢI NHÂN VẬT...";
				sessionStatus.Text = "TRẠNG THÁI TÀI KHOẢN • ĐANG TẢI";
				sessionStatus.ForeColor = Gold;
				sessionDetails.Text = "Đang đọc dbo.MEMB_STAT...";
				string connectionString = databaseOptions.CreateConnectionString();
				Task<AccountSessionInfo> sessionTask = Task.Run(() => new AccountSessionRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).FindByAccountId(selected.AccountId));
				try
				{
					IReadOnlyList<CharacterSummary> found = await Task.Run(() => new CharacterRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).ListByAccount(selected.AccountId));
					if (selectionVersion != accountSelectionVersion || !(accountList.SelectedItem is AccountInfo currentAccount) || !currentAccount.AccountId.Equals(selected.AccountId, StringComparison.OrdinalIgnoreCase))
					{
						return;
					}
					foreach (CharacterSummary character in found)
					{
						charList.Items.Add(character);
					}
					cHint.Text = ((found.Count == 0) ? "Tài khoản này chưa có nhân vật." : $"{found.Count} NHÂN VẬT • chỉ đọc");
					if (found.Count > 0)
					{
						charList.SelectedIndex = 0;
					}
				}
				catch
				{
					if (selectionVersion == accountSelectionVersion)
					{
						cHint.Text = "Không tải được danh sách. Kiểm tra quyền SELECT/schema dbo.Character.";
					}
				}
				try
				{
					AccountSessionInfo session = await sessionTask;
					if (selectionVersion == accountSelectionVersion && accountList.SelectedItem is AccountInfo current && current.AccountId.Equals(selected.AccountId, StringComparison.OrdinalIgnoreCase))
					{
						if ((object)session == null)
						{
							sessionStatus.Text = "TRẠNG THÁI TÀI KHOẢN • CHƯA CÓ DÒNG MEMB_STAT";
							sessionDetails.Text = "Không tìm thấy phiên đăng nhập cho tài khoản này.";
						}
						else
						{
							sessionStatus.Text = "TRẠNG THÁI TÀI KHOẢN • " + session.StatusText;
							sessionStatus.ForeColor = ((session.ConnectStat == 1) ? Color.FromArgb(103, 240, 170) : Gold);
							sessionDetails.Text = session.DetailText;
						}
					}
				}
				catch
				{
					if (selectionVersion == accountSelectionVersion && accountList.SelectedItem is AccountInfo current2 && current2.AccountId.Equals(selected.AccountId, StringComparison.OrdinalIgnoreCase))
					{
						sessionStatus.Text = "TRẠNG THÁI TÀI KHOẢN • CHƯA ĐỌC ĐƯỢC";
						sessionStatus.ForeColor = Gold;
						sessionDetails.Text = "Cần quyền SELECT dbo.MEMB_STAT và các cột trạng thái đã xác nhận.";
					}
				}
			};
			Panel equipment = Frame("Nhân vật & trang bị");
			TableLayoutPanel equipLayout = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				RowCount = 3,
				ColumnCount = 1
			};
			equipLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 38f));
			equipLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
			equipLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 126f));
			TableLayoutPanel previewHeader = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 2,
				RowCount = 1,
				Margin = new Padding(4, 2, 4, 2)
			};
			previewHeader.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
			previewHeader.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145f));
			Label previewTitle = new Label
			{
				Text = "MẪU 3D • CHỈ XEM, KHÔNG ĐỔI TRANG BỊ GAME",
				ForeColor = Gold,
				TextAlign = ContentAlignment.MiddleLeft,
				Dock = DockStyle.Fill,
				Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
				AutoEllipsis = true
			};
			previewHeader.Controls.Add(previewTitle, 0, 0);
			charList.SelectedIndexChanged += delegate
			{
				if (!(charList.SelectedItem is CharacterSummary characterSummary))
				{
					TextBox[] array2 = infoValues;
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j].Text = "—";
					}
					previewTitle.Text = "MẪU 3D • chọn nhân vật để xem thông tin";
				}
				else
				{
					infoValues[0].Text = selectedAccountId ?? "—";
					infoValues[1].Text = characterSummary.Name;
					infoValues[2].Text = characterSummary.Level?.ToString("N0") ?? "—";
					infoValues[3].Text = characterSummary.ResetCount?.ToString("N0") ?? "—";
					infoValues[4].Text = characterSummary.Zen?.ToString("N0") ?? "—";
					infoValues[5].Text = characterSummary.Points?.ToString("N0") ?? "—";
					previewTitle.Text = "MẪU 3D • mô hình mẫu, chưa đồng bộ trang bị nhân vật";
				}
			};
			equipLayout.Controls.Add(previewHeader, 0, 0);
			MuSvenGlbViewer portrait = new MuSvenGlbViewer
			{
				Dock = DockStyle.Fill,
				Margin = new Padding(8)
			};
			equipLayout.Controls.Add(portrait, 0, 1);
			ComboBox setPicker = new ComboBox
			{
				DropDownStyle = ComboBoxStyle.DropDownList,
				Width = 150,
				BackColor = Color.FromArgb(12, 25, 45),
				ForeColor = Color.White,
				Font = new Font("Segoe UI", 9f, FontStyle.Bold)
			};
			setPicker.Items.AddRange(new object[2] { "Bronze", "Group 02" });
			setPicker.SelectedIndex = 0;
			previewHeader.Controls.Add(setPicker, 1, 0);
			List<EquipmentSlot> previewSlots = new List<EquipmentSlot>();
			portrait.ViewerReady += delegate
			{
				setPicker.Enabled = true;
				foreach (EquipmentSlot item in previewSlots)
				{
					item.Enabled = true;
				}
			};
			setPicker.Enabled = false;
			setPicker.SelectedIndexChanged += async delegate
			{
				try
				{
					if (!(await portrait.SwitchEquipmentSetAsync((setPicker.SelectedIndex == 1) ? "group02" : "bronze")))
					{
						previewTitle.Text = "Mô hình 3D đang tải; hãy thử lại sau.";
					}
					else
					{
						foreach (EquipmentSlot item2 in previewSlots)
						{
							item2.SetPreviewVisible(visible: true);
						}
						previewTitle.Text = "MẪU 3D • CHỈ XEM, KHÔNG ĐỔI TRANG BỊ GAME";
					}
				}
				catch (Exception ex)
				{
					previewTitle.Text = "Không đổi được mô hình: " + ex.Message;
				}
			};
			TableLayoutPanel slots = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 3,
				RowCount = 3,
				Margin = new Padding(5)
			};
			foreach (int item3 in Enumerable.Range(0, 3))
			{
				_ = item3;
				slots.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
				slots.RowStyles.Add(new RowStyle(SizeType.Percent, 33.33f));
			}
			string[] items = new string[9] { "Vũ khí", "Mũ", "Cánh", "Giáp", "Găng", "Quần", "Giày", "Nhẫn", "Dây chuyền" };
			for (int i4 = 0; i4 < items.Length; i4++)
			{
				EquipmentSlot slot = new EquipmentSlot(items[i4])
				{
					Dock = DockStyle.Fill,
					Margin = new Padding(3)
				};
				string part = items[i4] switch
				{
					"Vũ khí" => "weapon", 
					"Mũ" => "helm", 
					"Cánh" => "wings", 
					"Giáp" => "armor", 
					"Găng" => "glove", 
					"Quần" => "pant", 
					"Giày" => "boot", 
					"Nhẫn" => "ring", 
					"Dây chuyền" => "necklace", 
					_ => null, 
				};
				if (part != null)
				{
					slot.Enable3DToggle = true;
					slot.Enabled = false;
					slot.SetPreviewVisible(visible: true);
					previewSlots.Add(slot);
					string selectedPart = part;
					slot.Click += async delegate
					{
						try
						{
							if (!(await portrait.ToggleEquipmentAsync(selectedPart)))
							{
								previewTitle.Text = "Mesh này chưa sẵn sàng trong mô hình.";
							}
							else
							{
								slot.SetPreviewVisible(!slot.PreviewVisible);
								previewTitle.Text = "Preview: " + slot.PreviewStateText + " • không đổi nhân vật game";
							}
						}
						catch (Exception ex)
						{
							previewTitle.Text = "Lỗi mô hình 3D: " + ex.Message;
						}
					};
				}
				else
				{
					slot.SetUnavailableHint("Chưa có mesh");
					slot.Enabled = false;
				}
				ToolTip toolTip = new ToolTip();
				toolTip.InitialDelay = 200;
				toolTip.SetToolTip(slot, (part == null) ? (items[i4] + " • chưa có mesh trong mô hình mẫu") : (items[i4] + " • bật/tắt mesh xem trước; không thay đổi trang bị nhân vật trong game"));
				slots.Controls.Add(slot, i4 % 3, i4 / 3);
			}
			equipLayout.Controls.Add(slots, 0, 2);
			equipment.Controls.Add(equipLayout);
			grid.Controls.Add(equipment, 3, 0);
			UiTheme.ApplyToChildren(body.Controls);
		}
	}

	private void RenderCharacterPage()
	{
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = Padding.Empty
		};
		root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 43f));
		root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57f));
		Panel directory = Frame("Tra cứu nhân vật theo tài khoản");
		TableLayoutPanel directoryLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 4,
			Margin = Padding.Empty
		};
		directoryLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
		directoryLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 36f));
		directoryLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		directoryLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43f));
		TextBox accountInput = Field(selectedAccountId ?? string.Empty, readOnly: false);
		accountInput.MaxLength = 10;
		accountInput.PlaceholderText = "Nhập AccountID (tối đa 10 ký tự)";
		characterAccountBox = accountInput;
		TableLayoutPanel searchRow = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = Padding.Empty
		};
		searchRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 69f));
		searchRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 31f));
		Button load = Action("TẢI", databaseOptions != null, gold: true);
		searchRow.Controls.Add(accountInput, 0, 0);
		searchRow.Controls.Add(load, 1, 0);
		directoryLayout.Controls.Add(searchRow, 0, 0);
		Label hint = new Label
		{
			Text = ((databaseOptions == null) ? "CẦN CẤU HÌNH KẾT NỐI TRONG CÀI ĐẶT" : "TRA CỨU • TẠO / SỬA / XÓA CÓ CỜ RIÊNG"),
			Dock = DockStyle.Fill,
			ForeColor = ((databaseOptions == null) ? Gold : Ice),
			Font = new Font("Segoe UI", 8f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		};
		directoryLayout.Controls.Add(hint, 0, 1);
		ListBox characterList = List();
		characterList.DisplayMember = "Name";
		directoryLayout.Controls.Add(characterList, 0, 2);
		Button editCharacter = Action("SỬA THÔNG TIN", databaseOptions != null, gold: true);
		SetActionState(editCharacter, enabled: false, gold: true);
		new ToolTip().SetToolTip(editCharacter, "Chọn một nhân vật trong danh sách để mở form chỉnh sửa chi tiết giống Titan Editor.");
		bool deletionEnabled = SqlAccountLookupOptions.CharacterDeletionEnabled(configPath);
		Button deleteCharacter = Action("XÓA NHÂN VẬT", enabled: false);
		SetActionState(deleteCharacter, enabled: false);
		new ToolTip().SetToolTip(deleteCharacter, deletionEnabled ? "Chọn nhân vật trước; yêu cầu tài khoản offline và xác nhận tên hai lần." : "Đang khóa. Bật [MUSVEN_CHARACTER_DELETE] Enabled=1 trong Config.ini để mở.");
		TableLayoutPanel characterActions = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = Padding.Empty
		};
		for (int column = 0; column < 3; column++)
		{
			characterActions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333332f));
		}
		Button createCharacter = Action("CẤU HÌNH TẠO", databaseOptions != null);
		createCharacter.Click += delegate
		{
			if (databaseOptions == null)
			{
				return;
			}
			using CharacterCreationForm characterCreationForm = new CharacterCreationForm(databaseOptions, SqlAccountLookupOptions.CharacterCreationEnabled(configPath));
			characterCreationForm.ShowDialog(this);
		};
		characterActions.Controls.Add(createCharacter, 0, 0);
		characterActions.Controls.Add(editCharacter, 1, 0);
		characterActions.Controls.Add(deleteCharacter, 2, 0);
		directoryLayout.Controls.Add(characterActions, 0, 3);
		directory.Controls.Add(directoryLayout);
		root.Controls.Add(directory, 0, 0);
		Panel details = Frame("Thông tin nhân vật");
		TableLayoutPanel detailLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 5,
			Padding = new Padding(8, 2, 8, 8)
		};
		detailLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34f));
		detailLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66f));
		for (int row = 0; row < 4; row++)
		{
			detailLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		}
		detailLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		string[] labels = new string[4] { "Tài khoản", "Tên nhân vật", "Level", "Reset" };
		TextBox accountValue = Field(selectedAccountId ?? "—");
		TextBox nameValue = Field();
		TextBox levelValue = Field();
		TextBox resetValue = Field();
		TextBox[] values = new TextBox[4] { accountValue, nameValue, levelValue, resetValue };
		for (int i = 0; i < labels.Length; i++)
		{
			detailLayout.Controls.Add(new Label
			{
				Text = labels[i],
				Dock = DockStyle.Fill,
				ForeColor = Gold,
				TextAlign = ContentAlignment.MiddleLeft
			}, 0, i);
			detailLayout.Controls.Add(values[i], 1, i);
		}
		detailLayout.Controls.Add(new Label
		{
			Text = "Nạp AccountID, chọn nhân vật bên trái rồi bấm SỬA THÔNG TIN để mở form chi tiết. Chỉ sửa trường số; inventory và kỹ năng không bị thay đổi.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Silver,
			Font = new Font("Segoe UI", 9f),
			TextAlign = ContentAlignment.TopLeft,
			Padding = new Padding(3, 10, 3, 3)
		}, 0, 4);
		detailLayout.SetColumnSpan(detailLayout.GetControlFromPosition(0, 4), 2);
		details.Controls.Add(detailLayout);
		root.Controls.Add(details, 1, 0);
		characterList.SelectedIndexChanged += delegate
		{
			if (!(characterList.SelectedItem is CharacterSummary characterSummary))
			{
				SetActionState(editCharacter, enabled: false, gold: true);
				SetActionState(deleteCharacter, enabled: false);
			}
			else
			{
				SetActionState(editCharacter, databaseOptions != null, gold: true);
				SetActionState(deleteCharacter, databaseOptions != null && deletionEnabled);
				accountValue.Text = accountInput.Text.Trim();
				nameValue.Text = characterSummary.Name;
				levelValue.Text = characterSummary.Level?.ToString() ?? "Không có cột";
				resetValue.Text = characterSummary.ResetCount?.ToString() ?? "Không có cột";
			}
		};
		editCharacter.Click += delegate
		{
			if (databaseOptions == null || !(characterList.SelectedItem is CharacterSummary characterSummary))
			{
				return;
			}
			using CharacterEditorForm characterEditorForm = new CharacterEditorForm(databaseOptions, SqlAccountLookupOptions.CharacterWritesEnabled(configPath), accountInput.Text.Trim(), characterSummary.Name);
			if (characterEditorForm.ShowDialog(this) == DialogResult.OK)
			{
				load.PerformClick();
			}
		};
		deleteCharacter.Click += delegate
		{
			if (databaseOptions == null || !(characterList.SelectedItem is CharacterSummary characterSummary))
			{
				return;
			}
			using CharacterDeletionForm characterDeletionForm = new CharacterDeletionForm(databaseOptions, accountInput.Text.Trim(), characterSummary.Name, deletionEnabled);
			if (characterDeletionForm.ShowDialog(this) == DialogResult.OK)
			{
				load.PerformClick();
			}
		};
		load.Click += async delegate
		{
			string accountId = accountInput.Text.Trim();
			characterList.Items.Clear();
			nameValue.Clear();
			levelValue.Clear();
			resetValue.Clear();
			if (string.IsNullOrWhiteSpace(accountId))
			{
				hint.Text = "NHẬP ACCOUNTID ĐỂ TÌM";
			}
			else if (accountId.Length > 10)
			{
				hint.Text = "ACCOUNTID TỐI ĐA 10 KÝ TỰ";
			}
			else
			{
				if (databaseOptions != null)
				{
					SetActionState(load, enabled: false, gold: true);
					hint.Text = "ĐANG TẢI DANH SÁCH...";
					try
					{
						string connectionString = databaseOptions.CreateConnectionString();
						IReadOnlyList<CharacterSummary> found = await Task.Run(() => new CharacterRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).ListByAccount(accountId));
						foreach (CharacterSummary character in found)
						{
							characterList.Items.Add(character);
						}
						hint.Text = ((found.Count == 0) ? "KHÔNG CÓ NHÂN VẬT • chỉ đọc" : $"{found.Count} NHÂN VẬT • chỉ đọc");
						accountValue.Text = accountId;
						selectedAccountId = accountId;
						status.Text = $"NHÂN VẬT • READ-ONLY | {databaseOptions.Database} | {found.Count} KẾT QUẢ";
						if (found.Count > 0)
						{
							characterList.SelectedIndex = 0;
						}
						return;
					}
					catch
					{
						hint.Text = "TẢI THẤT BẠI • kiểm tra kết nối và schema dbo.Character";
						status.Text = "CHARACTER LOOKUP ERROR | READ-ONLY";
						return;
					}
					finally
					{
						SetActionState(load, databaseOptions != null, gold: true);
					}
				}
				hint.Text = "CHƯA CÓ CẤU HÌNH SQL";
			}
		};
		body.Controls.Add(root);
	}

	private void RenderWarehousePage()
	{
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 2,
			Margin = Padding.Empty
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		Panel queryBar = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(8, 24, 42),
			Padding = new Padding(10, 7, 10, 7),
			Margin = new Padding(5)
		};
		TableLayoutPanel queryLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 5,
			RowCount = 1,
			Margin = Padding.Empty
		};
		queryLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112f));
		queryLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		queryLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 118f));
		queryLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160f));
		queryLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190f));
		queryLayout.Controls.Add(new Label
		{
			Text = "ACCOUNT ID",
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			Font = new Font("Segoe UI", 9f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		TextBox accountInput = Field(selectedAccountId ?? string.Empty, readOnly: false);
		accountInput.MaxLength = 10;
		accountInput.PlaceholderText = "Nhập tài khoản cần tra cứu";
		Button load = Action("TẢI KHO", databaseOptions != null, gold: true);
		Button editCurrencies = Action("TIỀN / NGỌC", databaseOptions != null);
		Button createItem = Action("TẠO VẬT PHẨM");
		queryLayout.Controls.Add(accountInput, 1, 0);
		queryLayout.Controls.Add(load, 2, 0);
		queryLayout.Controls.Add(editCurrencies, 3, 0);
		queryLayout.Controls.Add(createItem, 4, 0);
		queryBar.Controls.Add(queryLayout);
		root.Controls.Add(queryBar, 0, 0);
		TableLayoutPanel results = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = Padding.Empty
		};
		results.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 52f));
		results.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48f));
		Panel jewelFrame = Frame("Ngân hàng ngọc • DATDAT_BANK");
		TableLayoutPanel jewelLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 6,
			Padding = new Padding(8, 0, 8, 8)
		};
		jewelLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		jewelLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		string[] jewelNames = new string[10] { "Bless", "Soul", "Life", "Creation", "Guardian", "Harmony", "GemStone", "Chaos", "LowStone", "HighStone" };
		TextBox[] jewelFields = new TextBox[jewelNames.Length];
		for (int row = 0; row < 5; row++)
		{
			jewelLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 59f));
		}
		jewelLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		for (int i = 0; i < jewelNames.Length; i++)
		{
			TableLayoutPanel cell = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 2,
				RowCount = 1,
				Margin = new Padding(2)
			};
			cell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48f));
			cell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 52f));
			cell.Controls.Add(new Label
			{
				Text = jewelNames[i],
				Dock = DockStyle.Fill,
				ForeColor = Gold,
				TextAlign = ContentAlignment.MiddleLeft
			}, 0, 0);
			jewelFields[i] = Field("—");
			cell.Controls.Add(jewelFields[i], 1, 0);
			jewelLayout.Controls.Add(cell, i % 2, i / 2);
		}
		Label jewelHint = new Label
		{
			Text = ((databaseOptions == null) ? "CẤU HÌNH SQL ĐỂ TRA CỨU" : "Sẵn sàng • chỉ đọc"),
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			TextAlign = ContentAlignment.MiddleLeft
		};
		jewelLayout.Controls.Add(jewelHint, 0, 5);
		jewelLayout.SetColumnSpan(jewelHint, 2);
		jewelFrame.Controls.Add(jewelLayout);
		results.Controls.Add(jewelFrame, 0, 0);
		Panel warehouseFrame = Frame("Kho mở rộng • ExtWarehouse");
		TableLayoutPanel warehouseLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 5,
			Padding = new Padding(8, 6, 8, 8)
		};
		warehouseLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 43f));
		warehouseLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57f));
		string[] warehouseLabels = new string[4] { "AccountID", "Kho số", "Zen", "Dung lượng Items" };
		TextBox[] warehouseValues = new TextBox[4]
		{
			Field(),
			Field(),
			Field(),
			Field()
		};
		for (int j = 0; j < warehouseLabels.Length; j++)
		{
			warehouseLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 64f));
			warehouseLayout.Controls.Add(new Label
			{
				Text = warehouseLabels[j],
				Dock = DockStyle.Fill,
				ForeColor = Gold,
				TextAlign = ContentAlignment.MiddleLeft
			}, 0, j);
			warehouseLayout.Controls.Add(warehouseValues[j], 1, j);
		}
		warehouseLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		Label warehouseHint = new Label
		{
			Text = ((databaseOptions == null) ? "CẤU HÌNH SQL ĐỂ TRA CỨU" : "Sẵn sàng • chỉ đọc"),
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			TextAlign = ContentAlignment.TopLeft,
			Padding = new Padding(2, 12, 2, 2)
		};
		warehouseLayout.Controls.Add(warehouseHint, 0, 4);
		warehouseLayout.SetColumnSpan(warehouseHint, 2);
		warehouseFrame.Controls.Add(warehouseLayout);
		results.Controls.Add(warehouseFrame, 1, 0);
		root.Controls.Add(results, 0, 1);
		load.Click += async delegate
		{
			string accountId = accountInput.Text.Trim();
			TextBox[] array = jewelFields;
			for (int k = 0; k < array.Length; k++)
			{
				array[k].Text = "—";
			}
			array = warehouseValues;
			for (int k = 0; k < array.Length; k++)
			{
				array[k].Text = "—";
			}
			if (accountId.Length == 0)
			{
				Label label = jewelHint;
				string text = (warehouseHint.Text = "NHẬP ACCOUNTID ĐỂ TRA CỨU");
				label.Text = text;
			}
			else
			{
				string text;
				if (databaseOptions != null)
				{
					SetActionState(load, enabled: false, gold: true);
					Label label2 = jewelHint;
					text = (warehouseHint.Text = "ĐANG ĐỌC DỮ LIỆU...");
					label2.Text = text;
					try
					{
						string connectionString = databaseOptions.CreateConnectionString();
						(JewelBankBalance, ExtendedWarehouseSummary, string, string) data = await Task.Run(delegate
						{
							MuSvenDatabase database = new MuSvenDatabase(SqlClientFactory.Instance, connectionString);
							JewelBankBalance item = null;
							ExtendedWarehouseSummary item2 = null;
							string item3 = string.Empty;
							string item4 = string.Empty;
							try
							{
								item = new WarehouseRepository(database).FindJewelBank(accountId);
							}
							catch
							{
								item3 = "Không đọc được DATDAT_BANK; kiểm tra bảng/cột và quyền SELECT.";
							}
							try
							{
								item2 = new WarehouseRepository(database).FindExtendedWarehouse(accountId);
							}
							catch
							{
								item4 = "Không đọc được ExtWarehouse; kiểm tra bảng/cột và quyền SELECT.";
							}
							return (jewels: item, warehouse: item2, jewelError: item3, warehouseError: item4);
						});
						if ((object)data.Item1 != null)
						{
							int[] balances = new int[10]
							{
								data.Item1.Bless,
								data.Item1.Soul,
								data.Item1.Life,
								data.Item1.Creation,
								data.Item1.Guardian,
								data.Item1.Harmony,
								data.Item1.GemStone,
								data.Item1.Chaos,
								data.Item1.LowStone,
								data.Item1.HighStone
							};
							for (int i2 = 0; i2 < balances.Length; i2++)
							{
								jewelFields[i2].Text = balances[i2].ToString("N0");
							}
							jewelHint.Text = "ĐÃ TẢI SỐ DƯ • chỉ đọc";
						}
						else
						{
							jewelHint.Text = (string.IsNullOrEmpty(data.Item3) ? "Tài khoản chưa có dòng trong DATDAT_BANK." : data.Item3);
						}
						if ((object)data.Item2 != null)
						{
							warehouseValues[0].Text = data.Item2.AccountId;
							warehouseValues[1].Text = data.Item2.Number.ToString();
							warehouseValues[2].Text = data.Item2.Money.ToString("N0");
							warehouseValues[3].Text = data.Item2.ItemBytes?.ToString("N0") + " byte";
							warehouseHint.Text = "ĐÃ TẢI THÔNG TIN KHO • không giải mã Items";
						}
						else
						{
							warehouseHint.Text = (string.IsNullOrEmpty(data.Item4) ? "Tài khoản chưa có dòng trong ExtWarehouse." : data.Item4);
						}
						selectedAccountId = accountId;
						status.Text = "KHO • READ-ONLY | " + databaseOptions.Database + " | " + accountId;
						return;
					}
					catch
					{
						Label label3 = jewelHint;
						text = (warehouseHint.Text = "KHÔNG ĐỌC ĐƯỢC • kiểm tra kết nối SQL, schema và quyền SELECT");
						label3.Text = text;
						status.Text = "KHO LOOKUP ERROR | READ-ONLY";
						return;
					}
					finally
					{
						SetActionState(load, databaseOptions != null, gold: true);
					}
				}
				Label label4 = jewelHint;
				text = (warehouseHint.Text = "CHƯA CÓ CẤU HÌNH SQL");
				label4.Text = text;
			}
		};
		createItem.Click += delegate
		{
			string text = accountInput.Text.Trim();
			if (text.Length == 0)
			{
				text = selectedAccountId ?? string.Empty;
			}
			using WarehouseItemEditorForm warehouseItemEditorForm = new WarehouseItemEditorForm(databaseOptions ?? new SqlAccountLookupOptions("", ""), databaseOptions != null && SqlAccountLookupOptions.ItemWritesEnabled(configPath), text, databaseOptions != null);
			if (warehouseItemEditorForm.ShowDialog(this) == DialogResult.OK)
			{
				load.PerformClick();
			}
		};
		editCurrencies.Click += delegate
		{
			if (databaseOptions == null)
			{
				MessageBox.Show(this, "Hãy cấu hình [MUSVEN_READ_ONLY] trong Config.ini trước.", "MU SVEN • Tiền/ngọc", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			string text = accountInput.Text.Trim();
			if (text.Length == 0)
			{
				text = selectedAccountId ?? string.Empty;
			}
			using CurrencyEditorForm currencyEditorForm = new CurrencyEditorForm(databaseOptions, SqlAccountLookupOptions.CurrencyWritesEnabled(configPath), text);
			if (currencyEditorForm.ShowDialog(this) == DialogResult.OK)
			{
				load.PerformClick();
			}
		};
		accountInput.KeyDown += delegate(object? _, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Return)
			{
				e.SuppressKeyPress = true;
				load.PerformClick();
			}
		};
		body.Controls.Add(root);
	}

	private async Task CheckSqlConnectionAsync()
	{
		if (databaseOptions == null)
		{
			status.Text = "SQL CHƯA CẤU HÌNH • Xem Config.ini.template";
			MessageBox.Show("Hãy cấu hình mục [MUSVEN_READ_ONLY] trong Config.ini cạnh ứng dụng, sau đó mở lại Musven.", "MU SVEN • Kết nối SQL", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			return;
		}
		status.Text = "ĐANG KIỂM TRA SQL • READ-ONLY...";
		try
		{
			string connectionString = databaseOptions.CreateConnectionString();
			string databaseName = await Task.Run(delegate
			{
				using DbConnection dbConnection = new MuSvenDatabase(SqlClientFactory.Instance, connectionString).OpenConnection();
				using DbCommand dbCommand = dbConnection.CreateCommand();
				dbCommand.CommandText = "SELECT DB_NAME()";
				dbCommand.CommandTimeout = 5;
				return Convert.ToString(dbCommand.ExecuteScalar()) ?? string.Empty;
			});
			status.Text = "SQL KẾT NỐI OK • READ-ONLY | " + databaseName;
			MessageBox.Show("Kết nối thành công đến database " + databaseName + ". Musven vẫn đang ở chế độ chỉ đọc.", "MU SVEN • Kết nối SQL", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		catch (Exception ex)
		{
			status.Text = "SQL KẾT NỐI THẤT BẠI • READ-ONLY";
			string detail = ex.GetBaseException().Message;
			if (detail.Length > 500)
			{
				detail = detail.Substring(0, 500) + "…";
			}
			MessageBox.Show("Không kết nối được. Chi tiết SQL: " + detail + "\n\nKhông hiển thị mật khẩu hoặc chuỗi kết nối.", "MU SVEN • Kết nối SQL", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}
	}

	private void RenderFeatureHub(string heading, string intro, (string title, string detail, string button, string feature)[] features)
	{
		TableLayoutPanel layout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 2,
			Margin = Padding.Empty
		};
		layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 82f));
		layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		Panel introPanel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(8, 24, 42),
			Padding = new Padding(14, 8, 14, 6),
			Margin = new Padding(5)
		};
		StyleCard(introPanel);
		introPanel.Controls.Add(new Label
		{
			Dock = DockStyle.Top,
			Height = 25,
			Text = heading.ToUpperInvariant() + "  •  MU SVEN",
			ForeColor = Gold,
			Font = new Font("Segoe UI", 11f, FontStyle.Bold)
		});
		introPanel.Controls.Add(new Label
		{
			Dock = DockStyle.Fill,
			Text = intro,
			ForeColor = Ice,
			Font = new Font("Segoe UI", 9f),
			TextAlign = ContentAlignment.MiddleLeft
		});
		layout.Controls.Add(introPanel, 0, 0);
		int rowCount = (int)Math.Ceiling((double)features.Length / 2.0);
		TableLayoutPanel cards = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = rowCount,
			Margin = new Padding(2)
		};
		for (int c = 0; c < 2; c++)
		{
			cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		}
		for (int r = 0; r < rowCount; r++)
		{
			cards.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / (float)rowCount));
		}
		for (int i = 0; i < features.Length; i++)
		{
			(string, string, string, string) tuple = features[i];
			string title = tuple.Item1;
			string detail = tuple.Item2;
			string item = tuple.Item3;
			string feature = tuple.Item4;
			Panel card = new Panel
			{
				Dock = DockStyle.Fill,
				BackColor = Surface,
				Margin = new Padding(6),
				Padding = new Padding(15)
			};
			StyleCard(card);
			TableLayoutPanel content = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 1,
				RowCount = 3,
				Margin = Padding.Empty
			};
			content.RowStyles.Add(new RowStyle(SizeType.Absolute, 42f));
			content.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
			content.RowStyles.Add(new RowStyle(SizeType.Absolute, 46f));
			content.Controls.Add(new Label
			{
				Dock = DockStyle.Fill,
				Text = title,
				ForeColor = Gold,
				Font = new Font("Segoe UI", 11f, FontStyle.Bold),
				TextAlign = ContentAlignment.MiddleLeft
			}, 0, 0);
			content.Controls.Add(new Label
			{
				Dock = DockStyle.Fill,
				Text = detail,
				ForeColor = Color.Gainsboro,
				Font = new Font("Segoe UI", 9f),
				TextAlign = ContentAlignment.TopLeft,
				Padding = new Padding(2, 4, 2, 2)
			}, 0, 1);
			bool available = IsNativeFeatureAvailable(feature);
			Button launch = Action(item, available, available);
			launch.Click += delegate
			{
				OpenMusvenFeature(feature);
			};
			content.Controls.Add(launch, 0, 2);
			card.Controls.Add(content);
			int cardIndex = cards.Controls.Count;
			cards.Controls.Add(card, cardIndex % 2, cardIndex / 2);
		}
		layout.Controls.Add(cards, 0, 1);
		body.Controls.Add(layout);
	}

	private bool IsNativeFeatureAvailable(string feature)
	{
		bool flag;
		switch (feature)
		{
		case "account-find":
		case "account-page":
		case "character-page":
		case "warehouse-page":
		case "warehouse":
		case "item-page":
		case "char-edit":
		case "char-find":
		case "char-add":
		case "go-items":
		case "jewel-bank":
		case "item-search":
			flag = true;
			break;
		default:
			flag = false;
			break;
		}
		if (!flag && (!(feature == "char-delete") || databaseOptions == null || !SqlAccountLookupOptions.CharacterDeletionEnabled(configPath)))
		{
			switch (feature)
			{
			case "ranking-view":
			case "sql-backup":
			case "data-reset":
				return databaseOptions != null;
			default:
				return false;
			}
		}
		return true;
	}

	private void OpenMusvenFeature(string feature)
	{
		string text;
		char c;
		switch (feature)
		{
		case "ranking-view":
		{
			if (databaseOptions == null)
			{
				return;
			}
			using RankingBrowserForm browser = new RankingBrowserForm(databaseOptions);
			browser.ShowDialog(this);
			return;
		}
		case "sql-backup":
		{
			if (databaseOptions == null)
			{
				return;
			}
			using SqlBackupForm backup = new SqlBackupForm(databaseOptions, SqlBackupOptions.Load(configPath));
			backup.ShowDialog(this);
			return;
		}
		case "data-reset":
		{
			if (databaseOptions == null)
			{
				return;
			}
			using SqlDataResetForm reset = new SqlDataResetForm(databaseOptions, SqlDataResetOptions.Load(configPath), configPath);
			reset.ShowDialog(this);
			return;
		}
		default:
			switch (feature.Length)
			{
			case 12:
				break;
			case 14:
				goto IL_0120;
			case 9:
				goto IL_0140;
			case 8:
				goto IL_017d;
			case 11:
				goto IL_019d;
			case 10:
				goto IL_0292;
			default:
				goto IL_02c5;
			}
			c = feature[8];
			if (c != 'f')
			{
				if (c == 'p' && feature == "account-page")
				{
					goto IL_02a1;
				}
			}
			else if (feature == "account-find")
			{
				goto IL_02a1;
			}
			goto IL_02c5;
		case null:
			goto IL_02c5;
			IL_0292:
			if (feature == "jewel-bank")
			{
				goto IL_02b3;
			}
			goto IL_02c5;
			IL_019d:
			c = feature[0];
			if (c != 'c')
			{
				if (c == 'i' && feature == "item-search")
				{
					goto IL_02bc;
				}
			}
			else if (feature == "char-delete")
			{
				goto IL_02aa;
			}
			goto IL_02c5;
			IL_02bc:
			text = "Vật phẩm";
			break;
			IL_0120:
			c = feature[0];
			if (c != 'c')
			{
				if (c == 'w' && feature == "warehouse-page")
				{
					goto IL_02b3;
				}
			}
			else if (feature == "character-page")
			{
				goto IL_02aa;
			}
			goto IL_02c5;
			IL_02c5:
			text = null;
			break;
			IL_017d:
			c = feature[0];
			if (c != 'c')
			{
				if (c == 'g' && feature == "go-items")
				{
					goto IL_02bc;
				}
			}
			else if (feature == "char-add")
			{
				goto IL_02aa;
			}
			goto IL_02c5;
			IL_02b3:
			text = "Kho đồ";
			break;
			IL_0140:
			c = feature[5];
			if ((uint)c <= 102u)
			{
				if (c != 'e')
				{
					if (c == 'f' && feature == "char-find")
					{
						goto IL_02aa;
					}
				}
				else if (feature == "char-edit")
				{
					goto IL_02aa;
				}
			}
			else if (c != 'o')
			{
				if (c == 'p' && feature == "item-page")
				{
					goto IL_02bc;
				}
			}
			else if (feature == "warehouse")
			{
				goto IL_02b3;
			}
			goto IL_02c5;
			IL_02aa:
			text = "Nhân vật";
			break;
			IL_02a1:
			text = "Tài khoản";
			break;
		}
		string destination = text;
		if (destination == null)
		{
			MessageBox.Show("Mục này đang được tách riêng trong Musven. Chưa bật thao tác SQL cho đến khi cấu hình quyền ghi và xác nhận đủ schema.", "MU SVEN • Chức năng chưa bật", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			return;
		}
		active = destination;
		Render();
		if (destination == "Tài khoản")
		{
			accountSearchBox?.Focus();
		}
		if (destination == "Nhân vật")
		{
			characterAccountBox?.Focus();
		}
	}

	private void RenderItemIndexPage()
	{
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = Padding.Empty
		};
		root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 43f));
		root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 57f));
		Panel calculator = Frame("GetIndexV4 • Tra cứu ItemIndex");
		TableLayoutPanel form = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 5,
			Padding = new Padding(5, 0, 5, 5)
		};
		form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35f));
		form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65f));
		for (int r = 0; r < 4; r++)
		{
			form.RowStyles.Add(new RowStyle(SizeType.Absolute, 62f));
		}
		form.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		TextBox type = Field("", readOnly: false);
		type.PlaceholderText = "0–15";
		TextBox id = Field("", readOnly: false);
		id.PlaceholderText = "0–511";
		TextBox result = Field("—");
		form.Controls.Add(new Label
		{
			Text = "Type / nhóm",
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		form.Controls.Add(type, 1, 0);
		form.Controls.Add(new Label
		{
			Text = "ID trong nhóm",
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 1);
		form.Controls.Add(id, 1, 1);
		form.Controls.Add(new Label
		{
			Text = "ItemIndex",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			TextAlign = ContentAlignment.MiddleLeft,
			Font = new Font("Segoe UI", 10f, FontStyle.Bold)
		}, 0, 2);
		form.Controls.Add(result, 1, 2);
		TableLayoutPanel actions = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = Padding.Empty
		};
		actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60f));
		actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40f));
		Button calc = Action("TÍNH INDEX", enabled: true, gold: true);
		Button copy = Action("SAO CHÉP");
		calc.Click += delegate
		{
			int result2;
			int result3 = default(int);
			bool flag = !int.TryParse(type.Text, out result2) || !int.TryParse(id.Text, out result3);
			if (!flag)
			{
				bool flag2 = ((result2 < 0 || result2 > 15) ? true : false);
				flag = flag2;
			}
			bool flag3 = flag;
			if (!flag3)
			{
				bool flag2 = ((result3 < 0 || result3 > 511) ? true : false);
				flag3 = flag2;
			}
			if (flag3)
			{
				MessageBox.Show("Type cần từ 0 đến 15 và ID từ 0 đến 511.", "ItemIndex", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				result.Text = (result2 * 512 + result3).ToString();
				status.Text = $"ITEM INDEX | Type {result2} + ID {result3} = {result.Text}";
			}
		};
		copy.Click += delegate
		{
			if (int.TryParse(result.Text, out var _))
			{
				Clipboard.SetText(result.Text);
			}
		};
		actions.Controls.Add(calc, 0, 0);
		actions.Controls.Add(copy, 1, 0);
		form.Controls.Add(actions, 0, 3);
		form.SetColumnSpan(actions, 2);
		form.Controls.Add(new Label
		{
			Text = "Công thức: Type × 512 + ID. Công cụ này tính tại máy, không truy cập SQL.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Silver,
			Font = new Font("Segoe UI", 9f),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 4);
		calculator.Controls.Add(form);
		root.Controls.Add(calculator, 0, 0);
		Panel lookup = Frame("Danh mục vật phẩm của server");
		TableLayoutPanel info = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 5,
			Padding = new Padding(8, 0, 8, 8)
		};
		info.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
		info.RowStyles.Add(new RowStyle(SizeType.Absolute, 42f));
		info.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		info.RowStyles.Add(new RowStyle(SizeType.Absolute, 60f));
		info.RowStyles.Add(new RowStyle(SizeType.Absolute, 46f));
		ComboBox category = new ComboBox
		{
			Dock = DockStyle.Fill,
			DropDownStyle = ComboBoxStyle.DropDownList,
			BackColor = Color.FromArgb(18, 37, 58),
			ForeColor = Color.White,
			FlatStyle = FlatStyle.Flat,
			Margin = new Padding(4)
		};
		category.Items.Add("Tất cả nhóm");
		foreach (string itemCategory in ItemCatalog.All.Select((ItemDefinition x) => x.Category).Distinct())
		{
			category.Items.Add(itemCategory);
		}
		category.SelectedIndex = 0;
		TextBox searchItem = Field("", readOnly: false);
		searchItem.PlaceholderText = "Tìm tên vật phẩm";
		ListBox itemCatalogList = List();
		itemCatalogList.DisplayMember = "DisplayText";
		Label itemDetail = new Label
		{
			Text = "Chọn vật phẩm để xem Type, ID, ItemIndex và kích thước.",
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			Font = new Font("Segoe UI", 9f),
			TextAlign = ContentAlignment.MiddleLeft
		};
		Button copyItemIndex = Action("SAO CHÉP ITEMINDEX", enabled: true, gold: true);
		info.Controls.Add(category, 0, 0);
		info.Controls.Add(searchItem, 0, 1);
		info.Controls.Add(itemCatalogList, 0, 2);
		info.Controls.Add(itemDetail, 0, 3);
		info.Controls.Add(copyItemIndex, 0, 4);
		category.SelectedIndexChanged += delegate
		{
			RefreshCatalog();
		};
		searchItem.TextChanged += delegate
		{
			RefreshCatalog();
		};
		itemCatalogList.SelectedIndexChanged += delegate
		{
			if (itemCatalogList.SelectedItem is ItemDefinition itemDefinition)
			{
				type.Text = itemDefinition.Section.ToString();
				id.Text = itemDefinition.Id.ToString();
				result.Text = itemDefinition.ItemIndex.ToString();
				itemDetail.Text = $"{itemDefinition.Name}  •  Type {itemDefinition.Section} / ID {itemDefinition.Id}  •  ItemIndex {itemDefinition.ItemIndex}  •  {itemDefinition.Width}×{itemDefinition.Height} ô";
			}
		};
		copyItemIndex.Click += delegate
		{
			if (int.TryParse(result.Text, out var _))
			{
				Clipboard.SetText(result.Text);
			}
		};
		RefreshCatalog();
		lookup.Controls.Add(info);
		root.Controls.Add(lookup, 1, 0);
		body.Controls.Add(root);
		void RefreshCatalog()
		{
			string selectedCategory = category.SelectedItem?.ToString() ?? "Tất cả nhóm";
			string query = searchItem.Text.Trim();
			itemCatalogList.BeginUpdate();
			itemCatalogList.Items.Clear();
			foreach (ItemDefinition item in ItemCatalog.All.Where((ItemDefinition x) => (selectedCategory == "Tất cả nhóm" || x.Category == selectedCategory) && (query.Length == 0 || x.Name.Contains(query, StringComparison.OrdinalIgnoreCase))))
			{
				itemCatalogList.Items.Add(item);
			}
			itemCatalogList.EndUpdate();
		}
	}

	private void RenderSettingsPage()
	{
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = Padding.Empty
		};
		root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55f));
		root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45f));
		Panel connection = Frame("Trạng thái kết nối");
		TableLayoutPanel info = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 4,
			Padding = new Padding(8)
		};
		info.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42f));
		info.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58f));
		string configPath = Path.Combine(AppContext.BaseDirectory, "Config.ini");
		string[] labels = new string[4] { "Kết nối SQL", "Quyền ghi", "Tệp cấu hình", "Thư mục chạy" };
		string[] writeModes = new string[8]
		{
			SqlAccountLookupOptions.AccountModerationEnabled(configPath) ? "Gỡ khóa hết hạn" : null,
			SqlAccountLookupOptions.ItemWritesEnabled(configPath) ? "Kho đồ" : null,
			SqlAccountLookupOptions.CurrencyWritesEnabled(configPath) ? "Tiền/ngọc" : null,
			SqlAccountLookupOptions.CharacterWritesEnabled(configPath) ? "Sửa nhân vật" : null,
			SqlAccountLookupOptions.CharacterCreationEnabled(configPath) ? "Mặc định tạo nhân vật" : null,
			SqlAccountLookupOptions.CharacterDeletionEnabled(configPath) ? "Xóa nhân vật" : null,
			SqlBackupOptions.Load(configPath).Enabled ? "Backup SQL" : null,
			SqlDataResetOptions.Load(configPath).Enabled ? "Reset dữ liệu • xác nhận kép" : null
		}.Where((string x) => x != null).Cast<string>().ToArray();
		string writeStatus = ((writeModes.Length == 0) ? "ĐANG KHÓA • bật riêng trong Config.ini" : ("ĐÃ BẬT CẤU HÌNH: " + string.Join(" / ", writeModes) + " • cần quyền SQL"));
		string[] values = new string[4]
		{
			(databaseOptions == null) ? "CHƯA CẤU HÌNH" : "ĐÃ CẤU HÌNH • tra cứu chỉ đọc",
			writeStatus,
			File.Exists(configPath) ? "Config.ini • ĐÃ CÓ" : "Config.ini • THIẾU",
			AppContext.BaseDirectory
		};
		for (int i = 0; i < labels.Length; i++)
		{
			info.RowStyles.Add(new RowStyle((i != 3) ? SizeType.Absolute : SizeType.Percent, (i == 3) ? 100 : 55));
			info.Controls.Add(new Label
			{
				Text = labels[i],
				Dock = DockStyle.Fill,
				ForeColor = Ice,
				TextAlign = ContentAlignment.MiddleLeft
			}, 0, i);
			info.Controls.Add(new Label
			{
				Text = values[i],
				Dock = DockStyle.Fill,
				ForeColor = (((i == 0 && databaseOptions == null) || (i == 2 && values[i].Contains("THIẾU"))) ? Gold : Color.Gainsboro),
				TextAlign = ContentAlignment.MiddleLeft,
				AutoEllipsis = true
			}, 1, i);
		}
		connection.Controls.Add(info);
		root.Controls.Add(connection, 0, 0);
		Panel setup = Frame("Cấu hình & an toàn");
		TableLayoutPanel setupLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 6,
			Padding = new Padding(10)
		};
		setupLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		for (int i2 = 0; i2 < 5; i2++)
		{
			setupLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 51f));
		}
		setupLayout.Controls.Add(new Label
		{
			Text = "Tra cứu SQL mặc định chỉ đọc. Gỡ khóa chỉ áp dụng ban đã hết hạn, tài khoản phải offline và cần xác nhận AccountID. Các ghi khác có công tắc riêng trong Config.ini. Xóa nhân vật cần tên duy nhất và xác nhận; reset dữ liệu cần schema đúng, xem trước, backup đã kiểm tra và xác nhận riêng. Lưu chương trình trên ổ D hoặc E để dữ liệu 3D được đặt cùng ổ.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			Font = new Font("Segoe UI", 10f),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		Button folder = Action("MỞ THƯ MỤC CHƯƠNG TRÌNH");
		folder.Click += delegate
		{
			try
			{
				Process.Start(new ProcessStartInfo("explorer.exe", AppContext.BaseDirectory)
				{
					UseShellExecute = true
				});
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message, "MU SVEN");
			}
		};
		setupLayout.Controls.Add(folder, 0, 1);
		Button configure = Action(File.Exists(configPath) ? "MỞ CONFIG.INI" : "TẠO CONFIG.INI");
		configure.Click += delegate
		{
			try
			{
				if (!File.Exists(configPath))
				{
					using Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("MuSven.Resources.Config.ini.template") ?? throw new InvalidOperationException("Không tìm thấy mẫu cấu hình nhúng.");
					using FileStream destination = File.Create(configPath);
					stream.CopyTo(destination);
				}
				Process.Start(new ProcessStartInfo("notepad.exe", "\"" + configPath + "\"")
				{
					UseShellExecute = true
				});
				MessageBox.Show("Kết nối được nạp khi khởi động Musven. Sau khi điền Server và đặt Enabled=1, hãy đóng rồi mở lại ứng dụng để tải cấu hình.", "MU SVEN • Cấu hình", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Không thể tạo/mở cấu hình cạnh EXE: " + ex.Message, "MU SVEN • Cấu hình", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
		};
		setupLayout.Controls.Add(configure, 0, 2);
		Button licensesButton = Action("THƯ VIỆN & GIẤY PHÉP");
		licensesButton.Click += delegate
		{
			ShowThirdPartyNotices();
		};
		setupLayout.Controls.Add(licensesButton, 0, 3);
		Button schema = Action("KIỂM TRA SCHEMA MUSVEN", databaseOptions != null);
		schema.Click += delegate
		{
			if (databaseOptions == null)
			{
				return;
			}
			using SchemaAuditForm schemaAuditForm = new SchemaAuditForm(databaseOptions);
			schemaAuditForm.ShowDialog(this);
		};
		setupLayout.Controls.Add(schema, 0, 4);
		Button check = Action("KIỂM TRA KẾT NỐI SQL", enabled: true, gold: true);
		check.Click += async delegate
		{
			await CheckSqlConnectionAsync();
		};
		setupLayout.Controls.Add(check, 0, 5);
		setup.Controls.Add(setupLayout);
		root.Controls.Add(setup, 1, 0);
		body.Controls.Add(root);
	}

	private void ShowThirdPartyNotices()
	{
		Assembly assembly = Assembly.GetExecutingAssembly();
		string[] array = (from text2 in assembly.GetManifestResourceNames()
			where text2.StartsWith("MuSven.Resources.THIRD_PARTY_NOTICES", StringComparison.Ordinal) || text2.StartsWith("MuSven.Resources.Licenses.", StringComparison.Ordinal)
			select text2).OrderBy<string, string>((string result) => result, StringComparer.Ordinal).ToArray();
		StringBuilder text = new StringBuilder();
		string[] array2 = array;
		foreach (string name in array2)
		{
			using Stream stream = assembly.GetManifestResourceStream(name);
			if (stream != null)
			{
				using StreamReader reader = new StreamReader(stream);
				text.AppendLine("===== " + name + " =====");
				text.AppendLine(reader.ReadToEnd());
				text.AppendLine();
			}
		}
		using Form dialog = new Form
		{
			Text = "MU SVEN • Thư viện và giấy phép",
			StartPosition = FormStartPosition.CenterParent,
			Size = new Size(820, 600),
			BackColor = Bg,
			ForeColor = Color.White,
			Font = new Font("Segoe UI", 9f)
		};
		TextBox content = new TextBox
		{
			Dock = DockStyle.Fill,
			Multiline = true,
			ReadOnly = true,
			ScrollBars = ScrollBars.Both,
			WordWrap = false,
			BackColor = Surface,
			ForeColor = Color.Gainsboro,
			Text = ((text.Length == 0) ? "Không tìm thấy thông báo giấy phép trong gói." : text.ToString())
		};
		dialog.Controls.Add(content);
		dialog.ShowDialog(this);
	}
}
