using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace MuSven09M.Modules.Account;

public sealed class AccountBanForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly string accountId;

	private readonly bool writeEnabled;

	private readonly TextBox confirmation = new TextBox
	{
		Dock = DockStyle.Fill,
		BackColor = Color.FromArgb(18, 37, 58),
		ForeColor = Color.White,
		BorderStyle = BorderStyle.FixedSingle,
		MaxLength = 10,
		Enabled = false
	};

	private readonly DateTimePicker expiresAt = new DateTimePicker
	{
		Dock = DockStyle.Fill,
		Format = DateTimePickerFormat.Custom,
		CustomFormat = "yyyy-MM-dd HH:mm",
		MinDate = DateTime.Now.AddMinutes(2.0),
		MaxDate = DateTime.Now.AddDays(365.0),
		Value = DateTime.Now.AddDays(1.0),
		Enabled = false
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button banButton;

	private AccountBanPreview? preview;

	public bool WasBanned { get; private set; }

	public DateTime? BanExpiresAt { get; private set; }

	public AccountBanForm(SqlAccountLookupOptions options, string accountId, bool writeEnabled)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.accountId = accountId?.Trim() ?? string.Empty;
		this.writeEnabled = writeEnabled;
		Text = "MU SVEN • Khóa tài khoản tạm thời";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(620, 390);
		base.Size = new Size(720, 445);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 6,
			Padding = new Padding(18),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 38f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 64f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 56f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = "KHÓA TÀI KHOẢN TẠM THỜI",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 14f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		root.Controls.Add(new Label
		{
			Text = "Tài khoản: " + this.accountId,
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			Font = new Font("Segoe UI", 10f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 1);
		root.Controls.Add(new Label
		{
			Text = "Dùng đúng dbo.MEMB_INFO.bloc_code=1 và bloc_expire. Tài khoản phải offline; khóa đang còn hạn hoặc khóa vĩnh viễn sẽ không bị ghi đè.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(4)
		}, 0, 2);
		TableLayoutPanel expiryRow = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			BackColor = Surface,
			Padding = new Padding(10),
			Margin = new Padding(2)
		};
		expiryRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55f));
		expiryRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45f));
		expiryRow.Controls.Add(new Label
		{
			Text = "Hết hạn theo giờ SQL Server (tối đa 365 ngày)",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		expiryRow.Controls.Add(expiresAt, 1, 0);
		expiryRow.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border, 1.2f);
			e.Graphics.DrawRectangle(pen, 1, 1, Math.Max(1, expiryRow.Width - 3), Math.Max(1, expiryRow.Height - 3));
		};
		root.Controls.Add(expiryRow, 0, 3);
		Panel confirmPanel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			Padding = new Padding(10, 36, 10, 8),
			Margin = new Padding(2)
		};
		confirmPanel.Controls.Add(new Label
		{
			Text = "GÕ CHÍNH XÁC ACCOUNT ID ĐỂ XÁC NHẬN",
			Location = new Point(10, 5),
			Size = new Size(540, 24),
			ForeColor = Gold,
			Font = new Font("Segoe UI", 9f, FontStyle.Bold)
		});
		confirmPanel.Controls.Add(confirmation);
		confirmPanel.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border, 1.2f);
			e.Graphics.DrawRectangle(pen, 1, 1, Math.Max(1, confirmPanel.Width - 3), Math.Max(1, confirmPanel.Height - 3));
		};
		root.Controls.Add(confirmPanel, 0, 4);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = Padding.Empty
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120f));
		footer.Controls.Add(status, 0, 0);
		banButton = MakeButton("KHÓA TÀI KHOẢN", emphasized: true);
		banButton.Enabled = false;
		banButton.Click += async delegate
		{
			await ApplyAsync();
		};
		footer.Controls.Add(banButton, 1, 0);
		Button cancel = MakeButton("ĐÓNG", emphasized: false);
		cancel.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(cancel, 2, 0);
		root.Controls.Add(footer, 0, 5);
		confirmation.TextChanged += delegate
		{
			UpdateSaveEnabled();
		};
		expiresAt.ValueChanged += delegate
		{
			UpdateSaveEnabled();
		};
		base.Shown += async delegate
		{
			await LoadPreviewAsync();
		};
		UiTheme.Apply(this);
	}

	private async Task LoadPreviewAsync()
	{
		banButton.Enabled = false;
		confirmation.Enabled = false;
		expiresAt.Enabled = false;
		status.Text = "ĐANG KIỂM TRA SCHEMA, TRẠNG THÁI OFFLINE VÀ KHÓA HIỆN TẠI…";
		try
		{
			string connectionString = options.CreateConnectionString();
			preview = await Task.Run(() => new AccountBanRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).Preview(accountId));
			if (!preview.IsOffline)
			{
				status.Text = ((preview.ConnectStat == 1) ? "ĐANG ONLINE • khóa bị từ chối." : "KHÔNG XÁC MINH ĐƯỢC OFFLINE • khóa bị từ chối.");
				return;
			}
			if (preview.HasActiveOrPermanentBan)
			{
				status.Text = "ĐÃ CÓ KHÓA CÒN HẠN HOẶC VĨNH VIỄN • không ghi đè.";
				return;
			}
			if (!preview.CanApply)
			{
				status.Text = $"bloc_code={preview.BlockCode} không nằm trong hợp đồng khóa tạm thời.";
				return;
			}
			DateTime min = preview.SqlServerNow.AddMinutes(2.0);
			DateTime max = preview.SqlServerNow.AddDays(365.0);
			expiresAt.MinDate = min;
			expiresAt.MaxDate = max;
			expiresAt.Value = preview.SqlServerNow.AddDays(1.0);
			expiresAt.Enabled = writeEnabled;
			confirmation.Enabled = writeEnabled;
			status.Text = (writeEnabled ? $"SẴN SÀNG • bloc_code hiện tại: {preview.BlockCode}. Gõ AccountID và chọn hạn khóa." : "Đang khóa trong Config.ini.");
			UpdateSaveEnabled();
		}
		catch (Exception ex)
		{
			status.Text = "KHÔNG THỂ KIỂM TRA • " + ex.GetBaseException().Message;
		}
	}

	private async Task ApplyAsync()
	{
		if (!writeEnabled || (object)preview == null || !preview.CanApply || !confirmation.Text.Equals(accountId, StringComparison.Ordinal) || !expiresAt.Enabled || MessageBox.Show(this, $"Khóa tài khoản {accountId} đến {expiresAt.Value:yyyy-MM-dd HH:mm} theo giờ SQL Server?\n\nTài khoản phải offline. Thao tác không ghi đè khóa hiện đang còn hạn.", "MU SVEN • Xác nhận khóa", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return;
		}
		banButton.Enabled = false;
		confirmation.Enabled = false;
		expiresAt.Enabled = false;
		status.Text = "ĐANG KHÓA DÒNG, KIỂM TRA OFFLINE VÀ GHI TRONG GIAO DỊCH…";
		try
		{
			string connectionString = options.CreateConnectionString(readOnly: false);
			AccountBanResult result = await Task.Run(() => new AccountBanRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).Apply(preview, expiresAt.Value, writeEnabled));
			WasBanned = true;
			BanExpiresAt = result.ExpiresAt;
			status.Text = $"ĐÃ KHÓA ĐẾN {result.ExpiresAt:yyyy-MM-dd HH:mm}.";
			base.DialogResult = DialogResult.OK;
			Close();
		}
		catch (Exception ex)
		{
			status.Text = "KHÓA THẤT BẠI • " + ex.GetBaseException().Message;
			confirmation.Enabled = true;
			expiresAt.Enabled = true;
			UpdateSaveEnabled();
		}
	}

	private void UpdateSaveEnabled()
	{
		Button button = banButton;
		int enabled;
		if (writeEnabled)
		{
			AccountBanPreview accountBanPreview = preview;
			if ((object)accountBanPreview != null && accountBanPreview.CanApply && confirmation.Enabled && confirmation.Text.Equals(accountId, StringComparison.Ordinal) && expiresAt.Value > preview.SqlServerNow.AddMinutes(1.0))
			{
				enabled = ((expiresAt.Value <= preview.SqlServerNow.AddDays(365.0)) ? 1 : 0);
				goto IL_00ac;
			}
		}
		enabled = 0;
		goto IL_00ac;
		IL_00ac:
		button.Enabled = (byte)enabled != 0;
	}

	private static Button MakeButton(string text, bool emphasized)
	{
		Button button = new Button();
		button.Text = text;
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (emphasized ? Gold : Color.FromArgb(18, 51, 82));
		button.ForeColor = (emphasized ? Color.Black : Color.White);
		button.Margin = new Padding(4);
		button.Cursor = Cursors.Hand;
		button.FlatAppearance.BorderColor = (emphasized ? Gold : Border);
		return button;
	}
}
