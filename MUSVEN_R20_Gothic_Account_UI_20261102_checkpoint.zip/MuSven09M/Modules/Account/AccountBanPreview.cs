using System;

namespace MuSven09M.Modules.Account;

public sealed record AccountBanPreview(string AccountId, int BlockCode, DateTime? BlockExpires, DateTime SqlServerNow, int? ConnectStat)
{
	public bool IsOffline => ConnectStat == 0;

	public bool HasActiveOrPermanentBan
	{
		get
		{
			if (BlockCode == 1)
			{
				if (BlockExpires.HasValue)
				{
					return BlockExpires.Value >= SqlServerNow;
				}
				return true;
			}
			return false;
		}
	}

	public bool CanApply
	{
		get
		{
			bool flag = IsOffline && !HasActiveOrPermanentBan;
			if (flag)
			{
				int blockCode = BlockCode;
				bool flag2 = (uint)blockCode <= 1u;
				flag = flag2;
			}
			return flag;
		}
	}
}
