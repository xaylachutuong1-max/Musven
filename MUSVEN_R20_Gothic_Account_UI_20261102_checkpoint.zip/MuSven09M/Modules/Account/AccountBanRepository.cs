using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Runtime.CompilerServices;

namespace MuSven09M.Modules.Account;

public sealed class AccountBanRepository
{
	private readonly MuSvenDatabase database;

	public AccountBanRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public AccountBanPreview Preview(string accountId)
	{
		accountId = ValidateAccount(accountId);
		using DbConnection connection = database.OpenConnection();
		EnsureSchema(connection, null);
		EnsureAccountExists(connection, null, accountId, lockRow: false);
		(int, DateTime?, DateTime) account = ReadAccountBan(connection, null, accountId, lockRow: false);
		int? connectStat = ReadConnectStat(connection, null, accountId, lockRow: false);
		return new AccountBanPreview(accountId, account.Item1, account.Item2, account.Item3, connectStat);
	}

	public AccountBanResult Apply(AccountBanPreview expected, DateTime expiresAt, bool writeEnabled)
	{
		ArgumentNullException.ThrowIfNull(expected, "expected");
		if (!writeEnabled)
		{
			throw new InvalidOperationException("Khóa tài khoản đang khóa. Bật [MUSVEN_ACCOUNT_BAN] Enabled=1 sau khi xác minh quyền SQL.");
		}
		string accountId = ValidateAccount(expected.AccountId);
		if (!expected.IsOffline)
		{
			throw new InvalidOperationException("Tài khoản chưa ở trạng thái offline khi mở thao tác khóa.");
		}
		expiresAt = DateTime.SpecifyKind(expiresAt, DateTimeKind.Unspecified);
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			EnsureSchema(connection, transaction);
			EnsureAccountExists(connection, transaction, accountId, lockRow: true);
			(int, DateTime?, DateTime) current = ReadAccountBan(connection, transaction, accountId, lockRow: true);
			if (ReadConnectStat(connection, transaction, accountId, lockRow: true) != 0)
			{
				throw new InvalidOperationException("Không xác minh được tài khoản ngoại tuyến. Khóa bị từ chối.");
			}
			if (current.Item1 != expected.BlockCode || current.Item2 != expected.BlockExpires)
			{
				throw new InvalidOperationException("Trạng thái khóa đã đổi sau khi tải. Mở lại thao tác để đọc dữ liệu mới.");
			}
			var (num, _, _) = current;
			if ((uint)num > 1u)
			{
				throw new InvalidOperationException($"bloc_code={current.Item1} không thuộc hợp đồng khóa tạm thời đã xác minh.");
			}
			if (current.Item1 == 1)
			{
				DateTime? item = current.Item2;
				if (!item.HasValue || current.Item2 >= current.Item3)
				{
					throw new InvalidOperationException("Tài khoản đang bị khóa hoặc có khóa vĩnh viễn. Không ghi đè khóa hiện tại.");
				}
			}
			if (expiresAt <= current.Item3.AddMinutes(1.0) || expiresAt > current.Item3.AddDays(365.0))
			{
				throw new InvalidOperationException("Thời hạn phải nằm trong 2 phút đến 365 ngày tính từ giờ SQL Server.");
			}
			using (DbCommand update = connection.CreateCommand())
			{
				update.Transaction = transaction;
				update.CommandTimeout = 10;
				update.CommandText = "\nUPDATE dbo.MEMB_INFO\nSET bloc_code=1, bloc_expire=@ExpiresAt\nWHERE memb___id=@Account AND CONVERT(int,bloc_code)=@OldCode\n  AND ((bloc_expire IS NULL AND @OldExpiresAt IS NULL) OR bloc_expire=@OldExpiresAt)";
				AddAccount(update, accountId);
				Add(update, "@ExpiresAt", DbType.DateTime, expiresAt);
				Add(update, "@OldCode", DbType.Int32, current.Item1);
				DateTime? item = current.Item2;
				Add(update, "@OldExpiresAt", DbType.DateTime, (!item.HasValue) ? DBNull.Value : ((object)current.Item2.Value));
				if (update.ExecuteNonQuery() != 1)
				{
					throw new InvalidOperationException("Số dòng cập nhật không đúng 1. Giao dịch đã hủy.");
				}
			}
			(int, DateTime?, DateTime) after = ReadAccountBan(connection, transaction, accountId, lockRow: true);
			if (after.Item1 != 1 || after.Item2 != expiresAt)
			{
				throw new InvalidOperationException("Giá trị khóa sau cập nhật không khớp yêu cầu. Giao dịch đã hủy.");
			}
			transaction.Commit();
			return new AccountBanResult(accountId, after.Item2.Value);
		}
		catch
		{
			try
			{
				transaction.Rollback();
			}
			catch
			{
			}
			throw;
		}
	}

	private static void EnsureSchema(DbConnection connection, DbTransaction? transaction)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "\nSELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH\nFROM INFORMATION_SCHEMA.COLUMNS\nWHERE TABLE_SCHEMA=N'dbo' AND TABLE_NAME IN (N'MEMB_INFO',N'MEMB_STAT')";
		Dictionary<string, (string, int?)> columns = new Dictionary<string, (string, int?)>(StringComparer.OrdinalIgnoreCase);
		using (DbDataReader reader = command.ExecuteReader())
		{
			while (reader.Read())
			{
				string table = Convert.ToString(reader.GetValue(0)) ?? string.Empty;
				string column = Convert.ToString(reader.GetValue(1)) ?? string.Empty;
				string type = Convert.ToString(reader.GetValue(2)) ?? string.Empty;
				int? length = (reader.IsDBNull(3) ? ((int?)null) : new int?(Convert.ToInt32(reader.GetValue(3))));
				columns[table + "." + column] = (type, length);
			}
		}
		RequireColumn(columns, "MEMB_INFO.memb___id", new string[1] { "varchar" }, 10);
		RequireColumn(columns, "MEMB_INFO.bloc_code", new string[3] { "tinyint", "smallint", "int" });
		RequireColumn(columns, "MEMB_INFO.bloc_expire", new string[3] { "smalldatetime", "datetime", "datetime2" });
		RequireColumn(columns, "MEMB_STAT.memb___id", new string[1] { "varchar" }, 10);
		RequireColumn(columns, "MEMB_STAT.ConnectStat", new string[3] { "tinyint", "smallint", "int" });
	}

	private static void RequireColumn(IReadOnlyDictionary<string, (string Type, int? Length)> columns, string name, string[] allowedTypes, int? expectedLength = null)
	{
		if (columns.TryGetValue(name, out (string, int?) actual) && allowedTypes.Contains<string>(actual.Item1, StringComparer.OrdinalIgnoreCase) && (!expectedLength.HasValue || actual.Item2 == expectedLength))
		{
			return;
		}
		DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(53, 2);
		defaultInterpolatedStringHandler.AppendLiteral("Schema ");
		defaultInterpolatedStringHandler.AppendFormatted(name);
		defaultInterpolatedStringHandler.AppendLiteral(" không khớp hợp đồng khóa tạm thời. Thực tế: ");
		object value;
		if (!columns.TryGetValue(name, out actual))
		{
			value = "thiếu cột";
		}
		else
		{
			var (text, num) = actual;
			object obj;
			if (num.HasValue)
			{
				int length = num.GetValueOrDefault();
				obj = $"({length})";
			}
			else
			{
				obj = string.Empty;
			}
			value = text + (string?)obj;
		}
		defaultInterpolatedStringHandler.AppendFormatted((string?)value);
		defaultInterpolatedStringHandler.AppendLiteral(".");
		throw new InvalidOperationException(defaultInterpolatedStringHandler.ToStringAndClear());
	}

	private static void EnsureAccountExists(DbConnection connection, DbTransaction? transaction, string accountId, bool lockRow)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) memb___id FROM dbo.MEMB_INFO" + (lockRow ? " WITH (UPDLOCK,HOLDLOCK)" : string.Empty) + " WHERE memb___id=@Account";
		AddAccount(command, accountId);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không tìm thấy tài khoản trong dbo.MEMB_INFO.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("MEMB_INFO có nhiều dòng cho tài khoản; thao tác đã dừng.");
		}
	}

	private static (int Code, DateTime? ExpiresAt, DateTime SqlServerNow) ReadAccountBan(DbConnection connection, DbTransaction? transaction, string accountId, bool lockRow)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) CONVERT(int,bloc_code), CONVERT(datetime,bloc_expire), GETDATE()\nFROM dbo.MEMB_INFO" + (lockRow ? " WITH (UPDLOCK,HOLDLOCK)" : string.Empty) + " WHERE memb___id=@Account";
		AddAccount(command, accountId);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không tìm thấy trạng thái khóa trong dbo.MEMB_INFO.");
		}
		int item = Convert.ToInt32(reader.GetValue(0));
		DateTime? expiresAt = (reader.IsDBNull(1) ? ((DateTime?)null) : new DateTime?(Convert.ToDateTime(reader.GetValue(1))));
		DateTime now = Convert.ToDateTime(reader.GetValue(2));
		if (reader.Read())
		{
			throw new InvalidOperationException("MEMB_INFO có nhiều dòng cho tài khoản; thao tác đã dừng.");
		}
		return (Code: item, ExpiresAt: expiresAt, SqlServerNow: now);
	}

	private static int? ReadConnectStat(DbConnection connection, DbTransaction? transaction, string accountId, bool lockRow)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) ConnectStat FROM dbo.MEMB_STAT" + (lockRow ? " WITH (UPDLOCK,HOLDLOCK)" : string.Empty) + " WHERE memb___id=@Account";
		AddAccount(command, accountId);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			return null;
		}
		int? result = (reader.IsDBNull(0) ? ((int?)null) : new int?(Convert.ToInt32(reader.GetValue(0))));
		if (reader.Read())
		{
			throw new InvalidOperationException("MEMB_STAT có nhiều dòng cho tài khoản; thao tác đã dừng.");
		}
		return result;
	}

	private static string ValidateAccount(string accountId)
	{
		string value = accountId?.Trim() ?? string.Empty;
		int length = value.Length;
		bool flag = ((length < 1 || length > 10) ? true : false);
		if (flag || value.Any(char.IsControl) || value.Any(char.IsWhiteSpace))
		{
			throw new ArgumentException("AccountID phải có từ 1 đến 10 ký tự và không chứa khoảng trắng.", "accountId");
		}
		return value;
	}

	private static void AddAccount(DbCommand command, string accountId)
	{
		Add(command, "@Account", DbType.AnsiString, accountId, 10);
	}

	private static void Add(DbCommand command, string name, DbType type, object value, int size = 0)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = type;
		if (size > 0)
		{
			parameter.Size = size;
		}
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}
}
