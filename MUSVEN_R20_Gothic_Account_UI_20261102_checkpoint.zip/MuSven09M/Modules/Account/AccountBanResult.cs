using System;

namespace MuSven09M.Modules.Account;

public sealed record AccountBanResult(string AccountId, DateTime ExpiresAt);
