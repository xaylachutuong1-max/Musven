using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace MuSven09M.Modules.Account;

public sealed class AccountCreateForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly bool writeEnabled;

	private readonly TextBox accountId = new TextBox
	{
		Dock = DockStyle.Fill,
		MaxLength = 10
	};

	private readonly TextBox displayName = new TextBox
	{
		Dock = DockStyle.Fill,
		MaxLength = 10
	};

	private readonly TextBox email = new TextBox
	{
		Dock = DockStyle.Fill,
		MaxLength = 50
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button createButton;

	public bool WasCreated { get; private set; }

	public string CreatedAccountId { get; private set; } = string.Empty;

	public AccountCreateForm(SqlAccountLookupOptions options, bool writeEnabled)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.writeEnabled = writeEnabled;
		Text = "MU SVEN • Tạo tài khoản";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(600, 390);
		base.Size = new Size(680, 440);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 5,
			Padding = new Padding(18),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 38f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 138f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = "TẠO TÀI KHOẢN",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 14f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		root.Controls.Add(new Label
		{
			Text = "Tạo tài khoản mới trong dbo.MEMB_INFO • Không yêu cầu mật khẩu",
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 1);
		TableLayoutPanel fields = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 3,
			BackColor = Surface,
			Padding = new Padding(12)
		};
		fields.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145f));
		fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		for (int i = 0; i < 3; i++)
		{
			fields.RowStyles.Add(new RowStyle(SizeType.Percent, 33.333332f));
		}
		StyleField(accountId);
		StyleField(displayName);
		StyleField(email);
		fields.Controls.Add(FieldLabel("AccountID *"), 0, 0);
		fields.Controls.Add(accountId, 1, 0);
		fields.Controls.Add(FieldLabel("Tên hiển thị"), 0, 1);
		fields.Controls.Add(displayName, 1, 1);
		fields.Controls.Add(FieldLabel("Email (tùy chọn)"), 0, 2);
		fields.Controls.Add(email, 1, 2);
		root.Controls.Add(fields, 0, 2);
		TableLayoutPanel notes = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 2,
			Padding = new Padding(4, 8, 4, 4)
		};
		notes.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
		notes.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
		notes.Controls.Add(new Label
		{
			Text = "Mật khẩu được lưu trống theo yêu cầu. Khả năng đăng nhập phụ thuộc cấu hình xác thực của GameServer.",
			Dock = DockStyle.Fill,
			ForeColor = Color.FromArgb(255, 194, 112),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		notes.Controls.Add(status, 0, 1);
		root.Controls.Add(notes, 0, 3);
		FlowLayoutPanel buttons = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.RightToLeft,
			WrapContents = false
		};
		createButton = MakeButton("TẠO TÀI KHOẢN", primary: true);
		createButton.Enabled = false;
		createButton.Click += async delegate
		{
			await CreateAsync();
		};
		Button close = MakeButton("ĐÓNG", primary: false);
		close.Click += delegate
		{
			Close();
		};
		buttons.Controls.Add(close);
		buttons.Controls.Add(createButton);
		root.Controls.Add(buttons, 0, 4);
		base.Shown += async delegate
		{
			await CheckSchemaAsync();
		};
		UiTheme.Apply(this);
	}

	private async Task CheckSchemaAsync()
	{
		createButton.Enabled = false;
		TextBox textBox = accountId;
		TextBox textBox2 = displayName;
		bool flag = (email.Enabled = false);
		bool enabled = (textBox2.Enabled = flag);
		textBox.Enabled = enabled;
		status.Text = "ĐANG KIỂM TRA HỢP ĐỒNG dbo.MEMB_INFO…";
		try
		{
			await Task.Run(delegate
			{
				new AccountCreateRepository(CreateDatabase()).CheckSchema();
			});
			TextBox textBox3 = accountId;
			TextBox textBox4 = displayName;
			flag = (email.Enabled = writeEnabled);
			enabled = (textBox4.Enabled = flag);
			textBox3.Enabled = enabled;
			createButton.Enabled = writeEnabled;
			status.Text = (writeEnabled ? "Schema đạt hợp đồng. Khi tạo: khóa chống trùng, transaction và hậu kiểm được áp dụng." : "Đang khóa bởi [MUSVEN_ACCOUNT_CREATE] trong Config.ini; chỉ kiểm tra schema.");
		}
		catch (Exception ex)
		{
			status.Text = "KHÔNG THỂ TẠO • " + ex.GetBaseException().Message;
		}
	}

	private async Task CreateAsync()
	{
		if (!writeEnabled)
		{
			return;
		}
		string id = accountId.Text.Trim();
		string name = displayName.Text.Trim();
		string mail = email.Text.Trim();
		string finalName = ((name.Length == 0) ? id : name);
		if (MessageBox.Show(this, $"Tạo tài khoản {id} với tên hiển thị {finalName}?\n\nMật khẩu sẽ để trống. Đăng nhập được hay không tùy cấu hình GameServer.", "MU SVEN • Xác nhận tạo tài khoản", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return;
		}
		createButton.Enabled = false;
		TextBox textBox = accountId;
		TextBox textBox2 = displayName;
		bool flag = (email.Enabled = false);
		bool enabled = (textBox2.Enabled = flag);
		textBox.Enabled = enabled;
		status.Text = "ĐANG KIỂM TRA ID TRÙNG, SCHEMA VÀ TẠO TRONG TRANSACTION…";
		try
		{
			CreatedAccount created = await Task.Run(() => new AccountCreateRepository(CreateDatabase()).Create(id, name, mail, writeEnabled));
			WasCreated = true;
			CreatedAccountId = created.AccountId;
			status.Text = "ĐÃ TẠO VÀ HẬU KIỂM THÀNH CÔNG.";
			base.DialogResult = DialogResult.OK;
			Close();
		}
		catch (Exception ex)
		{
			status.Text = "KHÔNG LƯU ĐƯỢC • " + ex.GetBaseException().Message;
			TextBox textBox3 = accountId;
			TextBox textBox4 = displayName;
			flag = (email.Enabled = true);
			enabled = (textBox4.Enabled = flag);
			textBox3.Enabled = enabled;
			createButton.Enabled = true;
		}
	}

	private MuSvenDatabase CreateDatabase()
	{
		return new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString(readOnly: false));
	}

	private static Label FieldLabel(string text)
	{
		return new Label
		{
			Text = text,
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			TextAlign = ContentAlignment.MiddleLeft
		};
	}

	private static void StyleField(TextBox field)
	{
		field.BackColor = Color.FromArgb(18, 37, 58);
		field.ForeColor = Color.White;
		field.BorderStyle = BorderStyle.FixedSingle;
		field.Margin = new Padding(3, 5, 3, 5);
	}

	private static Button MakeButton(string text, bool primary)
	{
		return new Button
		{
			Text = text,
			Width = (primary ? 190 : 100),
			Height = 36,
			Margin = new Padding(8, 4, 0, 4),
			FlatStyle = FlatStyle.Flat,
			BackColor = (primary ? Color.FromArgb(117, 72, 22) : Color.FromArgb(28, 39, 53)),
			ForeColor = (primary ? Gold : Color.White),
			Font = new Font("Segoe UI", 9f, FontStyle.Bold),
			Cursor = Cursors.Hand
		};
	}
}
