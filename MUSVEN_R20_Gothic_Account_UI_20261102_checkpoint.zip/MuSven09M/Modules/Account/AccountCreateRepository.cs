using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace MuSven09M.Modules.Account;

public sealed class AccountCreateRepository
{
	private static readonly HashSet<string> InsertedColumns = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "memb___id", "memb__pwd", "memb_name", "sno__numb", "mail_addr", "bloc_code", "ctl1_code", "AccountLevel", "AccountExpireDate", "Lock" };

	private readonly MuSvenDatabase database;

	public AccountCreateRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public void CheckSchema()
	{
		using DbConnection connection = database.OpenConnection();
		ValidateSchema(connection, null);
	}

	public CreatedAccount Create(string accountId, string? displayName, string? email, bool writeEnabled)
	{
		if (!writeEnabled)
		{
			throw new InvalidOperationException("Tạo tài khoản đang khóa trong Config.ini.");
		}
		accountId = ValidateAccount(accountId);
		displayName = ValidateText(displayName, 10, "Tên hiển thị", allowEmpty: true);
		email = ValidateText(email, 50, "Email", allowEmpty: true);
		if (displayName.Length == 0)
		{
			displayName = accountId;
		}
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			ValidateSchema(connection, transaction);
			using (DbCommand duplicate = connection.CreateCommand())
			{
				duplicate.Transaction = transaction;
				duplicate.CommandTimeout = 8;
				duplicate.CommandText = "SELECT TOP (2) memb___id FROM dbo.MEMB_INFO WITH (UPDLOCK,HOLDLOCK) WHERE memb___id=@Account";
				Add(duplicate, "@Account", DbType.AnsiString, accountId, 10);
				using DbDataReader reader = duplicate.ExecuteReader();
				if (reader.Read())
				{
					throw new InvalidOperationException("AccountID đã tồn tại trong dbo.MEMB_INFO.");
				}
			}
			using (DbCommand insert = connection.CreateCommand())
			{
				insert.Transaction = transaction;
				insert.CommandTimeout = 8;
				insert.CommandText = "INSERT INTO dbo.MEMB_INFO\n    (memb___id,memb__pwd,memb_name,sno__numb,mail_addr,bloc_code,ctl1_code,AccountLevel,AccountExpireDate,Lock)\nVALUES\n    (@Account,'',@DisplayName,'1',@Email,'0','0',0,CONVERT(smalldatetime,'19000101',112),0)";
				Add(insert, "@Account", DbType.AnsiString, accountId, 10);
				Add(insert, "@DisplayName", DbType.AnsiString, displayName, 10);
				Add(insert, "@Email", DbType.AnsiString, email, 50);
				if (insert.ExecuteNonQuery() != 1)
				{
					throw new InvalidOperationException("Lệnh tạo không ghi đúng một dòng; giao dịch đã hủy.");
				}
			}
			CreatedAccount saved = ReadCreated(connection, transaction, accountId);
			if (!saved.DisplayName.Equals(displayName, StringComparison.Ordinal) || !saved.Email.Equals(email, StringComparison.Ordinal))
			{
				throw new InvalidOperationException("Hậu kiểm MEMB_INFO không khớp; giao dịch đã hủy.");
			}
			transaction.Commit();
			return saved;
		}
		catch
		{
			try
			{
				transaction.Rollback();
			}
			catch
			{
			}
			throw;
		}
	}

	private static void ValidateSchema(DbConnection connection, DbTransaction? transaction)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT c.name,t.name,c.max_length,c.is_nullable,c.is_identity,c.is_computed,c.default_object_id\nFROM sys.columns AS c\nJOIN sys.types AS t ON c.user_type_id=t.user_type_id\nWHERE c.object_id=OBJECT_ID(N'dbo.MEMB_INFO')";
		Dictionary<string, (string Type, int Length, bool Nullable, bool Identity, bool Computed, int DefaultId)> columns = new Dictionary<string, (string Type, int Length, bool Nullable, bool Identity, bool Computed, int DefaultId)>(StringComparer.OrdinalIgnoreCase);
		using (DbDataReader reader = command.ExecuteReader())
		{
			while (reader.Read())
			{
				columns[reader.GetString(0)] = (reader.GetString(1), Convert.ToInt32(reader.GetValue(2)), reader.GetBoolean(3), reader.GetBoolean(4), reader.GetBoolean(5), Convert.ToInt32(reader.GetValue(6)));
			}
		}
		if (columns.Count == 0)
		{
			throw new InvalidOperationException("Không tìm thấy dbo.MEMB_INFO hoặc tài khoản SQL không nhìn thấy metadata.");
		}
		Require(columns, "memb_guid", "int", 4, false, identity: true);
		Require(columns, "memb___id", "varchar", 10, false);
		Require(columns, "memb__pwd", "varchar", 10, false);
		Require(columns, "memb_name", "varchar", 10, false);
		Require(columns, "sno__numb", "char", 18, false);
		Require(columns, "mail_addr", "varchar", 50);
		Require(columns, "bloc_code", "char", 1, false);
		Require(columns, "ctl1_code", "char", 1, false);
		Require(columns, "AccountLevel", "int", 4, false);
		Require(columns, "AccountExpireDate", "smalldatetime", 4, false);
		Require(columns, "Lock", "int", 4, false);
		string[] unsupportedRequired = (from pair in columns
			where !pair.Value.Nullable && !pair.Value.Identity && !pair.Value.Computed && pair.Value.DefaultId == 0 && !InsertedColumns.Contains(pair.Key)
			select pair.Key).ToArray();
		if (unsupportedRequired.Length != 0)
		{
			throw new InvalidOperationException("Schema có cột bắt buộc chưa được hợp đồng tạo tài khoản hỗ trợ: " + string.Join(", ", unsupportedRequired));
		}
	}

	private static void Require(Dictionary<string, (string Type, int Length, bool Nullable, bool Identity, bool Computed, int DefaultId)> columns, string name, string type, int length, bool? nullable = null, bool identity = false)
	{
		if (!columns.TryGetValue(name, out (string, int, bool, bool, bool, int) column) || !column.Item1.Equals(type, StringComparison.OrdinalIgnoreCase) || column.Item2 != length || (nullable.HasValue && column.Item3 != nullable.Value) || column.Item4 != identity)
		{
			throw new InvalidOperationException($"Schema không khớp: dbo.MEMB_INFO.{name} phải là {type}({length})" + ((!nullable.HasValue) ? "." : (nullable.Value ? " NULL." : " NOT NULL.")));
		}
	}

	private static CreatedAccount ReadCreated(DbConnection connection, DbTransaction transaction, string accountId)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) memb_name,mail_addr,DATALENGTH(memb__pwd)\nFROM dbo.MEMB_INFO WITH (UPDLOCK,HOLDLOCK) WHERE memb___id=@Account";
		Add(command, "@Account", DbType.AnsiString, accountId, 10);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không tìm thấy dòng tài khoản mới khi hậu kiểm.");
		}
		string displayName = (reader.IsDBNull(0) ? string.Empty : (Convert.ToString(reader.GetValue(0))?.TrimEnd() ?? string.Empty));
		string email = (reader.IsDBNull(1) ? string.Empty : (Convert.ToString(reader.GetValue(1))?.TrimEnd() ?? string.Empty));
		int num = (reader.IsDBNull(2) ? (-1) : Convert.ToInt32(reader.GetValue(2)));
		if (reader.Read())
		{
			throw new InvalidOperationException("MEMB_INFO có nhiều dòng trùng AccountID sau khi tạo.");
		}
		if (num != 0)
		{
			throw new InvalidOperationException("Hậu kiểm phát hiện trường password không trống; giao dịch đã hủy.");
		}
		return new CreatedAccount(accountId, displayName, email);
	}

	private static string ValidateAccount(string? value)
	{
		value = value?.Trim() ?? string.Empty;
		int length = value.Length;
		bool flag = ((length < 1 || length > 10) ? true : false);
		if (flag || value.Any((char ch) => ch < '!' || ch > '~'))
		{
			throw new ArgumentException("AccountID phải có 1–10 ký tự ASCII, không có khoảng trắng hoặc ký tự điều khiển.", "value");
		}
		return value;
	}

	private static string ValidateText(string? value, int maxLength, string label, bool allowEmpty)
	{
		value = value?.Trim() ?? string.Empty;
		if ((!allowEmpty && value.Length == 0) || value.Length > maxLength || value.Any(char.IsControl))
		{
			throw new ArgumentException($"{label} vượt giới hạn {maxLength} ký tự hoặc có ký tự điều khiển.");
		}
		return value;
	}

	private static void Add(DbCommand command, string name, DbType type, object value, int size)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = type;
		parameter.Size = size;
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}
}
