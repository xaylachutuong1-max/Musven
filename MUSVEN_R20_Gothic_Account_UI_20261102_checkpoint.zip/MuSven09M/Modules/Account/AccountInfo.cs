namespace MuSven09M.Modules.Account;

public sealed record AccountInfo(string AccountId, string DisplayName)
{
	public string DisplayText
	{
		get
		{
			if (!string.IsNullOrWhiteSpace(DisplayName))
			{
				return AccountId + "  •  " + DisplayName;
			}
			return AccountId;
		}
	}

	public override string ToString()
	{
		return DisplayText;
	}
}
