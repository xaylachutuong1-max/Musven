using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace MuSven09M.Modules.Account;

public sealed class AccountMembershipForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly string accountId;

	private readonly bool writeEnabled;

	private readonly NumericUpDown level = new NumericUpDown
	{
		Minimum = 0m,
		Maximum = 255m,
		Width = 190,
		ThousandsSeparator = true
	};

	private readonly NumericUpDown days = new NumericUpDown
	{
		Minimum = 0m,
		Maximum = 3650m,
		Width = 190,
		ThousandsSeparator = true
	};

	private readonly Label current = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button save = new Button
	{
		Text = "LƯU CẤP THÀNH VIÊN",
		Dock = DockStyle.Fill,
		Enabled = false
	};

	private AccountMembershipSnapshot? snapshot;

	public bool WasUpdated { get; private set; }

	public AccountMembershipForm(SqlAccountLookupOptions options, string accountId, bool writeEnabled)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.accountId = accountId.Trim();
		this.writeEnabled = writeEnabled;
		Text = "MU SVEN • Cấp thành viên / VIP";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(620, 430);
		base.Size = new Size(700, 470);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 5,
			Padding = new Padding(18),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 60f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 132f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = "CẤP THÀNH VIÊN / THỜI HẠN",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 14f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		root.Controls.Add(new Label
		{
			Text = "Tài khoản: " + this.accountId,
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			Font = new Font("Segoe UI", 10f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 1);
		TableLayoutPanel fields = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 3,
			BackColor = Surface,
			Padding = new Padding(14)
		};
		fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		fields.RowStyles.Add(new RowStyle(SizeType.Absolute, 40f));
		fields.RowStyles.Add(new RowStyle(SizeType.Absolute, 40f));
		fields.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		fields.Controls.Add(MakeLabel("Cấp thành viên (0–255)"), 0, 0);
		fields.Controls.Add(level, 1, 0);
		fields.Controls.Add(MakeLabel("Thời hạn cộng thêm (ngày)"), 0, 1);
		fields.Controls.Add(days, 1, 1);
		fields.Controls.Add(current, 0, 2);
		fields.SetColumnSpan(current, 2);
		root.Controls.Add(fields, 0, 2);
		root.Controls.Add(new Label
		{
			Text = "Procedure WZ_SetAccountLevel nhận thời lượng bằng giây. Cùng cấp sẽ cộng vào hạn hiện có; đổi cấp sẽ tính từ thời điểm máy chủ. Tài khoản phải offline.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(4)
		}, 0, 3);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100f));
		footer.Controls.Add(status, 0, 0);
		save.FlatStyle = FlatStyle.Flat;
		save.BackColor = Gold;
		save.ForeColor = Color.Black;
		save.FlatAppearance.BorderColor = Gold;
		save.Click += async delegate
		{
			await SaveAsync();
		};
		footer.Controls.Add(save, 1, 0);
		Button button = new Button();
		button.Text = "ĐÓNG";
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = Color.FromArgb(32, 40, 52);
		button.ForeColor = Color.White;
		button.FlatAppearance.BorderColor = Border;
		Button close = button;
		close.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(close, 2, 0);
		root.Controls.Add(footer, 0, 4);
		status.Text = (writeEnabled ? "Đã bật công tắc riêng; vẫn cần xác nhận trước khi ghi." : "Chỉ xem • bật [MUSVEN_ACCOUNT_LEVEL] Enabled=1 để lưu.");
		base.Load += async delegate
		{
			await LoadMembershipAsync();
		};
		UiTheme.Apply(this);
	}

	private async Task LoadMembershipAsync()
	{
		save.Enabled = false;
		status.Text = "Đang đọc MEMB_INFO và xác minh procedure…";
		try
		{
			MuSvenDatabase database = new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString());
			snapshot = await Task.Run(() => new AccountMembershipRepository(database).Load(accountId));
			level.Value = Math.Clamp(snapshot.AccountLevel, (int)level.Minimum, (int)level.Maximum);
			current.Text = $"Hiện tại: cấp {snapshot.AccountLevel} • hết hạn {snapshot.ExpireAt?.ToString("yyyy-MM-dd HH:mm") ?? "NULL"}";
			status.Text = (writeEnabled ? "Đã tải trạng thái thành viên." : "Đã tải ở chế độ chỉ đọc.");
			save.Enabled = writeEnabled;
		}
		catch (Exception ex)
		{
			status.Text = "Không tải được • " + ex.Message;
		}
	}

	private async Task SaveAsync()
	{
		if (!writeEnabled || (object)snapshot == null)
		{
			return;
		}
		int selectedLevel = (int)level.Value;
		int durationDays = (int)days.Value;
		if (MessageBox.Show(this, $"Cập nhật cấp tài khoản {accountId} thành cấp {selectedLevel}, cộng {durationDays:N0} ngày? Tài khoản phải offline.", "MU SVEN • Xác nhận cấp thành viên", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return;
		}
		save.Enabled = false;
		level.Enabled = false;
		days.Enabled = false;
		status.Text = "Đang khóa dòng, xác minh offline và lưu…";
		try
		{
			MuSvenDatabase database = new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString(readOnly: false));
			snapshot = await Task.Run(() => new AccountMembershipRepository(database).Save(snapshot, selectedLevel, durationDays, writeEnabled: true));
			WasUpdated = true;
			current.Text = $"Đã lưu: cấp {snapshot.AccountLevel} • hết hạn {snapshot.ExpireAt:yyyy-MM-dd HH:mm}";
			status.Text = "Đã cập nhật qua WZ_SetAccountLevel.";
			base.DialogResult = DialogResult.OK;
			Close();
		}
		catch (Exception ex)
		{
			status.Text = "Không lưu được • " + ex.Message;
			MessageBox.Show(this, ex.Message, "MU SVEN • Không thể cập nhật", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			level.Enabled = true;
			days.Enabled = true;
			save.Enabled = true;
		}
	}

	private static Label MakeLabel(string text)
	{
		return new Label
		{
			Text = text,
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			TextAlign = ContentAlignment.MiddleLeft
		};
	}
}
