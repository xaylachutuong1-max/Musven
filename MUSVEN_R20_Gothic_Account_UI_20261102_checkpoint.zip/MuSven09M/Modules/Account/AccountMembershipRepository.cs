using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text.RegularExpressions;

namespace MuSven09M.Modules.Account;

public sealed class AccountMembershipRepository
{
	private readonly MuSvenDatabase database;

	public AccountMembershipRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public AccountMembershipSnapshot Load(string accountId)
	{
		accountId = ValidateAccount(accountId);
		using DbConnection connection = database.OpenConnection();
		EnsureSchema(connection, null);
		return ReadSnapshot(connection, null, accountId, lockRow: false);
	}

	public AccountMembershipSnapshot Save(AccountMembershipSnapshot expected, int accountLevel, int durationDays, bool writeEnabled)
	{
		ArgumentNullException.ThrowIfNull(expected, "expected");
		string accountId = ValidateAccount(expected.AccountId);
		if (!writeEnabled)
		{
			throw new InvalidOperationException("Cập nhật cấp thành viên đang khóa. Bật [MUSVEN_ACCOUNT_LEVEL] sau khi xác minh quyền SQL.");
		}
		if ((accountLevel < 0 || accountLevel > 255) ? true : false)
		{
			throw new ArgumentOutOfRangeException("accountLevel", "Cấp thành viên phải từ 0 đến 255.");
		}
		if ((durationDays < 0 || durationDays > 3650) ? true : false)
		{
			throw new ArgumentOutOfRangeException("durationDays", "Thời hạn phải từ 0 đến 3.650 ngày.");
		}
		int seconds = checked(durationDays * 86400);
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			EnsureSchema(connection, transaction);
			EnsureProcedureMatches(connection, transaction);
			EnsureOffline(connection, transaction, accountId);
			AccountMembershipSnapshot current = ReadSnapshot(connection, transaction, accountId, lockRow: true);
			if (current.AccountLevel != expected.AccountLevel || current.ExpireAt != expected.ExpireAt)
			{
				throw new InvalidOperationException("Cấp thành viên hoặc hạn dùng đã đổi sau khi tải. Tải lại trước khi lưu.");
			}
			if (current.AccountLevel == accountLevel && !current.ExpireAt.HasValue)
			{
				throw new InvalidOperationException("Hạn dùng hiện tại đang NULL; hãy đổi cấp thành viên để procedure tạo hạn mới.");
			}
			DateTime serverNow = ReadServerTime(connection, transaction);
			using (DbCommand command = connection.CreateCommand())
			{
				command.Transaction = transaction;
				command.CommandTimeout = 15;
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "dbo.WZ_SetAccountLevel";
				AddAnsi(command, "@Account", accountId, 10);
				AddInt(command, "@AccountLevel", accountLevel);
				AddInt(command, "@AccountExpireTime", seconds);
				command.ExecuteNonQuery();
			}
			AccountMembershipSnapshot updated = ReadSnapshot(connection, transaction, accountId, lockRow: true);
			if (updated.AccountLevel != accountLevel || !updated.ExpireAt.HasValue)
			{
				throw new InvalidOperationException("WZ_SetAccountLevel không ghi đúng cấp/hạn dự kiến; giao dịch đã hủy.");
			}
			DateTime expectedExpiry = ((current.AccountLevel == accountLevel) ? current.ExpireAt.Value : serverNow).AddSeconds(seconds);
			if (Math.Abs((updated.ExpireAt.Value - expectedExpiry).TotalSeconds) > 75.0)
			{
				throw new InvalidOperationException("Hạn dùng sau khi ghi khác thời lượng đã chọn; giao dịch đã hủy.");
			}
			transaction.Commit();
			return updated;
		}
		catch
		{
			TryRollback(transaction);
			throw;
		}
	}

	private static void EnsureSchema(DbConnection connection, DbTransaction? transaction)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "\nSELECT c.name, ty.name\nFROM sys.columns AS c\nJOIN sys.types AS ty ON ty.user_type_id=c.user_type_id\nWHERE c.object_id=OBJECT_ID(N'dbo.MEMB_INFO') AND c.name IN (N'memb___id',N'AccountLevel',N'AccountExpireDate')";
		Dictionary<string, string> columns = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		using DbDataReader reader = command.ExecuteReader();
		while (reader.Read())
		{
			columns[Convert.ToString(reader.GetValue(0)) ?? string.Empty] = Convert.ToString(reader.GetValue(1)) ?? string.Empty;
		}
		if (!columns.TryGetValue("memb___id", out var accountType) || !accountType.Equals("varchar", StringComparison.OrdinalIgnoreCase) || !columns.TryGetValue("AccountLevel", out var levelType) || !levelType.Equals("int", StringComparison.OrdinalIgnoreCase) || !columns.TryGetValue("AccountExpireDate", out var expireType) || !expireType.Equals("smalldatetime", StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("Schema MEMB_INFO không khớp hợp đồng: memb___id varchar, AccountLevel int, AccountExpireDate smalldatetime.");
		}
	}

	private static void EnsureProcedureMatches(DbConnection connection, DbTransaction transaction)
	{
		string definition;
		using (DbCommand command = connection.CreateCommand())
		{
			command.Transaction = transaction;
			command.CommandTimeout = 8;
			command.CommandText = "SELECT OBJECT_DEFINITION(OBJECT_ID(N'dbo.WZ_SetAccountLevel'))";
			definition = Convert.ToString(command.ExecuteScalar()) ?? string.Empty;
		}
		Match match = Regex.Match(Normalize(definition), "^(?:CREATE|ALTER)\\s+(?:PROC(?:EDURE)?)\\s+WZ_SETACCOUNTLEVEL\\b[\\s\\S]*?\\bAS\\s+BEGIN\\s+(?<body>[\\s\\S]+?)\\s+END\\s*;?$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
		if (!match.Success || NormalizeTokens(match.Groups["body"].Value) != "SET NOCOUNT ON SET XACT_ABORT ON DECLARE @CURRENTACCOUNTLEVEL INT DECLARE @CURRENTACCOUNTEXPIREDATE SMALLDATETIME SELECT @CURRENTACCOUNTLEVEL ACCOUNTLEVEL @CURRENTACCOUNTEXPIREDATE ACCOUNTEXPIREDATE FROM MEMB_INFO WHERE MEMB___ID @ACCOUNT IF @CURRENTACCOUNTLEVEL @ACCOUNTLEVEL BEGIN SET @CURRENTACCOUNTLEVEL @CURRENTACCOUNTLEVEL SET @CURRENTACCOUNTEXPIREDATE DATEADD SECOND @ACCOUNTEXPIRETIME @CURRENTACCOUNTEXPIREDATE END ELSE BEGIN SET @CURRENTACCOUNTLEVEL @ACCOUNTLEVEL SET @CURRENTACCOUNTEXPIREDATE DATEADD SECOND @ACCOUNTEXPIRETIME GETDATE END UPDATE MEMB_INFO SET ACCOUNTLEVEL @CURRENTACCOUNTLEVEL ACCOUNTEXPIREDATE @CURRENTACCOUNTEXPIREDATE WHERE MEMB___ID @ACCOUNT SET NOCOUNT OFF SET XACT_ABORT OFF")
		{
			throw new InvalidOperationException("dbo.WZ_SetAccountLevel không khớp toàn bộ hợp đồng đã rà soát; Musven chưa gọi procedure.");
		}
		using DbCommand parameters = connection.CreateCommand();
		parameters.Transaction = transaction;
		parameters.CommandTimeout = 8;
		parameters.CommandText = "\nSELECT p.parameter_id,p.name,ty.name,p.max_length,p.is_output\nFROM sys.parameters AS p\nJOIN sys.types AS ty ON ty.user_type_id=p.user_type_id\nWHERE p.object_id=OBJECT_ID(N'dbo.WZ_SetAccountLevel') AND p.parameter_id>0\nORDER BY p.parameter_id";
		using DbDataReader reader = parameters.ExecuteReader();
		(string, string, int)[] expected = new(string, string, int)[3]
		{
			("@Account", "varchar", 10),
			("@AccountLevel", "int", 4),
			("@AccountExpireTime", "int", 4)
		};
		for (int i = 0; i < expected.Length; i++)
		{
			if (!reader.Read() || Convert.ToInt32(reader.GetValue(0)) != i + 1 || !Convert.ToString(reader.GetValue(1)).Equals(expected[i].Item1, StringComparison.OrdinalIgnoreCase) || !Convert.ToString(reader.GetValue(2)).Equals(expected[i].Item2, StringComparison.OrdinalIgnoreCase) || Convert.ToInt32(reader.GetValue(3)) != expected[i].Item3 || Convert.ToBoolean(reader.GetValue(4)))
			{
				throw new InvalidOperationException("Chữ ký dbo.WZ_SetAccountLevel khác hợp đồng (@Account varchar(10), @AccountLevel int, @AccountExpireTime int).");
			}
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.WZ_SetAccountLevel có tham số thừa; Musven chưa gọi procedure.");
		}
	}

	private static AccountMembershipSnapshot ReadSnapshot(DbConnection connection, DbTransaction? transaction, string accountId, bool lockRow)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) AccountLevel,AccountExpireDate FROM dbo.MEMB_INFO" + (lockRow ? " WITH (UPDLOCK,HOLDLOCK)" : string.Empty) + " WHERE memb___id=@Account";
		AddAnsi(command, "@Account", accountId, 10);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không tìm thấy AccountID trong dbo.MEMB_INFO.");
		}
		if (reader.IsDBNull(0))
		{
			throw new InvalidOperationException("MEMB_INFO.AccountLevel đang NULL.");
		}
		AccountMembershipSnapshot result = new AccountMembershipSnapshot(accountId, Convert.ToInt32(reader.GetValue(0)), reader.IsDBNull(1) ? ((DateTime?)null) : new DateTime?(Convert.ToDateTime(reader.GetValue(1))));
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.MEMB_INFO có nhiều dòng cho AccountID; Musven dừng để tránh cập nhật nhầm.");
		}
		return result;
	}

	private static void EnsureOffline(DbConnection connection, DbTransaction transaction, string accountId)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) ConnectStat FROM dbo.MEMB_STAT WITH (UPDLOCK,HOLDLOCK) WHERE memb___id=@Account";
		AddAnsi(command, "@Account", accountId, 10);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read() || reader.IsDBNull(0))
		{
			throw new InvalidOperationException("Không xác định được trạng thái tài khoản trong MEMB_STAT.");
		}
		int num = Convert.ToInt32(reader.GetValue(0));
		if (reader.Read())
		{
			throw new InvalidOperationException("MEMB_STAT có nhiều dòng cho AccountID.");
		}
		if (num != 0)
		{
			throw new InvalidOperationException("Tài khoản đang online; không thể đổi cấp thành viên.");
		}
	}

	private static DateTime ReadServerTime(DbConnection connection, DbTransaction transaction)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT GETDATE()";
		return Convert.ToDateTime(command.ExecuteScalar());
	}

	private static string Normalize(string definition)
	{
		return Regex.Replace(Regex.Replace(Regex.Replace(definition, "--.*?$|/\\*[\\s\\S]*?\\*/", "", RegexOptions.Multiline | RegexOptions.CultureInvariant).Replace("[", string.Empty, StringComparison.Ordinal).Replace("]", string.Empty, StringComparison.Ordinal), "\\bDBO\\.", string.Empty, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant), "\\s+", " ", RegexOptions.CultureInvariant).Trim().ToUpperInvariant();
	}

	private static string NormalizeTokens(string body)
	{
		return Regex.Replace(Regex.Replace(body, "[();,=<>]", " ", RegexOptions.CultureInvariant), "\\s+", " ", RegexOptions.CultureInvariant).Trim().ToUpperInvariant();
	}

	private static string ValidateAccount(string accountId)
	{
		string value = accountId?.Trim() ?? string.Empty;
		int length = value.Length;
		bool flag = ((length < 1 || length > 10) ? true : false);
		if (flag || value.Any(char.IsControl) || value.Any(char.IsWhiteSpace) || value.Any((char ch) => ch > '\u007f'))
		{
			throw new ArgumentException("AccountID phải có từ 1 đến 10 ký tự ASCII và không chứa khoảng trắng.", "accountId");
		}
		return value;
	}

	private static void AddAnsi(DbCommand command, string name, string value, int size)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = DbType.AnsiString;
		parameter.Size = size;
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}

	private static void AddInt(DbCommand command, string name, int value)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = DbType.Int32;
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}

	private static void TryRollback(DbTransaction transaction)
	{
		try
		{
			transaction.Rollback();
		}
		catch
		{
		}
	}
}
