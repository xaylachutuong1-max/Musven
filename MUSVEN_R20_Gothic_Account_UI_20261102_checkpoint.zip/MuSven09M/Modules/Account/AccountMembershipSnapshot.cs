using System;

namespace MuSven09M.Modules.Account;

public sealed record AccountMembershipSnapshot(string AccountId, int AccountLevel, DateTime? ExpireAt);
