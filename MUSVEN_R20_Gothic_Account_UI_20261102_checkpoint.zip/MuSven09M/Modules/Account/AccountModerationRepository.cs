using System;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text.RegularExpressions;

namespace MuSven09M.Modules.Account;

public sealed class AccountModerationRepository
{
	private readonly MuSvenDatabase database;

	public AccountModerationRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public AccountUnbanPreview PreviewExpiredUnban(string accountId)
	{
		accountId = ValidateAccount(accountId);
		using DbConnection connection = database.OpenConnection();
		EnsureInstalledProcedureMatches(connection, null);
		EnsureAccountExists(connection, null, accountId, lockRow: false);
		int? status = ReadConnectStat(connection, null, accountId, lockRow: false);
		(int, int) counts = ReadExpiredCounts(connection, null, accountId, lockRows: false);
		return new AccountUnbanPreview(accountId, counts.Item1, counts.Item2, status);
	}

	public AccountUnbanResult UnbanExpired(string accountId, bool writeEnabled)
	{
		accountId = ValidateAccount(accountId);
		if (!writeEnabled)
		{
			throw new InvalidOperationException("Gỡ khóa đang khóa. Bật [MUSVEN_ACCOUNT_MODERATION] Enabled=1 sau khi xác minh procedure và quyền SQL.");
		}
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			EnsureInstalledProcedureMatches(connection, transaction);
			EnsureAccountExists(connection, transaction, accountId, lockRow: true);
			if (ReadConnectStat(connection, transaction, accountId, lockRow: true) != 0)
			{
				throw new InvalidOperationException("Không xác minh được trạng thái offline. Gỡ khóa bị từ chối.");
			}
			(int, int) before = ReadExpiredCounts(connection, transaction, accountId, lockRows: true);
			if (before.Item1 + before.Item2 == 0)
			{
				throw new InvalidOperationException("Không có khóa đã hết hạn để gỡ. Khóa còn hạn hoặc không có khóa sẽ được giữ nguyên.");
			}
			using (DbCommand command = connection.CreateCommand())
			{
				command.Transaction = transaction;
				command.CommandTimeout = 15;
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "dbo.WZ_DesblocAccount";
				AddAccountParameter(command, accountId);
				command.ExecuteNonQuery();
			}
			(int, int) after = ReadExpiredCounts(connection, transaction, accountId, lockRows: true);
			if (after.Item1 != 0 || after.Item2 != 0)
			{
				throw new InvalidOperationException("Thủ tục chưa gỡ hết các khóa hết hạn. Giao dịch đã hủy.");
			}
			transaction.Commit();
			return new AccountUnbanResult(accountId, before.Item1, before.Item2);
		}
		catch
		{
			TryRollback(transaction);
			throw;
		}
	}

	private static void EnsureInstalledProcedureMatches(DbConnection connection, DbTransaction? transaction)
	{
		string definition;
		using (DbCommand command = connection.CreateCommand())
		{
			command.Transaction = transaction;
			command.CommandTimeout = 8;
			command.CommandText = "SELECT OBJECT_DEFINITION(OBJECT_ID(N'dbo.WZ_DesblocAccount'))";
			definition = Convert.ToString(command.ExecuteScalar()) ?? string.Empty;
		}
		Match procedure = Regex.Match(NormalizeProcedureBody(definition), "^(?:CREATE|ALTER)\\s+(?:PROC(?:EDURE)?)\\s+(?:DBO\\.)?WZ_DESBLOACCOUNT\\s+@ACCOUNT\\s+VARCHAR\\s*\\(\\s*10\\s*\\)\\s+AS\\s+BEGIN\\s+(?<body>[\\s\\S]+?)\\s+END\\s*;?$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
		if (!procedure.Success || !NormalizeSqlTokens(procedure.Groups["body"].Value).Equals("SET NOCOUNT ON SET XACT_ABORT ON UPDATE MEMB_INFO SET BLOC_CODE = 0 WHERE MEMB___ID = @ACCOUNT AND BLOC_CODE = 1 AND BLOC_EXPIRE < GETDATE ( ) UPDATE CHARACTER SET CTLCODE = 0 WHERE ACCOUNTID = @ACCOUNT AND CTLCODE = 1 AND BLOC_EXPIRE < GETDATE ( ) SET NOCOUNT OFF SET XACT_ABORT OFF", StringComparison.Ordinal))
		{
			throw new InvalidOperationException("dbo.WZ_DesblocAccount không khớp toàn bộ hợp đồng đã rà soát; Musven chưa gọi thủ tục.");
		}
		using DbCommand parameters = connection.CreateCommand();
		parameters.Transaction = transaction;
		parameters.CommandTimeout = 8;
		parameters.CommandText = "\nSELECT p.parameter_id, p.name, ty.name, p.max_length, p.is_output\nFROM sys.parameters AS p\nJOIN sys.types AS ty ON ty.user_type_id=p.user_type_id\nWHERE p.object_id=OBJECT_ID(N'dbo.WZ_DesblocAccount') AND p.parameter_id>0\nORDER BY p.parameter_id";
		using DbDataReader reader = parameters.ExecuteReader();
		if (!reader.Read() || Convert.ToInt32(reader.GetValue(0)) != 1 || !Convert.ToString(reader.GetValue(1)).Equals("@Account", StringComparison.OrdinalIgnoreCase) || !Convert.ToString(reader.GetValue(2)).Equals("varchar", StringComparison.OrdinalIgnoreCase) || Convert.ToInt32(reader.GetValue(3)) != 10 || Convert.ToBoolean(reader.GetValue(4)) || reader.Read())
		{
			throw new InvalidOperationException("Chữ ký dbo.WZ_DesblocAccount phải chỉ có @Account varchar(10); Musven chưa gọi thủ tục.");
		}
	}

	private static string NormalizeProcedureBody(string definition)
	{
		return Regex.Replace(Regex.Replace(Regex.Replace(definition, "--.*?$|/\\*[\\s\\S]*?\\*/", "", RegexOptions.Multiline | RegexOptions.CultureInvariant).Replace("[", string.Empty, StringComparison.Ordinal).Replace("]", string.Empty, StringComparison.Ordinal), "\\bDBO\\.", string.Empty, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant), "\\s+", " ", RegexOptions.CultureInvariant).Trim().ToUpperInvariant();
	}

	private static string NormalizeSqlTokens(string body)
	{
		return Regex.Replace(Regex.Replace(body, "[();,=<>]", " ", RegexOptions.CultureInvariant), "\\s+", " ", RegexOptions.CultureInvariant).Trim().ToUpperInvariant();
	}

	private static void EnsureAccountExists(DbConnection connection, DbTransaction? transaction, string accountId, bool lockRow)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) memb___id FROM dbo.MEMB_INFO" + (lockRow ? " WITH (UPDLOCK, HOLDLOCK)" : string.Empty) + " WHERE memb___id=@Account";
		AddAccountParameter(command, accountId);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không tìm thấy AccountID trong dbo.MEMB_INFO.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.MEMB_INFO có nhiều dòng cho AccountID này; Musven từ chối gỡ khóa.");
		}
	}

	private static int? ReadConnectStat(DbConnection connection, DbTransaction? transaction, string accountId, bool lockRow)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) ConnectStat FROM dbo.MEMB_STAT" + (lockRow ? " WITH (UPDLOCK, HOLDLOCK)" : string.Empty) + " WHERE memb___id=@Account";
		AddAccountParameter(command, accountId);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			return null;
		}
		int? result = (reader.IsDBNull(0) ? ((int?)null) : new int?(Convert.ToInt32(reader.GetValue(0))));
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.MEMB_STAT có nhiều dòng cho AccountID này.");
		}
		return result;
	}

	private static (int AccountBans, int CharacterBans) ReadExpiredCounts(DbConnection connection, DbTransaction? transaction, string accountId, bool lockRows)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		string hint = (lockRows ? " WITH (UPDLOCK, HOLDLOCK)" : string.Empty);
		command.CommandText = $"\nSELECT\n    (SELECT COUNT(*) FROM dbo.MEMB_INFO{hint} WHERE memb___id=@Account AND bloc_code=1 AND bloc_expire < GETDATE()),\n    (SELECT COUNT(*) FROM dbo.[Character]{hint} WHERE AccountID=@Account AND CtlCode=1 AND bloc_expire < GETDATE())";
		AddAccountParameter(command, accountId);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SingleRow | CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không đọc được số khóa hết hạn.");
		}
		return (AccountBans: Convert.ToInt32(reader.GetValue(0)), CharacterBans: Convert.ToInt32(reader.GetValue(1)));
	}

	private static string ValidateAccount(string accountId)
	{
		string value = accountId?.Trim() ?? string.Empty;
		int length = value.Length;
		bool flag = ((length < 1 || length > 10) ? true : false);
		if (flag || value.Any(char.IsControl) || value.Any(char.IsWhiteSpace))
		{
			throw new ArgumentException("AccountID phải có từ 1 đến 10 ký tự và không chứa khoảng trắng.", "accountId");
		}
		return value;
	}

	private static void AddAccountParameter(DbCommand command, string accountId)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = "@Account";
		parameter.DbType = DbType.AnsiString;
		parameter.Size = 10;
		parameter.Value = accountId;
		command.Parameters.Add(parameter);
	}

	private static void TryRollback(DbTransaction transaction)
	{
		try
		{
			transaction.Rollback();
		}
		catch
		{
		}
	}
}
