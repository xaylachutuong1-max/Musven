using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace MuSven09M.Modules.Account;

public sealed class AccountProfileForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly string accountId;

	private readonly bool writeEnabled;

	private readonly TextBox displayName = new TextBox
	{
		Dock = DockStyle.Fill,
		MaxLength = 10
	};

	private readonly TextBox email = new TextBox
	{
		Dock = DockStyle.Fill,
		MaxLength = 50
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button saveButton;

	private AccountProfileSnapshot? snapshot;

	public bool WasUpdated { get; private set; }

	public AccountProfileForm(SqlAccountLookupOptions options, string accountId, bool writeEnabled)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.accountId = accountId?.Trim() ?? string.Empty;
		this.writeEnabled = writeEnabled;
		Text = "MU SVEN • Sửa thông tin tài khoản";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(560, 310);
		base.Size = new Size(640, 365);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 5,
			Padding = new Padding(18),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 42f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 32f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 92f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = "THÔNG TIN TÀI KHOẢN",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 14f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		root.Controls.Add(new Label
		{
			Text = "AccountID: " + this.accountId + "  •  chỉ sửa tên hiển thị và email",
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 1);
		TableLayoutPanel fields = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 2,
			BackColor = Surface,
			Padding = new Padding(12)
		};
		fields.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145f));
		fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		fields.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
		fields.RowStyles.Add(new RowStyle(SizeType.Percent, 50f));
		StyleField(displayName);
		StyleField(email);
		fields.Controls.Add(FieldLabel("Tên hiển thị"), 0, 0);
		fields.Controls.Add(displayName, 1, 0);
		fields.Controls.Add(FieldLabel("Email"), 0, 1);
		fields.Controls.Add(email, 1, 1);
		root.Controls.Add(fields, 0, 2);
		root.Controls.Add(status, 0, 3);
		FlowLayoutPanel buttons = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.RightToLeft,
			WrapContents = false
		};
		saveButton = MakeButton("LƯU THAY ĐỔI", primary: true);
		saveButton.Enabled = false;
		saveButton.Click += async delegate
		{
			await SaveAsync();
		};
		Button close = MakeButton("ĐÓNG", primary: false);
		close.Click += delegate
		{
			Close();
		};
		buttons.Controls.Add(close);
		buttons.Controls.Add(saveButton);
		root.Controls.Add(buttons, 0, 4);
		base.Shown += async delegate
		{
			await LoadAsync();
		};
		UiTheme.Apply(this);
	}

	private async Task LoadAsync()
	{
		saveButton.Enabled = false;
		status.Text = "ĐANG KIỂM TRA HỢP ĐỒNG VÀ TẢI THÔNG TIN…";
		try
		{
			snapshot = await Task.Run(() => new AccountProfileRepository(CreateDatabase()).Load(accountId));
			displayName.Text = snapshot.DisplayName;
			email.Text = snapshot.Email;
			displayName.Enabled = writeEnabled;
			email.Enabled = writeEnabled;
			saveButton.Enabled = writeEnabled;
			status.Text = (writeEnabled ? "Đã tải. Khi lưu: tài khoản phải offline, schema và snapshot được kiểm tra trong transaction. Mật khẩu không bị thay đổi." : "Đang khóa trong Config.ini; thông tin chỉ đọc.");
		}
		catch (Exception ex)
		{
			status.Text = "KHÔNG THỂ TẢI • " + ex.GetBaseException().Message;
		}
	}

	private async Task SaveAsync()
	{
		if (!writeEnabled || (object)snapshot == null || MessageBox.Show(this, "Lưu tên hiển thị và email cho " + accountId + "? Tài khoản phải offline. Mật khẩu và câu trả lời khôi phục không bị thay đổi.", "MU SVEN • Xác nhận sửa thông tin", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
		{
			return;
		}
		saveButton.Enabled = false;
		displayName.Enabled = false;
		email.Enabled = false;
		status.Text = "ĐANG KIỂM TRA OFFLINE, SNAPSHOT VÀ CẬP NHẬT TRONG TRANSACTION…";
		try
		{
			snapshot = await Task.Run(() => new AccountProfileRepository(CreateDatabase()).Save(snapshot, displayName.Text, email.Text, writeEnabled));
			WasUpdated = true;
			status.Text = "ĐÃ LƯU VÀ HẬU KIỂM THÀNH CÔNG.";
			base.DialogResult = DialogResult.OK;
			Close();
		}
		catch (Exception ex)
		{
			status.Text = "KHÔNG LƯU ĐƯỢC • " + ex.GetBaseException().Message;
			displayName.Enabled = true;
			email.Enabled = true;
			saveButton.Enabled = true;
		}
	}

	private MuSvenDatabase CreateDatabase()
	{
		return new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString(readOnly: false));
	}

	private static Label FieldLabel(string text)
	{
		return new Label
		{
			Text = text,
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			TextAlign = ContentAlignment.MiddleLeft
		};
	}

	private static void StyleField(TextBox field)
	{
		field.BackColor = Color.FromArgb(18, 37, 58);
		field.ForeColor = Color.White;
		field.BorderStyle = BorderStyle.FixedSingle;
		field.Margin = new Padding(3, 5, 3, 5);
	}

	private static Button MakeButton(string text, bool primary)
	{
		return new Button
		{
			Text = text,
			Width = (primary ? 180 : 100),
			Height = 36,
			Margin = new Padding(8, 4, 0, 4),
			FlatStyle = FlatStyle.Flat,
			BackColor = (primary ? Color.FromArgb(117, 72, 22) : Color.FromArgb(28, 39, 53)),
			ForeColor = (primary ? Gold : Color.White),
			Font = new Font("Segoe UI", 9f, FontStyle.Bold),
			Cursor = Cursors.Hand
		};
	}
}
