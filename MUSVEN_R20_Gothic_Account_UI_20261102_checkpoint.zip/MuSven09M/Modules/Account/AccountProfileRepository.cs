using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace MuSven09M.Modules.Account;

public sealed class AccountProfileRepository
{
	private readonly MuSvenDatabase database;

	public AccountProfileRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public AccountProfileSnapshot Load(string accountId)
	{
		accountId = ValidateAccount(accountId);
		using DbConnection connection = database.OpenConnection();
		ValidateSchema(connection, null);
		return ReadSnapshot(connection, null, accountId, lockRow: false);
	}

	public AccountProfileSnapshot Save(AccountProfileSnapshot expected, string displayName, string email, bool writeEnabled)
	{
		ArgumentNullException.ThrowIfNull(expected, "expected");
		if (!writeEnabled)
		{
			throw new InvalidOperationException("Sửa thông tin tài khoản đang khóa trong Config.ini.");
		}
		string accountId = ValidateAccount(expected.AccountId);
		displayName = ValidateValue(displayName, 10, "Tên hiển thị", allowEmpty: false);
		email = ValidateValue(email, 50, "Email", allowEmpty: true);
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			ValidateSchema(connection, transaction);
			EnsureOffline(connection, transaction, accountId);
			AccountProfileSnapshot current = ReadSnapshot(connection, transaction, accountId, lockRow: true);
			if (!current.DisplayName.Equals(expected.DisplayName, StringComparison.Ordinal) || !current.Email.Equals(expected.Email, StringComparison.Ordinal))
			{
				throw new InvalidOperationException("Thông tin tài khoản đã đổi sau khi tải. Musven chưa ghi gì; hãy mở lại.");
			}
			using DbCommand update = connection.CreateCommand();
			update.Transaction = transaction;
			update.CommandTimeout = 8;
			update.CommandText = "UPDATE dbo.MEMB_INFO\nSET memb_name=@NewName, mail_addr=@NewEmail\nWHERE memb___id=@Account AND memb_name=@OldName\n  AND ((mail_addr=@OldEmail) OR (mail_addr IS NULL AND @OldEmail IS NULL))";
			Add(update, "@NewName", DbType.AnsiString, displayName, 10);
			Add(update, "@NewEmail", DbType.AnsiString, (email.Length == 0) ? ((IConvertible)DBNull.Value) : ((IConvertible)email), 50);
			Add(update, "@Account", DbType.AnsiString, accountId, 10);
			Add(update, "@OldName", DbType.AnsiString, current.DisplayName, 10);
			Add(update, "@OldEmail", DbType.AnsiString, (current.Email.Length == 0) ? ((IConvertible)DBNull.Value) : ((IConvertible)current.Email), 50);
			if (update.ExecuteNonQuery() != 1)
			{
				throw new InvalidOperationException("Cập nhật không khớp đúng một dòng MEMB_INFO; giao dịch đã hủy.");
			}
			AccountProfileSnapshot saved = ReadSnapshot(connection, transaction, accountId, lockRow: true);
			if (!saved.DisplayName.Equals(displayName, StringComparison.Ordinal) || !saved.Email.Equals(email, StringComparison.Ordinal))
			{
				throw new InvalidOperationException("Giá trị hậu kiểm khác yêu cầu; giao dịch đã hủy.");
			}
			transaction.Commit();
			return saved;
		}
		catch
		{
			try
			{
				transaction.Rollback();
			}
			catch
			{
			}
			throw;
		}
	}

	private static void ValidateSchema(DbConnection connection, DbTransaction? transaction)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH\nFROM INFORMATION_SCHEMA.COLUMNS\nWHERE TABLE_SCHEMA=N'dbo' AND TABLE_NAME=N'MEMB_INFO'\n  AND COLUMN_NAME IN (N'memb___id',N'memb_name',N'mail_addr')";
		Dictionary<string, (string, int?)> found = new Dictionary<string, (string, int?)>(StringComparer.OrdinalIgnoreCase);
		using DbDataReader reader = command.ExecuteReader();
		while (reader.Read())
		{
			found[reader.GetString(0)] = (reader.GetString(1), reader.IsDBNull(2) ? ((int?)null) : new int?(Convert.ToInt32(reader.GetValue(2))));
		}
		if (!found.TryGetValue("memb___id", out var id) || !id.Item1.Equals("varchar", StringComparison.OrdinalIgnoreCase) || id.Item2 != 10 || !found.TryGetValue("memb_name", out var name) || !name.Item1.Equals("varchar", StringComparison.OrdinalIgnoreCase) || name.Item2 != 10 || !found.TryGetValue("mail_addr", out var email) || !email.Item1.Equals("varchar", StringComparison.OrdinalIgnoreCase) || email.Item2 != 50)
		{
			throw new InvalidOperationException("Hợp đồng không khớp: dbo.MEMB_INFO.memb___id varchar(10), memb_name varchar(10), mail_addr varchar(50).");
		}
	}

	private static AccountProfileSnapshot ReadSnapshot(DbConnection connection, DbTransaction? transaction, string accountId, bool lockRow)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) memb_name,mail_addr FROM dbo.MEMB_INFO" + (lockRow ? " WITH (UPDLOCK,HOLDLOCK)" : string.Empty) + " WHERE memb___id=@Account";
		Add(command, "@Account", DbType.AnsiString, accountId, 10);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SingleResult);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không tìm thấy tài khoản trong dbo.MEMB_INFO.");
		}
		AccountProfileSnapshot result = new AccountProfileSnapshot(accountId, reader.IsDBNull(0) ? string.Empty : (Convert.ToString(reader.GetValue(0))?.TrimEnd() ?? string.Empty), reader.IsDBNull(1) ? string.Empty : (Convert.ToString(reader.GetValue(1))?.TrimEnd() ?? string.Empty));
		if (reader.Read())
		{
			throw new InvalidOperationException("MEMB_INFO có nhiều dòng trùng AccountID.");
		}
		return result;
	}

	private static void EnsureOffline(DbConnection connection, DbTransaction transaction, string accountId)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) ConnectStat FROM dbo.MEMB_STAT WITH (UPDLOCK,HOLDLOCK) WHERE memb___id=@Account";
		Add(command, "@Account", DbType.AnsiString, accountId, 10);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không xác minh được trạng thái trong dbo.MEMB_STAT.");
		}
		int status = (reader.IsDBNull(0) ? (-1) : Convert.ToInt32(reader.GetValue(0)));
		if (reader.Read())
		{
			throw new InvalidOperationException("MEMB_STAT có nhiều dòng cho AccountID.");
		}
		object message;
		switch (status)
		{
		default:
			message = "Không xác minh được tài khoản offline.";
			break;
		case 1:
			message = "Tài khoản đang online; sửa thông tin bị từ chối.";
			break;
		case 0:
			return;
		}
		throw new InvalidOperationException((string?)message);
	}

	private static string ValidateAccount(string value)
	{
		value = value?.Trim() ?? string.Empty;
		int length = value.Length;
		bool flag = ((length < 1 || length > 10) ? true : false);
		if (flag || value.Any(char.IsWhiteSpace))
		{
			throw new ArgumentException("AccountID phải có từ 1 đến 10 ký tự, không có khoảng trắng.", "value");
		}
		return value;
	}

	private static string ValidateValue(string? value, int maxLength, string label, bool allowEmpty)
	{
		value = value?.Trim() ?? string.Empty;
		if ((!allowEmpty && value.Length == 0) || value.Length > maxLength || value.Any(char.IsControl))
		{
			throw new ArgumentException($"{label} phải dài {(allowEmpty ? "0" : "1")}–{maxLength} ký tự và không có ký tự điều khiển.");
		}
		return value;
	}

	private static void Add(DbCommand command, string name, DbType type, object value, int size)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = type;
		parameter.Size = size;
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}
}
