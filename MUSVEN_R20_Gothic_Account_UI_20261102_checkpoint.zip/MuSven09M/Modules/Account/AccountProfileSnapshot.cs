namespace MuSven09M.Modules.Account;

public sealed record AccountProfileSnapshot(string AccountId, string DisplayName, string Email);
