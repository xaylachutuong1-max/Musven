using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace MuSven09M.Modules.Account;

public sealed class AccountRepository
{
	private const string FindByIdSql = "\nSELECT TOP (1) memb___id, memb_name\nFROM MEMB_INFO\nWHERE memb___id = @AccountId";

	private readonly MuSvenDatabase database;

	public AccountRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public AccountInfo? FindById(string accountId)
	{
		if (string.IsNullOrWhiteSpace(accountId))
		{
			throw new ArgumentException("Account ID is required.", "accountId");
		}
		using DbConnection connection = database.OpenConnection();
		using DbCommand command = connection.CreateCommand();
		command.CommandText = "\nSELECT TOP (1) memb___id, memb_name\nFROM MEMB_INFO\nWHERE memb___id = @AccountId";
		command.CommandType = CommandType.Text;
		command.CommandTimeout = 5;
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = "@AccountId";
		parameter.DbType = DbType.String;
		parameter.Size = 64;
		parameter.Value = accountId.Trim();
		command.Parameters.Add(parameter);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SingleRow | CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			return null;
		}
		return new AccountInfo(reader.IsDBNull(0) ? string.Empty : (Convert.ToString(reader.GetValue(0)) ?? string.Empty), reader.IsDBNull(1) ? string.Empty : (Convert.ToString(reader.GetValue(1)) ?? string.Empty));
	}

	public IReadOnlyList<AccountInfo> Search(string prefix, int limit = 200)
	{
		if ((limit < 1 || limit > 500) ? true : false)
		{
			throw new ArgumentOutOfRangeException("limit", "Result limit must be from 1 to 500.");
		}
		using DbConnection connection = database.OpenConnection();
		using DbCommand command = connection.CreateCommand();
		command.CommandText = "\nSELECT TOP (@Limit) memb___id, memb_name\nFROM dbo.MEMB_INFO\nWHERE memb___id LIKE @Prefix ESCAPE '\\'\nORDER BY memb___id";
		command.CommandType = CommandType.Text;
		command.CommandTimeout = 5;
		DbParameter limitParameter = command.CreateParameter();
		limitParameter.ParameterName = "@Limit";
		limitParameter.DbType = DbType.Int32;
		limitParameter.Value = limit;
		command.Parameters.Add(limitParameter);
		DbParameter prefixParameter = command.CreateParameter();
		prefixParameter.ParameterName = "@Prefix";
		prefixParameter.DbType = DbType.String;
		prefixParameter.Size = 64;
		prefixParameter.Value = EscapeLike(prefix.Trim()) + "%";
		command.Parameters.Add(prefixParameter);
		List<AccountInfo> accounts = new List<AccountInfo>();
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		while (reader.Read())
		{
			accounts.Add(new AccountInfo(reader.IsDBNull(0) ? string.Empty : (Convert.ToString(reader.GetValue(0)) ?? string.Empty), reader.IsDBNull(1) ? string.Empty : (Convert.ToString(reader.GetValue(1)) ?? string.Empty)));
		}
		return accounts;
	}

	private static string EscapeLike(string value)
	{
		return value.Replace("\\", "\\\\", StringComparison.Ordinal).Replace("%", "\\%", StringComparison.Ordinal).Replace("_", "\\_", StringComparison.Ordinal)
			.Replace("[", "\\[", StringComparison.Ordinal);
	}
}
