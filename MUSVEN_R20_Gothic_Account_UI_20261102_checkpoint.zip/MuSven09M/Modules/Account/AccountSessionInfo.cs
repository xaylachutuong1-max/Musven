using System;

namespace MuSven09M.Modules.Account;

public sealed record AccountSessionInfo(int? ConnectStat, string? ServerName, string? IpAddress, DateTime? ConnectTime, DateTime? DisconnectTime, int? OnlineHours)
{
	public string StatusText => ConnectStat switch
	{
		1 => "ONLINE", 
		0 => "OFFLINE", 
		null => "CHƯA CÓ TRẠNG THÁI", 
		_ => $"TRẠNG THÁI {ConnectStat}", 
	};

	public string DetailText
	{
		get
		{
			string server = (string.IsNullOrWhiteSpace(ServerName) ? "Server: —" : ("Server: " + ServerName));
			string ip = (string.IsNullOrWhiteSpace(IpAddress) ? "IP: —" : ("IP: " + IpAddress));
			DateTime? time = ((ConnectStat == 1) ? ConnectTime : DisconnectTime);
			string timeLabel = ((ConnectStat == 1) ? "Kết nối" : "Ngắt kết nối");
			string lastTime = (time.HasValue ? $"{timeLabel}: {time.Value:yyyy-MM-dd HH:mm}" : (timeLabel + ": —"));
			string online = ((ConnectStat == 1 && OnlineHours.HasValue) ? $"  •  {OnlineHours.Value:N0} giờ online" : string.Empty);
			return $"{server}  •  {ip}  •  {lastTime}{online}";
		}
	}
}
