using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace MuSven09M.Modules.Account;

public sealed class AccountSessionRepository
{
	private readonly MuSvenDatabase database;

	public AccountSessionRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public AccountSessionInfo? FindByAccountId(string accountId)
	{
		if (string.IsNullOrWhiteSpace(accountId))
		{
			throw new ArgumentException("Account ID is required.", "accountId");
		}
		using DbConnection connection = database.OpenConnection();
		using DbCommand command = connection.CreateCommand();
		command.CommandText = "\nSELECT TOP (2) ConnectStat, ServerName, IP, ConnectTM, DisConnectTM, OnlineHours\nFROM dbo.MEMB_STAT\nWHERE memb___id = @AccountId";
		command.CommandType = CommandType.Text;
		command.CommandTimeout = 5;
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = "@AccountId";
		parameter.DbType = DbType.String;
		parameter.Size = 10;
		parameter.Value = accountId.Trim();
		command.Parameters.Add(parameter);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			return null;
		}
		AccountSessionInfo result = new AccountSessionInfo(NullableInt(reader, 0), NullableText(reader, 1), NullableText(reader, 2), NullableDateTime(reader, 3), NullableDateTime(reader, 4), NullableInt(reader, 5));
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.MEMB_STAT có nhiều dòng cho cùng tài khoản; Musven không hiển thị trạng thái mơ hồ.");
		}
		return result;
	}

	public IReadOnlyList<OnlineAccountInfo> ListOnline(int limit = 200)
	{
		if ((limit < 1 || limit > 500) ? true : false)
		{
			throw new ArgumentOutOfRangeException("limit", "Limit phải từ 1 đến 500.");
		}
		using DbConnection connection = database.OpenConnection();
		using DbCommand command = connection.CreateCommand();
		command.CommandText = "\nSELECT TOP (@Limit) memb___id, ServerName, IP, ConnectTM, OnlineHours\nFROM dbo.MEMB_STAT\nWHERE ConnectStat = 1\nORDER BY ConnectTM DESC, memb___id";
		command.CommandType = CommandType.Text;
		command.CommandTimeout = 5;
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = "@Limit";
		parameter.DbType = DbType.Int32;
		parameter.Value = limit;
		command.Parameters.Add(parameter);
		List<OnlineAccountInfo> accounts = new List<OnlineAccountInfo>();
		HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		while (reader.Read())
		{
			string accountId = NullableText(reader, 0)?.Trim() ?? string.Empty;
			if (accountId.Length == 0)
			{
				throw new InvalidOperationException("dbo.MEMB_STAT có tài khoản online rỗng; không thể hiển thị chính xác.");
			}
			if (!seen.Add(accountId))
			{
				throw new InvalidOperationException("dbo.MEMB_STAT có nhiều dòng online cho " + accountId + "; danh sách đã dừng để tránh trạng thái mơ hồ.");
			}
			accounts.Add(new OnlineAccountInfo(accountId, NullableText(reader, 1), NullableText(reader, 2), NullableDateTime(reader, 3), NullableInt(reader, 4)));
		}
		return accounts;
	}

	private static int? NullableInt(DbDataReader reader, int ordinal)
	{
		if (!reader.IsDBNull(ordinal))
		{
			return Convert.ToInt32(reader.GetValue(ordinal));
		}
		return null;
	}

	private static string? NullableText(DbDataReader reader, int ordinal)
	{
		if (!reader.IsDBNull(ordinal))
		{
			return Convert.ToString(reader.GetValue(ordinal));
		}
		return null;
	}

	private static DateTime? NullableDateTime(DbDataReader reader, int ordinal)
	{
		if (!reader.IsDBNull(ordinal))
		{
			return Convert.ToDateTime(reader.GetValue(ordinal));
		}
		return null;
	}
}
