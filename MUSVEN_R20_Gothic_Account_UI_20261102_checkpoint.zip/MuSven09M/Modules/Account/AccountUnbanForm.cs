using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace MuSven09M.Modules.Account;

public sealed class AccountUnbanForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly string accountId;

	private readonly bool writeEnabled;

	private readonly TextBox confirmation = new TextBox
	{
		Dock = DockStyle.Fill,
		BackColor = Color.FromArgb(18, 37, 58),
		ForeColor = Color.White,
		BorderStyle = BorderStyle.FixedSingle,
		MaxLength = 10,
		Enabled = false
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button unbanButton;

	private AccountUnbanPreview? preview;

	public bool WasUnbanned { get; private set; }

	public int AccountBansCleared { get; private set; }

	public int CharacterBansCleared { get; private set; }

	public AccountUnbanForm(SqlAccountLookupOptions options, string accountId, bool writeEnabled)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.accountId = accountId?.Trim() ?? string.Empty;
		this.writeEnabled = writeEnabled;
		Text = "MU SVEN • Gỡ khóa hết hạn";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(620, 350);
		base.Size = new Size(720, 410);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 5,
			Padding = new Padding(18),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 46f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 42f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 86f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = "GỠ KHÓA ĐÃ HẾT HẠN",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 14f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		root.Controls.Add(new Label
		{
			Text = "Tài khoản: " + this.accountId,
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			Font = new Font("Segoe UI", 10f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 1);
		root.Controls.Add(new Label
		{
			Text = "Chỉ xóa bloc_code/CtlCode = 1 khi bloc_expire đã qua. Khóa còn hạn được giữ nguyên. Tài khoản phải offline và thủ tục WZ_DesblocAccount phải đúng hợp đồng đã rà soát.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(4)
		}, 0, 2);
		Panel confirmPanel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			Padding = new Padding(10, 36, 10, 8),
			Margin = new Padding(2)
		};
		confirmPanel.Controls.Add(new Label
		{
			Text = "GÕ CHÍNH XÁC ACCOUNT ID ĐỂ XÁC NHẬN",
			Location = new Point(10, 5),
			Size = new Size(540, 24),
			ForeColor = Gold,
			Font = new Font("Segoe UI", 9f, FontStyle.Bold)
		});
		confirmPanel.Controls.Add(confirmation);
		confirmPanel.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border, 1.2f);
			e.Graphics.DrawRectangle(pen, 1, 1, Math.Max(1, confirmPanel.Width - 3), Math.Max(1, confirmPanel.Height - 3));
		};
		root.Controls.Add(confirmPanel, 0, 3);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = Padding.Empty
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120f));
		footer.Controls.Add(status, 0, 0);
		unbanButton = MakeButton("GỠ KHÓA HẾT HẠN", emphasized: true);
		unbanButton.Enabled = false;
		unbanButton.Click += async delegate
		{
			await UnbanAsync();
		};
		footer.Controls.Add(unbanButton, 1, 0);
		Button cancel = MakeButton("ĐÓNG", emphasized: false);
		cancel.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(cancel, 2, 0);
		root.Controls.Add(footer, 0, 4);
		confirmation.TextChanged += delegate
		{
			UpdateUnbanButton();
		};
		base.Shown += async delegate
		{
			await LoadPreviewAsync();
		};
		UiTheme.Apply(this);
	}

	private async Task LoadPreviewAsync()
	{
		unbanButton.Enabled = false;
		confirmation.Enabled = false;
		status.Text = "ĐANG KIỂM TRA OFFLINE, THỦ TỤC VÀ KHÓA HẾT HẠN…";
		try
		{
			string connectionString = options.CreateConnectionString();
			preview = await Task.Run(() => new AccountModerationRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).PreviewExpiredUnban(accountId));
			if (!preview.IsOffline)
			{
				status.Text = ((preview.ConnectStat == 1) ? "ĐANG ONLINE • gỡ khóa bị từ chối." : "KHÔNG XÁC MINH ĐƯỢC OFFLINE • gỡ khóa bị từ chối.");
				return;
			}
			if (preview.TotalExpiredBans == 0)
			{
				status.Text = "KHÔNG CÓ KHÓA HẾT HẠN • khóa còn hạn được giữ nguyên.";
				return;
			}
			confirmation.Enabled = writeEnabled;
			status.Text = $"SẴN SÀNG • tài khoản hết hạn: {preview.ExpiredAccountBans}; nhân vật hết hạn: {preview.ExpiredCharacterBans}." + (writeEnabled ? " Gõ AccountID để bật nút." : " Đang khóa trong Config.ini.");
			UpdateUnbanButton();
		}
		catch (Exception ex)
		{
			status.Text = "KHÔNG THỂ KIỂM TRA • " + ex.GetBaseException().Message;
		}
	}

	private async Task UnbanAsync()
	{
		if (!writeEnabled || (object)preview == null || !preview.IsOffline || preview.TotalExpiredBans == 0 || !confirmation.Text.Equals(accountId, StringComparison.Ordinal) || MessageBox.Show(this, "Gỡ các khóa đã hết hạn cho tài khoản " + accountId + "?\n\nTài khoản và nhân vật đang bị khóa còn hạn sẽ không thay đổi.", "MU SVEN • Xác nhận gỡ khóa", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return;
		}
		unbanButton.Enabled = false;
		confirmation.Enabled = false;
		status.Text = "ĐANG GỌI WZ_DesblocAccount TRONG GIAO DỊCH…";
		try
		{
			string connectionString = options.CreateConnectionString(readOnly: false);
			AccountUnbanResult result = await Task.Run(() => new AccountModerationRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).UnbanExpired(accountId, writeEnabled));
			WasUnbanned = true;
			AccountBansCleared = result.AccountBansCleared;
			CharacterBansCleared = result.CharacterBansCleared;
			status.Text = $"ĐÃ GỠ • tài khoản: {AccountBansCleared}; nhân vật: {CharacterBansCleared}.";
			base.DialogResult = DialogResult.OK;
			Close();
		}
		catch (Exception ex)
		{
			status.Text = "GỠ KHÓA THẤT BẠI • " + ex.GetBaseException().Message;
			confirmation.Enabled = true;
			UpdateUnbanButton();
		}
	}

	private void UpdateUnbanButton()
	{
		unbanButton.Enabled = writeEnabled && (object)preview != null && preview.IsOffline && preview.TotalExpiredBans > 0 && confirmation.Text.Equals(accountId, StringComparison.Ordinal);
	}

	private static Button MakeButton(string text, bool emphasized)
	{
		Button button = new Button();
		button.Text = text;
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (emphasized ? Gold : Color.FromArgb(18, 51, 82));
		button.ForeColor = (emphasized ? Color.Black : Color.White);
		button.Margin = new Padding(4);
		button.Cursor = Cursors.Hand;
		button.FlatAppearance.BorderColor = (emphasized ? Gold : Border);
		return button;
	}
}
