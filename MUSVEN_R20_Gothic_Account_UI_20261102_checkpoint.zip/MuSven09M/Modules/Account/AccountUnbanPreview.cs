namespace MuSven09M.Modules.Account;

public sealed record AccountUnbanPreview(string AccountId, int ExpiredAccountBans, int ExpiredCharacterBans, int? ConnectStat)
{
	public int TotalExpiredBans => checked(ExpiredAccountBans + ExpiredCharacterBans);

	public bool IsOffline => ConnectStat == 0;
}
