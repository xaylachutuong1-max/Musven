namespace MuSven09M.Modules.Account;

public sealed record AccountUnbanResult(string AccountId, int AccountBansCleared, int CharacterBansCleared);
