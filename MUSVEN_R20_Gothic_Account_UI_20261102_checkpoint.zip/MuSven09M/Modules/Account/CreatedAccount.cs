namespace MuSven09M.Modules.Account;

public sealed record CreatedAccount(string AccountId, string DisplayName, string Email);
