using System;
using System.Data.Common;

namespace MuSven09M.Modules.Account;

public sealed class MuSvenDatabase
{
	private readonly DbProviderFactory factory;

	private readonly string connectionString;

	public MuSvenDatabase(DbProviderFactory providerFactory, string connectionString)
	{
		factory = providerFactory ?? throw new ArgumentNullException("providerFactory");
		if (string.IsNullOrWhiteSpace(connectionString))
		{
			throw new ArgumentException("Connection string is required.", "connectionString");
		}
		this.connectionString = connectionString;
	}

	public DbConnection OpenConnection()
	{
		DbConnection connection = factory.CreateConnection() ?? throw new InvalidOperationException("The database provider could not create a connection.");
		try
		{
			connection.ConnectionString = connectionString;
			connection.Open();
			return connection;
		}
		catch
		{
			connection.Dispose();
			throw;
		}
	}
}
