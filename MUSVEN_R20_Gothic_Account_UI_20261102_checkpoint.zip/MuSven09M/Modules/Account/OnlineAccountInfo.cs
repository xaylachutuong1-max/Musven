using System;

namespace MuSven09M.Modules.Account;

public sealed record OnlineAccountInfo(string AccountId, string? ServerName, string? IpAddress, DateTime? ConnectTime, int? OnlineHours);
