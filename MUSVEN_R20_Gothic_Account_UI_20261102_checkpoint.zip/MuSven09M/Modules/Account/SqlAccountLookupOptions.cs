using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.SqlClient;

namespace MuSven09M.Modules.Account;

public sealed class SqlAccountLookupOptions
{
	private readonly string? userId;

	private readonly string? password;

	private readonly bool useSqlAuthentication;

	public string Server { get; }

	public string Database { get; }

	public bool TrustServerCertificate { get; }

	public SqlAccountLookupOptions(string server, string database, bool trustServerCertificate = false, string authentication = "Windows", string? userId = null, string? password = null)
	{
		Server = server;
		Database = database;
		TrustServerCertificate = trustServerCertificate;
		useSqlAuthentication = authentication.Equals("Sql", StringComparison.OrdinalIgnoreCase);
		this.userId = userId;
		this.password = password;
	}

	public override string ToString()
	{
		return $"SQL options ({(useSqlAuthentication ? "SQL authentication" : "Windows authentication")}, {Server}, {Database})";
	}

	public string CreateConnectionString(bool readOnly = true)
	{
		SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder
		{
			DataSource = Server,
			InitialCatalog = Database,
			IntegratedSecurity = !useSqlAuthentication,
			ConnectTimeout = 5,
			Encrypt = true,
			TrustServerCertificate = TrustServerCertificate,
			ApplicationIntent = (readOnly ? ApplicationIntent.ReadOnly : ApplicationIntent.ReadWrite),
			ApplicationName = (readOnly ? "MU SVEN 09Q lookup" : "MU SVEN 09Q warehouse item editor")
		};
		if (useSqlAuthentication)
		{
			builder.UserID = userId ?? throw new InvalidOperationException("Config.ini thiếu SQL User.");
			builder.Password = password ?? throw new InvalidOperationException("Config.ini thiếu SQL Password.");
			builder.PersistSecurityInfo = false;
		}
		return builder.ConnectionString;
	}

	public static bool ItemWritesEnabled(string configPath)
	{
		if (!File.Exists(configPath))
		{
			return false;
		}
		bool inSection = false;
		foreach (string item in File.ReadLines(configPath))
		{
			string line = item.Trim();
			if (line.Length == 0 || line.StartsWith(';') || line.StartsWith('#'))
			{
				continue;
			}
			if (line.StartsWith('[') && line.EndsWith(']'))
			{
				string text = line;
				inSection = text.Substring(1, text.Length - 1 - 1).Trim().Equals("MUSVEN_ITEM_WRITES", StringComparison.OrdinalIgnoreCase);
			}
			else if (inSection)
			{
				int separator = line.IndexOf('=');
				if (separator > 0 && line.Substring(0, separator).Trim().Equals("Enabled", StringComparison.OrdinalIgnoreCase))
				{
					string text = line;
					int num = separator + 1;
					string value = text.Substring(num, text.Length - num).Trim();
					return value.Equals("1", StringComparison.OrdinalIgnoreCase) || value.Equals("true", StringComparison.OrdinalIgnoreCase);
				}
			}
		}
		return false;
	}

	public static bool CurrencyWritesEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_CURRENCY_WRITES");
	}

	public static bool CharacterWritesEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_CHARACTER_WRITES");
	}

	public static bool CharacterCreationEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_CHARACTER_CREATE");
	}

	public static bool CharacterDeletionEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_CHARACTER_DELETE");
	}

	public static bool CharacterRenameEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_CHARACTER_RENAME");
	}

	public static bool AccountLevelWritesEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_ACCOUNT_LEVEL");
	}

	public static bool AccountModerationEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_ACCOUNT_MODERATION");
	}

	public static bool AccountBanEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_ACCOUNT_BAN");
	}

	public static bool AccountProfileWritesEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_ACCOUNT_PROFILE");
	}

	public static bool AccountCreationEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_ACCOUNT_CREATE");
	}

	public static bool CharacterInventoryWritesEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_CHARACTER_INVENTORY");
	}

	public static bool CharacterQuestCountsEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_CHARACTER_QUEST_COUNTS");
	}

	public static bool RankingWritesEnabled(string configPath)
	{
		return IsSectionEnabled(configPath, "MUSVEN_RANKING_WRITES");
	}

	private static bool IsSectionEnabled(string configPath, string sectionName)
	{
		if (!File.Exists(configPath))
		{
			return false;
		}
		bool inSection = false;
		foreach (string item in File.ReadLines(configPath))
		{
			string line = item.Trim();
			if (line.Length == 0 || line.StartsWith(';') || line.StartsWith('#'))
			{
				continue;
			}
			if (line.StartsWith('[') && line.EndsWith(']'))
			{
				string text = line;
				inSection = text.Substring(1, text.Length - 1 - 1).Trim().Equals(sectionName, StringComparison.OrdinalIgnoreCase);
			}
			else if (inSection)
			{
				int separator = line.IndexOf('=');
				if (separator > 0 && line.Substring(0, separator).Trim().Equals("Enabled", StringComparison.OrdinalIgnoreCase))
				{
					string text = line;
					int num = separator + 1;
					string value = text.Substring(num, text.Length - num).Trim();
					return value.Equals("1", StringComparison.OrdinalIgnoreCase) || value.Equals("true", StringComparison.OrdinalIgnoreCase);
				}
			}
		}
		return false;
	}

	public static SqlAccountLookupOptions? Load(string configPath)
	{
		if (!File.Exists(configPath))
		{
			return null;
		}
		Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		string section = string.Empty;
		foreach (string item in File.ReadLines(configPath))
		{
			string line = item.Trim();
			if (line.Length == 0 || line.StartsWith(';') || line.StartsWith('#'))
			{
				continue;
			}
			if (line.StartsWith('[') && line.EndsWith(']'))
			{
				string text = line;
				section = text.Substring(1, text.Length - 1 - 1).Trim();
			}
			else if (section.Equals("MUSVEN_READ_ONLY", StringComparison.OrdinalIgnoreCase))
			{
				int separator = line.IndexOf('=');
				if (separator > 0)
				{
					string key = line.Substring(0, separator).Trim();
					string text = line;
					int num = separator + 1;
					values[key] = text.Substring(num, text.Length - num).Trim();
				}
			}
		}
		if (!values.TryGetValue("Enabled", out var enabled) || (!enabled.Equals("1", StringComparison.OrdinalIgnoreCase) && !enabled.Equals("true", StringComparison.OrdinalIgnoreCase)))
		{
			return null;
		}
		if (!values.TryGetValue("Authentication", out var authentication) || (!authentication.Equals("Windows", StringComparison.OrdinalIgnoreCase) && !authentication.Equals("Sql", StringComparison.OrdinalIgnoreCase)))
		{
			return null;
		}
		if (!values.TryGetValue("Server", out var server) || string.IsNullOrWhiteSpace(server) || server.Equals("CHANGE_ME", StringComparison.OrdinalIgnoreCase))
		{
			return null;
		}
		if (!values.TryGetValue("Database", out var database) || string.IsNullOrWhiteSpace(database) || database.Equals("CHANGE_ME", StringComparison.OrdinalIgnoreCase))
		{
			return null;
		}
		string trustValue;
		bool trustServerCertificate = values.TryGetValue("TrustServerCertificate", out trustValue) && (trustValue.Equals("1", StringComparison.OrdinalIgnoreCase) || trustValue.Equals("true", StringComparison.OrdinalIgnoreCase));
		string userId = null;
		string password = null;
		if (authentication.Equals("Sql", StringComparison.OrdinalIgnoreCase) && (!values.TryGetValue("User", out userId) || string.IsNullOrWhiteSpace(userId) || !values.TryGetValue("Password", out password) || string.IsNullOrWhiteSpace(password)))
		{
			return null;
		}
		return new SqlAccountLookupOptions(server, database, trustServerCertificate, authentication, userId, password);
	}
}
