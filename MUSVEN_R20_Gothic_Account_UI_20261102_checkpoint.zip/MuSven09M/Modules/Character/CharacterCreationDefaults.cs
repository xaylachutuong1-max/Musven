using System;

namespace MuSven09M.Modules.Character;

public sealed record CharacterCreationDefaults(int Level, int Points, int Zen, int Reset, int MasterLevel, int MasterPoints, int WCoinC, int WCoinP, int GoblinPoint)
{
	public void Validate()
	{
		int level = Level;
		if ((level < 0 || level > 400) ? true : false)
		{
			throw new InvalidOperationException("Level khi tạo phải từ 0 đến 400.");
		}
		level = Points;
		if ((level < 0 || level > 100000000) ? true : false)
		{
			throw new InvalidOperationException("Point tặng phải từ 0 đến 100.000.000.");
		}
		level = Zen;
		if ((level < 0 || level > 2000000000) ? true : false)
		{
			throw new InvalidOperationException("Zen tặng phải từ 0 đến 2.000.000.000.");
		}
		level = Reset;
		if ((level < 0 || level > 1000000) ? true : false)
		{
			throw new InvalidOperationException("Reset tặng phải từ 0 đến 1.000.000.");
		}
		level = MasterLevel;
		if ((level < 0 || level > 400) ? true : false)
		{
			throw new InvalidOperationException("Master Level tặng phải từ 0 đến 400.");
		}
		level = MasterPoints;
		if ((level < 0 || level > 400) ? true : false)
		{
			throw new InvalidOperationException("Điểm Master tặng phải từ 0 đến 400.");
		}
		if (WCoinC < 0 || WCoinP < 0 || GoblinPoint < 0)
		{
			throw new InvalidOperationException("Tiền tặng phải là số nguyên không âm.");
		}
	}
}
