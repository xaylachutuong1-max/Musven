using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

internal sealed class CharacterCreationForm : Form
{
	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions databaseOptions;

	private readonly bool writeEnabled;

	private readonly NumericUpDown levelBox = Number(400, 400);

	private readonly NumericUpDown pointsBox = Number(100000, 100000000);

	private readonly NumericUpDown zenBox = Number(2000000000, 2000000000);

	private readonly NumericUpDown resetBox = Number(500, 1000000);

	private readonly NumericUpDown masterLevelBox = Number(400, 400);

	private readonly NumericUpDown masterPointsBox = Number(400, 400);

	private readonly NumericUpDown wcoinCBox = Number(100000000, int.MaxValue);

	private readonly NumericUpDown wcoinPBox = Number(100000000, int.MaxValue);

	private readonly NumericUpDown goblinBox = Number(100000000, int.MaxValue);

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button saveButton = new Button
	{
		Text = "LƯU MẶC ĐỊNH",
		Dock = DockStyle.Fill
	};

	public CharacterCreationForm(SqlAccountLookupOptions options, bool writeEnabled)
	{
		databaseOptions = options;
		this.writeEnabled = writeEnabled;
		Text = "MU SVEN • CẤU HÌNH TẠO NHÂN VẬT";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(820, 650);
		base.Size = new Size(900, 700);
		BackColor = Color.FromArgb(5, 11, 23);
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 10f);
		BuildLayout();
		UiTheme.Apply(this);
		base.Load += async delegate
		{
			await LoadDefaultsAsync();
		};
		saveButton.Click += async delegate
		{
			await SaveAsync();
		};
	}

	private void BuildLayout()
	{
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 4,
			Padding = new Padding(14)
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 52f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = "MẶC ĐỊNH KHI NGƯỜI CHƠI TẠO NHÂN VẬT TRONG GAME",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 13f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleCenter
		}, 0, 0);
		GroupBox frame = new GroupBox
		{
			Text = "PHẦN THƯỞNG VÀ GIÁ TRỊ KHỞI TẠO TOÀN SERVER",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			BackColor = Surface,
			Padding = new Padding(12)
		};
		TableLayoutPanel fields = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 4,
			RowCount = 5,
			Padding = new Padding(12, 24, 12, 8)
		};
		fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27f));
		fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 23f));
		fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27f));
		fields.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 23f));
		for (int row = 0; row < fields.RowCount; row++)
		{
			fields.RowStyles.Add(new RowStyle(SizeType.Percent, 20f));
		}
		AddSetting(fields, 0, 0, "Level mới (tối đa 400)", levelBox);
		AddSetting(fields, 2, 0, "Point tặng", pointsBox);
		AddSetting(fields, 0, 1, "Zen tặng", zenBox);
		AddSetting(fields, 2, 1, "Reset tặng", resetBox);
		AddSetting(fields, 0, 2, "Master Level (tối đa 400)", masterLevelBox);
		AddSetting(fields, 2, 2, "Điểm Master (tối đa 400)", masterPointsBox);
		AddSetting(fields, 0, 3, "WCoin C cộng", wcoinCBox);
		AddSetting(fields, 2, 3, "WCoin P cộng", wcoinPBox);
		AddSetting(fields, 0, 4, "WCoin G cộng", goblinBox);
		Label currencyHint = new Label
		{
			Text = "WCoin là số dư tài khoản, được cộng theo mỗi lần tạo nhân vật.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.MiddleLeft,
			AutoEllipsis = true
		};
		fields.Controls.Add(currencyHint, 2, 4);
		fields.SetColumnSpan(currencyHint, 2);
		frame.Controls.Add(fields);
		root.Controls.Add(frame, 0, 1);
		root.Controls.Add(new Label
		{
			Text = "Cấu hình được lưu trực tiếp vào database Muonline và áp dụng cho nhân vật được tạo sau khi lưu. Nhân vật hiện có không bị thay đổi.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 2);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 175f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 105f));
		footer.Controls.Add(status, 0, 0);
		StyleButton(saveButton, primary: true);
		saveButton.Enabled = false;
		footer.Controls.Add(saveButton, 1, 0);
		Button close = new Button
		{
			Text = "ĐÓNG",
			Dock = DockStyle.Fill
		};
		StyleButton(close, primary: false);
		close.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(close, 2, 0);
		root.Controls.Add(footer, 0, 3);
	}

	private async Task LoadDefaultsAsync()
	{
		saveButton.Enabled = false;
		status.Text = "Đang đọc cấu hình mặc định từ database Muonline…";
		try
		{
			MuSvenDatabase database = new MuSvenDatabase(SqlClientFactory.Instance, databaseOptions.CreateConnectionString());
			CharacterCreationDefaults defaults = await Task.Run(() => new CharacterCreationRepository(database).LoadDefaults());
			levelBox.Value = defaults.Level;
			pointsBox.Value = defaults.Points;
			zenBox.Value = defaults.Zen;
			resetBox.Value = defaults.Reset;
			masterLevelBox.Value = defaults.MasterLevel;
			masterPointsBox.Value = defaults.MasterPoints;
			wcoinCBox.Value = defaults.WCoinC;
			wcoinPBox.Value = defaults.WCoinP;
			goblinBox.Value = defaults.GoblinPoint;
			status.Text = (writeEnabled ? "Đã tải cấu hình hiện dùng; thay đổi sẽ áp dụng cho lượt tạo nhân vật tiếp theo." : "Đang ở chế độ chỉ xem. Bật [MUSVEN_CHARACTER_CREATE] Enabled=1 để lưu cấu hình.");
			saveButton.Enabled = writeEnabled;
		}
		catch (InvalidOperationException ex)
		{
			status.Text = ex.Message;
		}
		catch (SqlException)
		{
			status.Text = "Không đọc được cấu hình SQL. Kiểm tra kết nối và quyền SELECT.";
		}
		catch
		{
			status.Text = "Không đọc được cấu hình. Musven không hiển thị thông tin kết nối.";
		}
	}

	private async Task SaveAsync()
	{
		if (!writeEnabled)
		{
			return;
		}
		CharacterCreationDefaults defaults = new CharacterCreationDefaults((int)levelBox.Value, (int)pointsBox.Value, (int)zenBox.Value, (int)resetBox.Value, (int)masterLevelBox.Value, (int)masterPointsBox.Value, (int)wcoinCBox.Value, (int)wcoinPBox.Value, (int)goblinBox.Value);
		defaults.Validate();
		string values = string.Join("\n", $"Level {defaults.Level:N0} • Point {defaults.Points:N0} • Zen {defaults.Zen:N0} • Reset {defaults.Reset:N0}", $"Master Level {defaults.MasterLevel:N0} • Điểm Master {defaults.MasterPoints:N0}", $"WCoin cộng mỗi lượt tạo: C {defaults.WCoinC:N0} • P {defaults.WCoinP:N0} • G {defaults.GoblinPoint:N0}");
		if (MessageBox.Show(this, "Lưu mặc định toàn server vào database Muonline?\n\n" + values + "\n\nCác lượt tạo nhân vật trong game sau đó sẽ dùng các giá trị này. Nhân vật cũ không đổi.", "Xác nhận lưu cấu hình", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return;
		}
		saveButton.Enabled = false;
		status.Text = "Đang lưu cấu hình vào Muonline…";
		try
		{
			MuSvenDatabase database = new MuSvenDatabase(SqlClientFactory.Instance, databaseOptions.CreateConnectionString(readOnly: false));
			await Task.Run(delegate
			{
				new CharacterCreationRepository(database).SaveDefaults(defaults);
			});
			status.Text = "Đã lưu vào Muonline. Nhân vật tạo trong game tiếp theo sẽ nhận cấu hình này.";
			base.DialogResult = DialogResult.OK;
		}
		catch (InvalidOperationException ex)
		{
			status.Text = ex.Message;
		}
		catch (SqlException)
		{
			status.Text = "SQL từ chối lưu. Kiểm tra quyền UPDATE trên bảng cấu hình.";
		}
		catch
		{
			status.Text = "Không lưu được cấu hình. Musven không hiển thị thông tin kết nối.";
		}
		finally
		{
			saveButton.Enabled = writeEnabled;
		}
	}

	private static Label FieldLabel(string text)
	{
		return new Label
		{
			Text = text,
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			TextAlign = ContentAlignment.MiddleLeft,
			AutoEllipsis = true
		};
	}

	private static NumericUpDown Number(int value, int maximum)
	{
		return new NumericUpDown
		{
			Minimum = 0m,
			Maximum = maximum,
			Value = value,
			Dock = DockStyle.Fill,
			TextAlign = HorizontalAlignment.Right,
			ThousandsSeparator = true,
			BackColor = Color.FromArgb(18, 37, 58),
			ForeColor = Color.White,
			BorderStyle = BorderStyle.FixedSingle,
			Margin = new Padding(4, 8, 4, 8)
		};
	}

	private static void AddSetting(TableLayoutPanel layout, int labelColumn, int row, string label, NumericUpDown control)
	{
		layout.Controls.Add(FieldLabel(label), labelColumn, row);
		layout.Controls.Add(control, labelColumn + 1, row);
	}

	private static void StyleButton(Button button, bool primary)
	{
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (primary ? Gold : Color.FromArgb(32, 40, 52));
		button.ForeColor = (primary ? Color.Black : Color.White);
		button.FlatAppearance.BorderColor = (primary ? Gold : Border);
		button.Margin = new Padding(4, 3, 4, 3);
	}
}
