using System;
using System.Data;
using System.Data.Common;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

public sealed class CharacterCreationRepository
{
	private const string VersionMarker = "MU SVEN CHARACTER DEFAULTS V03";

	private readonly MuSvenDatabase database;

	public CharacterCreationRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public CharacterCreationDefaults LoadDefaults()
	{
		using DbConnection connection = database.OpenConnection();
		EnsureInstalledProcedure(connection, null);
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 8;
		command.CommandText = "SELECT StartLevel, StartPoints, StartZen, StartReset,\n       MasterLevel, MasterPoints, WCoinC, WCoinP, GoblinPoint\nFROM dbo.MUSVEN_CharacterCreateDefaults\nWHERE ConfigID=1";
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read())
		{
			throw new InvalidOperationException("Database chưa có cấu hình mặc định nhân vật. Hãy cài script SQL đi kèm.");
		}
		CharacterCreationDefaults characterCreationDefaults = ReadDefaults(reader);
		if (reader.Read())
		{
			throw new InvalidOperationException("Bảng cấu hình có nhiều dòng cho máy chủ; Musven không tải cấu hình.");
		}
		characterCreationDefaults.Validate();
		return characterCreationDefaults;
	}

	public void SaveDefaults(CharacterCreationDefaults defaults)
	{
		ArgumentNullException.ThrowIfNull(defaults, "defaults");
		defaults.Validate();
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			EnsureInstalledProcedure(connection, transaction);
			using DbCommand command = connection.CreateCommand();
			command.Transaction = transaction;
			command.CommandTimeout = 8;
			command.CommandText = "UPDATE dbo.MUSVEN_CharacterCreateDefaults\nSET StartLevel=@Level, StartPoints=@Points, StartZen=@Zen, StartReset=@Reset,\n    MasterLevel=@MasterLevel, MasterPoints=@MasterPoints,\n    WCoinC=@WCoinC, WCoinP=@WCoinP, GoblinPoint=@GoblinPoint,\n    ModifiedAt=GETDATE()\nWHERE ConfigID=1";
			AddParameter(command, "@Level", defaults.Level);
			AddParameter(command, "@Points", defaults.Points);
			AddParameter(command, "@Zen", defaults.Zen);
			AddParameter(command, "@Reset", defaults.Reset);
			AddParameter(command, "@MasterLevel", defaults.MasterLevel);
			AddParameter(command, "@MasterPoints", defaults.MasterPoints);
			AddParameter(command, "@WCoinC", defaults.WCoinC);
			AddParameter(command, "@WCoinP", defaults.WCoinP);
			AddParameter(command, "@GoblinPoint", defaults.GoblinPoint);
			if (command.ExecuteNonQuery() != 1)
			{
				throw new InvalidOperationException("Không cập nhật đúng một dòng cấu hình trong Muonline; giao dịch đã hủy.");
			}
			transaction.Commit();
		}
		catch
		{
			try
			{
				transaction.Rollback();
			}
			catch
			{
			}
			throw;
		}
	}

	private static CharacterCreationDefaults ReadDefaults(DbDataReader reader)
	{
		return new CharacterCreationDefaults(Convert.ToInt32(reader.GetValue(0)), Convert.ToInt32(reader.GetValue(1)), Convert.ToInt32(reader.GetValue(2)), Convert.ToInt32(reader.GetValue(3)), Convert.ToInt32(reader.GetValue(4)), Convert.ToInt32(reader.GetValue(5)), Convert.ToInt32(reader.GetValue(6)), Convert.ToInt32(reader.GetValue(7)), Convert.ToInt32(reader.GetValue(8)));
	}

	private static void EnsureInstalledProcedure(DbConnection connection, DbTransaction? transaction)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT OBJECT_DEFINITION(OBJECT_ID(N'dbo.WZ_CreateCharacter'))";
		string definition = Convert.ToString(command.ExecuteScalar());
		if (string.IsNullOrWhiteSpace(definition) || !definition.Contains("MU SVEN CHARACTER DEFAULTS V03", StringComparison.OrdinalIgnoreCase) || !definition.Contains("dbo.MUSVEN_CharacterCreateDefaults", StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("WZ_CreateCharacter chưa đọc cấu hình V03. Hãy áp dụng MUSVEN_CharacterCreateDefaults.sql trong package trước.");
		}
	}

	private static void AddParameter(DbCommand command, string name, int value)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = DbType.Int32;
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}
}
