using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

public sealed class CharacterDeletionForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly string accountId;

	private readonly string characterName;

	private readonly bool deletionEnabled;

	private readonly TextBox confirmation = new TextBox
	{
		Dock = DockStyle.Fill,
		BackColor = Color.FromArgb(18, 37, 58),
		ForeColor = Color.White,
		BorderStyle = BorderStyle.FixedSingle,
		MaxLength = 10
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button deleteButton;

	public CharacterDeletionForm(SqlAccountLookupOptions options, string accountId, string characterName, bool deletionEnabled)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.accountId = accountId.Trim();
		this.characterName = characterName.Trim();
		this.deletionEnabled = deletionEnabled;
		Text = "MU SVEN • Xóa nhân vật";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(610, 390);
		base.Size = new Size(700, 430);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 5,
			Padding = new Padding(18),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 46f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 82f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = "XÓA NHÂN VẬT",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 14f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		root.Controls.Add(new Label
		{
			Text = "Tài khoản: " + this.accountId + "     •     Nhân vật: " + this.characterName,
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			Font = new Font("Segoe UI", 10f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 1);
		root.Controls.Add(new Label
		{
			Text = "Thao tác này xóa nhân vật và dữ liệu liên quan trong nhiều bảng. Không thể hoàn tác. Tài khoản phải offline; Guild Master cần được chuyển quyền guild trước. Hãy đảm bảo có bản backup trước khi tiếp tục.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(4)
		}, 0, 2);
		Panel confirmPanel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			Padding = new Padding(10, 34, 10, 8),
			Margin = new Padding(2)
		};
		confirmPanel.Controls.Add(new Label
		{
			Text = "GÕ CHÍNH XÁC TÊN NHÂN VẬT ĐỂ MỞ NÚT XÓA",
			Location = new Point(10, 5),
			Size = new Size(520, 24),
			ForeColor = Gold,
			Font = new Font("Segoe UI", 9f, FontStyle.Bold)
		});
		confirmPanel.Controls.Add(confirmation);
		confirmPanel.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border, 1.2f);
			e.Graphics.DrawRectangle(pen, 1, 1, Math.Max(1, confirmPanel.Width - 3), Math.Max(1, confirmPanel.Height - 3));
		};
		root.Controls.Add(confirmPanel, 0, 3);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = Padding.Empty
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120f));
		footer.Controls.Add(status, 0, 0);
		deleteButton = MakeButton("XÓA NHÂN VẬT", emphasized: true);
		deleteButton.Enabled = false;
		deleteButton.Click += async delegate
		{
			await DeleteAsync();
		};
		footer.Controls.Add(deleteButton, 1, 0);
		Button cancel = MakeButton("HỦY", emphasized: false);
		cancel.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(cancel, 2, 0);
		root.Controls.Add(footer, 0, 4);
		confirmation.TextChanged += delegate
		{
			deleteButton.Enabled = this.deletionEnabled && confirmation.Text.Equals(this.characterName, StringComparison.Ordinal);
		};
		status.Text = (deletionEnabled ? "ĐÃ BẬT CỜ RIÊNG • vẫn cần backup và xác nhận hai lần." : "ĐANG KHÓA • bật riêng [MUSVEN_CHARACTER_DELETE] Enabled=1 trong Config.ini.");
		UiTheme.Apply(this);
	}

	private async Task DeleteAsync()
	{
		if (!confirmation.Text.Equals(characterName, StringComparison.Ordinal) || MessageBox.Show(this, $"Xóa vĩnh viễn nhân vật {characterName} thuộc tài khoản {accountId}?", "MU SVEN • Xác nhận lần cuối", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return;
		}
		deleteButton.Enabled = false;
		confirmation.Enabled = false;
		status.Text = "ĐANG KIỂM TRA OFFLINE VÀ GỌI WZ_DeleteCharacter...";
		try
		{
			string connectionString = options.CreateConnectionString(readOnly: false);
			await Task.Run(delegate
			{
				new CharacterDeletionRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).Delete(accountId, characterName, deletionEnabled);
			});
			status.Text = "ĐÃ XÓA NHÂN VẬT VÀ DỮ LIỆU LIÊN QUAN.";
			base.DialogResult = DialogResult.OK;
			Close();
		}
		catch (Exception ex)
		{
			status.Text = "XÓA THẤT BẠI • " + ex.Message;
			MessageBox.Show(this, ex.Message, "MU SVEN • Không thể xóa", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			confirmation.Enabled = true;
			deleteButton.Enabled = deletionEnabled && confirmation.Text.Equals(characterName, StringComparison.Ordinal);
		}
	}

	private static Button MakeButton(string text, bool emphasized)
	{
		Button button = new Button();
		button.Text = text;
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (emphasized ? Gold : Color.FromArgb(18, 51, 82));
		button.ForeColor = (emphasized ? Color.Black : Color.White);
		button.Margin = new Padding(4);
		button.Cursor = Cursors.Hand;
		button.FlatAppearance.BorderColor = (emphasized ? Gold : Border);
		return button;
	}
}
