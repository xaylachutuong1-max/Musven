using System;
using System.Data;
using System.Data.Common;
using System.Linq;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

public sealed class CharacterDeletionRepository
{
	private readonly MuSvenDatabase database;

	public CharacterDeletionRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public void Delete(string accountId, string characterName, bool deletionEnabled)
	{
		accountId = ValidateValue(accountId, "AccountID");
		characterName = ValidateValue(characterName, "Tên nhân vật");
		if (!deletionEnabled)
		{
			throw new InvalidOperationException("Xóa nhân vật đang khóa. Bật riêng [MUSVEN_CHARACTER_DELETE] Enabled=1 sau khi xác minh SQL.");
		}
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			EnsureInstalledProcedureMatches(connection, transaction);
			EnsureAccountOffline(connection, transaction, accountId);
			EnsureCharacterBelongsToAccount(connection, transaction, accountId, characterName);
			using DbCommand command = connection.CreateCommand();
			command.Transaction = transaction;
			command.CommandTimeout = 20;
			command.CommandType = CommandType.StoredProcedure;
			command.CommandText = "dbo.WZ_DeleteCharacter";
			AddParameter(command, "@Account", accountId);
			AddParameter(command, "@Name", characterName);
			object raw = command.ExecuteScalar();
			if (raw == null || raw is DBNull || !byte.TryParse(Convert.ToString(raw), out var result))
			{
				throw new InvalidOperationException("dbo.WZ_DeleteCharacter không trả mã kết quả hợp lệ; giao dịch bị hủy.");
			}
			if (result != 1)
			{
				TryRollback(transaction);
				throw new InvalidOperationException("Thủ tục từ chối xóa. Nhân vật có thể không thuộc tài khoản, đang là Guild Master, hoặc một bảng phụ gặp lỗi; không có dữ liệu nào được Musven commit.");
			}
			transaction.Commit();
		}
		catch
		{
			TryRollback(transaction);
			throw;
		}
	}

	private static void EnsureInstalledProcedureMatches(DbConnection connection, DbTransaction transaction)
	{
		string definition;
		using (DbCommand command = connection.CreateCommand())
		{
			command.Transaction = transaction;
			command.CommandTimeout = 8;
			command.CommandText = "SELECT OBJECT_DEFINITION(OBJECT_ID(N'dbo.WZ_DeleteCharacter'))";
			definition = Convert.ToString(command.ExecuteScalar()) ?? string.Empty;
		}
		string[] array = new string[7] { "owner verification", "BEGIN TRANSACTION", "AccountCharacter", "GameID1", "G_Master", "GoblinMix", "T_FriendMail" };
		foreach (string marker in array)
		{
			if (!definition.Contains(marker, StringComparison.OrdinalIgnoreCase))
			{
				throw new InvalidOperationException("Định nghĩa dbo.WZ_DeleteCharacter không khớp bản V02 đã rà soát (thiếu marker " + marker + "); Musven chưa gọi thủ tục.");
			}
		}
		using DbCommand parameters = connection.CreateCommand();
		parameters.Transaction = transaction;
		parameters.CommandTimeout = 8;
		parameters.CommandText = "\nSELECT p.parameter_id, p.name, ty.name, p.max_length, p.is_output\nFROM sys.parameters AS p\nJOIN sys.types AS ty ON ty.user_type_id = p.user_type_id\nWHERE p.object_id = OBJECT_ID(N'dbo.WZ_DeleteCharacter') AND p.parameter_id > 0\nORDER BY p.parameter_id";
		using DbDataReader reader = parameters.ExecuteReader();
		(string, string, int)[] expected = new(string, string, int)[2]
		{
			("@Account", "varchar", 10),
			("@Name", "varchar", 10)
		};
		for (int j = 0; j < expected.Length; j++)
		{
			if (!reader.Read() || Convert.ToInt32(reader.GetValue(0)) != j + 1 || !Convert.ToString(reader.GetValue(1)).Equals(expected[j].Item1, StringComparison.OrdinalIgnoreCase) || !Convert.ToString(reader.GetValue(2)).Equals(expected[j].Item2, StringComparison.OrdinalIgnoreCase) || Convert.ToInt32(reader.GetValue(3)) != expected[j].Item3 || Convert.ToBoolean(reader.GetValue(4)))
			{
				throw new InvalidOperationException("Chữ ký dbo.WZ_DeleteCharacter khác V02 (@Account varchar(10), @Name varchar(10)); Musven chưa gọi thủ tục.");
			}
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.WZ_DeleteCharacter có tham số bổ sung ngoài V02; Musven chưa gọi thủ tục.");
		}
	}

	private static void EnsureAccountOffline(DbConnection connection, DbTransaction transaction, string accountId)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "\nSELECT TOP (2) ConnectStat\nFROM dbo.MEMB_STAT WITH (UPDLOCK, HOLDLOCK)\nWHERE memb___id = @Account";
		AddParameter(command, "@Account", accountId);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không xác định được trạng thái tài khoản trong dbo.MEMB_STAT; Musven từ chối xóa.");
		}
		if (reader.IsDBNull(0) || Convert.ToInt32(reader.GetValue(0)) != 0)
		{
			throw new InvalidOperationException("Tài khoản đang online hoặc trạng thái chưa rõ. Hãy đăng xuất trước khi xóa nhân vật.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.MEMB_STAT có nhiều dòng cho tài khoản này; Musven từ chối xóa.");
		}
	}

	private static void EnsureCharacterBelongsToAccount(DbConnection connection, DbTransaction transaction, string accountId, string characterName)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "\nSELECT TOP (2) AccountID\nFROM dbo.[Character] WITH (UPDLOCK, HOLDLOCK)\nWHERE [Name] = @Name";
		AddParameter(command, "@Name", characterName);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không tìm thấy nhân vật này trong dbo.Character.");
		}
		if (!(Convert.ToString(reader.GetValue(0)) ?? string.Empty).Equals(accountId, StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("Tên nhân vật không thuộc tài khoản đang chọn.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("Tên nhân vật xuất hiện ở nhiều tài khoản. Vì thủ tục dọn dữ liệu theo tên, Musven từ chối xóa.");
		}
	}

	private static string ValidateValue(string value, string label)
	{
		string result = value?.Trim() ?? string.Empty;
		int length = result.Length;
		bool flag = ((length < 1 || length > 10) ? true : false);
		if (flag || result.Any(char.IsControl) || result.Any(char.IsWhiteSpace))
		{
			throw new ArgumentException(label + " phải có từ 1 đến 10 ký tự, không có khoảng trắng.", label);
		}
		return result;
	}

	private static void AddParameter(DbCommand command, string name, string value)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = DbType.AnsiString;
		parameter.Size = 10;
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}

	private static void TryRollback(DbTransaction transaction)
	{
		try
		{
			transaction.Rollback();
		}
		catch
		{
		}
	}
}
