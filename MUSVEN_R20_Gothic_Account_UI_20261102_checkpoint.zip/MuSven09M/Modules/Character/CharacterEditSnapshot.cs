using System.Collections.Generic;

namespace MuSven09M.Modules.Character;

public sealed record CharacterEditSnapshot(string AccountId, string Name, IReadOnlyList<CharacterField> Fields, string Notice);
