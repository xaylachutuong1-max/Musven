using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

internal sealed class CharacterEditorForm : Form
{
	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly bool writeEnabled;

	private readonly string accountId;

	private readonly string characterName;

	private readonly TableLayoutPanel fieldsPanel = new TableLayoutPanel
	{
		Dock = DockStyle.Fill,
		ColumnCount = 2,
		AutoScroll = true,
		Padding = new Padding(10)
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button saveButton = new Button();

	private readonly List<(CharacterField Field, NumericUpDown? Editor)> editors = new List<(CharacterField, NumericUpDown)>();

	private CharacterEditSnapshot? snapshot;

	public CharacterEditorForm(SqlAccountLookupOptions options, bool writeEnabled, string accountId, string characterName)
	{
		this.options = options;
		this.writeEnabled = writeEnabled;
		this.accountId = accountId;
		this.characterName = characterName;
		Text = "MU SVEN • SỬA THÔNG TIN NHÂN VẬT";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(820, 650);
		base.Size = new Size(980, 780);
		BackColor = Color.FromArgb(5, 11, 23);
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		BuildLayout();
		UiTheme.Apply(this);
		base.Load += async delegate
		{
			await LoadCharacterAsync();
		};
		saveButton.Click += async delegate
		{
			await SaveAsync();
		};
	}

	private void BuildLayout()
	{
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 4,
			Padding = new Padding(10)
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 64f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 42f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54f));
		base.Controls.Add(root);
		Label heading = new Label
		{
			Text = "TÀI KHOẢN: " + accountId + "     •     NHÂN VẬT: " + characterName,
			Dock = DockStyle.Fill,
			BackColor = Surface,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 12f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleCenter
		};
		root.Controls.Add(heading, 0, 0);
		GroupBox frame = new GroupBox
		{
			Text = "TRƯỜNG SỐ CÓ TRONG dbo.Character",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			BackColor = Surface,
			Padding = new Padding(8)
		};
		fieldsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		fieldsPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		frame.Controls.Add(fieldsPanel);
		root.Controls.Add(frame, 0, 1);
		Label note = new Label
		{
			Text = (writeEnabled ? "Tài khoản phải ngoại tuyến khi lưu. Musven chỉ sửa các trường số cho phép; inventory, kỹ năng và item không bị thay đổi." : "Chế độ xem/soạn. Để lưu, bật [MUSVEN_CHARACTER_WRITES] trong Config.ini sau khi cấp quyền SQL."),
			Dock = DockStyle.Fill,
			ForeColor = (writeEnabled ? Color.FromArgb(103, 240, 170) : Color.FromArgb(255, 178, 115)),
			TextAlign = ContentAlignment.MiddleLeft
		};
		root.Controls.Add(note, 0, 2);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120f));
		footer.Controls.Add(status, 0, 0);
		saveButton.Text = "LƯU THAY ĐỔI";
		StyleButton(saveButton, primary: true);
		saveButton.Enabled = false;
		footer.Controls.Add(saveButton, 1, 0);
		Button close = new Button
		{
			Text = "ĐÓNG",
			Dock = DockStyle.Fill
		};
		StyleButton(close, primary: false);
		close.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(close, 2, 0);
		root.Controls.Add(footer, 0, 3);
	}

	private async Task LoadCharacterAsync()
	{
		saveButton.Enabled = false;
		status.Text = "Đang đọc schema và dữ liệu nhân vật…";
		try
		{
			CharacterEditorRepository repository = ReadRepository();
			snapshot = await Task.Run(() => repository.Load(accountId, characterName));
			fieldsPanel.Controls.Clear();
			editors.Clear();
			fieldsPanel.RowCount = snapshot.Fields.Count;
			fieldsPanel.RowStyles.Clear();
			int row = 0;
			using (IEnumerator<CharacterField> enumerator = snapshot.Fields.GetEnumerator())
			{
				CharacterField field;
				Panel cell;
				NumericUpDown editor;
				for (; enumerator.MoveNext(); fieldsPanel.Controls.Add(cell, row % 2, row / 2), editors.Add((field, editor)), row++)
				{
					field = enumerator.Current;
					fieldsPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
					cell = new Panel
					{
						Dock = DockStyle.Fill,
						Margin = new Padding(4),
						BackColor = Color.FromArgb(8, 20, 36)
					};
					Label label = new Label
					{
						Text = field.Label,
						Dock = DockStyle.Top,
						Height = 24,
						ForeColor = Ice,
						TextAlign = ContentAlignment.MiddleLeft,
						Padding = new Padding(7, 0, 0, 0)
					};
					cell.Controls.Add(label);
					editor = null;
					decimal? value = field.Value;
					if (value.HasValue)
					{
						decimal value2 = value.GetValueOrDefault();
						if (value2 >= field.Minimum && value2 <= field.Maximum)
						{
							editor = new NumericUpDown
							{
								Minimum = field.Minimum,
								Maximum = field.Maximum,
								Value = value2,
								Dock = DockStyle.Bottom,
								Height = 28,
								BackColor = Color.FromArgb(18, 37, 58),
								ForeColor = Color.White,
								BorderStyle = BorderStyle.FixedSingle,
								TextAlign = HorizontalAlignment.Center,
								ThousandsSeparator = true,
								DecimalPlaces = ((field.DataType.Equals("real", StringComparison.OrdinalIgnoreCase) || field.DataType.Equals("float", StringComparison.OrdinalIgnoreCase)) ? 2 : 0),
								Increment = ((field.DataType.Equals("real", StringComparison.OrdinalIgnoreCase) || field.DataType.Equals("float", StringComparison.OrdinalIgnoreCase)) ? 0.1m : 1m)
							};
							editor.ValueChanged += delegate
							{
								UpdateSaveEnabled();
							};
							cell.Controls.Add(editor);
							continue;
						}
					}
					cell.Controls.Add(new Label
					{
						Text = (field.Value?.ToString("N0") ?? "NULL"),
						Dock = DockStyle.Bottom,
						Height = 28,
						ForeColor = Color.Silver,
						TextAlign = ContentAlignment.MiddleCenter
					});
				}
			}
			status.Text = $"Đã tải {snapshot.Fields.Count} trường số • {snapshot.Notice}";
			UpdateSaveEnabled();
		}
		catch (InvalidOperationException ex)
		{
			status.Text = ex.Message;
		}
		catch
		{
			status.Text = "Không tải được nhân vật. Kiểm tra kết nối SQL, schema và quyền SELECT.";
		}
	}

	private async Task SaveAsync()
	{
		if (!writeEnabled || (object)snapshot == null)
		{
			return;
		}
		Dictionary<string, decimal> changed = editors.Where<(CharacterField, NumericUpDown)>(delegate((CharacterField Field, NumericUpDown Editor) x)
		{
			if (x.Editor != null)
			{
				decimal? value = x.Field.Value;
				decimal value2 = x.Editor.Value;
				return !((value.GetValueOrDefault() == value2) & value.HasValue);
			}
			return false;
		}).ToDictionary<(CharacterField, NumericUpDown), string, decimal>(((CharacterField Field, NumericUpDown Editor) x) => x.Field.Key, ((CharacterField Field, NumericUpDown Editor) x) => x.Editor.Value, StringComparer.OrdinalIgnoreCase);
		if (changed.Count == 0)
		{
			status.Text = "Không có thay đổi cần lưu.";
		}
		else
		{
			if (MessageBox.Show(this, $"Lưu {changed.Count} trường cho nhân vật {snapshot.Name} (tài khoản {snapshot.AccountId})?\n\nNhân vật phải ngoại tuyến. Inventory, kỹ năng, kho và bảng tài khoản không bị thay đổi.", "Xác nhận sửa nhân vật", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
			{
				return;
			}
			saveButton.Enabled = false;
			status.Text = "Đang khóa dòng, kiểm tra ngoại tuyến và lưu…";
			try
			{
				MuSvenDatabase writeDatabase = new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString(readOnly: false));
				int count = await Task.Run(() => new CharacterEditorRepository(writeDatabase).Save(snapshot, changed));
				MessageBox.Show(this, $"Đã cập nhật {count} trường cho {snapshot.Name}.", "MU SVEN • Đã lưu", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				base.DialogResult = DialogResult.OK;
				Close();
			}
			catch (InvalidOperationException ex)
			{
				status.Text = ex.Message;
			}
			catch (SqlException)
			{
				status.Text = "SQL từ chối giao dịch. Kiểm tra quyền SELECT/UPDATE, schema và trạng thái kết nối.";
			}
			catch
			{
				status.Text = "Không lưu được giao dịch. Kiểm tra cấu hình SQL; Musven không hiển thị thông tin kết nối.";
			}
			finally
			{
				UpdateSaveEnabled();
			}
		}
	}

	private void UpdateSaveEnabled()
	{
		saveButton.Enabled = writeEnabled && (object)snapshot != null && editors.Any<(CharacterField, NumericUpDown)>(delegate((CharacterField Field, NumericUpDown Editor) x)
		{
			if (x.Editor != null)
			{
				decimal? value = x.Field.Value;
				decimal value2 = x.Editor.Value;
				return !((value.GetValueOrDefault() == value2) & value.HasValue);
			}
			return false;
		});
	}

	private CharacterEditorRepository ReadRepository()
	{
		return new CharacterEditorRepository(new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString()));
	}

	private static void StyleButton(Button button, bool primary)
	{
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (primary ? Gold : Color.FromArgb(32, 40, 52));
		button.ForeColor = (primary ? Color.Black : Color.White);
		button.FlatAppearance.BorderColor = (primary ? Gold : Border);
		button.Margin = new Padding(4, 3, 4, 3);
	}
}
