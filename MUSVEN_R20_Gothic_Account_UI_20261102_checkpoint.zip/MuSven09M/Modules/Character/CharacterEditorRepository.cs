using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

public sealed class CharacterEditorRepository
{
	private sealed record FieldSpec(string Key, string Label, decimal Minimum, decimal Maximum, string[] Candidates, string TableName = "Character", bool AllowReal = false);

	private static readonly FieldSpec[] Specs = new FieldSpec[29]
	{
		new FieldSpec("level", "Cấp độ", 0m, 400m, new string[2] { "cLevel", "Level" }),
		new FieldSpec("masterLevel", "Cấp Master", 0m, 400m, new string[1] { "MasterLevel" }, "MasterSkillTree"),
		new FieldSpec("points", "Điểm dư", 0m, 100000000m, new string[2] { "LevelUpPoint", "LevelUpPoints" }),
		new FieldSpec("masterPoints", "Điểm Master", 0m, 400m, new string[1] { "MasterPoint" }, "MasterSkillTree"),
		new FieldSpec("masterExperience", "Kinh nghiệm Master", 0m, 9223372036854775807m, new string[1] { "MasterExperience" }, "MasterSkillTree"),
		new FieldSpec("experience", "Kinh nghiệm", -2147483648m, 2147483647m, new string[1] { "Experience" }),
		new FieldSpec("strength", "Sức mạnh", 0m, 65535m, new string[1] { "Strength" }),
		new FieldSpec("dexterity", "Nhanh nhẹn", 0m, 65535m, new string[1] { "Dexterity" }),
		new FieldSpec("vitality", "Thể lực", 0m, 65535m, new string[1] { "Vitality" }),
		new FieldSpec("energy", "Năng lượng", 0m, 65535m, new string[1] { "Energy" }),
		new FieldSpec("leadership", "Mệnh lệnh", 0m, 65535m, new string[1] { "Leadership" }),
		new FieldSpec("life", "Máu hiện tại", 0m, 65535m, new string[1] { "Life" }, "Character", AllowReal: true),
		new FieldSpec("mana", "Mana hiện tại", 0m, 65535m, new string[1] { "Mana" }, "Character", AllowReal: true),
		new FieldSpec("zen", "Zen", 0m, 2000000000m, new string[2] { "Money", "Zen" }),
		new FieldSpec("reset", "Reset", 0m, 1000000m, new string[2] { "ResetCount", "Reset" }),
		new FieldSpec("masterReset", "Master Reset", 0m, 1000000m, new string[1] { "MasterResetCount" }),
		new FieldSpec("fruitPoint", "Fruit Point", 0m, 100000000m, new string[1] { "FruitPoint" }),
		new FieldSpec("fruitAddPoint", "Fruit Add Point", 0m, 100000000m, new string[1] { "FruitAddPoint" }),
		new FieldSpec("fruitSubPoint", "Fruit Sub Point", 0m, 100000000m, new string[1] { "FruitSubPoint" }),
		new FieldSpec("extInventory", "Ext. Inventory", 0m, 255m, new string[1] { "ExtInventory" }),
		new FieldSpec("kills", "Số lần hạ gục", 0m, 2147483647m, new string[1] { "Kills" }),
		new FieldSpec("deads", "Số lần bị hạ", 0m, 2147483647m, new string[1] { "Deads" }),
		new FieldSpec("class", "Lớp nhân vật", 0m, 255m, new string[1] { "Class" }),
		new FieldSpec("map", "Map", 0m, 255m, new string[1] { "MapNumber" }),
		new FieldSpec("mapX", "Tọa độ X", 0m, 255m, new string[1] { "MapPosX" }),
		new FieldSpec("mapY", "Tọa độ Y", 0m, 255m, new string[1] { "MapPosY" }),
		new FieldSpec("pkLevel", "PK Level", 0m, 10m, new string[1] { "PkLevel" }),
		new FieldSpec("pkCount", "PK Count", 0m, 2147483647m, new string[1] { "PkCount" }),
		new FieldSpec("pkTime", "PK Time", 0m, 2147483647m, new string[1] { "PkTime" })
	};

	private readonly MuSvenDatabase database;

	public CharacterEditorRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public CharacterEditSnapshot Load(string accountId, string characterName)
	{
		RequireIdentity(accountId, characterName);
		using DbConnection connection = database.OpenConnection();
		Dictionary<string, string> characterColumns = ReadNumericColumns(connection, "Character");
		Dictionary<string, string> masterColumns = ReadNumericColumns(connection, "MasterSkillTree");
		string nameColumn = FindColumn(characterColumns, "Name") ?? throw new InvalidOperationException("dbo.Character thiếu cột Name.");
		string accountColumn = FindColumn(characterColumns, "AccountID", "AccountId") ?? throw new InvalidOperationException("dbo.Character thiếu cột AccountID.");
		List<CharacterField> characterFields = ResolveFields(characterColumns, "Character");
		List<CharacterField> masterFields = ResolveFields(masterColumns, "MasterSkillTree");
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 8;
		string[] projections = characterFields.Select((CharacterField characterField, int value3) => $"CONVERT(decimal(38,6),{Quote(characterField.ColumnName)}) AS [f{value3}]").ToArray();
		command.CommandText = $"SELECT TOP (2) {Quote(nameColumn)}, {Quote(accountColumn)}{((projections.Length == 0) ? string.Empty : (", " + string.Join(", ", projections)))}\nFROM dbo.[Character]\nWHERE {Quote(nameColumn)}=@Name AND {Quote(accountColumn)}=@AccountId";
		AddIdentity(command, characterName.Trim(), accountId.Trim());
		List<CharacterField> result = new List<CharacterField>(characterFields.Count + masterFields.Count);
		string actualName;
		string actualAccount;
		using (DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess))
		{
			if (!reader.Read())
			{
				throw new InvalidOperationException("Không tìm thấy nhân vật thuộc tài khoản đã chọn.");
			}
			actualName = Convert.ToString(reader.GetValue(0)) ?? string.Empty;
			actualAccount = Convert.ToString(reader.GetValue(1)) ?? string.Empty;
			for (int i = 0; i < characterFields.Count; i++)
			{
				int ordinal = i + 2;
				decimal? value = (reader.IsDBNull(ordinal) ? ((decimal?)null) : new decimal?(Convert.ToDecimal(reader.GetValue(ordinal))));
				CharacterField field = characterFields[i];
				result.Add(new CharacterField(field.Key, field.Label, field.TableName, field.ColumnName, field.DataType, field.Minimum, field.Maximum, value));
			}
			if (reader.Read())
			{
				throw new InvalidOperationException("Có nhiều nhân vật trùng Name và AccountID; Musven dừng để tránh sửa nhầm.");
			}
		}
		string notice = string.Empty;
		if (masterFields.Count > 0)
		{
			try
			{
				string masterNameColumn = FindColumn(masterColumns, "Name");
				if (masterNameColumn == null)
				{
					notice = "MasterSkillTree thiếu cột Name; trường Master không tải được.";
				}
				else
				{
					using DbCommand masterCommand = connection.CreateCommand();
					masterCommand.CommandTimeout = 8;
					string[] masterProjections = masterFields.Select((CharacterField characterField, int value3) => $"CONVERT(decimal(38,6),{Quote(characterField.ColumnName)}) AS [f{value3}]").ToArray();
					masterCommand.CommandText = $"SELECT TOP (2) {string.Join(", ", masterProjections)} FROM dbo.MasterSkillTree WHERE {Quote(masterNameColumn)}=@Name";
					AddParameter(masterCommand, "@Name", DbType.String, actualName, 50);
					using DbDataReader masterReader = masterCommand.ExecuteReader(CommandBehavior.SequentialAccess);
					if (!masterReader.Read())
					{
						notice = "Chưa có dòng MasterSkillTree cho nhân vật; trường Master ở chế độ không chỉnh sửa.";
					}
					else
					{
						for (int i2 = 0; i2 < masterFields.Count; i2++)
						{
							decimal? value2 = (masterReader.IsDBNull(i2) ? ((decimal?)null) : new decimal?(Convert.ToDecimal(masterReader.GetValue(i2))));
							CharacterField field2 = masterFields[i2];
							result.Add(new CharacterField(field2.Key, field2.Label, field2.TableName, field2.ColumnName, field2.DataType, field2.Minimum, field2.Maximum, value2));
						}
						if (masterReader.Read())
						{
							throw new InvalidOperationException("MasterSkillTree có nhiều dòng cho một nhân vật; dừng để tránh sửa nhầm.");
						}
					}
				}
			}
			catch (DbException)
			{
				notice = "Không đọc được MasterSkillTree; kiểm tra quyền SELECT. Các trường nhân vật khác vẫn có thể xem.";
			}
		}
		else
		{
			notice = "Không tìm thấy các cột MasterLevel/MasterPoint trong dbo.MasterSkillTree.";
		}
		if (result.Count == 0)
		{
			throw new InvalidOperationException("Không tìm thấy cột số được Musven hỗ trợ trong dbo.Character.");
		}
		return new CharacterEditSnapshot(actualAccount, actualName, result, notice);
	}

	public int Save(CharacterEditSnapshot expected, IReadOnlyDictionary<string, decimal> values)
	{
		if (values.Count == 0)
		{
			throw new InvalidOperationException("Không có trường nào được thay đổi.");
		}
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			EnsureAccountOffline(connection, transaction, expected.AccountId);
			Dictionary<string, string> characterColumns = ReadNumericColumns(connection, "Character", transaction);
			Dictionary<string, string> masterColumns = ReadNumericColumns(connection, "MasterSkillTree", transaction);
			Dictionary<string, CharacterField> currentFields = ResolveFields(characterColumns, "Character").Concat(ResolveFields(masterColumns, "MasterSkillTree")).ToDictionary<CharacterField, string>((CharacterField x) => x.Key, StringComparer.OrdinalIgnoreCase);
			Dictionary<string, CharacterField> expectedByKey = expected.Fields.ToDictionary<CharacterField, string>((CharacterField x) => x.Key, StringComparer.OrdinalIgnoreCase);
			foreach (KeyValuePair<string, decimal> pair in values)
			{
				if (!expectedByKey.TryGetValue(pair.Key, out var field) || !currentFields.TryGetValue(pair.Key, out var currentField) || !currentField.ColumnName.Equals(field.ColumnName, StringComparison.OrdinalIgnoreCase) || !currentField.TableName.Equals(field.TableName, StringComparison.OrdinalIgnoreCase))
				{
					throw new InvalidOperationException("Có trường không còn trong schema hiện tại. Hãy mở lại thông tin nhân vật.");
				}
				bool realValue = field.DataType.Equals("real", StringComparison.OrdinalIgnoreCase) || field.DataType.Equals("float", StringComparison.OrdinalIgnoreCase);
				if (pair.Value < field.Minimum || pair.Value > field.Maximum || (!realValue && decimal.Truncate(pair.Value) != pair.Value) || (realValue && decimal.Round(pair.Value, 2) != pair.Value))
				{
					throw new InvalidOperationException("Giá trị " + field.Label + " nằm ngoài giới hạn cho phép.");
				}
			}
			foreach (IGrouping<string, CharacterField> group in expected.Fields.GroupBy<CharacterField, string>((CharacterField x) => x.TableName, StringComparer.OrdinalIgnoreCase))
			{
				EnsureSnapshotUnchanged(connection, transaction, expected, group.ToArray());
			}
			foreach (IGrouping<string, KeyValuePair<string, decimal>> group2 in values.GroupBy<KeyValuePair<string, decimal>, string>((KeyValuePair<string, decimal> keyValuePair) => expectedByKey[keyValuePair.Key].TableName, StringComparer.OrdinalIgnoreCase))
			{
				bool masterTable = group2.Key.Equals("MasterSkillTree", StringComparison.OrdinalIgnoreCase);
				string tableName = (masterTable ? "MasterSkillTree" : "Character");
				Dictionary<string, string> tableColumns = (masterTable ? masterColumns : characterColumns);
				string nameColumn = FindColumn(tableColumns, "Name") ?? throw new InvalidOperationException("dbo." + tableName + " thiếu cột Name.");
				string accountColumn = (masterTable ? null : FindColumn(tableColumns, "AccountID", "AccountId"));
				if (!masterTable && accountColumn == null)
				{
					throw new InvalidOperationException("dbo.Character thiếu cột AccountID.");
				}
				using DbCommand update = connection.CreateCommand();
				update.Transaction = transaction;
				update.CommandTimeout = 8;
				List<string> assignments = new List<string>();
				int parameterIndex = 0;
				foreach (KeyValuePair<string, decimal> pair2 in group2)
				{
					CharacterField field2 = expectedByKey[pair2.Key];
					string parameterName = "@Value" + parameterIndex++;
					assignments.Add(Quote(field2.ColumnName) + "=" + parameterName);
					AddParameter(update, parameterName, DbType.Decimal, pair2.Value);
				}
				update.CommandText = $"UPDATE dbo.{(masterTable ? "MasterSkillTree" : "[Character]")} SET {string.Join(", ", assignments)} WHERE {Quote(nameColumn)}=@Name" + (masterTable ? string.Empty : (" AND " + Quote(accountColumn) + "=@AccountId"));
				AddParameter(update, "@Name", DbType.String, expected.Name, 10);
				if (!masterTable)
				{
					AddParameter(update, "@AccountId", DbType.String, expected.AccountId, 10);
				}
				if (update.ExecuteNonQuery() != 1)
				{
					throw new InvalidOperationException("Số dòng dbo." + tableName + " cập nhật không đúng 1; giao dịch đã hủy.");
				}
			}
			transaction.Commit();
			return values.Count;
		}
		catch
		{
			try
			{
				transaction.Rollback();
			}
			catch
			{
			}
			throw;
		}
	}

	private static void EnsureSnapshotUnchanged(DbConnection connection, DbTransaction transaction, CharacterEditSnapshot expected, IReadOnlyList<CharacterField> fields)
	{
		if (fields.Count == 0)
		{
			return;
		}
		bool masterTable = fields[0].TableName.Equals("MasterSkillTree", StringComparison.OrdinalIgnoreCase);
		string tableName = (masterTable ? "MasterSkillTree" : "Character");
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		string[] projections = fields.Select((CharacterField field, int value) => $"CONVERT(decimal(38,6),{Quote(field.ColumnName)}) AS [f{value}]").ToArray();
		command.CommandText = $"SELECT TOP (2) {string.Join(", ", projections)} FROM dbo.{(masterTable ? "MasterSkillTree" : "[Character]")} WITH (UPDLOCK,HOLDLOCK) WHERE [Name]=@Name" + (masterTable ? string.Empty : " AND [AccountID]=@AccountId");
		AddParameter(command, "@Name", DbType.String, expected.Name, 10);
		if (!masterTable)
		{
			AddParameter(command, "@AccountId", DbType.String, expected.AccountId, 10);
		}
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không còn dòng tương ứng trong dbo." + tableName + "; giao dịch đã hủy.");
		}
		for (int i = 0; i < fields.Count; i++)
		{
			decimal? obj = (reader.IsDBNull(i) ? ((decimal?)null) : new decimal?(Convert.ToDecimal(reader.GetValue(i))));
			if (!(fields[i].Value == obj))
			{
				throw new InvalidOperationException("Thông tin nhân vật đã thay đổi sau khi tải. Musven chưa ghi gì; hãy mở lại rồi thử lại.");
			}
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("Có nhiều dòng trùng trong dbo." + tableName + "; giao dịch đã hủy.");
		}
	}

	private static void EnsureAccountOffline(DbConnection connection, DbTransaction transaction, string accountId)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) ConnectStat FROM dbo.MEMB_STAT WITH (UPDLOCK,HOLDLOCK) WHERE memb___id=@AccountId";
		AddParameter(command, "@AccountId", DbType.String, accountId, 10);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không xác định được trạng thái tài khoản trong dbo.MEMB_STAT.");
		}
		int num = Convert.ToInt32(reader.GetValue(0));
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.MEMB_STAT có nhiều dòng cho tài khoản; giao dịch đã hủy.");
		}
		if (num != 0)
		{
			throw new InvalidOperationException("Tài khoản đang trực tuyến. Hãy đăng xuất nhân vật trước khi lưu.");
		}
	}

	private static Dictionary<string, string> ReadNumericColumns(DbConnection connection, string tableName, DbTransaction? transaction = null)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS\nWHERE TABLE_SCHEMA=N'dbo' AND TABLE_NAME=@TableName";
		AddParameter(command, "@TableName", DbType.String, tableName, 128);
		Dictionary<string, string> columns = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		using DbDataReader reader = command.ExecuteReader();
		while (reader.Read())
		{
			string name = reader.GetString(0);
			string type = reader.GetString(1);
			if (type.Equals("tinyint", StringComparison.OrdinalIgnoreCase) || type.Equals("smallint", StringComparison.OrdinalIgnoreCase) || type.Equals("int", StringComparison.OrdinalIgnoreCase) || type.Equals("bigint", StringComparison.OrdinalIgnoreCase) || type.Equals("real", StringComparison.OrdinalIgnoreCase) || type.Equals("float", StringComparison.OrdinalIgnoreCase))
			{
				columns[name] = type;
			}
			else
			{
				columns.TryAdd(name, string.Empty);
			}
		}
		return columns;
	}

	private static List<CharacterField> ResolveFields(IReadOnlyDictionary<string, string> columns, string tableName)
	{
		List<CharacterField> fields = new List<CharacterField>();
		FieldSpec[] specs = Specs;
		foreach (FieldSpec spec in specs)
		{
			if (!spec.TableName.Equals(tableName, StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			string column = FindColumn(columns, spec.Candidates);
			if (column != null && !string.IsNullOrEmpty(columns[column]))
			{
				bool num = columns[column].Equals("tinyint", StringComparison.OrdinalIgnoreCase) || columns[column].Equals("smallint", StringComparison.OrdinalIgnoreCase) || columns[column].Equals("int", StringComparison.OrdinalIgnoreCase) || columns[column].Equals("bigint", StringComparison.OrdinalIgnoreCase);
				bool isReal = columns[column].Equals("real", StringComparison.OrdinalIgnoreCase) || columns[column].Equals("float", StringComparison.OrdinalIgnoreCase);
				if (num || (spec.AllowReal && isReal))
				{
					fields.Add(new CharacterField(spec.Key, spec.Label, tableName, column, columns[column], spec.Minimum, spec.Maximum, null));
				}
			}
		}
		return fields;
	}

	private static string? FindColumn(IReadOnlyDictionary<string, string> columns, params string[] candidates)
	{
		foreach (string candidate in candidates)
		{
			string match = columns.Keys.FirstOrDefault((string x) => x.Equals(candidate, StringComparison.OrdinalIgnoreCase));
			if (match != null)
			{
				return match;
			}
		}
		return null;
	}

	private static string Quote(string identifier)
	{
		return "[" + identifier.Replace("]", "]]", StringComparison.Ordinal) + "]";
	}

	private static void RequireIdentity(string accountId, string name)
	{
		if (string.IsNullOrWhiteSpace(accountId) || accountId.Trim().Length > 10)
		{
			throw new ArgumentException("AccountID phải từ 1 đến 10 ký tự.", "accountId");
		}
		if (string.IsNullOrWhiteSpace(name) || name.Trim().Length > 10)
		{
			throw new ArgumentException("Tên nhân vật phải từ 1 đến 10 ký tự.", "name");
		}
	}

	private static void AddIdentity(DbCommand command, string name, string accountId)
	{
		AddParameter(command, "@Name", DbType.String, name, 10);
		AddParameter(command, "@AccountId", DbType.String, accountId, 10);
	}

	private static void AddParameter(DbCommand command, string name, DbType type, object value, int size = 0)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = type;
		if (size > 0)
		{
			parameter.Size = size;
		}
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}
}
