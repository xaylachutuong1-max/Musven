namespace MuSven09M.Modules.Character;

public sealed record CharacterField(string Key, string Label, string TableName, string ColumnName, string DataType, decimal Minimum, decimal Maximum, decimal? Value);
