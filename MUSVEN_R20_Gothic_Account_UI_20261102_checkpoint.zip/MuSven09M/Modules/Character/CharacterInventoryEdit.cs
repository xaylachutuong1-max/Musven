using MuSven09M.Modules.Warehouse;

namespace MuSven09M.Modules.Character;

public sealed record CharacterInventoryEdit(int Slot, ItemDefinition Item, ItemCreationOptions Options);
