using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;
using MuSven09M.Modules.Warehouse;

namespace MuSven09M.Modules.Character;

public sealed class CharacterInventoryEditorForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly string accountId;

	private readonly string characterName;

	private readonly bool writeEnabled;

	private readonly ListView items = new ListView
	{
		Dock = DockStyle.Fill,
		View = View.Details,
		FullRowSelect = true,
		GridLines = true,
		MultiSelect = false,
		HideSelection = false,
		BackColor = Color.FromArgb(8, 18, 32),
		ForeColor = Color.Gainsboro
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Label safetyNotice = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Gold,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button edit = MakeButton("CHỈNH THUỘC TÍNH", emphasized: true);

	private readonly Button save = MakeButton("LƯU TÚI NHÂN VẬT", emphasized: true);

	private readonly Button reload = MakeButton("TẢI LẠI", emphasized: false);

	private CharacterInventorySnapshot? snapshot;

	private IReadOnlyList<CharacterInventoryEntry> entries = Array.Empty<CharacterInventoryEntry>();

	private readonly Dictionary<int, ItemCreationOptions> changes = new Dictionary<int, ItemCreationOptions>();

	public CharacterInventoryEditorForm(SqlAccountLookupOptions options, string accountId, string characterName, bool writeEnabled)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.accountId = accountId;
		this.characterName = characterName;
		this.writeEnabled = writeEnabled;
		Text = "MU SVEN • Túi nhân vật • " + characterName;
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(850, 560);
		base.Size = new Size(1040, 700);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 3,
			Padding = new Padding(12),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 76f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 86f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = $"TÚI NHÂN VẬT • {characterName}   /   Tài khoản {accountId}\nHợp đồng server: Character.Inventory varbinary(4080), 255 bản ghi × 16 byte. Blob có độ dài khác sẽ chỉ đọc; không tự thêm byte.",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 10f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(8),
			BackColor = Surface
		}, 0, 0);
		items.Columns.Add("Ô", 54);
		items.Columns.Add("VẬT PHẨM", 300);
		items.Columns.Add("ItemIndex", 90);
		items.Columns.Add("Level", 70);
		items.Columns.Add("Options", 90);
		items.Columns.Add("Độ bền", 85);
		items.Columns.Add("Serial", 110);
		items.DoubleClick += delegate
		{
			EditSelected();
		};
		root.Controls.Add(items, 0, 1);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 2,
			Padding = new Padding(0, 6, 0, 0)
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 520f));
		footer.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		footer.RowStyles.Add(new RowStyle(SizeType.Absolute, 34f));
		footer.Controls.Add(status, 0, 0);
		FlowLayoutPanel buttons = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.RightToLeft,
			WrapContents = false
		};
		Button close = MakeButton("ĐÓNG", emphasized: false);
		edit.Click += delegate
		{
			EditSelected();
		};
		save.Click += async delegate
		{
			await SaveAsync();
		};
		reload.Click += async delegate
		{
			await LoadAsync();
		};
		close.Click += delegate
		{
			Close();
		};
		buttons.Controls.Add(close);
		buttons.Controls.Add(save);
		buttons.Controls.Add(edit);
		buttons.Controls.Add(reload);
		footer.Controls.Add(buttons, 1, 0);
		footer.Controls.Add(safetyNotice, 0, 1);
		footer.SetColumnSpan(footer.GetControlFromPosition(0, 1), 2);
		root.Controls.Add(footer, 0, 2);
		UpdateSafetyNotice();
		UpdateButtons();
		base.Shown += async delegate
		{
			UiTheme.Apply(this);
			await LoadAsync();
		};
	}

	private async Task LoadAsync()
	{
		reload.Enabled = false;
		edit.Enabled = false;
		save.Enabled = false;
		status.Text = "ĐANG TẢI • kiểm tra schema và đọc blob Inventory…";
		try
		{
			MuSvenDatabase database = new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString());
			CharacterInventoryRepository repository = new CharacterInventoryRepository(database);
			CharacterInventorySnapshot loadedSnapshot = (snapshot = await Task.Run(() => repository.Load(accountId, characterName)));
			entries = repository.Decode(loadedSnapshot);
			changes.Clear();
			RefreshRows();
			int slots = loadedSnapshot.Items.Length / 16;
			status.Text = $"Đã đọc {entries.Count} vật phẩm • {slots} ô trong blob • item ngoài catalog được giữ nguyên.";
		}
		catch (InvalidOperationException ex)
		{
			snapshot = null;
			entries = Array.Empty<CharacterInventoryEntry>();
			items.Items.Clear();
			status.Text = ex.Message;
		}
		catch (SqlException)
		{
			snapshot = null;
			entries = Array.Empty<CharacterInventoryEntry>();
			items.Items.Clear();
			status.Text = "SQL từ chối đọc Inventory. Kiểm tra SELECT và schema; không ghi dữ liệu.";
		}
		catch
		{
			snapshot = null;
			entries = Array.Empty<CharacterInventoryEntry>();
			items.Items.Clear();
			status.Text = "Không đọc được túi nhân vật. Kiểm tra kết nối và schema.";
		}
		finally
		{
			reload.Enabled = true;
			UpdateSafetyNotice();
			UpdateButtons();
		}
	}

	private void RefreshRows()
	{
		items.BeginUpdate();
		items.Items.Clear();
		foreach (CharacterInventoryEntry entry in entries)
		{
			ItemCreationOptions staged;
			ItemCreationOptions value = (changes.TryGetValue(entry.Slot, out staged) ? staged : entry.Options);
			string displayName = entry.Definition?.Name ?? $"Không có trong catalog • 0x{entry.ItemIndex:X4}";
			ListViewItem row = new ListViewItem((entry.Slot + 1).ToString())
			{
				Tag = entry
			};
			row.SubItems.Add(displayName);
			row.SubItems.Add(entry.ItemIndex.ToString());
			row.SubItems.Add(((object)value == null) ? "—" : value.Level.ToString());
			row.SubItems.Add(((object)value == null) ? "—" : $"+{value.Option * 4}");
			row.SubItems.Add(((object)value == null) ? "—" : value.Durability.ToString());
			row.SubItems.Add(entry.Serial.ToString());
			if (changes.ContainsKey(entry.Slot))
			{
				row.BackColor = Color.FromArgb(51, 45, 25);
			}
			if ((object)entry.Definition == null)
			{
				row.ForeColor = Color.Silver;
			}
			items.Items.Add(row);
		}
		items.EndUpdate();
		UpdateButtons();
	}

	private void EditSelected()
	{
		if ((object)snapshot == null || snapshot.Items.Length != 4080)
		{
			MessageBox.Show(this, "Blob Inventory không đủ đúng 4080 byte theo hợp đồng server. Danh sách chỉ đọc; không thể chỉnh hoặc lưu để tránh thay đổi dữ liệu.", "Túi nhân vật chỉ đọc", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		else
		{
			if (items.SelectedItems.Count == 0 || !(items.SelectedItems[0].Tag is CharacterInventoryEntry entry))
			{
				return;
			}
			if ((object)entry.Definition != null && (object)entry.Options != null)
			{
				ItemCreationOptions changed;
				ItemCreationOptions current = (changes.TryGetValue(entry.Slot, out changed) ? changed : entry.Options);
				using WarehouseItemEditDialog dialog = new WarehouseItemEditDialog(entry.Definition, current, entry.Serial, entry.Raw);
				if (dialog.ShowDialog(this) == DialogResult.OK)
				{
					changes[entry.Slot] = dialog.Result;
					RefreshRows();
					status.Text = $"Đã xếp sửa thuộc tính ở ô {entry.Slot + 1}; chưa ghi SQL.";
				}
				return;
			}
			MessageBox.Show(this, "ItemIndex này không có trong catalog server hiện tại nên không thể đổi thuộc tính. Blob gốc vẫn được giữ nguyên.", "Không hỗ trợ item", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	private async Task SaveAsync()
	{
		if (!writeEnabled || (object)snapshot == null || changes.Count == 0)
		{
			return;
		}
		if (snapshot.Items.Length != 4080)
		{
			status.Text = "Blob Inventory lệch hợp đồng 4080 byte; không ghi SQL.";
			UpdateButtons();
		}
		else
		{
			if (MessageBox.Show(this, $"Lưu {changes.Count} chỉnh sửa thuộc tính cho {characterName} (tài khoản {accountId})?\n\nVật phẩm giữ nguyên ô, ItemIndex, serial và các byte không được chỉnh. Tài khoản phải offline; giao dịch đối chiếu toàn bộ Inventory trước khi ghi.", "MU SVEN • Xác nhận sửa túi nhân vật", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
			{
				return;
			}
			Button button = edit;
			Button button2 = save;
			bool flag = (reload.Enabled = false);
			bool enabled = (button2.Enabled = flag);
			button.Enabled = enabled;
			status.Text = "ĐANG LƯU • xác nhận offline, khóa bản ghi và đối chiếu snapshot…";
			try
			{
				MuSvenDatabase database = new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString(readOnly: false));
				CharacterInventoryEdit[] edits = changes.Select<KeyValuePair<int, ItemCreationOptions>, CharacterInventoryEdit>(delegate(KeyValuePair<int, ItemCreationOptions> pair)
				{
					CharacterInventoryEntry characterInventoryEntry = entries.First((CharacterInventoryEntry x) => x.Slot == pair.Key);
					if ((object)characterInventoryEntry.Definition == null)
					{
						throw new InvalidOperationException("Một vật phẩm đã chỉnh không còn trong catalog.");
					}
					return new CharacterInventoryEdit(pair.Key, characterInventoryEntry.Definition, pair.Value);
				}).ToArray();
				int count = await Task.Run(() => new CharacterInventoryRepository(database).Save(snapshot, edits));
				MessageBox.Show(this, $"Đã lưu {count} vật phẩm cho {characterName}.", "MU SVEN • Đã lưu", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				await LoadAsync();
			}
			catch (InvalidOperationException ex)
			{
				status.Text = ex.Message;
			}
			catch (SqlException)
			{
				status.Text = "SQL từ chối giao dịch. Kiểm tra quyền UPDATE Inventory và trạng thái tài khoản; thay đổi đã rollback.";
			}
			catch
			{
				status.Text = "Không lưu được. Giao dịch đã rollback nếu SQL phát sinh lỗi.";
			}
			finally
			{
				UpdateButtons();
			}
		}
	}

	private void UpdateButtons()
	{
		CharacterInventorySnapshot? characterInventorySnapshot = snapshot;
		bool exactServerLength = (object)characterInventorySnapshot != null && characterInventorySnapshot.Items.Length == 4080;
		edit.Enabled = exactServerLength && items.SelectedItems.Count > 0;
		save.Enabled = writeEnabled && exactServerLength && changes.Count > 0;
		items.SelectedIndexChanged -= ItemsSelectedIndexChanged;
		items.SelectedIndexChanged += ItemsSelectedIndexChanged;
	}

	private void UpdateSafetyNotice()
	{
		if ((object)snapshot != null && snapshot.Items.Length != 4080)
		{
			int slots = snapshot.Items.Length / 16;
			safetyNotice.Text = $"Blob thực tế {snapshot.Items.Length} byte ({slots} bản ghi); hợp đồng là 4080 byte. Chỉ xem; nút sửa/lưu bị khóa.";
		}
		else
		{
			safetyNotice.Text = (writeEnabled ? "Ghi được bật theo Config.ini; mỗi lần lưu đều xác nhận và kiểm tra offline/snapshot." : "Đang khóa ghi trong Config.ini; danh sách vẫn xem được.");
		}
	}

	private void ItemsSelectedIndexChanged(object? sender, EventArgs e)
	{
		UpdateButtons();
	}

	private static Button MakeButton(string text, bool emphasized)
	{
		Button button = new Button();
		button.Text = text;
		button.AutoSize = false;
		button.Width = 126;
		button.Height = 34;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (emphasized ? Gold : Color.FromArgb(18, 51, 82));
		button.ForeColor = (emphasized ? Color.Black : Color.White);
		button.Margin = new Padding(4);
		button.Cursor = Cursors.Hand;
		button.FlatAppearance.BorderColor = (emphasized ? Gold : Color.FromArgb(41, 111, 172));
		return button;
	}
}
