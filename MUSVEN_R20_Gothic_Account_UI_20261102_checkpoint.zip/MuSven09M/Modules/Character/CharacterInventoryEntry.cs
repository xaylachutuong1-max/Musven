using MuSven09M.Modules.Warehouse;

namespace MuSven09M.Modules.Character;

public sealed record CharacterInventoryEntry(int Slot, int ItemIndex, ItemDefinition? Definition, ItemCreationOptions? Options, uint Serial, byte[] Raw);
