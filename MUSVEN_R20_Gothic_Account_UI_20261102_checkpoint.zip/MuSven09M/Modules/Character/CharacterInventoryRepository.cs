using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using MuSven09M.Modules.Account;
using MuSven09M.Modules.Warehouse;

namespace MuSven09M.Modules.Character;

public sealed class CharacterInventoryRepository
{
	public const int InventoryBytes = 4080;

	public const int ItemSize = 16;

	public const int SlotCount = 255;

	private readonly MuSvenDatabase database;

	public CharacterInventoryRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public CharacterInventorySnapshot Load(string accountId, string characterName)
	{
		RequireIdentity(accountId, characterName);
		using DbConnection connection = database.OpenConnection();
		ValidateContract(connection, null);
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) Inventory FROM dbo.[Character] WHERE AccountID=@AccountId AND Name=@Name";
		AddParameter(command, "@AccountId", DbType.String, 10, accountId.Trim());
		AddParameter(command, "@Name", DbType.String, 10, characterName.Trim());
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không tìm thấy nhân vật thuộc tài khoản đã chọn.");
		}
		if (reader.IsDBNull(0) || !(reader.GetValue(0) is byte[] items))
		{
			throw new InvalidOperationException("dbo.Character.Inventory đang NULL hoặc không phải dữ liệu nhị phân.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("Có nhiều nhân vật trùng AccountID và Name; không thể mở túi an toàn.");
		}
		if (!HasReadableRecordLength(items.Length))
		{
			throw new InvalidOperationException($"Inventory dài {items.Length} byte; chỉ đọc được blob gồm 1–{255} bản ghi đủ {16} byte.");
		}
		return new CharacterInventorySnapshot(accountId.Trim(), characterName.Trim(), items);
	}

	public IReadOnlyList<CharacterInventoryEntry> Decode(CharacterInventorySnapshot snapshot)
	{
		ArgumentNullException.ThrowIfNull(snapshot, "snapshot");
		if (!HasReadableRecordLength(snapshot.Items.Length))
		{
			throw new InvalidOperationException("Snapshot Inventory không chứa số byte nguyên vẹn theo bản ghi.");
		}
		List<CharacterInventoryEntry> entries = new List<CharacterInventoryEntry>();
		int slotCount = snapshot.Items.Length / 16;
		for (int slot = 0; slot < slotCount; slot++)
		{
			byte[] raw = snapshot.Items.AsSpan(slot * 16, 16).ToArray();
			if (!IsEmpty(raw))
			{
				int index = raw[0] | ((raw[7] & 0x80) << 1) | ((raw[9] & 0xF0) << 5);
				ItemCatalog.ByIndex.TryGetValue(index, out ItemDefinition definition);
				ItemCreationOptions options = (((object)definition == null) ? null : WarehouseItemFormat.DecodeOptions(raw));
				uint serial = BinaryPrimitives.ReadUInt32BigEndian(raw.AsSpan(3, 4));
				entries.Add(new CharacterInventoryEntry(slot, index, definition, options, serial, raw));
			}
		}
		return entries;
	}

	public int Save(CharacterInventorySnapshot expected, IReadOnlyList<CharacterInventoryEdit> edits)
	{
		ArgumentNullException.ThrowIfNull(expected, "expected");
		if (edits == null || edits.Count == 0)
		{
			throw new InvalidOperationException("Chưa có thuộc tính vật phẩm nào được chỉnh.");
		}
		RequireIdentity(expected.AccountId, expected.CharacterName);
		if (expected.Items.Length != 4080)
		{
			throw new InvalidOperationException("Snapshot Inventory không đúng kích thước hợp đồng.");
		}
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			ValidateContract(connection, transaction);
			EnsureAccountOffline(connection, transaction, expected.AccountId);
			byte[] current = ReadLockedInventory(connection, transaction, expected.AccountId, expected.CharacterName);
			if (!current.AsSpan().SequenceEqual(expected.Items))
			{
				throw new InvalidOperationException("Túi nhân vật đã thay đổi sau khi tải. Musven chưa ghi gì; hãy tải lại.");
			}
			HashSet<int> uniqueSlots = new HashSet<int>();
			byte[] updated = (byte[])current.Clone();
			foreach (CharacterInventoryEdit edit in edits)
			{
				if (!uniqueSlots.Add(edit.Slot))
				{
					throw new InvalidOperationException($"Ô {edit.Slot} bị lặp trong danh sách sửa.");
				}
				int slot = edit.Slot;
				if ((slot < 0 || slot >= 255) ? true : false)
				{
					throw new InvalidOperationException("Vị trí vật phẩm nằm ngoài blob Inventory.");
				}
				if (!ItemCatalog.ByIndex.TryGetValue(edit.Item.ItemIndex, out ItemDefinition definition) || definition != edit.Item)
				{
					throw new InvalidOperationException("Vật phẩm không còn thuộc danh mục server hiện tại.");
				}
				int offset = edit.Slot * 16;
				ReadOnlySpan<byte> original = current.AsSpan(offset, 16);
				if (IsEmpty(original))
				{
					throw new InvalidOperationException($"Ô {edit.Slot} đang trống; chỉ được sửa vật phẩm đã có.");
				}
				if ((original[0] | ((original[7] & 0x80) << 1) | ((original[9] & 0xF0) << 5)) != edit.Item.ItemIndex)
				{
					throw new InvalidOperationException($"ItemIndex tại ô {edit.Slot} đã thay đổi. Tải lại túi trước khi sửa.");
				}
				uint serial = BinaryPrimitives.ReadUInt32BigEndian(original.Slice(3, 4));
				Buffer.BlockCopy(WarehouseItemFormat.Encode(edit.Item, edit.Options, serial), 0, updated, offset, 16);
			}
			using DbCommand update = connection.CreateCommand();
			update.Transaction = transaction;
			update.CommandTimeout = 8;
			update.CommandText = "UPDATE dbo.[Character] SET Inventory=@Inventory WHERE AccountID=@AccountId AND Name=@Name";
			AddParameter(update, "@Inventory", DbType.Binary, 4080, updated);
			AddParameter(update, "@AccountId", DbType.String, 10, expected.AccountId.Trim());
			AddParameter(update, "@Name", DbType.String, 10, expected.CharacterName.Trim());
			if (update.ExecuteNonQuery() != 1)
			{
				throw new InvalidOperationException("Số dòng Character được cập nhật không đúng 1; giao dịch đã hủy.");
			}
			transaction.Commit();
			return edits.Count;
		}
		catch
		{
			try
			{
				transaction.Rollback();
			}
			catch
			{
			}
			throw;
		}
	}

	private static byte[] ReadLockedInventory(DbConnection connection, DbTransaction transaction, string accountId, string characterName)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) Inventory FROM dbo.[Character] WITH (UPDLOCK,HOLDLOCK) WHERE AccountID=@AccountId AND Name=@Name";
		AddParameter(command, "@AccountId", DbType.String, 10, accountId.Trim());
		AddParameter(command, "@Name", DbType.String, 10, characterName.Trim());
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read() || reader.IsDBNull(0) || !(reader.GetValue(0) is byte[] items))
		{
			throw new InvalidOperationException("Không đọc được Inventory trong giao dịch; dữ liệu chưa được ghi.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("Có nhiều dòng Character trùng; giao dịch đã hủy.");
		}
		if (items.Length != 4080)
		{
			throw new InvalidOperationException("Kích thước Inventory đổi sau khi tải; giao dịch đã hủy.");
		}
		return items;
	}

	private static void EnsureAccountOffline(DbConnection connection, DbTransaction transaction, string accountId)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) ConnectStat FROM dbo.MEMB_STAT WITH (UPDLOCK,HOLDLOCK) WHERE memb___id=@AccountId";
		AddParameter(command, "@AccountId", DbType.String, 10, accountId.Trim());
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không xác định được trạng thái tài khoản trong dbo.MEMB_STAT.");
		}
		int num = Convert.ToInt32(reader.GetValue(0));
		if (reader.Read())
		{
			throw new InvalidOperationException("MEMB_STAT có nhiều dòng cho tài khoản; giao dịch đã hủy.");
		}
		if (num != 0)
		{
			throw new InvalidOperationException("Tài khoản đang online. Hãy đăng xuất nhân vật trước khi sửa túi.");
		}
	}

	private static void ValidateContract(DbConnection connection, DbTransaction? transaction)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "\nSELECT c.name, TYPE_NAME(c.user_type_id), c.max_length\nFROM sys.columns c\nWHERE c.object_id=OBJECT_ID(N'dbo.Character') AND c.name IN (N'AccountID',N'Name',N'Inventory')";
		Dictionary<string, (string, int)> found = new Dictionary<string, (string, int)>(StringComparer.OrdinalIgnoreCase);
		using (DbDataReader reader = command.ExecuteReader())
		{
			while (reader.Read())
			{
				found[reader.GetString(0)] = (reader.GetString(1), Convert.ToInt32(reader.GetValue(2)));
			}
		}
		if (!found.TryGetValue("AccountID", out var account) || !account.Item1.Equals("varchar", StringComparison.OrdinalIgnoreCase) || account.Item2 != 10 || !found.TryGetValue("Name", out var name) || !name.Item1.Equals("varchar", StringComparison.OrdinalIgnoreCase) || name.Item2 != 10 || !found.TryGetValue("Inventory", out var inventory) || !inventory.Item1.Equals("varbinary", StringComparison.OrdinalIgnoreCase) || inventory.Item2 != 4080)
		{
			throw new InvalidOperationException("Hợp đồng túi nhân vật không khớp: dbo.Character cần AccountID/Name varchar(10) và Inventory varbinary(4080).");
		}
	}

	private static bool IsEmpty(ReadOnlySpan<byte> record)
	{
		bool allOnes = true;
		bool allZeroes = true;
		ReadOnlySpan<byte> readOnlySpan = record;
		for (int i = 0; i < readOnlySpan.Length; i++)
		{
			byte value = readOnlySpan[i];
			allOnes = allOnes && value == byte.MaxValue;
			allZeroes = allZeroes && value == 0;
		}
		return allOnes || allZeroes;
	}

	private static bool HasReadableRecordLength(int length)
	{
		if (length > 0 && length <= 4080)
		{
			return length % 16 == 0;
		}
		return false;
	}

	private static void RequireIdentity(string accountId, string characterName)
	{
		bool flag = string.IsNullOrWhiteSpace(accountId);
		if (!flag)
		{
			int length = accountId.Trim().Length;
			bool flag2 = ((length < 1 || length > 10) ? true : false);
			flag = flag2;
		}
		if (flag)
		{
			throw new ArgumentException("AccountID phải từ 1 đến 10 ký tự.", "accountId");
		}
		flag = string.IsNullOrWhiteSpace(characterName);
		if (!flag)
		{
			int length = characterName.Trim().Length;
			bool flag2 = ((length < 1 || length > 10) ? true : false);
			flag = flag2;
		}
		if (flag)
		{
			throw new ArgumentException("Tên nhân vật phải từ 1 đến 10 ký tự.", "characterName");
		}
	}

	private static void AddParameter(DbCommand command, string name, DbType type, int size, object value)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = type;
		if (size > 0)
		{
			parameter.Size = size;
		}
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}
}
