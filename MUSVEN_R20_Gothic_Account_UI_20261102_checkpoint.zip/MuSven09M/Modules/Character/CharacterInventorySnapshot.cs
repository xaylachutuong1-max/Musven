namespace MuSven09M.Modules.Character;

public sealed record CharacterInventorySnapshot(string AccountId, string CharacterName, byte[] Items);
