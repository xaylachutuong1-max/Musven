using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

public sealed class CharacterQuestKillCountForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly string accountId;

	private readonly string characterName;

	private readonly bool writeEnabled;

	private readonly TextBox[] counters = (from _ in Enumerable.Range(0, 5)
		select new TextBox
		{
			Width = 170,
			MaxLength = 10,
			TextAlign = HorizontalAlignment.Right,
			BackColor = Color.FromArgb(18, 37, 58),
			ForeColor = Color.White,
			BorderStyle = BorderStyle.FixedSingle,
			Font = new Font("Segoe UI", 10f)
		}).ToArray();

	private readonly Label[] monsters = (from _ in Enumerable.Range(0, 5)
		select new Label
		{
			Dock = DockStyle.Fill,
			TextAlign = ContentAlignment.MiddleLeft,
			ForeColor = Ice
		}).ToArray();

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		AutoEllipsis = true,
		TextAlign = ContentAlignment.MiddleLeft
	};

	private readonly Button save = new Button
	{
		Text = "LƯU SỐ ĐẾM",
		Width = 150,
		Height = 36,
		FlatStyle = FlatStyle.Flat,
		BackColor = Color.FromArgb(10, 87, 67),
		ForeColor = Color.White,
		Font = new Font("Segoe UI", 9f, FontStyle.Bold)
	};

	private readonly Button reload = new Button
	{
		Text = "TẢI LẠI",
		Width = 100,
		Height = 36,
		FlatStyle = FlatStyle.Flat,
		BackColor = Surface,
		ForeColor = Color.White
	};

	private CharacterQuestKillCountsSnapshot? snapshot;

	public bool WasSaved { get; private set; }

	public CharacterQuestKillCountForm(SqlAccountLookupOptions options, string accountId, string characterName, bool writeEnabled)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.accountId = accountId;
		this.characterName = characterName;
		this.writeEnabled = writeEnabled;
		Text = "MU SVEN • Số đếm nhiệm vụ • " + characterName;
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(610, 470);
		base.Size = new Size(720, 560);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 4,
			Padding = new Padding(16),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 75f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 52f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = $"SỐ ĐẾM QUÁI NHIỆM VỤ • {characterName}  /  Tài khoản {accountId}\nChỉ sửa KillCount1–5; QuestIndex và MonsterClass được giữ nguyên. Không có dòng nhiệm vụ thì chỉ xem, không tự tạo.",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 10f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(8),
			BackColor = Surface
		}, 0, 0);
		TableLayoutPanel grid = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 6,
			Padding = new Padding(12),
			BackColor = Surface
		};
		grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 72f));
		grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55f));
		grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45f));
		grid.RowStyles.Add(new RowStyle(SizeType.Absolute, 36f));
		for (int i = 0; i < 5; i++)
		{
			grid.RowStyles.Add(new RowStyle(SizeType.Percent, 20f));
		}
		grid.Controls.Add(Header("Ô"), 0, 0);
		grid.Controls.Add(Header("Monster Class (chỉ đọc)"), 1, 0);
		grid.Controls.Add(Header("Số lần hạ"), 2, 0);
		for (int i2 = 0; i2 < 5; i2++)
		{
			grid.Controls.Add(new Label
			{
				Text = $"Quest {i2 + 1}",
				Dock = DockStyle.Fill,
				ForeColor = Gold,
				TextAlign = ContentAlignment.MiddleLeft
			}, 0, i2 + 1);
			grid.Controls.Add(monsters[i2], 1, i2 + 1);
			grid.Controls.Add(counters[i2], 2, i2 + 1);
		}
		root.Controls.Add(grid, 0, 1);
		root.Controls.Add(status, 0, 2);
		FlowLayoutPanel footer = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.RightToLeft,
			WrapContents = false,
			Padding = new Padding(0, 5, 0, 0)
		};
		Button close = new Button
		{
			Text = "ĐÓNG",
			Width = 90,
			Height = 36,
			FlatStyle = FlatStyle.Flat,
			BackColor = Surface,
			ForeColor = Color.White,
			DialogResult = DialogResult.Cancel
		};
		footer.Controls.Add(close);
		footer.Controls.Add(save);
		footer.Controls.Add(reload);
		root.Controls.Add(footer, 0, 3);
		base.CancelButton = close;
		save.Click += async delegate
		{
			await SaveAsync();
		};
		reload.Click += async delegate
		{
			await LoadAsync();
		};
		base.Shown += async delegate
		{
			UiTheme.Apply(this);
			await LoadAsync();
		};
	}

	private static Label Header(string text)
	{
		return new Label
		{
			Text = text,
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 9f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		};
	}

	private async Task LoadAsync()
	{
		SetBusy(busy: true);
		status.Text = "ĐANG TẢI • kiểm tra schema và trạng thái tài khoản…";
		try
		{
			MuSvenDatabase database = new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString());
			snapshot = await Task.Run(() => new CharacterQuestKillCountRepository(database).Load(accountId, characterName));
			if ((object)snapshot == null)
			{
				for (int i = 0; i < 5; i++)
				{
					monsters[i].Text = "—";
					counters[i].Text = string.Empty;
				}
				status.Text = "Nhân vật chưa có dòng trong dbo.QuestKillCount. Musven không tự tạo dữ liệu nhiệm vụ.";
			}
			else
			{
				for (int i2 = 0; i2 < 5; i2++)
				{
					monsters[i2].Text = snapshot.Entries[i2].MonsterClass?.ToString(CultureInfo.InvariantCulture) ?? "—";
					counters[i2].Text = snapshot.Entries[i2].KillCount?.ToString(CultureInfo.InvariantCulture) ?? string.Empty;
				}
				status.Text = "QuestIndex: " + (snapshot.QuestIndex?.ToString(CultureInfo.InvariantCulture) ?? "—") + ". " + (writeEnabled ? "Lưu chỉ sửa năm cột KillCount; cần tài khoản offline và xác nhận." : "Chế độ xem; ghi đang khóa trong Config.ini.");
			}
		}
		catch (Exception ex)
		{
			snapshot = null;
			status.Text = ((ex is SqlException) ? "SQL không cho phép đọc QuestKillCount/Character/MEMB_STAT; kiểm tra quyền SELECT." : ex.Message);
		}
		finally
		{
			SetBusy(busy: false);
		}
	}

	private async Task SaveAsync()
	{
		if (!writeEnabled)
		{
			status.Text = "Ghi đang khóa trong Config.ini.";
			return;
		}
		if ((object)snapshot == null)
		{
			status.Text = "Không có dòng nhiệm vụ đã tải để sửa.";
			return;
		}
		int?[] values = new int?[5];
		for (int i = 0; i < counters.Length; i++)
		{
			string text = counters[i].Text.Trim();
			if (text.Length == 0)
			{
				values[i] = null;
				continue;
			}
			if (!int.TryParse(text, NumberStyles.None, CultureInfo.InvariantCulture, out var value))
			{
				status.Text = $"Số đếm Quest {i + 1} phải là số nguyên không âm, hoặc để trống để giữ NULL.";
				counters[i].Focus();
				return;
			}
			values[i] = value;
		}
		if (snapshot.Entries.Select((QuestKillCountEntry x) => x.KillCount).SequenceEqual(values))
		{
			status.Text = "Không có thay đổi.";
		}
		else
		{
			if (MessageBox.Show(this, "Lưu số đếm quái nhiệm vụ cho " + characterName + "?\n\nChỉ KillCount1–5 sẽ được cập nhật. MonsterClass/QuestIndex không đổi. Tài khoản phải offline; thao tác dùng transaction, so snapshot và hậu kiểm.", "MU SVEN • Xác nhận sửa nhiệm vụ", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
			{
				return;
			}
			SetBusy(busy: true);
			try
			{
				MuSvenDatabase database = new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString(readOnly: false));
				snapshot = await Task.Run(() => new CharacterQuestKillCountRepository(database).Save(snapshot, values, writeEnabled));
				WasSaved = true;
				status.Text = "Đã lưu và hậu kiểm năm số đếm nhiệm vụ.";
				MessageBox.Show(this, "Đã lưu số đếm nhiệm vụ.", "MU SVEN", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			catch (Exception ex)
			{
				status.Text = ((ex is SqlException) ? "SQL từ chối cập nhật. Kiểm tra quyền UPDATE giới hạn trên dbo.QuestKillCount." : ex.Message);
			}
			finally
			{
				SetBusy(busy: false);
			}
		}
	}

	private void SetBusy(bool busy)
	{
		reload.Enabled = !busy;
		save.Enabled = !busy && writeEnabled && (object)snapshot != null;
		TextBox[] array = counters;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].ReadOnly = busy || !writeEnabled || (object)snapshot == null;
		}
	}
}
