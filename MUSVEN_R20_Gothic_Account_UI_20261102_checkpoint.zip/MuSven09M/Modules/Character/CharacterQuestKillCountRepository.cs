using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

public sealed class CharacterQuestKillCountRepository
{
	private static readonly string[] RequiredColumns = new string[12]
	{
		"Name", "QuestIndex", "MonsterClass1", "MonsterClass2", "MonsterClass3", "MonsterClass4", "MonsterClass5", "KillCount1", "KillCount2", "KillCount3",
		"KillCount4", "KillCount5"
	};

	private readonly MuSvenDatabase database;

	public CharacterQuestKillCountRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public CharacterQuestKillCountsSnapshot? Load(string accountId, string characterName)
	{
		(accountId, characterName) = ValidateIdentity(accountId, characterName);
		using DbConnection connection = database.OpenConnection();
		ValidateSchema(connection, null);
		EnsureCharacterBelongsToAccount(connection, null, accountId, characterName, lockRow: false);
		return ReadSnapshot(connection, null, accountId, characterName, lockRow: false, allowMissing: true);
	}

	public CharacterQuestKillCountsSnapshot Save(CharacterQuestKillCountsSnapshot expected, IReadOnlyList<int?> killCounts, bool writeEnabled)
	{
		ArgumentNullException.ThrowIfNull(expected, "expected");
		if (!writeEnabled)
		{
			throw new InvalidOperationException("Sửa số đếm nhiệm vụ đang khóa trong Config.ini.");
		}
		if (expected.Entries.Count != 5 || killCounts == null || killCounts.Count != 5)
		{
			throw new ArgumentException("Hợp đồng nhiệm vụ yêu cầu đúng 5 ô MonsterClass/KillCount.", "killCounts");
		}
		if (killCounts.Any((int? value) => value < 0))
		{
			throw new ArgumentOutOfRangeException("killCounts", "Số lần tiêu diệt không thể âm.");
		}
		var (accountId, characterName) = ValidateIdentity(expected.AccountId, expected.CharacterName);
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			ValidateSchema(connection, transaction);
			EnsureCharacterBelongsToAccount(connection, transaction, accountId, characterName, lockRow: true);
			EnsureOffline(connection, transaction, accountId);
			CharacterQuestKillCountsSnapshot current = ReadSnapshot(connection, transaction, accountId, characterName, lockRow: true, allowMissing: false);
			if (current.QuestIndex != expected.QuestIndex || !current.Entries.SequenceEqual(expected.Entries))
			{
				throw new InvalidOperationException("Dữ liệu nhiệm vụ đã thay đổi sau khi tải. Musven chưa ghi gì; hãy mở lại.");
			}
			using DbCommand update = connection.CreateCommand();
			update.Transaction = transaction;
			update.CommandTimeout = 8;
			update.CommandText = "UPDATE dbo.QuestKillCount\nSET KillCount1=@K1, KillCount2=@K2, KillCount3=@K3, KillCount4=@K4, KillCount5=@K5\nWHERE Name=@Name\n  AND ((QuestIndex=@QuestIndex) OR (QuestIndex IS NULL AND @QuestIndex IS NULL))\n  AND ((MonsterClass1=@M1) OR (MonsterClass1 IS NULL AND @M1 IS NULL))\n  AND ((MonsterClass2=@M2) OR (MonsterClass2 IS NULL AND @M2 IS NULL))\n  AND ((MonsterClass3=@M3) OR (MonsterClass3 IS NULL AND @M3 IS NULL))\n  AND ((MonsterClass4=@M4) OR (MonsterClass4 IS NULL AND @M4 IS NULL))\n  AND ((MonsterClass5=@M5) OR (MonsterClass5 IS NULL AND @M5 IS NULL))\n  AND ((KillCount1=@OldK1) OR (KillCount1 IS NULL AND @OldK1 IS NULL))\n  AND ((KillCount2=@OldK2) OR (KillCount2 IS NULL AND @OldK2 IS NULL))\n  AND ((KillCount3=@OldK3) OR (KillCount3 IS NULL AND @OldK3 IS NULL))\n  AND ((KillCount4=@OldK4) OR (KillCount4 IS NULL AND @OldK4 IS NULL))\n  AND ((KillCount5=@OldK5) OR (KillCount5 IS NULL AND @OldK5 IS NULL))";
			for (int index = 0; index < 5; index++)
			{
				Add(update, $"@K{index + 1}", DbType.Int32, ((object)killCounts[index]) ?? DBNull.Value);
			}
			Add(update, "@Name", DbType.AnsiString, characterName, 10);
			Add(update, "@QuestIndex", DbType.Int32, ((object)expected.QuestIndex) ?? DBNull.Value);
			for (int index2 = 0; index2 < 5; index2++)
			{
				Add(update, $"@M{index2 + 1}", DbType.Int32, ((object)expected.Entries[index2].MonsterClass) ?? DBNull.Value);
				Add(update, $"@OldK{index2 + 1}", DbType.Int32, ((object)expected.Entries[index2].KillCount) ?? DBNull.Value);
			}
			if (update.ExecuteNonQuery() != 1)
			{
				throw new InvalidOperationException("Cập nhật QuestKillCount không khớp đúng một dòng; giao dịch đã hủy.");
			}
			CharacterQuestKillCountsSnapshot saved = ReadSnapshot(connection, transaction, accountId, characterName, lockRow: true, allowMissing: false);
			if (saved.QuestIndex != expected.QuestIndex || !saved.Entries.Select((QuestKillCountEntry x) => x.MonsterClass).SequenceEqual(expected.Entries.Select((QuestKillCountEntry x) => x.MonsterClass)) || !saved.Entries.Select((QuestKillCountEntry x) => x.KillCount).SequenceEqual(killCounts))
			{
				throw new InvalidOperationException("Hậu kiểm QuestKillCount không khớp; giao dịch đã hủy.");
			}
			transaction.Commit();
			return saved;
		}
		catch
		{
			try
			{
				transaction.Rollback();
			}
			catch
			{
			}
			throw;
		}
	}

	private static void ValidateSchema(DbConnection connection, DbTransaction? transaction)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH\nFROM INFORMATION_SCHEMA.COLUMNS\nWHERE TABLE_SCHEMA=N'dbo' AND TABLE_NAME=N'QuestKillCount'";
		Dictionary<string, (string, int?)> columns = new Dictionary<string, (string, int?)>(StringComparer.OrdinalIgnoreCase);
		using (DbDataReader reader = command.ExecuteReader())
		{
			while (reader.Read())
			{
				columns[reader.GetString(0)] = (reader.GetString(1), reader.IsDBNull(2) ? ((int?)null) : new int?(Convert.ToInt32(reader.GetValue(2))));
			}
		}
		if (!columns.TryGetValue("Name", out var name) || !name.Item1.Equals("varchar", StringComparison.OrdinalIgnoreCase) || name.Item2 != 10)
		{
			throw new InvalidOperationException("Schema QuestKillCount không khớp: Name phải là varchar(10).");
		}
		foreach (string column in RequiredColumns.Skip(1))
		{
			if (!columns.TryGetValue(column, out var field) || !field.Item1.Equals("int", StringComparison.OrdinalIgnoreCase))
			{
				throw new InvalidOperationException("Schema QuestKillCount không khớp: " + column + " phải là int.");
			}
		}
	}

	private static void EnsureCharacterBelongsToAccount(DbConnection connection, DbTransaction? transaction, string accountId, string characterName, bool lockRow)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) Name, AccountID\nFROM dbo.[Character]" + (lockRow ? " WITH (UPDLOCK,HOLDLOCK)" : string.Empty) + "\nWHERE Name=@Name AND AccountID=@Account";
		Add(command, "@Name", DbType.AnsiString, characterName, 10);
		Add(command, "@Account", DbType.AnsiString, accountId, 10);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không tìm thấy nhân vật thuộc tài khoản đã chọn trong dbo.Character.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("Có nhiều nhân vật trùng Name/AccountID; Musven dừng để tránh sửa nhầm.");
		}
	}

	private static CharacterQuestKillCountsSnapshot? ReadSnapshot(DbConnection connection, DbTransaction? transaction, string accountId, string characterName, bool lockRow, bool allowMissing)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) QuestIndex,\nMonsterClass1,MonsterClass2,MonsterClass3,MonsterClass4,MonsterClass5,\nKillCount1,KillCount2,KillCount3,KillCount4,KillCount5\nFROM dbo.QuestKillCount" + (lockRow ? " WITH (UPDLOCK,HOLDLOCK)" : string.Empty) + " WHERE Name=@Name";
		Add(command, "@Name", DbType.AnsiString, characterName, 10);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read())
		{
			if (allowMissing)
			{
				return null;
			}
			throw new InvalidOperationException("Không còn dòng QuestKillCount cho nhân vật; Musven không tạo dòng mới.");
		}
		int? questIndex = (reader.IsDBNull(0) ? ((int?)null) : new int?(Convert.ToInt32(reader.GetValue(0))));
		QuestKillCountEntry[] entries = new QuestKillCountEntry[5];
		for (int i = 0; i < 5; i++)
		{
			int? monster = (reader.IsDBNull(i + 1) ? ((int?)null) : new int?(Convert.ToInt32(reader.GetValue(i + 1))));
			int? count = (reader.IsDBNull(i + 6) ? ((int?)null) : new int?(Convert.ToInt32(reader.GetValue(i + 6))));
			if (count < 0)
			{
				throw new InvalidOperationException($"QuestKillCount.KillCount{i + 1} âm; Musven chỉ hiển thị để tránh ghi giá trị không hợp lệ.");
			}
			entries[i] = new QuestKillCountEntry(monster, count);
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("Có nhiều dòng QuestKillCount cho nhân vật; Musven dừng để tránh cập nhật nhầm.");
		}
		return new CharacterQuestKillCountsSnapshot(accountId, characterName, questIndex, entries);
	}

	private static void EnsureOffline(DbConnection connection, DbTransaction transaction, string accountId)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) ConnectStat FROM dbo.MEMB_STAT WITH (UPDLOCK,HOLDLOCK) WHERE memb___id=@Account";
		Add(command, "@Account", DbType.AnsiString, accountId, 10);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không xác minh được trạng thái tài khoản trong dbo.MEMB_STAT.");
		}
		int status = (reader.IsDBNull(0) ? (-1) : Convert.ToInt32(reader.GetValue(0)));
		if (reader.Read())
		{
			throw new InvalidOperationException("MEMB_STAT có nhiều dòng cho tài khoản.");
		}
		object message;
		switch (status)
		{
		default:
			message = "Không xác minh được tài khoản offline.";
			break;
		case 1:
			message = "Tài khoản đang online; thao tác sửa nhiệm vụ bị từ chối.";
			break;
		case 0:
			return;
		}
		throw new InvalidOperationException((string?)message);
	}

	private static (string AccountId, string CharacterName) ValidateIdentity(string accountId, string characterName)
	{
		accountId = accountId?.Trim() ?? string.Empty;
		characterName = characterName?.Trim() ?? string.Empty;
		int length = accountId.Length;
		bool flag = ((length < 1 || length > 10) ? true : false);
		if (flag || accountId.Any(char.IsWhiteSpace))
		{
			throw new ArgumentException("AccountID phải dài 1–10 ký tự, không có khoảng trắng.", "accountId");
		}
		length = characterName.Length;
		flag = ((length < 1 || length > 10) ? true : false);
		if (flag || characterName.Any(char.IsWhiteSpace))
		{
			throw new ArgumentException("Tên nhân vật phải dài 1–10 ký tự, không có khoảng trắng.", "characterName");
		}
		return (AccountId: accountId, CharacterName: characterName);
	}

	private static void Add(DbCommand command, string name, DbType type, object value, int size = 0)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = type;
		if (size > 0)
		{
			parameter.Size = size;
		}
		parameter.Value = value ?? DBNull.Value;
		command.Parameters.Add(parameter);
	}
}
