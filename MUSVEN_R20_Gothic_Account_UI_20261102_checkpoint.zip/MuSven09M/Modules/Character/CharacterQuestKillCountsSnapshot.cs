using System.Collections.Generic;

namespace MuSven09M.Modules.Character;

public sealed record CharacterQuestKillCountsSnapshot(string AccountId, string CharacterName, int? QuestIndex, IReadOnlyList<QuestKillCountEntry> Entries);
