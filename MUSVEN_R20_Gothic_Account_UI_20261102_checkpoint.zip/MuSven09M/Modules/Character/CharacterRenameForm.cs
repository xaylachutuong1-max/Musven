using System;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

public sealed class CharacterRenameForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly string accountId;

	private readonly string oldName;

	private readonly bool renameEnabled;

	private readonly TextBox newName = new TextBox
	{
		Dock = DockStyle.Fill,
		BackColor = Color.FromArgb(18, 37, 58),
		ForeColor = Color.White,
		BorderStyle = BorderStyle.FixedSingle,
		MaxLength = 10
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button save = new Button
	{
		Text = "ĐỔI TÊN",
		Dock = DockStyle.Fill,
		Enabled = false
	};

	public bool WasRenamed { get; private set; }

	public string NewCharacterName => newName.Text.Trim();

	public CharacterRenameForm(SqlAccountLookupOptions options, string accountId, string oldName, bool renameEnabled)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.accountId = accountId.Trim();
		this.oldName = oldName.Trim();
		this.renameEnabled = renameEnabled;
		Text = "MU SVEN • Đổi tên nhân vật";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(620, 380);
		base.Size = new Size(700, 410);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 5,
			Padding = new Padding(18),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 78f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = "ĐỔI TÊN NHÂN VẬT",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 14f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		root.Controls.Add(new Label
		{
			Text = "Tài khoản: " + this.accountId + "     •     Tên hiện tại: " + this.oldName,
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			Font = new Font("Segoe UI", 10f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 1);
		TableLayoutPanel edit = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			BackColor = Surface,
			Padding = new Padding(12)
		};
		edit.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150f));
		edit.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		edit.Controls.Add(new Label
		{
			Text = "Tên mới (tối đa 10)",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		edit.Controls.Add(newName, 1, 0);
		root.Controls.Add(edit, 0, 2);
		root.Controls.Add(new Label
		{
			Text = "Musven gọi WZ_RenameCharacter trong transaction, cập nhật các bảng tham chiếu đã kiểm kê và từ chối khi tài khoản online hoặc tên mới đã có người dùng.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(4)
		}, 0, 3);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100f));
		footer.Controls.Add(status, 0, 0);
		save.FlatStyle = FlatStyle.Flat;
		save.BackColor = Gold;
		save.ForeColor = Color.Black;
		save.FlatAppearance.BorderColor = Gold;
		save.Click += async delegate
		{
			await RenameAsync();
		};
		footer.Controls.Add(save, 1, 0);
		Button button = new Button();
		button.Text = "HỦY";
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = Color.FromArgb(32, 40, 52);
		button.ForeColor = Color.White;
		button.FlatAppearance.BorderColor = Border;
		Button close = button;
		close.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(close, 2, 0);
		root.Controls.Add(footer, 0, 4);
		newName.TextChanged += delegate
		{
			UpdateEnabled();
		};
		status.Text = (renameEnabled ? "Đã bật công tắc đổi tên; vẫn yêu cầu xác nhận trước khi lưu." : "Đang khóa • bật [MUSVEN_CHARACTER_RENAME] Enabled=1.");
		UiTheme.Apply(this);
	}

	private void UpdateEnabled()
	{
		save.Enabled = renameEnabled && IsValidDraft(newName.Text, oldName);
	}

	private async Task RenameAsync()
	{
		string value = newName.Text.Trim();
		if (!renameEnabled || !IsValidDraft(value, oldName) || MessageBox.Show(this, $"Đổi {oldName} thành {value} cho tài khoản {accountId}? Tên mới sẽ cập nhật cả các bảng ranking, guild, quest và bạn bè có tham chiếu.", "MU SVEN • Xác nhận đổi tên", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return;
		}
		save.Enabled = false;
		newName.Enabled = false;
		status.Text = "Đang xác minh procedure, schema và trạng thái offline…";
		try
		{
			MuSvenDatabase database = new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString(readOnly: false));
			await Task.Run(delegate
			{
				new CharacterRenameRepository(database).Rename(accountId, oldName, value, renameEnabled: true);
			});
			WasRenamed = true;
			base.DialogResult = DialogResult.OK;
			Close();
		}
		catch (Exception ex)
		{
			status.Text = "Không đổi được • " + ex.Message;
			MessageBox.Show(this, ex.Message, "MU SVEN • Không thể đổi tên", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			newName.Enabled = true;
			UpdateEnabled();
		}
	}

	private static bool IsValidDraft(string candidate, string current)
	{
		string value = candidate?.Trim() ?? string.Empty;
		int length = value.Length;
		if (length >= 1 && length <= 10 && !value.Equals(current, StringComparison.OrdinalIgnoreCase))
		{
			return value.All((char ch) => ch >= '!' && ch <= '~');
		}
		return false;
	}
}
