using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text.RegularExpressions;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

public sealed class CharacterRenameRepository
{
	private sealed record Reference(string Table, string Column, string? OwnerColumn = null);

	private static readonly Reference[] References = new Reference[28]
	{
		new Reference("Character", "Name", "AccountID"),
		new Reference("AccountCharacter", "GameID1", "Id"),
		new Reference("AccountCharacter", "GameID2", "Id"),
		new Reference("AccountCharacter", "GameID3", "Id"),
		new Reference("AccountCharacter", "GameID4", "Id"),
		new Reference("AccountCharacter", "GameID5", "Id"),
		new Reference("AccountCharacter", "GameIDC", "Id"),
		new Reference("Guild", "G_Master"),
		new Reference("GuildMember", "Name"),
		new Reference("OptionData", "Name"),
		new Reference("T_CGuid", "Name"),
		new Reference("T_FriendList", "FriendName"),
		new Reference("T_FriendMail", "FriendName"),
		new Reference("T_FriendMain", "Name"),
		new Reference("T_WaitFriend", "FriendName"),
		new Reference("QuestKillCount", "Name"),
		new Reference("MasterSkillTree", "Name"),
		new Reference("EventLeoTheHelper", "Name"),
		new Reference("EventSantaClaus", "Name"),
		new Reference("QuestWorld", "Name"),
		new Reference("Gens_Rank", "Name"),
		new Reference("Gens_Reward", "Name"),
		new Reference("RankingDuel", "Name"),
		new Reference("RankingBloodCastle", "Name"),
		new Reference("RankingChaosCastle", "Name"),
		new Reference("RankingDevilSquare", "Name"),
		new Reference("RankingIllusionTemple", "Name"),
		new Reference("HelperData", "Name")
	};

	private readonly MuSvenDatabase database;

	public CharacterRenameRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public void Rename(string accountId, string oldName, string newName, bool renameEnabled)
	{
		accountId = ValidateValue(accountId, "AccountID");
		oldName = ValidateValue(oldName, "Tên cũ");
		newName = ValidateValue(newName, "Tên mới");
		if (oldName.Equals(newName, StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("Tên mới phải khác tên hiện tại.");
		}
		if (!renameEnabled)
		{
			throw new InvalidOperationException("Đổi tên nhân vật đang khóa. Bật [MUSVEN_CHARACTER_RENAME] Enabled=1 sau khi xác minh procedure.");
		}
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			EnsureProcedureMatches(connection, transaction);
			EnsureReferenceSchema(connection, transaction);
			EnsureOffline(connection, transaction, accountId);
			EnsureOldCharacter(connection, transaction, accountId, oldName);
			EnsureNewNameAvailable(connection, transaction, newName);
			using (DbCommand command = connection.CreateCommand())
			{
				command.Transaction = transaction;
				command.CommandTimeout = 25;
				command.CommandType = CommandType.StoredProcedure;
				command.CommandText = "dbo.WZ_RenameCharacter";
				AddAnsi(command, "@Account", accountId);
				AddAnsi(command, "@OldName", oldName);
				AddAnsi(command, "@NewName", newName);
				object raw = command.ExecuteScalar();
				if (raw == null || raw is DBNull || !byte.TryParse(Convert.ToString(raw), out var result) || result != 0)
				{
					throw new InvalidOperationException("WZ_RenameCharacter từ chối đổi tên hoặc trả mã không hợp lệ; giao dịch đã hủy.");
				}
			}
			EnsureRenameApplied(connection, transaction, accountId, oldName, newName);
			EnsureNoOldReferences(connection, transaction, accountId, oldName);
			transaction.Commit();
		}
		catch
		{
			TryRollback(transaction);
			throw;
		}
	}

	private static void EnsureProcedureMatches(DbConnection connection, DbTransaction transaction)
	{
		string definition;
		using (DbCommand command = connection.CreateCommand())
		{
			command.Transaction = transaction;
			command.CommandTimeout = 8;
			command.CommandText = "SELECT OBJECT_DEFINITION(OBJECT_ID(N'dbo.WZ_RenameCharacter'))";
			definition = Convert.ToString(command.ExecuteScalar()) ?? string.Empty;
		}
		Match match = Regex.Match(Normalize(definition), "^(?:CREATE|ALTER)\\s+(?:PROC(?:EDURE)?)\\s+WZ_RENAMECHARACTER\\b[\\s\\S]*?\\bAS\\s+BEGIN\\s+(?<body>[\\s\\S]+?)\\s+END\\s*;?$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
		if (!match.Success)
		{
			throw new InvalidOperationException("Không đọc được định nghĩa dbo.WZ_RenameCharacter.");
		}
		string body = match.Groups["body"].Value;
		MatchCollection source = Regex.Matches(body, "\\bUPDATE\\s+(?<table>[A-Z0-9_]+)\\s+SET\\s+(?<set>[A-Z0-9_]+)\\s*=\\s*@NEWNAME\\s+WHERE\\s+(?<where>[A-Z0-9_]+)\\s*=\\s*@OLDNAME(?:(?:\\s+AND\\s+(?<owner>[A-Z0-9_]+)\\s*=\\s*@ACCOUNT))?", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
		HashSet<string> expected = References.Select((Reference x) => $"{x.Table}|{x.Column}|{x.Column}|{x.OwnerColumn ?? string.Empty}").ToHashSet<string>(StringComparer.OrdinalIgnoreCase);
		HashSet<string> actual = source.Select((Match m) => $"{m.Groups["table"].Value}|{m.Groups["set"].Value}|{m.Groups["where"].Value}|{m.Groups["owner"].Value}").ToHashSet<string>(StringComparer.OrdinalIgnoreCase);
		int updateCount = Regex.Matches(body, "\\bUPDATE\\b", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant).Count;
		bool num = body.Contains("IF EXISTS (SELECT NAME FROM CHARACTER WHERE NAME=@NEWNAME)", StringComparison.OrdinalIgnoreCase) && body.Contains("SET @RESULT=1", StringComparison.OrdinalIgnoreCase) && body.Contains("SET @RESULT=0", StringComparison.OrdinalIgnoreCase) && body.Contains("SELECT @RESULT", StringComparison.OrdinalIgnoreCase) && body.Contains("SET XACT_ABORT ON", StringComparison.OrdinalIgnoreCase);
		bool unexpectedMutation = Regex.IsMatch(body, "\\b(INSERT|DELETE|MERGE|TRUNCATE|EXEC(?:UTE)?|SP_EXECUTESQL|OPENROWSET)\\b", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
		if (!num || unexpectedMutation || updateCount != References.Length || actual.Count != expected.Count || !actual.SetEquals(expected))
		{
			throw new InvalidOperationException("dbo.WZ_RenameCharacter khác hợp đồng đã rà soát; Musven chưa gọi procedure.");
		}
		using DbCommand parameters = connection.CreateCommand();
		parameters.Transaction = transaction;
		parameters.CommandTimeout = 8;
		parameters.CommandText = "\nSELECT p.parameter_id,p.name,ty.name,p.max_length,p.is_output\nFROM sys.parameters AS p JOIN sys.types AS ty ON ty.user_type_id=p.user_type_id\nWHERE p.object_id=OBJECT_ID(N'dbo.WZ_RenameCharacter') AND p.parameter_id>0 ORDER BY p.parameter_id";
		using DbDataReader reader = parameters.ExecuteReader();
		(string, string, int)[] array = new(string, string, int)[3]
		{
			("@Account", "varchar", 10),
			("@OldName", "varchar", 10),
			("@NewName", "varchar", 10)
		};
		int num2 = 0;
		while (num2 < array.Length)
		{
			(string, string, int) expectedParameter = array[num2];
			if (reader.Read())
			{
				string name = Convert.ToString(reader.GetValue(1));
				if (name != null && name.Equals(expectedParameter.Item1, StringComparison.OrdinalIgnoreCase) && Convert.ToString(reader.GetValue(2)).Equals(expectedParameter.Item2, StringComparison.OrdinalIgnoreCase) && Convert.ToInt32(reader.GetValue(3)) == expectedParameter.Item3 && !Convert.ToBoolean(reader.GetValue(4)))
				{
					num2++;
					continue;
				}
			}
			throw new InvalidOperationException("Chữ ký dbo.WZ_RenameCharacter phải là @Account, @OldName, @NewName varchar(10).");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.WZ_RenameCharacter có tham số thừa.");
		}
	}

	private static void EnsureReferenceSchema(DbConnection connection, DbTransaction transaction)
	{
		Reference[] references = References;
		foreach (Reference reference in references)
		{
			string[] array = ((reference.OwnerColumn != null) ? new string[2] { reference.Column, reference.OwnerColumn } : new string[1] { reference.Column });
			foreach (string column in array)
			{
				using DbCommand command = connection.CreateCommand();
				command.Transaction = transaction;
				command.CommandTimeout = 8;
				command.CommandText = "SELECT CASE WHEN OBJECT_ID(@ObjectName,N'U') IS NOT NULL AND COL_LENGTH(@ObjectName,@ColumnName) IS NOT NULL THEN 1 ELSE 0 END";
				AddText(command, "@ObjectName", "dbo." + reference.Table, 128);
				AddText(command, "@ColumnName", column, 128);
				if (Convert.ToInt32(command.ExecuteScalar()) != 1)
				{
					throw new InvalidOperationException($"Thiếu dbo.{reference.Table}.{column}; Musven từ chối gọi procedure đổi tên.");
				}
			}
		}
	}

	private static void EnsureOffline(DbConnection connection, DbTransaction transaction, string accountId)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) ConnectStat FROM dbo.MEMB_STAT WITH (UPDLOCK,HOLDLOCK) WHERE memb___id=@Account";
		AddAnsi(command, "@Account", accountId);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read() || reader.IsDBNull(0))
		{
			throw new InvalidOperationException("Không xác minh được trạng thái tài khoản trong MEMB_STAT.");
		}
		int num = Convert.ToInt32(reader.GetValue(0));
		if (reader.Read())
		{
			throw new InvalidOperationException("MEMB_STAT có nhiều dòng cho AccountID.");
		}
		if (num != 0)
		{
			throw new InvalidOperationException("Tài khoản đang online; hãy đăng xuất trước khi đổi tên.");
		}
	}

	private static void EnsureOldCharacter(DbConnection connection, DbTransaction transaction, string accountId, string oldName)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) AccountID FROM dbo.Character WITH (UPDLOCK,HOLDLOCK) WHERE Name=@Name";
		AddAnsi(command, "@Name", oldName);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không tìm thấy nhân vật cần đổi tên.");
		}
		if (!(Convert.ToString(reader.GetValue(0)) ?? string.Empty).Equals(accountId, StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("Nhân vật không thuộc tài khoản đang chọn.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("Tên cũ bị trùng trong Character; Musven từ chối đổi tên.");
		}
	}

	private static void EnsureNewNameAvailable(DbConnection connection, DbTransaction transaction, string newName)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) Name FROM dbo.Character WITH (UPDLOCK,HOLDLOCK) WHERE Name=@Name";
		AddAnsi(command, "@Name", newName);
		using DbDataReader reader = command.ExecuteReader();
		if (reader.Read())
		{
			throw new InvalidOperationException("Tên mới đã được dùng.");
		}
	}

	private static void EnsureRenameApplied(DbConnection connection, DbTransaction transaction, string accountId, string oldName, string newName)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) AccountID FROM dbo.Character WITH (UPDLOCK,HOLDLOCK) WHERE Name=@Name";
		AddAnsi(command, "@Name", newName);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read() || !string.Equals(Convert.ToString(reader.GetValue(0)), accountId, StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("Không xác minh được nhân vật mới sau khi gọi procedure.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("Tên mới xuất hiện nhiều dòng sau khi đổi tên.");
		}
		reader.Close();
		using DbCommand oldCheck = connection.CreateCommand();
		oldCheck.Transaction = transaction;
		oldCheck.CommandTimeout = 8;
		oldCheck.CommandText = "SELECT TOP (1) 1 FROM dbo.Character WITH (UPDLOCK,HOLDLOCK) WHERE Name=@Name";
		AddAnsi(oldCheck, "@Name", oldName);
		if (oldCheck.ExecuteScalar() != null)
		{
			throw new InvalidOperationException("Tên cũ vẫn còn trong Character; giao dịch đã hủy.");
		}
	}

	private static void EnsureNoOldReferences(DbConnection connection, DbTransaction transaction, string accountId, string oldName)
	{
		foreach (Reference reference in References.Skip(1))
		{
			using DbCommand command = connection.CreateCommand();
			command.Transaction = transaction;
			command.CommandTimeout = 8;
			string owner = ((reference.OwnerColumn == null) ? string.Empty : (" AND " + Quote(reference.OwnerColumn) + "=@Account"));
			command.CommandText = $"SELECT TOP (1) 1 FROM dbo.{Quote(reference.Table)} WITH (UPDLOCK,HOLDLOCK) WHERE {Quote(reference.Column)}=@OldName{owner}";
			AddAnsi(command, "@OldName", oldName);
			if (reference.OwnerColumn != null)
			{
				AddAnsi(command, "@Account", accountId);
			}
			if (command.ExecuteScalar() != null)
			{
				throw new InvalidOperationException($"dbo.{reference.Table}.{reference.Column} còn tham chiếu tên cũ; giao dịch đã hủy.");
			}
		}
	}

	private static string Normalize(string definition)
	{
		return Regex.Replace(Regex.Replace(Regex.Replace(definition, "--.*?$|/\\*[\\s\\S]*?\\*/", "", RegexOptions.Multiline | RegexOptions.CultureInvariant).Replace("[", string.Empty, StringComparison.Ordinal).Replace("]", string.Empty, StringComparison.Ordinal), "\\bDBO\\.", string.Empty, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant), "\\s+", " ", RegexOptions.CultureInvariant).Trim().ToUpperInvariant();
	}

	private static string ValidateValue(string value, string label)
	{
		string result = value?.Trim() ?? string.Empty;
		int length = result.Length;
		bool flag = ((length < 1 || length > 10) ? true : false);
		if (flag || result.Any(char.IsControl) || result.Any(char.IsWhiteSpace) || result.Any((char ch) => ch > '\u007f'))
		{
			throw new ArgumentException(label + " phải có từ 1 đến 10 ký tự ASCII, không có khoảng trắng.", label);
		}
		return result;
	}

	private static string Quote(string identifier)
	{
		return "[" + identifier.Replace("]", "]]", StringComparison.Ordinal) + "]";
	}

	private static void AddAnsi(DbCommand command, string name, string value)
	{
		AddText(command, name, value, 10, DbType.AnsiString);
	}

	private static void AddText(DbCommand command, string name, string value, int size, DbType type = DbType.String)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = type;
		parameter.Size = size;
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}

	private static void TryRollback(DbTransaction transaction)
	{
		try
		{
			transaction.Rollback();
		}
		catch
		{
		}
	}
}
