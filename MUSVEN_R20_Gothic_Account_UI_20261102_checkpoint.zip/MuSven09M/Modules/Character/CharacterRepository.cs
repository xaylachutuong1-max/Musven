using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Character;

public sealed class CharacterRepository
{
	private readonly MuSvenDatabase database;

	public CharacterRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public IReadOnlyList<CharacterSummary> ListByAccount(string accountId, int limit = 200)
	{
		if (string.IsNullOrWhiteSpace(accountId))
		{
			throw new ArgumentException("Account ID is required.", "accountId");
		}
		if ((limit < 1 || limit > 500) ? true : false)
		{
			throw new ArgumentOutOfRangeException("limit", "Result limit must be from 1 to 500.");
		}
		using DbConnection connection = database.OpenConnection();
		Dictionary<string, string> columns = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		using (DbCommand schemaCommand = connection.CreateCommand())
		{
			schemaCommand.CommandText = "\nSELECT COLUMN_NAME, DATA_TYPE\nFROM INFORMATION_SCHEMA.COLUMNS\nWHERE TABLE_SCHEMA = N'dbo' AND TABLE_NAME = N'Character'";
			schemaCommand.CommandTimeout = 5;
			using DbDataReader schemaReader = schemaCommand.ExecuteReader();
			while (schemaReader.Read())
			{
				columns[schemaReader.GetString(0)] = schemaReader.GetString(1);
			}
		}
		string nameColumn = Find(columns.Keys, "Name");
		string accountColumn = Find(columns.Keys, "AccountID", "AccountId");
		if (nameColumn == null || accountColumn == null)
		{
			throw new InvalidOperationException("dbo.Character thiếu cột Name hoặc AccountID; Musven dừng truy vấn nhân vật để tránh đọc sai schema.");
		}
		string levelColumn = Find(columns.Keys, "cLevel", "Level");
		string resetColumn = Find(columns.Keys, "ResetCount", "Reset");
		string zenColumn = Find(columns.Keys, "Money", "Zen");
		string pointsColumn = Find(columns.Keys, "LevelUpPoint", "LevelUpPoints");
		string levelExpression = ((levelColumn == null) ? "CAST(NULL AS int)" : Quote(levelColumn));
		string resetExpression = ((resetColumn == null) ? "CAST(NULL AS int)" : Quote(resetColumn));
		string zenExpression = ((zenColumn != null && IsNumeric(columns[zenColumn])) ? ("CONVERT(bigint," + Quote(zenColumn) + ")") : "CAST(NULL AS bigint)");
		string pointsExpression = ((pointsColumn != null && IsNumeric(columns[pointsColumn])) ? ("CONVERT(int," + Quote(pointsColumn) + ")") : "CAST(NULL AS int)");
		using DbCommand command = connection.CreateCommand();
		command.CommandText = $"\nSELECT TOP (@Limit) {Quote(nameColumn)} AS CharacterName,\n       {levelExpression} AS CharacterLevel,\n       {resetExpression} AS CharacterReset,\n       {zenExpression} AS CharacterZen,\n       {pointsExpression} AS CharacterPoints\nFROM dbo.[Character]\nWHERE {Quote(accountColumn)} = @AccountId\nORDER BY {Quote(nameColumn)}";
		command.CommandType = CommandType.Text;
		command.CommandTimeout = 5;
		AddParameter(command, "@Limit", DbType.Int32, limit, 0);
		AddParameter(command, "@AccountId", DbType.String, accountId.Trim(), 32);
		List<CharacterSummary> result = new List<CharacterSummary>();
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		while (reader.Read())
		{
			result.Add(new CharacterSummary(reader.IsDBNull(0) ? string.Empty : (Convert.ToString(reader.GetValue(0)) ?? string.Empty), ReadOptionalInteger(reader, 1), ReadOptionalInteger(reader, 2), ReadOptionalInt64(reader, 3), ReadOptionalInteger(reader, 4)));
		}
		return result;
	}

	private static int? ReadOptionalInteger(DbDataReader reader, int ordinal)
	{
		if (reader.IsDBNull(ordinal) || !int.TryParse(Convert.ToString(reader.GetValue(ordinal), CultureInfo.InvariantCulture), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value))
		{
			return null;
		}
		return value;
	}

	private static long? ReadOptionalInt64(DbDataReader reader, int ordinal)
	{
		if (reader.IsDBNull(ordinal) || !long.TryParse(Convert.ToString(reader.GetValue(ordinal), CultureInfo.InvariantCulture), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value))
		{
			return null;
		}
		return value;
	}

	private static bool IsNumeric(string dataType)
	{
		if (!dataType.Equals("tinyint", StringComparison.OrdinalIgnoreCase) && !dataType.Equals("smallint", StringComparison.OrdinalIgnoreCase) && !dataType.Equals("int", StringComparison.OrdinalIgnoreCase) && !dataType.Equals("bigint", StringComparison.OrdinalIgnoreCase) && !dataType.Equals("decimal", StringComparison.OrdinalIgnoreCase))
		{
			return dataType.Equals("numeric", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	private static string? Find(IEnumerable<string> columns, params string[] names)
	{
		foreach (string name in names)
		{
			string match = columns.FirstOrDefault((string column) => column.Equals(name, StringComparison.OrdinalIgnoreCase));
			if (match != null)
			{
				return match;
			}
		}
		return null;
	}

	private static string Quote(string identifier)
	{
		return "[" + identifier.Replace("]", "]]", StringComparison.Ordinal) + "]";
	}

	private static void AddParameter(DbCommand command, string name, DbType type, object value, int size)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = type;
		if (size > 0)
		{
			parameter.Size = size;
		}
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}
}
