namespace MuSven09M.Modules.Character;

public sealed record CharacterSummary(string Name, int? Level, int? ResetCount, long? Zen = null, int? Points = null);
