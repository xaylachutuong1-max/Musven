namespace MuSven09M.Modules.Character;

public sealed record QuestKillCountEntry(int? MonsterClass, int? KillCount);
