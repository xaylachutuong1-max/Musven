using System;
using System.Data;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Management;

public sealed class RankingBrowserForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly bool writeEnabled;

	private readonly ComboBox tables = new ComboBox
	{
		Dock = DockStyle.Fill,
		DropDownStyle = ComboBoxStyle.DropDownList,
		BackColor = Color.FromArgb(18, 37, 58),
		ForeColor = Color.White,
		FlatStyle = FlatStyle.Flat,
		Margin = new Padding(4)
	};

	private readonly DataGridView grid = new DataGridView
	{
		Dock = DockStyle.Fill,
		ReadOnly = true,
		AllowUserToAddRows = false,
		AllowUserToDeleteRows = false,
		AllowUserToResizeRows = false,
		MultiSelect = false,
		SelectionMode = DataGridViewSelectionMode.FullRowSelect,
		AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells,
		BackgroundColor = Surface,
		BorderStyle = BorderStyle.None,
		RowHeadersVisible = false
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button loadButton;

	private readonly Button resetButton = MakeButton("XEM TRƯỚC RESET", emphasized: true);

	private readonly TextBox confirmTable = new TextBox
	{
		Width = 190,
		MaxLength = 64,
		BackColor = Color.FromArgb(18, 37, 58),
		ForeColor = Color.White,
		BorderStyle = BorderStyle.FixedSingle,
		Margin = new Padding(5, 8, 5, 4)
	};

	private RankingResetPreview? resetPreview;

	public RankingBrowserForm(SqlAccountLookupOptions options, bool writeEnabled = false)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.writeEnabled = writeEnabled;
		Text = "MU SVEN • Xếp hạng và sự kiện";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(850, 560);
		base.Size = new Size(1100, 700);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 3,
			Padding = new Padding(12),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 64f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 108f));
		base.Controls.Add(root);
		TableLayoutPanel header = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 4,
			RowCount = 1,
			BackColor = Surface,
			Padding = new Padding(8),
			Margin = new Padding(2)
		};
		header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 132f));
		header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 152f));
		header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170f));
		header.Controls.Add(new Label
		{
			Text = "BẢNG / SỰ KIỆN",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 10f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		tables.DataSource = RankingRepository.AvailableTables;
		tables.DisplayMember = "DisplayName";
		header.Controls.Add(tables, 1, 0);
		loadButton = MakeButton("TẢI TỐI ĐA 100", emphasized: true);
		loadButton.Click += async delegate
		{
			await LoadRankingAsync();
		};
		header.Controls.Add(loadButton, 2, 0);
		resetButton.Enabled = writeEnabled;
		resetButton.Click += async delegate
		{
			await ResetRankingAsync();
		};
		header.Controls.Add(resetButton, 3, 0);
		tables.SelectionChangeCommitted += delegate
		{
			ResetPreviewState();
		};
		root.Controls.Add(header, 0, 0);
		grid.EnableHeadersVisualStyles = false;
		grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(16, 43, 70);
		grid.ColumnHeadersDefaultCellStyle.ForeColor = Gold;
		grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
		grid.DefaultCellStyle.BackColor = Color.FromArgb(12, 25, 43);
		grid.DefaultCellStyle.ForeColor = Color.Gainsboro;
		grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(25, 78, 119);
		grid.DefaultCellStyle.SelectionForeColor = Color.White;
		grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(15, 31, 51);
		Panel gridFrame = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			Padding = new Padding(8),
			Margin = new Padding(2)
		};
		gridFrame.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border, 1.2f);
			e.Graphics.DrawRectangle(pen, 1, 1, Math.Max(1, gridFrame.Width - 3), Math.Max(1, gridFrame.Height - 3));
		};
		gridFrame.Controls.Add(grid);
		root.Controls.Add(gridFrame, 0, 1);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 2,
			Margin = Padding.Empty
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130f));
		footer.RowStyles.Add(new RowStyle(SizeType.Absolute, 46f));
		footer.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
		footer.Controls.Add(status, 0, 0);
		Button close = MakeButton("ĐÓNG", emphasized: false);
		close.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(close, 1, 0);
		FlowLayoutPanel resetConfirm = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.LeftToRight,
			WrapContents = false,
			Margin = Padding.Empty
		};
		resetConfirm.Controls.Add(new Label
		{
			Text = "Xác nhận xóa ranking • nhập đúng tên bảng:",
			AutoSize = true,
			ForeColor = Gold,
			Padding = new Padding(0, 12, 0, 0)
		});
		resetConfirm.Controls.Add(confirmTable);
		footer.Controls.Add(resetConfirm, 0, 1);
		footer.SetColumnSpan(resetConfirm, 2);
		root.Controls.Add(footer, 0, 2);
		base.Shown += async delegate
		{
			UiTheme.Apply(this);
			await LoadRankingAsync();
		};
	}

	private void ResetPreviewState()
	{
		resetPreview = null;
		confirmTable.Clear();
		bool resettable = tables.SelectedItem is RankingTableOption selected && RankingMaintenanceRepository.IsResettable(selected.TableName);
		resetButton.Text = "XEM TRƯỚC RESET";
		resetButton.Enabled = writeEnabled && resettable;
	}

	private async Task LoadRankingAsync()
	{
		object selectedItem = tables.SelectedItem;
		RankingTableOption selected = selectedItem as RankingTableOption;
		if ((object)selected == null)
		{
			return;
		}
		loadButton.Enabled = false;
		status.Text = "ĐANG ĐỌC • chỉ đọc, tối đa 100 dòng...";
		try
		{
			string connectionString = options.CreateConnectionString();
			DataTable result = await Task.Run(() => new RankingRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).ReadTop(selected.TableName));
			grid.DataSource = result;
			status.Text = $"{selected.DisplayName} • {result.Rows.Count} dòng • chỉ đọc";
		}
		catch
		{
			grid.DataSource = null;
			status.Text = "Không đọc được dbo." + selected.TableName + ". Kiểm tra bảng/cột và quyền SELECT.";
		}
		finally
		{
			loadButton.Enabled = true;
		}
	}

	private async Task ResetRankingAsync()
	{
		if (!writeEnabled)
		{
			status.Text = "Reset ranking đang khóa trong Config.ini.";
			return;
		}
		object selectedItem = tables.SelectedItem;
		RankingTableOption selected = selectedItem as RankingTableOption;
		if ((object)selected == null || !RankingMaintenanceRepository.IsResettable(selected.TableName))
		{
			status.Text = "Chỉ reset bảng Ranking*; bảng event và quest không nằm trong hợp đồng xóa.";
			return;
		}
		string connectionString = options.CreateConnectionString(readOnly: false);
		if ((object)resetPreview == null || !resetPreview.TableName.Equals(selected.TableName, StringComparison.OrdinalIgnoreCase))
		{
			resetButton.Enabled = false;
			status.Text = "ĐANG XEM TRƯỚC • kiểm tra bảng, trigger, khóa ngoại và số dòng…";
			try
			{
				resetPreview = await Task.Run(() => new RankingMaintenanceRepository(new MuSvenDatabase(SqlClientFactory.Instance, options.CreateConnectionString())).Preview(selected.TableName));
				resetButton.Text = "XÓA RESET BẢNG";
				status.Text = $"Preview dbo.{selected.TableName}: {resetPreview.RowCount:N0} dòng. GameServer phải được dừng trước khi tiếp tục.";
				return;
			}
			catch (Exception ex)
			{
				resetPreview = null;
				status.Text = ((ex is InvalidOperationException) ? ex.Message : ("Không xem trước được dbo." + selected.TableName + "; kiểm tra quyền SELECT/schema."));
				return;
			}
			finally
			{
				resetButton.Enabled = writeEnabled && (object)resetPreview != null;
			}
		}
		if (!confirmTable.Text.Trim().Equals(selected.TableName, StringComparison.Ordinal))
		{
			status.Text = "Gõ chính xác " + selected.TableName + " để xác nhận reset.";
		}
		else
		{
			if (MessageBox.Show(this, $"XÓA TOÀN BỘ {resetPreview.RowCount:N0} dòng trong dbo.{selected.TableName}?\n\nGameServer phải được người vận hành dừng. Musven xác nhận không còn tài khoản online, kiểm tra lại số dòng và dùng transaction. Bảng event/quest không bị tác động.", "MU SVEN • Xác nhận reset ranking", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
			{
				return;
			}
			resetButton.Enabled = false;
			loadButton.Enabled = false;
			status.Text = "ĐANG RESET • khóa bảng, kiểm tra phiên online và đối chiếu preview…";
			try
			{
				long cleared = await Task.Run(() => new RankingMaintenanceRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).Clear(resetPreview));
				resetPreview = null;
				confirmTable.Clear();
				resetButton.Text = "XEM TRƯỚC RESET";
				status.Text = $"Đã xóa {cleared:N0} dòng trong dbo.{selected.TableName}; giao dịch đã xác minh bảng rỗng.";
				await LoadRankingAsync();
			}
			catch (Exception ex2)
			{
				status.Text = ((ex2 is InvalidOperationException) ? ex2.Message : "SQL từ chối reset hoặc kiểm tra schema/quyền; giao dịch đã rollback.");
			}
			finally
			{
				loadButton.Enabled = true;
				resetButton.Enabled = writeEnabled && tables.SelectedItem is RankingTableOption active && RankingMaintenanceRepository.IsResettable(active.TableName);
			}
		}
	}

	private static Button MakeButton(string text, bool emphasized)
	{
		Button button = new Button();
		button.Text = text;
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (emphasized ? Gold : Color.FromArgb(18, 51, 82));
		button.ForeColor = (emphasized ? Color.Black : Color.White);
		button.Margin = new Padding(4);
		button.Cursor = Cursors.Hand;
		button.FlatAppearance.BorderColor = (emphasized ? Gold : Border);
		return button;
	}
}
