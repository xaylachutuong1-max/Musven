using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Management;

public sealed class RankingMaintenanceRepository
{
	private static readonly HashSet<string> Resettable = (from x in RankingRepository.AvailableTables
		where x.TableName.StartsWith("Ranking", StringComparison.OrdinalIgnoreCase)
		select x.TableName).ToHashSet<string>(StringComparer.OrdinalIgnoreCase);

	private readonly MuSvenDatabase database;

	public RankingMaintenanceRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public static bool IsResettable(string tableName)
	{
		return Resettable.Contains(tableName);
	}

	public RankingResetPreview Preview(string tableName)
	{
		RankingTableOption option = RequireTable(tableName);
		using DbConnection connection = database.OpenConnection();
		ValidateTableContract(connection, null, option.TableName);
		long count = CountRows(connection, null, option.TableName, lockTable: false);
		return new RankingResetPreview(option.TableName, option.DisplayName, count);
	}

	public long Clear(RankingResetPreview expected)
	{
		ArgumentNullException.ThrowIfNull(expected, "expected");
		RankingTableOption option = RequireTable(expected.TableName);
		if (!option.DisplayName.Equals(expected.DisplayName, StringComparison.Ordinal))
		{
			throw new InvalidOperationException("Bảng ranking không khớp bản xem trước.");
		}
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			ValidateTableContract(connection, transaction, option.TableName);
			EnsureNoOnlineAccounts(connection, transaction);
			long current = CountRows(connection, transaction, option.TableName, lockTable: true);
			if (current != expected.RowCount)
			{
				throw new InvalidOperationException("Số dòng đã đổi sau khi xem trước. Chưa xóa gì; hãy tải lại preview.");
			}
			using (DbCommand delete = connection.CreateCommand())
			{
				delete.Transaction = transaction;
				delete.CommandTimeout = 30;
				delete.CommandText = "DELETE FROM dbo." + Quote(option.TableName) + " WITH (TABLOCKX,HOLDLOCK)";
				if (delete.ExecuteNonQuery() != current)
				{
					throw new InvalidOperationException("Số dòng xóa khác bản xem trước; giao dịch đã hủy.");
				}
			}
			if (CountRows(connection, transaction, option.TableName, lockTable: true) != 0L)
			{
				throw new InvalidOperationException("Bảng ranking chưa rỗng sau DELETE; giao dịch đã hủy.");
			}
			transaction.Commit();
			return current;
		}
		catch
		{
			try
			{
				transaction.Rollback();
			}
			catch
			{
			}
			throw;
		}
	}

	private static RankingTableOption RequireTable(string tableName)
	{
		return RankingRepository.AvailableTables.FirstOrDefault((RankingTableOption x) => Resettable.Contains(x.TableName) && x.TableName.Equals(tableName, StringComparison.OrdinalIgnoreCase)) ?? throw new InvalidOperationException("Chỉ được reset bảng Ranking* nằm trong danh sách cho phép; bảng event/quest không hỗ trợ reset tại đây.");
	}

	private static void ValidateTableContract(DbConnection connection, DbTransaction? transaction, string tableName)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "\nSELECT COUNT_BIG(*)\nFROM sys.columns c\nWHERE c.object_id=OBJECT_ID(@ObjectName)\n  AND TYPE_NAME(c.user_type_id) NOT IN (N'text',N'ntext',N'image',N'xml',N'geography',N'geometry')";
		AddParameter(command, "@ObjectName", DbType.String, 260, "dbo." + tableName);
		if (Convert.ToInt64(command.ExecuteScalar()) == 0L)
		{
			throw new InvalidOperationException("Không tìm thấy schema an toàn cho dbo." + tableName + ".");
		}
		using DbCommand guards = connection.CreateCommand();
		guards.Transaction = transaction;
		guards.CommandTimeout = 8;
		guards.CommandText = "\nSELECT\n  (SELECT COUNT_BIG(*) FROM sys.triggers WHERE parent_id=OBJECT_ID(@ObjectName) AND is_disabled=0),\n  (SELECT COUNT_BIG(*) FROM sys.foreign_keys WHERE parent_object_id=OBJECT_ID(@ObjectName) OR referenced_object_id=OBJECT_ID(@ObjectName))";
		AddParameter(guards, "@ObjectName", DbType.String, 260, "dbo." + tableName);
		using DbDataReader reader = guards.ExecuteReader(CommandBehavior.SingleRow);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không kiểm tra được trigger/FK của bảng ranking.");
		}
		long num = Convert.ToInt64(reader.GetValue(0));
		long foreignKeys = Convert.ToInt64(reader.GetValue(1));
		if (num != 0L)
		{
			throw new InvalidOperationException("dbo." + tableName + " có trigger đang bật; Musven từ chối reset để tránh side effect.");
		}
		if (foreignKeys != 0L)
		{
			throw new InvalidOperationException("dbo." + tableName + " có khóa ngoại; Musven từ chối reset để giữ nguyên quan hệ dữ liệu.");
		}
	}

	private static void EnsureNoOnlineAccounts(DbConnection connection, DbTransaction transaction)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 10;
		command.CommandText = "SELECT COUNT_BIG(*) FROM dbo.MEMB_STAT WITH (TABLOCKX,HOLDLOCK) WHERE ConnectStat<>0";
		long online = Convert.ToInt64(command.ExecuteScalar());
		if (online != 0L)
		{
			throw new InvalidOperationException($"Có {online} tài khoản online. Không reset ranking khi còn phiên game.");
		}
	}

	private static long CountRows(DbConnection connection, DbTransaction? transaction, string tableName, bool lockTable)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 20;
		command.CommandText = "SELECT COUNT_BIG(*) FROM dbo." + Quote(tableName) + (lockTable ? " WITH (TABLOCKX,HOLDLOCK)" : string.Empty);
		return Convert.ToInt64(command.ExecuteScalar());
	}

	private static string Quote(string identifier)
	{
		return "[" + identifier.Replace("]", "]]", StringComparison.Ordinal) + "]";
	}

	private static void AddParameter(DbCommand command, string name, DbType type, int size, object value)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = type;
		parameter.Size = size;
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}
}
