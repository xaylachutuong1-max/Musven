using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Management;

public sealed class RankingRepository
{
	private static readonly RankingTableOption[] Tables = new RankingTableOption[13]
	{
		new RankingTableOption("RankingBloodCastle", "Blood Castle"),
		new RankingTableOption("RankingBos", "Boss"),
		new RankingTableOption("RankingChaosCastle", "Chaos Castle"),
		new RankingTableOption("RankingDevilSquare", "Devil Square"),
		new RankingTableOption("RankingDuel", "Duel"),
		new RankingTableOption("RankingIllusionTemple", "Illusion Temple"),
		new RankingTableOption("RankingKingGuild", "King Guild"),
		new RankingTableOption("RankingKingPlayer", "King Player"),
		new RankingTableOption("RankingTvT", "Team vs Team"),
		new RankingTableOption("CustomQuest", "Nhiệm vụ tùy biến"),
		new RankingTableOption("CustomNpcQuest", "Nhiệm vụ NPC"),
		new RankingTableOption("EventLeoTheHelper", "Sự kiện Leo the Helper"),
		new RankingTableOption("EventSantaClaus", "Sự kiện Santa Claus")
	};

	private static readonly HashSet<string> SafeTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
	{
		"varchar", "nvarchar", "char", "nchar", "int", "bigint", "smallint", "tinyint", "bit", "decimal",
		"numeric", "money", "smallmoney", "float", "real", "datetime", "smalldatetime", "date", "time"
	};

	private readonly MuSvenDatabase database;

	public static IReadOnlyList<RankingTableOption> AvailableTables => Tables;

	public RankingRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public DataTable ReadTop(string tableName)
	{
		RankingTableOption table = Tables.FirstOrDefault((RankingTableOption x) => x.TableName.Equals(tableName, StringComparison.OrdinalIgnoreCase)) ?? throw new ArgumentException("Bảng ranking không nằm trong danh sách cho phép.", "tableName");
		using DbConnection connection = database.OpenConnection();
		List<string> columns = new List<string>();
		using (DbCommand metadata = connection.CreateCommand())
		{
			metadata.CommandText = "\nSELECT COLUMN_NAME, DATA_TYPE\nFROM INFORMATION_SCHEMA.COLUMNS\nWHERE TABLE_SCHEMA = N'dbo' AND TABLE_NAME = @TableName\nORDER BY ORDINAL_POSITION";
			metadata.CommandTimeout = 5;
			DbParameter parameter = metadata.CreateParameter();
			parameter.ParameterName = "@TableName";
			parameter.DbType = DbType.String;
			parameter.Size = 128;
			parameter.Value = table.TableName;
			metadata.Parameters.Add(parameter);
			using DbDataReader reader = metadata.ExecuteReader(CommandBehavior.SequentialAccess);
			while (reader.Read())
			{
				string name = reader.GetString(0);
				string type = reader.GetString(1);
				if (SafeTypes.Contains(type))
				{
					columns.Add(name);
				}
			}
		}
		if (columns.Count == 0)
		{
			throw new InvalidOperationException("Không tìm thấy bảng dbo." + table.TableName + " hoặc bảng chưa có cột xem được.");
		}
		string projection = string.Join(", ", columns.Select(Quote));
		string order = FindOrderColumn(columns);
		string orderClause = ((order == null) ? string.Empty : (" ORDER BY " + Quote(order) + (IsRankColumn(order) ? " ASC" : " DESC")));
		using DbCommand command = connection.CreateCommand();
		command.CommandText = $"SELECT TOP (100) {projection} FROM dbo.{Quote(table.TableName)}{orderClause}";
		command.CommandTimeout = 5;
		using DbDataReader dataReader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		DataTable dataTable = new DataTable(table.DisplayName);
		dataTable.Load(dataReader);
		return dataTable;
	}

	private static string? FindOrderColumn(IEnumerable<string> columns)
	{
		string[] names = columns.ToArray();
		string[] array = new string[11]
		{
			"Rank", "Ranking", "Position", "TotalScore", "Score", "Points", "Point", "Kills", "KillCount", "Level",
			"ResetCount"
		};
		foreach (string candidate in array)
		{
			string found = names.FirstOrDefault((string x) => x.Equals(candidate, StringComparison.OrdinalIgnoreCase));
			if (found != null)
			{
				return found;
			}
		}
		return null;
	}

	private static bool IsRankColumn(string name)
	{
		if (!name.Equals("Rank", StringComparison.OrdinalIgnoreCase) && !name.Equals("Ranking", StringComparison.OrdinalIgnoreCase))
		{
			return name.Equals("Position", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	private static string Quote(string identifier)
	{
		return "[" + identifier.Replace("]", "]]", StringComparison.Ordinal) + "]";
	}
}
