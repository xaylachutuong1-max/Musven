namespace MuSven09M.Modules.Management;

public sealed record RankingResetPreview(string TableName, string DisplayName, long RowCount);
