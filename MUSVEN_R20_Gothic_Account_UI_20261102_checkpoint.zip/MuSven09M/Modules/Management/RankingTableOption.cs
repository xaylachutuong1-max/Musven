namespace MuSven09M.Modules.Management;

public sealed record RankingTableOption(string TableName, string DisplayName)
{
	public override string ToString()
	{
		return DisplayName;
	}
}
