using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Management;

public sealed class SchemaAuditForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly DataGridView grid = new DataGridView
	{
		Dock = DockStyle.Fill,
		ReadOnly = true,
		AllowUserToAddRows = false,
		AllowUserToDeleteRows = false,
		AllowUserToResizeRows = false,
		MultiSelect = false,
		SelectionMode = DataGridViewSelectionMode.FullRowSelect,
		AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells,
		BackgroundColor = Surface,
		BorderStyle = BorderStyle.None,
		RowHeadersVisible = false
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button copyButton;

	private SchemaAuditReport? report;

	public SchemaAuditForm(SqlAccountLookupOptions options)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		Text = "MU SVEN • Kiểm tra schema";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(980, 600);
		base.Size = new Size(1280, 780);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 3,
			Padding = new Padding(12),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 78f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		base.Controls.Add(root);
		TableLayoutPanel header = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 2,
			BackColor = Surface,
			Padding = new Padding(12, 6, 12, 6),
			Margin = new Padding(2)
		};
		header.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
		header.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		header.Controls.Add(new Label
		{
			Text = "KIỂM KÊ SCHEMA MUSVEN",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 12f, FontStyle.Bold)
		}, 0, 0);
		header.Controls.Add(new Label
		{
			Text = "Chỉ đọc metadata trong dbo/sys; không đọc dữ liệu tài khoản, nhân vật, không chạy DDL hay sửa database.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.MiddleLeft,
			AutoEllipsis = true
		}, 0, 1);
		header.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border, 1.2f);
			e.Graphics.DrawRectangle(pen, 1, 1, Math.Max(1, header.Width - 3), Math.Max(1, header.Height - 3));
		};
		root.Controls.Add(header, 0, 0);
		grid.EnableHeadersVisualStyles = false;
		grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(16, 43, 70);
		grid.ColumnHeadersDefaultCellStyle.ForeColor = Gold;
		grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9f, FontStyle.Bold);
		grid.DefaultCellStyle.BackColor = Color.FromArgb(12, 25, 43);
		grid.DefaultCellStyle.ForeColor = Color.Gainsboro;
		grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(25, 78, 119);
		grid.DefaultCellStyle.SelectionForeColor = Color.White;
		grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(15, 31, 51);
		grid.CellFormatting += delegate(object? _, DataGridViewCellFormattingEventArgs e)
		{
			if (!(grid.Columns[e.ColumnIndex].DataPropertyName != "Status") && e.Value is string text)
			{
				e.CellStyle.ForeColor = ((text == "OK") ? Color.FromArgb(103, 240, 170) : (text.StartsWith("TÙY CHỌN", StringComparison.Ordinal) ? Gold : Color.FromArgb(255, 128, 128)));
				e.CellStyle.Font = new Font(grid.Font, FontStyle.Bold);
			}
		};
		Panel frame = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			Padding = new Padding(6),
			Margin = new Padding(2)
		};
		frame.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border, 1.2f);
			e.Graphics.DrawRectangle(pen, 1, 1, Math.Max(1, frame.Width - 3), Math.Max(1, frame.Height - 3));
		};
		frame.Controls.Add(grid);
		root.Controls.Add(frame, 0, 1);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = Padding.Empty
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120f));
		footer.Controls.Add(status, 0, 0);
		copyButton = MakeButton("SAO CHÉP BÁO CÁO", emphasized: true);
		copyButton.Enabled = false;
		copyButton.Click += delegate
		{
			CopyReport();
		};
		footer.Controls.Add(copyButton, 1, 0);
		Button close = MakeButton("ĐÓNG", emphasized: false);
		close.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(close, 2, 0);
		root.Controls.Add(footer, 0, 2);
		base.Shown += async delegate
		{
			UiTheme.Apply(this);
			await LoadAsync();
		};
	}

	private async Task LoadAsync()
	{
		status.Text = "ĐANG KIỂM TRA • chỉ đọc metadata...";
		copyButton.Enabled = false;
		try
		{
			string connectionString = options.CreateConnectionString();
			report = await Task.Run(() => new SqlSchemaAuditRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).Read());
			grid.DataSource = report.Rows;
			status.Text = $"{report.Server} • {report.Database} • SQL {report.ProductVersion} • lỗi schema bắt buộc: {report.RequiredIssueCount} • tùy chọn thiếu: {report.OptionalMissingCount}";
			copyButton.Enabled = true;
		}
		catch (Exception ex)
		{
			grid.DataSource = null;
			status.Text = "KHÔNG ĐỌC ĐƯỢC METADATA • kiểm tra kết nối, quyền xem schema và Config.ini.";
			MessageBox.Show(this, ex.Message, "MU SVEN • Schema", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}
	}

	private void CopyReport()
	{
		if ((object)report == null)
		{
			return;
		}
		try
		{
			Clipboard.SetText(report.ToClipboardText());
			status.Text += " • ĐÃ SAO CHÉP";
		}
		catch (Exception ex)
		{
			MessageBox.Show(this, ex.Message, "MU SVEN • Sao chép", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}
	}

	private static Button MakeButton(string text, bool emphasized)
	{
		Button button = new Button();
		button.Text = text;
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (emphasized ? Gold : Color.FromArgb(18, 51, 82));
		button.ForeColor = (emphasized ? Color.Black : Color.White);
		button.Margin = new Padding(4);
		button.Cursor = Cursors.Hand;
		button.FlatAppearance.BorderColor = (emphasized ? Gold : Border);
		return button;
	}
}
