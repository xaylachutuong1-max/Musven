using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MuSven09M.Modules.Management;

public sealed record SchemaAuditReport(string Server, string Database, string ProductVersion, IReadOnlyList<SchemaAuditRow> Rows)
{
	public int RequiredIssueCount => Rows.Count((SchemaAuditRow row) => row.Required && row.Status != "OK");

	public int OptionalMissingCount => Rows.Count((SchemaAuditRow row) => !row.Required && row.Status.StartsWith("TÙY CHỌN", StringComparison.Ordinal));

	public string ToClipboardText()
	{
		StringBuilder text = new StringBuilder();
		StringBuilder stringBuilder = text;
		StringBuilder stringBuilder2 = stringBuilder;
		StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(29, 3, stringBuilder);
		handler.AppendLiteral("Server\t");
		handler.AppendFormatted(Server);
		handler.AppendLiteral("\tDatabase\t");
		handler.AppendFormatted(Database);
		handler.AppendLiteral("\tSQL Server\t");
		handler.AppendFormatted(ProductVersion);
		stringBuilder2.AppendLine(ref handler);
		text.AppendLine("Chức năng\tĐối tượng\tThành phần\tYêu cầu\tThực tế\tTrạng thái");
		foreach (SchemaAuditRow row in Rows)
		{
			stringBuilder = text;
			StringBuilder stringBuilder3 = stringBuilder;
			handler = new StringBuilder.AppendInterpolatedStringHandler(5, 6, stringBuilder);
			handler.AppendFormatted(row.Feature);
			handler.AppendLiteral("\t");
			handler.AppendFormatted(row.ObjectName);
			handler.AppendLiteral("\t");
			handler.AppendFormatted(row.Element);
			handler.AppendLiteral("\t");
			handler.AppendFormatted(row.Expected);
			handler.AppendLiteral("\t");
			handler.AppendFormatted(row.Actual);
			handler.AppendLiteral("\t");
			handler.AppendFormatted(row.Status);
			stringBuilder3.AppendLine(ref handler);
		}
		return text.ToString();
	}
}
