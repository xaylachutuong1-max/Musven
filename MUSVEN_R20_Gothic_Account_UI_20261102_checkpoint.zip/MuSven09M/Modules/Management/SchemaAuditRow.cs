namespace MuSven09M.Modules.Management;

public sealed record SchemaAuditRow(string Feature, string ObjectName, string Element, string Expected, string Actual, string Status, bool Required);
