using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Management;

public sealed class SqlBackupForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions connectionOptions;

	private readonly SqlBackupOptions backupOptions;

	private readonly TextBox directory = new TextBox
	{
		Dock = DockStyle.Fill,
		BackColor = Color.FromArgb(18, 37, 58),
		ForeColor = Color.White,
		BorderStyle = BorderStyle.FixedSingle,
		Margin = new Padding(4)
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button backupButton;

	public SqlBackupForm(SqlAccountLookupOptions connectionOptions, SqlBackupOptions backupOptions)
	{
		this.connectionOptions = connectionOptions ?? throw new ArgumentNullException("connectionOptions");
		this.backupOptions = backupOptions ?? throw new ArgumentNullException("backupOptions");
		Text = "MU SVEN • Sao lưu SQL";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(760, 460);
		base.Size = new Size(900, 520);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 4,
			Padding = new Padding(18),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 104f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = "SAO LƯU DATABASE HIỆN TẠI",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 14f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		Panel pathGroup = MakePanel("ĐƯỜNG DẪN TRÊN MÁY SQL SERVER");
		TableLayoutPanel pathLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 2,
			Padding = new Padding(10, 6, 10, 8)
		};
		pathLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 35f));
		pathLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		pathLayout.Controls.Add(new Label
		{
			Text = "Nhập thư mục tuyệt đối mà dịch vụ SQL Server có quyền ghi. Đây là đường dẫn bên VM nếu SQL chạy trong VM.",
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			TextAlign = ContentAlignment.MiddleLeft,
			AutoEllipsis = true
		}, 0, 0);
		directory.Text = backupOptions.ServerDirectory;
		directory.PlaceholderText = "Ví dụ: D:\\MuServer\\SQLBackups";
		pathLayout.Controls.Add(directory, 0, 1);
		pathGroup.Controls.Add(pathLayout);
		root.Controls.Add(pathGroup, 0, 1);
		Label warning = new Label
		{
			Text = "Backup dùng COPY_ONLY và CHECKSUM, sau đó chạy RESTORE VERIFYONLY. Tệp được tạo mới theo dấu thời gian, không ghi đè tệp cũ. SQL Server cần quyền backup database và quyền ghi thư mục. Tác vụ tự động vẫn chưa bật.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.MiddleLeft,
			Padding = new Padding(8)
		};
		root.Controls.Add(warning, 0, 2);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = Padding.Empty
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130f));
		footer.Controls.Add(status, 0, 0);
		backupButton = MakeButton("TẠO + KIỂM TRA BACKUP", emphasized: true);
		backupButton.Enabled = backupOptions.Enabled;
		backupButton.Click += async delegate
		{
			await RunBackupAsync();
		};
		footer.Controls.Add(backupButton, 1, 0);
		Button close = MakeButton("ĐÓNG", emphasized: false);
		close.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(close, 2, 0);
		root.Controls.Add(footer, 0, 3);
		status.Text = (backupOptions.Enabled ? "Backup đã được mở trong Config.ini; thao tác tạo file chỉ chạy khi bấm nút." : "CHƯA BẬT • mở [MUSVEN_SQL_BACKUP] Enabled=1 trong Config.ini sau khi cấu hình đường dẫn server.");
		UiTheme.Apply(this);
	}

	private async Task RunBackupAsync()
	{
		if (!backupOptions.Enabled)
		{
			return;
		}
		string serverDirectory = directory.Text.Trim();
		if (serverDirectory.Length == 0)
		{
			status.Text = "Nhập thư mục đích trên máy chạy SQL Server.";
			directory.Focus();
		}
		else
		{
			if (MessageBox.Show(this, "Tạo bản sao lưu mới của " + connectionOptions.Database + " trong thư mục cấu hình trên máy SQL Server?\n\nĐường dẫn: " + serverDirectory, "MU SVEN • Xác nhận sao lưu", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk) != DialogResult.Yes)
			{
				return;
			}
			backupButton.Enabled = false;
			directory.Enabled = false;
			status.Text = "ĐANG SAO LƯU • SQL Server có thể mất vài phút...";
			try
			{
				string connectionString = connectionOptions.CreateConnectionString(readOnly: false);
				SqlDatabaseBackupResult result = await Task.Run(() => new SqlDatabaseBackupService(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).CreateAndVerify(serverDirectory));
				status.Text = "ĐÃ SAO LƯU VÀ KIỂM TRA • " + result.DatabaseName + " • " + result.BackupPath;
				MessageBox.Show(this, "Backup được tạo và kiểm tra thành công:\n" + result.BackupPath, "MU SVEN • Backup hoàn tất", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			catch
			{
				status.Text = "SAO LƯU THẤT BẠI • kiểm tra quyền SQL và đường dẫn trên máy SQL Server.";
				MessageBox.Show(this, "Không tạo/kiểm tra được backup. Kiểm tra quyền BACKUP DATABASE, đường dẫn trên máy chạy SQL Server và quyền ghi của dịch vụ SQL.", "MU SVEN • Backup thất bại", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			finally
			{
				directory.Enabled = true;
				backupButton.Enabled = backupOptions.Enabled;
			}
		}
	}

	private static Panel MakePanel(string title)
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			Margin = new Padding(3),
			Padding = new Padding(10, 34, 10, 8)
		};
		panel.Controls.Add(new Label
		{
			Text = title,
			Location = new Point(10, 5),
			Size = new Size(500, 25),
			ForeColor = Gold,
			Font = new Font("Segoe UI", 9f, FontStyle.Bold),
			AutoEllipsis = true
		});
		panel.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border, 1.2f);
			e.Graphics.DrawRectangle(pen, 1, 1, Math.Max(1, panel.Width - 3), Math.Max(1, panel.Height - 3));
		};
		return panel;
	}

	private static Button MakeButton(string text, bool emphasized)
	{
		Button button = new Button();
		button.Text = text;
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (emphasized ? Gold : Color.FromArgb(18, 51, 82));
		button.ForeColor = (emphasized ? Color.Black : Color.White);
		button.Margin = new Padding(4);
		button.Cursor = Cursors.Hand;
		button.FlatAppearance.BorderColor = (emphasized ? Gold : Border);
		return button;
	}
}
