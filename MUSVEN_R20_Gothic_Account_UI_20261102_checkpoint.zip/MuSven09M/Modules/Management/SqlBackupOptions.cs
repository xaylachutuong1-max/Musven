using System;
using System.Collections.Generic;
using System.IO;

namespace MuSven09M.Modules.Management;

public sealed record SqlBackupOptions(bool Enabled, string ServerDirectory)
{
	public static SqlBackupOptions Load(string configPath)
	{
		if (!File.Exists(configPath))
		{
			return new SqlBackupOptions(Enabled: false, string.Empty);
		}
		Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		bool inSection = false;
		foreach (string item in File.ReadLines(configPath))
		{
			string line = item.Trim();
			if (line.Length == 0 || line.StartsWith(';') || line.StartsWith('#'))
			{
				continue;
			}
			if (line.StartsWith('[') && line.EndsWith(']'))
			{
				string text = line;
				inSection = text.Substring(1, text.Length - 1 - 1).Trim().Equals("MUSVEN_SQL_BACKUP", StringComparison.OrdinalIgnoreCase);
			}
			else if (inSection)
			{
				int separator = line.IndexOf('=');
				if (separator > 0)
				{
					string key = line.Substring(0, separator).Trim();
					string text = line;
					int num = separator + 1;
					values[key] = text.Substring(num, text.Length - num).Trim();
				}
			}
		}
		string value;
		bool enabled = values.TryGetValue("Enabled", out value) && (value.Equals("1", StringComparison.OrdinalIgnoreCase) || value.Equals("true", StringComparison.OrdinalIgnoreCase));
		string path;
		string directory = (values.TryGetValue("ServerPath", out path) ? path : string.Empty);
		if (directory.Equals("CHANGE_ME", StringComparison.OrdinalIgnoreCase))
		{
			directory = string.Empty;
		}
		return new SqlBackupOptions(enabled, directory);
	}
}
