using System;

namespace MuSven09M.Modules.Management;

public sealed class SqlDataResetException : Exception
{
	public bool DataCommitted { get; }

	public bool MultiUserRestored { get; }

	public SqlDataResetException(string message, bool dataCommitted, bool multiUserRestored, Exception innerException)
		: base(message, innerException)
	{
		DataCommitted = dataCommitted;
		MultiUserRestored = multiUserRestored;
	}
}
