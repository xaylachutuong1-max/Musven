using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Management;

public sealed class SqlDataResetForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private static readonly string ConfirmationPhrase = "XOA TRANG Muonline";

	private readonly SqlAccountLookupOptions connectionOptions;

	private readonly SqlDataResetOptions resetOptions;

	private readonly DataGridView tableGrid = new DataGridView
	{
		Dock = DockStyle.Fill,
		ReadOnly = true,
		AllowUserToAddRows = false,
		AllowUserToDeleteRows = false,
		RowHeadersVisible = false,
		AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
		BackgroundColor = Surface,
		BorderStyle = BorderStyle.FixedSingle,
		GridColor = Border,
		ForeColor = Color.White,
		EnableHeadersVisualStyles = false,
		SelectionMode = DataGridViewSelectionMode.FullRowSelect
	};

	private readonly TextBox confirmation = new TextBox
	{
		Dock = DockStyle.Fill,
		BackColor = Color.FromArgb(18, 37, 58),
		ForeColor = Color.White,
		BorderStyle = BorderStyle.FixedSingle,
		PlaceholderText = ConfirmationPhrase,
		Margin = new Padding(4)
	};

	private readonly Label summary = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button previewButton;

	private readonly Button resetButton;

	private readonly Button configButton;

	private readonly SqlDataResetService resetService;

	private readonly string configPath;

	private SqlDataResetPreview? preview;

	private bool busy;

	public SqlDataResetForm(SqlAccountLookupOptions connectionOptions, SqlDataResetOptions resetOptions, string configPath)
	{
		this.connectionOptions = connectionOptions ?? throw new ArgumentNullException("connectionOptions");
		this.resetOptions = resetOptions ?? throw new ArgumentNullException("resetOptions");
		this.configPath = configPath ?? throw new ArgumentNullException("configPath");
		resetService = new SqlDataResetService(connectionOptions);
		Text = "MU SVEN • Xóa trắng dữ liệu server";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(820, 620);
		base.Size = new Size(980, 720);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		tableGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(18, 51, 82);
		tableGrid.ColumnHeadersDefaultCellStyle.ForeColor = Gold;
		tableGrid.DefaultCellStyle.BackColor = Surface;
		tableGrid.DefaultCellStyle.ForeColor = Color.White;
		tableGrid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(20, 74, 108);
		tableGrid.DefaultCellStyle.SelectionForeColor = Color.White;
		tableGrid.Columns.Add(new DataGridViewTextBoxColumn
		{
			HeaderText = "Bảng dữ liệu sẽ xóa",
			DataPropertyName = "Name",
			FillWeight = 70f
		});
		tableGrid.Columns.Add(new DataGridViewTextBoxColumn
		{
			HeaderText = "Số dòng hiện tại",
			DataPropertyName = "Rows",
			FillWeight = 30f
		});
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 6,
			Padding = new Padding(16),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 76f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 80f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 52f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 60f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		base.Controls.Add(root);
		Panel warning = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(62, 22, 23),
			Padding = new Padding(12),
			Margin = new Padding(3)
		};
		warning.Controls.Add(new Label
		{
			Text = "CẢNH BÁO • XÓA KHÔNG THỂ HOÀN TÁC. Tác vụ xóa tài khoản, nhân vật, kho, tiền, guild, sự kiện và toàn bộ bảng ranking. Bảy bảng cấu hình máy chủ/lớp nhân vật cùng mặc định tạo nhân vật được giữ lại. Musven chỉ chạy sau khi đã tạo và kiểm tra backup.",
			Dock = DockStyle.Fill,
			ForeColor = Color.FromArgb(255, 204, 204),
			Font = new Font("Segoe UI", 10f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		});
		warning.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Color.FromArgb(196, 65, 65), 1.5f);
			e.Graphics.DrawRectangle(pen, 1, 1, warning.Width - 3, warning.Height - 3);
		};
		root.Controls.Add(warning, 0, 0);
		Panel preparation = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			Padding = new Padding(12),
			Margin = new Padding(3)
		};
		Label preparationText = new Label
		{
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.MiddleLeft,
			Text = "Trước khi tiếp tục: dừng các dịch vụ game để không có kết nối SQL nào khác tới Muonline. Musven yêu cầu schema 09Q đã rà sau migration mặc định nhân vật (63 bảng, 76 procedure), một database online/multi-user, đúng máy SQL ghim trong Config.ini, và thư mục backup trên ổ D:/E: hoặc đúng thư mục chuyên dụng C:\\MUSVEN_TITAN_BACKUP của máy SQL Server."
		};
		preparation.Controls.Add(preparationText);
		preparation.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border, 1.1f);
			e.Graphics.DrawRectangle(pen, 1, 1, preparation.Width - 3, preparation.Height - 3);
		};
		root.Controls.Add(preparation, 0, 1);
		summary.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
		root.Controls.Add(summary, 0, 2);
		root.Controls.Add(tableGrid, 0, 3);
		TableLayoutPanel confirmationRow = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = Padding.Empty
		};
		confirmationRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58f));
		confirmationRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42f));
		confirmationRow.Controls.Add(new Label
		{
			Text = "Gõ chính xác “" + ConfirmationPhrase + "” để mở nút xóa:",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		confirmation.TextChanged += delegate
		{
			UpdateResetButton();
		};
		confirmationRow.Controls.Add(confirmation, 1, 0);
		root.Controls.Add(confirmationRow, 0, 4);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 5,
			RowCount = 1,
			Margin = Padding.Empty
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 122f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 126f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90f));
		footer.Controls.Add(status, 0, 0);
		previewButton = MakeButton("XEM TRƯỚC", emphasized: true);
		previewButton.Enabled = connectionOptions.Database.Equals("Muonline", StringComparison.OrdinalIgnoreCase);
		previewButton.Click += async delegate
		{
			await PreviewAsync();
		};
		footer.Controls.Add(previewButton, 1, 0);
		configButton = MakeButton("MỞ CONFIG", emphasized: false);
		configButton.Click += delegate
		{
			OpenConfig();
		};
		footer.Controls.Add(configButton, 2, 0);
		resetButton = MakeButton("XÓA TRẮNG", emphasized: true);
		resetButton.BackColor = Color.FromArgb(175, 48, 43);
		resetButton.FlatAppearance.BorderColor = Color.FromArgb(220, 75, 70);
		resetButton.Enabled = false;
		resetButton.Click += async delegate
		{
			await ResetAsync();
		};
		footer.Controls.Add(resetButton, 3, 0);
		Button close = MakeButton("ĐÓNG", emphasized: false);
		close.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(close, 4, 0);
		root.Controls.Add(footer, 0, 5);
		summary.Text = "Mục tiêu: Muonline • chưa xem trước.";
		status.Text = ConfigurationStatus();
		UpdateResetButton();
		UiTheme.Apply(this);
	}

	private string ConfigurationStatus()
	{
		if (!connectionOptions.Database.Equals("Muonline", StringComparison.OrdinalIgnoreCase))
		{
			return "BỊ KHÓA • Config.ini phải trỏ tới Muonline.";
		}
		if (!resetOptions.Enabled)
		{
			return "BỊ KHÓA • [MUSVEN_DATA_RESET] Enabled=0. Xem trước chỉ đọc vẫn dùng được.";
		}
		if (string.IsNullOrWhiteSpace(resetOptions.ExpectedServer))
		{
			return "BỊ KHÓA • thiếu ExpectedServer trong [MUSVEN_DATA_RESET].";
		}
		if (string.IsNullOrWhiteSpace(resetOptions.BackupDirectory) || !IsAllowedBackupDrive(resetOptions.BackupDirectory))
		{
			return "BỊ KHÓA • đặt BackupPath trên ổ D:/E: hoặc C:\\MUSVEN_TITAN_BACKUP của máy SQL Server.";
		}
		return "Sẵn sàng kiểm tra. Backup bắt buộc tạo trước khi reset.";
	}

	private async Task PreviewAsync()
	{
		if (busy || !connectionOptions.Database.Equals("Muonline", StringComparison.OrdinalIgnoreCase))
		{
			return;
		}
		SetBusy(value: true);
		status.ForeColor = Ice;
		status.Text = "ĐANG KIỂM TRA • chỉ đọc metadata và số dòng, chưa đổi dữ liệu...";
		try
		{
			SqlDataResetPreview result = (preview = await Task.Run(() => resetService.Preview(resetOptions.ExpectedServer)));
			tableGrid.DataSource = result.Tables.ToList();
			summary.Text = $"{result.Server} • Muonline • SQL {result.ProductVersion} • bảng {result.UserTableCount} • xóa {result.ResetTableCount} bảng / {result.TotalRows:N0} dòng • tài khoản {result.AccountRows:N0} • nhân vật {result.CharacterRows:N0} • guild {result.GuildRows:N0} • ranking {result.RankingRows:N0}";
			if (result.CanExecute)
			{
				status.ForeColor = Color.LightGreen;
				status.Text = "ĐỦ ĐIỀU KIỆN XEM TRƯỚC • kiểm tra lại danh sách rồi gõ câu xác nhận.";
			}
			else
			{
				status.ForeColor = Color.FromArgb(255, 151, 151);
				status.Text = "ĐANG BỊ CHẶN • " + string.Join(" | ", result.Blockers.Take(3));
			}
		}
		catch (Exception ex)
		{
			preview = null;
			tableGrid.DataSource = null;
			summary.Text = "Không có bản xem trước hợp lệ.";
			status.ForeColor = Color.FromArgb(255, 151, 151);
			status.Text = "KIỂM TRA THẤT BẠI • " + ex.Message;
		}
		finally
		{
			SetBusy(value: false);
			UpdateResetButton();
		}
	}

	private async Task ResetAsync()
	{
		if (busy || (object)preview == null || !preview.CanExecute || !resetOptions.Enabled || confirmation.Text != ConfirmationPhrase)
		{
			return;
		}
		string message = $"XÓA TRẮNG {preview.Database} trên {preview.Server}?\n\nMusven sẽ backup + VERIFYONLY ở:\n{resetOptions.BackupDirectory}\n\nSau đó xóa {preview.ResetTableCount} bảng, khoảng {preview.TotalRows:N0} dòng; gồm {preview.AccountRows:N0} tài khoản, {preview.CharacterRows:N0} nhân vật, {preview.GuildRows:N0} guild và {preview.RankingRows:N0} dòng ranking.\n\nBảy bảng cấu hình được giữ lại. Game server phải dừng. Hành động không thể hoàn tác nếu không restore backup.\n\nBạn xác nhận bắt đầu?";
		if (MessageBox.Show(this, message, "MU SVEN • Xác nhận xóa dữ liệu", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
		{
			return;
		}
		SetBusy(value: true);
		status.ForeColor = Gold;
		status.Text = "ĐANG BACKUP VÀ XÓA • không đóng Musven cho tới khi có kết quả...";
		try
		{
			SqlDataResetResult result = await Task.Run(() => resetService.Reset(preview, resetOptions.ExpectedServer, resetOptions.BackupDirectory));
			status.ForeColor = Color.LightGreen;
			status.Text = $"HOÀN TẤT • {result.ClearedTables} bảng / {result.DeletedRows:N0} dòng • backup: {result.BackupPath}";
			confirmation.Clear();
			MessageBox.Show(this, "Đã xóa trắng dữ liệu người chơi và xác minh các bảng cấu hình được giữ lại.\n\nBackup đã kiểm tra:\n" + result.BackupPath + "\n\nDatabase đã trở lại MULTI_USER.", "MU SVEN • Reset hoàn tất", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			preview = await Task.Run(() => resetService.Preview(resetOptions.ExpectedServer));
			tableGrid.DataSource = preview.Tables.ToList();
			summary.Text = $"{preview.Server} • Muonline • sau reset: {preview.TotalRows:N0} dòng trong các bảng dữ liệu • tài khoản {preview.AccountRows:N0} • nhân vật {preview.CharacterRows:N0} • guild {preview.GuildRows:N0} • ranking {preview.RankingRows:N0}";
		}
		catch (SqlDataResetException ex)
		{
			status.ForeColor = Color.FromArgb(255, 151, 151);
			status.Text = ex.Message;
			MessageBox.Show(this, ex.Message, ex.DataCommitted ? "MU SVEN • Kiểm tra trạng thái reset" : "MU SVEN • Reset đã dừng", MessageBoxButtons.OK, (ex.DataCommitted || !ex.MultiUserRestored) ? MessageBoxIcon.Hand : MessageBoxIcon.Exclamation);
			preview = null;
		}
		catch (Exception ex2)
		{
			status.ForeColor = Color.FromArgb(255, 151, 151);
			status.Text = "RESET DỪNG • " + ex2.Message;
			MessageBox.Show(this, ex2.Message, "MU SVEN • Reset đã dừng", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			preview = null;
		}
		finally
		{
			SetBusy(value: false);
			UpdateResetButton();
		}
	}

	private void SetBusy(bool value)
	{
		busy = value;
		previewButton.Enabled = !value && connectionOptions.Database.Equals("Muonline", StringComparison.OrdinalIgnoreCase);
		configButton.Enabled = !value;
		confirmation.Enabled = !value;
		UpdateResetButton();
	}

	private void UpdateResetButton()
	{
		int num;
		if (!busy)
		{
			SqlDataResetPreview sqlDataResetPreview = preview;
			if ((object)sqlDataResetPreview != null && sqlDataResetPreview.CanExecute && resetOptions.Enabled && connectionOptions.Database.Equals("Muonline", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(resetOptions.ExpectedServer) && IsAllowedBackupDrive(resetOptions.BackupDirectory))
			{
				num = (confirmation.Text.Equals(ConfirmationPhrase, StringComparison.Ordinal) ? 1 : 0);
				goto IL_007c;
			}
		}
		num = 0;
		goto IL_007c;
		IL_007c:
		bool ready = (byte)num != 0;
		resetButton.Enabled = ready;
	}

	private void OpenConfig()
	{
		try
		{
			if (!File.Exists(configPath))
			{
				MessageBox.Show(this, "Chưa có Config.ini. Mở ứng dụng một lần để tạo file mẫu, sau đó cấu hình riêng [MUSVEN_DATA_RESET].", "MU SVEN • Config", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				return;
			}
			Process.Start(new ProcessStartInfo("notepad.exe", "\"" + configPath + "\"")
			{
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			MessageBox.Show(this, "Không mở được Config.ini: " + ex.Message, "MU SVEN • Config", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}
	}

	private static bool IsAllowedBackupDrive(string directory)
	{
		if (string.IsNullOrWhiteSpace(directory) || !Path.IsPathRooted(directory))
		{
			return false;
		}
		try
		{
			string fullPath = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
			string root = Path.GetPathRoot(fullPath) ?? string.Empty;
			return (root.Equals("D:" + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || root.Equals("E:" + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || fullPath.Equals("C:\\MUSVEN_TITAN_BACKUP", StringComparison.OrdinalIgnoreCase)) && Directory.Exists(fullPath);
		}
		catch
		{
			return false;
		}
	}

	private static Button MakeButton(string text, bool emphasized)
	{
		Button button = new Button();
		button.Text = text;
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (emphasized ? Gold : Color.FromArgb(18, 51, 82));
		button.ForeColor = (emphasized ? Color.Black : Color.White);
		button.Margin = new Padding(4);
		button.Cursor = Cursors.Hand;
		button.FlatAppearance.BorderColor = (emphasized ? Gold : Border);
		return button;
	}
}
