using System;
using System.Collections.Generic;
using System.IO;

namespace MuSven09M.Modules.Management;

public sealed record SqlDataResetOptions(bool Enabled, string ExpectedServer, string BackupDirectory)
{
	public static SqlDataResetOptions Load(string configPath)
	{
		if (!File.Exists(configPath))
		{
			return new SqlDataResetOptions(Enabled: false, string.Empty, string.Empty);
		}
		Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		bool inSection = false;
		foreach (string item in File.ReadLines(configPath))
		{
			string line = item.Trim();
			if (line.Length == 0 || line.StartsWith(';') || line.StartsWith('#'))
			{
				continue;
			}
			if (line.StartsWith('[') && line.EndsWith(']'))
			{
				string text = line;
				inSection = text.Substring(1, text.Length - 1 - 1).Trim().Equals("MUSVEN_DATA_RESET", StringComparison.OrdinalIgnoreCase);
			}
			else if (inSection)
			{
				int separator = line.IndexOf('=');
				if (separator > 0)
				{
					string key = line.Substring(0, separator).Trim();
					string text = line;
					int num = separator + 1;
					values[key] = text.Substring(num, text.Length - num).Trim();
				}
			}
		}
		string value;
		bool enabled = values.TryGetValue("Enabled", out value) && (value.Equals("1", StringComparison.OrdinalIgnoreCase) || value.Equals("true", StringComparison.OrdinalIgnoreCase));
		string expected;
		string server = (values.TryGetValue("ExpectedServer", out expected) ? expected : string.Empty);
		string path;
		string backup = (values.TryGetValue("BackupPath", out path) ? path : string.Empty);
		if (server.Equals("CHANGE_ME", StringComparison.OrdinalIgnoreCase))
		{
			server = string.Empty;
		}
		if (backup.Equals("CHANGE_ME", StringComparison.OrdinalIgnoreCase))
		{
			backup = string.Empty;
		}
		return new SqlDataResetOptions(enabled, server, backup);
	}
}
