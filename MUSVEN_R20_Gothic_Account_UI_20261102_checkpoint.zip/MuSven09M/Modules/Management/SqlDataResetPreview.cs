using System.Collections.Generic;

namespace MuSven09M.Modules.Management;

public sealed record SqlDataResetPreview(string Server, string Database, string ProductVersion, string UserAccess, int UserTableCount, int ResetTableCount, long TotalRows, long AccountRows, long CharacterRows, long GuildRows, long RankingRows, IReadOnlyList<SqlResetTablePreview> Tables, IReadOnlyDictionary<string, long> PreservedTableRows, IReadOnlyList<string> AllTableNames, IReadOnlyList<string> Blockers)
{
	public bool CanExecute => Blockers.Count == 0;
}
