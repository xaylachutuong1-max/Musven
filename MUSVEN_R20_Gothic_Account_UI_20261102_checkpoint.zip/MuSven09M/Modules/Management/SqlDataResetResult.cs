namespace MuSven09M.Modules.Management;

public sealed record SqlDataResetResult(string Server, string Database, string BackupPath, int ClearedTables, long DeletedRows, bool MultiUserRestored);
