using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Management;

public sealed class SqlDataResetService
{
	private sealed record TableInfo(int ObjectId, string Schema, string Name);

	private sealed record ForeignKeyInfo(string Name, int ChildObjectId, int ParentObjectId, bool Disabled, bool NotTrusted);

	private const string TargetDatabase = "Muonline";

	private const int ExpectedTableCount = 63;

	private const int ExpectedProcedureCount = 76;

	private const int ExpectedResetTableCount = 56;

	private const string ExpectedProductVersionPrefix = "10.50.";

	private static readonly string[] PreservedTables = new string[7] { "DefaultClassType", "GameServerInfo", "MK_Server", "MuCastle_DATA", "MuCastle_NPC", "WZ_CW_INFO", "MUSVEN_CharacterCreateDefaults" };

	private static readonly string[] ExpectedForeignKeys = new string[2] { "FK_CustomNpcQuest_Character", "FK_CustomQuest_Character" };

	private readonly SqlConnectionStringBuilder connectionBuilder;

	private readonly string configuredDatabase;

	public SqlDataResetService(SqlAccountLookupOptions connectionOptions)
	{
		ArgumentNullException.ThrowIfNull(connectionOptions, "connectionOptions");
		configuredDatabase = connectionOptions.Database;
		connectionBuilder = new SqlConnectionStringBuilder(connectionOptions.CreateConnectionString(readOnly: false))
		{
			InitialCatalog = "master",
			ApplicationName = "MU SVEN 09Q data reset"
		};
	}

	public SqlDataResetPreview Preview(string expectedServer)
	{
		if (!configuredDatabase.Equals("Muonline", StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("Config.ini phải trỏ đúng database Muonline trước khi xem trước reset.");
		}
		using SqlConnection connection = OpenConnection();
		return Inspect(connection, expectedServer, "MULTI_USER");
	}

	public SqlDataResetResult Reset(SqlDataResetPreview confirmedPreview, string expectedServer, string backupDirectory)
	{
		ArgumentNullException.ThrowIfNull(confirmedPreview, "confirmedPreview");
		if (string.IsNullOrWhiteSpace(expectedServer))
		{
			throw new InvalidOperationException("Chưa cấu hình máy SQL được phép xóa trắng.");
		}
		if (!string.Equals(confirmedPreview.Server, expectedServer.Trim(), StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("Máy SQL trong bản xem trước không khớp máy SQL được ghim trong Config.ini.");
		}
		if (!string.Equals(confirmedPreview.Database, "Muonline", StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("Chỉ cho phép xóa dữ liệu database Muonline.");
		}
		if (!confirmedPreview.CanExecute)
		{
			throw new InvalidOperationException("Bản xem trước còn điều kiện chặn; Musven không thể xóa.");
		}
		if (!configuredDatabase.Equals("Muonline", StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("Config.ini phải trỏ đúng database Muonline trước khi reset.");
		}
		if (string.IsNullOrWhiteSpace(backupDirectory) || !IsAllowedBackupDrive(backupDirectory))
		{
			throw new InvalidOperationException("Cần cấu hình thư mục backup có sẵn trên ổ D:/E: hoặc đúng thư mục C:\\MUSVEN_TITAN_BACKUP của máy chạy dịch vụ SQL Server.");
		}
		using SqlConnection connection = OpenConnection();
		bool singleUserAttempted = false;
		bool committed = false;
		bool multiUserRestored = false;
		SqlTransaction transaction = null;
		try
		{
			SqlDataResetPreview current = Inspect(connection, expectedServer, "MULTI_USER");
			EnsureExecutable(current);
			if (!SameSnapshot(confirmedPreview, current))
			{
				throw new InvalidOperationException("Dữ liệu hoặc schema đã thay đổi sau bước xem trước. Hãy tải lại xem trước và xác nhận lại.");
			}
			singleUserAttempted = true;
			Execute(connection, "ALTER DATABASE [Muonline] SET SINGLE_USER", 30);
			Execute(connection, "USE [Muonline]", 10);
			SqlDataResetPreview isolated = Inspect(connection, expectedServer, "SINGLE_USER");
			EnsureExecutable(isolated);
			if (!SameSnapshot(confirmedPreview, isolated))
			{
				throw new InvalidOperationException("Dữ liệu đã thay đổi trước khi khóa database. Không có bảng nào bị xóa; vui lòng xem trước lại.");
			}
			string backupPath = CreateAndVerifyBackup(connection, backupDirectory);
			List<TableInfo> tables = ReadTables(connection);
			List<ForeignKeyInfo> foreignKeys = ReadForeignKeys(connection);
			TableInfo[] resetTables = tables.Where((TableInfo tableInfo) => !PreservedTables.Contains<string>(tableInfo.Name, StringComparer.OrdinalIgnoreCase)).ToArray();
			List<TableInfo> list = BuildDeleteOrder((IReadOnlyCollection<TableInfo>)(object)resetTables, foreignKeys);
			transaction = connection.BeginTransaction(IsolationLevel.Serializable);
			long deletedRows = 0L;
			foreach (TableInfo table in list)
			{
				using SqlCommand command = connection.CreateCommand();
				command.Transaction = transaction;
				command.CommandTimeout = 0;
				command.CommandText = "DELETE FROM " + Quote(table.Schema) + "." + Quote(table.Name);
				deletedRows += command.ExecuteNonQuery();
			}
			using (SqlCommand castle = connection.CreateCommand())
			{
				castle.Transaction = transaction;
				castle.CommandTimeout = 30;
				castle.CommandText = "\r\nUPDATE dbo.MuCastle_DATA\r\nSET CASTLE_OCCUPY=0, OWNER_GUILD='', MONEY=0,\r\n    TAX_RATE_CHAOS=0, TAX_RATE_STORE=0, TAX_HUNT_ZONE=0\r\nWHERE MAP_SVR_GROUP=0";
				if (castle.ExecuteNonQuery() != 1)
				{
					throw new InvalidOperationException("Reset thành trì không cập nhật đúng một dòng; Musven sẽ rollback toàn bộ.");
				}
			}
			VerifyReset(connection, transaction, tables, (IReadOnlyCollection<TableInfo>)(object)resetTables, confirmedPreview.PreservedTableRows);
			transaction.Commit();
			committed = true;
			transaction.Dispose();
			transaction = null;
			Execute(connection, "USE [master]", 10);
			Execute(connection, "ALTER DATABASE [Muonline] SET MULTI_USER", 30);
			multiUserRestored = true;
			return new SqlDataResetResult(current.Server, "Muonline", backupPath, resetTables.Length, deletedRows, MultiUserRestored: true);
		}
		catch (Exception ex)
		{
			try
			{
				transaction?.Rollback();
			}
			catch
			{
			}
			try
			{
				transaction?.Dispose();
			}
			catch
			{
			}
			if (singleUserAttempted && !multiUserRestored)
			{
				try
				{
					Execute(connection, "USE [master]", 10);
					Execute(connection, "ALTER DATABASE [Muonline] SET MULTI_USER", 30);
					multiUserRestored = true;
				}
				catch
				{
				}
			}
			string obj4 = (committed ? "DỮ LIỆU ĐÃ ĐƯỢC COMMIT. " : "GIAO DỊCH ĐÃ ROLLBACK; không commit dữ liệu xóa. ");
			string accessState = (multiUserRestored ? "Database đã trở lại MULTI_USER." : (singleUserAttempted ? "CẢNH BÁO: cần vào SQL Server kiểm tra và khôi phục Muonline về MULTI_USER ngay." : "Database chưa bị chuyển sang SINGLE_USER."));
			throw new SqlDataResetException(obj4 + accessState + " Chi tiết: " + ex.Message, committed, multiUserRestored, ex);
		}
		finally
		{
			if (transaction != null)
			{
				try
				{
					transaction.Dispose();
				}
				catch
				{
				}
			}
		}
	}

	private static bool IsAllowedBackupDrive(string directory)
	{
		if (string.IsNullOrWhiteSpace(directory) || !Path.IsPathRooted(directory))
		{
			return false;
		}
		try
		{
			string fullPath = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
			string root = Path.GetPathRoot(fullPath) ?? string.Empty;
			return (root.Equals("D:" + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || root.Equals("E:" + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || fullPath.Equals("C:\\MUSVEN_TITAN_BACKUP", StringComparison.OrdinalIgnoreCase)) && Directory.Exists(fullPath);
		}
		catch
		{
			return false;
		}
	}

	private SqlConnection OpenConnection()
	{
		SqlConnection sqlConnection = new SqlConnection(connectionBuilder.ConnectionString);
		sqlConnection.Open();
		return sqlConnection;
	}

	private static SqlDataResetPreview Inspect(DbConnection connection, string expectedServer, string expectedUserAccess)
	{
		List<string> blockers = new List<string>();
		string server;
		string productVersion;
		string databaseState;
		string userAccess;
		using (DbCommand command = connection.CreateCommand())
		{
			command.CommandTimeout = 15;
			command.CommandText = "\r\nSELECT CONVERT(nvarchar(128), SERVERPROPERTY('ServerName')),\r\n       CONVERT(nvarchar(128), SERVERPROPERTY('ProductVersion')),\r\n       COALESCE((SELECT state_desc FROM master.sys.databases WHERE name=N'Muonline'), N'MISSING'),\r\n       COALESCE((SELECT user_access_desc FROM master.sys.databases WHERE name=N'Muonline'), N'MISSING')";
			using DbDataReader reader = command.ExecuteReader();
			if (!reader.Read())
			{
				throw new InvalidOperationException("Không lấy được danh tính SQL Server/database.");
			}
			server = Convert.ToString(reader.GetValue(0)) ?? string.Empty;
			productVersion = Convert.ToString(reader.GetValue(1)) ?? string.Empty;
			databaseState = Convert.ToString(reader.GetValue(2)) ?? "MISSING";
			userAccess = Convert.ToString(reader.GetValue(3)) ?? "MISSING";
		}
		if (!string.Equals(server, expectedServer.Trim(), StringComparison.OrdinalIgnoreCase))
		{
			blockers.Add($"Máy SQL thực tế là {server}; Config.ini chỉ cho phép {expectedServer.Trim()}.");
		}
		if (!databaseState.Equals("ONLINE", StringComparison.OrdinalIgnoreCase))
		{
			blockers.Add("Muonline phải ONLINE; hiện tại " + databaseState + ".");
		}
		if (!userAccess.Equals(expectedUserAccess, StringComparison.OrdinalIgnoreCase))
		{
			blockers.Add($"Muonline phải ở chế độ {expectedUserAccess}; hiện tại {userAccess}.");
		}
		if (!productVersion.StartsWith("10.50.", StringComparison.OrdinalIgnoreCase))
		{
			blockers.Add("Schema reset đã rà cho SQL Server 2008 R2 (10.50); phiên bản hiện tại là " + productVersion + ".");
		}
		if (!connection.Database.Equals("master", StringComparison.OrdinalIgnoreCase) && !connection.Database.Equals("Muonline", StringComparison.OrdinalIgnoreCase))
		{
			blockers.Add("Kết nối SQL đang ở database khác ngữ cảnh dự kiến.");
		}
		int userTableCount = 0;
		int procedureCount = 0;
		List<TableInfo> tables = ReadTables(connection);
		userTableCount = tables.Count;
		if (tables.Any((TableInfo tableInfo) => !tableInfo.Schema.Equals("dbo", StringComparison.OrdinalIgnoreCase)))
		{
			blockers.Add("Có bảng người dùng ngoài schema dbo; Musven sẽ không xóa.");
		}
		if (userTableCount != 63)
		{
			blockers.Add($"Cần đúng {63} bảng người dùng; hiện có {userTableCount}.");
		}
		TableInfo[] preserved = tables.Where((TableInfo tableInfo) => PreservedTables.Contains<string>(tableInfo.Name, StringComparer.OrdinalIgnoreCase)).ToArray();
		TableInfo[] resetTables = tables.Where((TableInfo tableInfo) => !PreservedTables.Contains<string>(tableInfo.Name, StringComparer.OrdinalIgnoreCase)).ToArray();
		if (preserved.Length != PreservedTables.Length || PreservedTables.Any((string value) => !preserved.Any((TableInfo tableInfo) => tableInfo.Name.Equals(value, StringComparison.OrdinalIgnoreCase))))
		{
			blockers.Add("Thiếu hoặc sai một trong bảy bảng cấu hình được giữ lại.");
		}
		if (resetTables.Length != 56)
		{
			blockers.Add($"Cần đúng {56} bảng dữ liệu sẽ xóa; hiện có {resetTables.Length}.");
		}
		using (DbCommand command2 = connection.CreateCommand())
		{
			command2.CommandTimeout = 15;
			command2.CommandText = "SELECT COUNT(*) FROM Muonline.sys.procedures WHERE is_ms_shipped=0";
			procedureCount = Convert.ToInt32(command2.ExecuteScalar());
		}
		if (procedureCount != 76)
		{
			blockers.Add($"Cần đúng {76} procedure đã rà; hiện có {procedureCount}.");
		}
		List<ForeignKeyInfo> foreignKeys = ReadForeignKeys(connection);
		if (foreignKeys.Count != ExpectedForeignKeys.Length || ExpectedForeignKeys.Any((string value) => !foreignKeys.Any((ForeignKeyInfo fk) => fk.Name.Equals(value, StringComparison.OrdinalIgnoreCase))))
		{
			blockers.Add("Cấu trúc khóa ngoại khác bản SQL đã rà; cần đúng hai FK CustomNpcQuest/CustomQuest → Character.");
		}
		if (foreignKeys.Any((ForeignKeyInfo fk) => fk.Disabled || fk.NotTrusted))
		{
			blockers.Add("Có khóa ngoại bị disable hoặc không trusted; Musven sẽ dừng.");
		}
		HashSet<int> targetIds = resetTables.Select((TableInfo tableInfo) => tableInfo.ObjectId).ToHashSet();
		HashSet<int> preservedIds = preserved.Select((TableInfo tableInfo) => tableInfo.ObjectId).ToHashSet();
		if (foreignKeys.Any((ForeignKeyInfo fk) => preservedIds.Contains(fk.ChildObjectId) && targetIds.Contains(fk.ParentObjectId)))
		{
			blockers.Add("Bảng cấu hình được giữ lại đang tham chiếu bảng sắp xóa.");
		}
		if (foreignKeys.Any((ForeignKeyInfo fk) => fk.ChildObjectId == fk.ParentObjectId && targetIds.Contains(fk.ChildObjectId)))
		{
			blockers.Add("Có khóa ngoại tự tham chiếu trong bảng sẽ xóa.");
		}
		int triggerCount;
		using (DbCommand command3 = connection.CreateCommand())
		{
			command3.CommandTimeout = 15;
			command3.CommandText = "\r\nSELECT COUNT(*) FROM Muonline.sys.triggers AS tr\r\nJOIN Muonline.sys.tables AS t ON t.object_id=tr.parent_id\r\nWHERE tr.is_disabled=0 AND t.is_ms_shipped=0\r\n  AND t.name NOT IN (N'DefaultClassType',N'GameServerInfo',N'MK_Server',N'MuCastle_DATA',N'MuCastle_NPC',N'WZ_CW_INFO')";
			triggerCount = Convert.ToInt32(command3.ExecuteScalar());
		}
		if (triggerCount != 0)
		{
			blockers.Add("Có trigger đang bật trên bảng dữ liệu; reset có thể gây tác động ngoài dự kiến.");
		}
		int hasServerStatePermission;
		using (DbCommand command4 = connection.CreateCommand())
		{
			command4.CommandTimeout = 15;
			command4.CommandText = "SELECT CASE WHEN IS_SRVROLEMEMBER(N'sysadmin')=1 OR HAS_PERMS_BY_NAME(NULL,NULL,N'VIEW SERVER STATE')=1 THEN 1 ELSE 0 END";
			hasServerStatePermission = Convert.ToInt32(command4.ExecuteScalar());
		}
		if (hasServerStatePermission == 0)
		{
			blockers.Add("Cần quyền VIEW SERVER STATE hoặc sysadmin để xác nhận không còn game server kết nối.");
		}
		int otherSessions;
		using (DbCommand command5 = connection.CreateCommand())
		{
			command5.CommandTimeout = 15;
			command5.CommandText = "\r\nSELECT COUNT(*) FROM master.dbo.sysprocesses\r\nWHERE dbid=DB_ID(N'Muonline') AND spid<>@@SPID AND spid>50";
			otherSessions = Convert.ToInt32(command5.ExecuteScalar());
		}
		if (otherSessions > 0)
		{
			blockers.Add($"Còn {otherSessions} kết nối khác tới Muonline. Hãy dừng game server và đóng kết nối SSMS tới database trước khi xóa.");
		}
		int openTransactions;
		using (DbCommand command6 = connection.CreateCommand())
		{
			command6.CommandTimeout = 10;
			command6.CommandText = "SELECT @@TRANCOUNT";
			openTransactions = Convert.ToInt32(command6.ExecuteScalar());
		}
		if (openTransactions != 0)
		{
			blockers.Add("Kết nối hiện tại đang có transaction mở.");
		}
		List<SqlResetTablePreview> tableRows = new List<SqlResetTablePreview>();
		long totalRows = 0L;
		long accountRows = 0L;
		long characterRows = 0L;
		long guildRows = 0L;
		long rankingRows = 0L;
		TableInfo[] array = resetTables;
		foreach (TableInfo table in array)
		{
			long count = CountRows(connection, table.Schema, table.Name);
			tableRows.Add(new SqlResetTablePreview(table.Name, count));
			totalRows += count;
			if (table.Name.Equals("MEMB_INFO", StringComparison.OrdinalIgnoreCase))
			{
				accountRows = count;
			}
			else if (table.Name.Equals("Character", StringComparison.OrdinalIgnoreCase))
			{
				characterRows = count;
			}
			else if (table.Name.Equals("Guild", StringComparison.OrdinalIgnoreCase))
			{
				guildRows = count;
			}
			if (table.Name.StartsWith("Ranking", StringComparison.OrdinalIgnoreCase))
			{
				rankingRows += count;
			}
		}
		SortedDictionary<string, long> preservedRows = new SortedDictionary<string, long>(StringComparer.OrdinalIgnoreCase);
		string[] preservedTables = PreservedTables;
		foreach (string name in preservedTables)
		{
			if (preserved.Any((TableInfo tableInfo) => tableInfo.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
			{
				preservedRows[name] = CountRows(connection, "dbo", name);
			}
		}
		CheckPreservedSeeds(preservedRows, blockers);
		CheckCastleColumns(connection, blockers);
		return new SqlDataResetPreview(server, "Muonline", productVersion, userAccess, userTableCount, resetTables.Length, totalRows, accountRows, characterRows, guildRows, rankingRows, tableRows.OrderBy<SqlResetTablePreview, string>((SqlResetTablePreview sqlResetTablePreview) => sqlResetTablePreview.Name, StringComparer.OrdinalIgnoreCase).ToArray(), preservedRows, tables.Select((TableInfo tableInfo) => tableInfo.Schema + "." + tableInfo.Name).OrderBy<string, string>((string result) => result, StringComparer.OrdinalIgnoreCase).ToArray(), blockers.Distinct<string>(StringComparer.OrdinalIgnoreCase).ToArray());
	}

	private static void EnsureExecutable(SqlDataResetPreview preview)
	{
		if (!preview.CanExecute)
		{
			throw new InvalidOperationException("Reset bị chặn:\n• " + string.Join("\n• ", preview.Blockers));
		}
	}

	private static bool SameSnapshot(SqlDataResetPreview first, SqlDataResetPreview second)
	{
		if (first.Server.Equals(second.Server, StringComparison.OrdinalIgnoreCase) && first.Database.Equals(second.Database, StringComparison.OrdinalIgnoreCase) && first.ProductVersion.Equals(second.ProductVersion, StringComparison.OrdinalIgnoreCase) && first.AllTableNames.SequenceEqual<string>(second.AllTableNames, StringComparer.OrdinalIgnoreCase) && first.Tables.SequenceEqual(second.Tables))
		{
			return first.PreservedTableRows.OrderBy<KeyValuePair<string, long>, string>((KeyValuePair<string, long> pair) => pair.Key, StringComparer.OrdinalIgnoreCase).SequenceEqual(second.PreservedTableRows.OrderBy<KeyValuePair<string, long>, string>((KeyValuePair<string, long> pair) => pair.Key, StringComparer.OrdinalIgnoreCase));
		}
		return false;
	}

	private static List<TableInfo> ReadTables(DbConnection connection)
	{
		List<TableInfo> result = new List<TableInfo>();
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 15;
		command.CommandText = "\r\nSELECT t.object_id,s.name,t.name\r\nFROM Muonline.sys.tables AS t\r\nJOIN Muonline.sys.schemas AS s ON s.schema_id=t.schema_id\r\nWHERE t.is_ms_shipped=0\r\nORDER BY s.name,t.name";
		using DbDataReader reader = command.ExecuteReader();
		while (reader.Read())
		{
			result.Add(new TableInfo(Convert.ToInt32(reader.GetValue(0)), Convert.ToString(reader.GetValue(1)) ?? string.Empty, Convert.ToString(reader.GetValue(2)) ?? string.Empty));
		}
		return result;
	}

	private static List<ForeignKeyInfo> ReadForeignKeys(DbConnection connection)
	{
		List<ForeignKeyInfo> result = new List<ForeignKeyInfo>();
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 15;
		command.CommandText = "\r\nSELECT name,parent_object_id,referenced_object_id,is_disabled,is_not_trusted\r\nFROM Muonline.sys.foreign_keys\r\nORDER BY name";
		using DbDataReader reader = command.ExecuteReader();
		while (reader.Read())
		{
			result.Add(new ForeignKeyInfo(Convert.ToString(reader.GetValue(0)) ?? string.Empty, Convert.ToInt32(reader.GetValue(1)), Convert.ToInt32(reader.GetValue(2)), Convert.ToBoolean(reader.GetValue(3)), Convert.ToBoolean(reader.GetValue(4))));
		}
		return result;
	}

	private static long CountRows(DbConnection connection, string schema, string table)
	{
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 30;
		command.CommandText = "SELECT COUNT_BIG(*) FROM Muonline." + Quote(schema) + "." + Quote(table);
		return Convert.ToInt64(command.ExecuteScalar());
	}

	private static void CheckPreservedSeeds(IReadOnlyDictionary<string, long> rows, List<string> blockers)
	{
		foreach (KeyValuePair<string, long> pair in new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase)
		{
			["DefaultClassType"] = 15L,
			["GameServerInfo"] = 1L,
			["MK_Server"] = 1L,
			["MuCastle_DATA"] = 1L,
			["MuCastle_NPC"] = 10L,
			["WZ_CW_INFO"] = 0L,
			["MUSVEN_CharacterCreateDefaults"] = 1L
		})
		{
			if (!rows.TryGetValue(pair.Key, out var actual) || actual != pair.Value)
			{
				blockers.Add($"Bảng cấu hình được giữ lại {pair.Key} cần có {pair.Value} dòng; hiện có {(rows.TryGetValue(pair.Key, out actual) ? actual : (-1))}.");
			}
		}
	}

	private static void CheckCastleColumns(DbConnection connection, List<string> blockers)
	{
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 15;
		command.CommandText = "\r\nSELECT COUNT(*) FROM Muonline.sys.columns AS c\r\nJOIN Muonline.sys.tables AS t ON t.object_id=c.object_id\r\nJOIN Muonline.sys.schemas AS s ON s.schema_id=t.schema_id\r\nWHERE s.name=N'dbo' AND t.name=N'MuCastle_DATA'\r\n  AND c.name IN (N'MAP_SVR_GROUP',N'CASTLE_OCCUPY',N'OWNER_GUILD',N'MONEY',N'TAX_RATE_CHAOS',N'TAX_RATE_STORE',N'TAX_HUNT_ZONE')";
		if (Convert.ToInt32(command.ExecuteScalar()) != 7)
		{
			blockers.Add("Schema MuCastle_DATA thiếu cột reset trạng thái thành trì đã rà.");
		}
	}

	private static List<TableInfo> BuildDeleteOrder(IReadOnlyCollection<TableInfo> tables, IReadOnlyCollection<ForeignKeyInfo> foreignKeys)
	{
		Dictionary<int, TableInfo> byId = tables.ToDictionary((TableInfo table) => table.ObjectId);
		HashSet<int> remaining = byId.Keys.ToHashSet();
		List<TableInfo> order = new List<TableInfo>(tables.Count);
		while (remaining.Count > 0)
		{
			TableInfo candidate = (from table in tables
				where remaining.Contains(table.ObjectId)
				where !foreignKeys.Any((ForeignKeyInfo fk) => fk.ParentObjectId == table.ObjectId && remaining.Contains(fk.ChildObjectId))
				select table).OrderBy<TableInfo, string>((TableInfo table) => table.Name, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
			if ((object)candidate == null)
			{
				throw new InvalidOperationException("Khóa ngoại tạo vòng phụ thuộc; Musven dừng trước khi xóa.");
			}
			order.Add(candidate);
			remaining.Remove(candidate.ObjectId);
		}
		if (order.Any((TableInfo table) => !byId.ContainsKey(table.ObjectId)))
		{
			throw new InvalidOperationException("Không tạo được thứ tự xóa bảng hợp lệ.");
		}
		return order;
	}

	private static void VerifyReset(DbConnection connection, DbTransaction transaction, IReadOnlyCollection<TableInfo> allTables, IReadOnlyCollection<TableInfo> resetTables, IReadOnlyDictionary<string, long> preservedBefore)
	{
		foreach (TableInfo table in resetTables)
		{
			using DbCommand command = connection.CreateCommand();
			command.Transaction = transaction;
			command.CommandTimeout = 30;
			command.CommandText = "SELECT COUNT_BIG(*) FROM " + Quote(table.Schema) + "." + Quote(table.Name);
			if (Convert.ToInt64(command.ExecuteScalar()) != 0L)
			{
				throw new InvalidOperationException($"Bảng {table.Schema}.{table.Name} vẫn còn dữ liệu; Musven sẽ rollback.");
			}
		}
		foreach (KeyValuePair<string, long> pair in preservedBefore)
		{
			using DbCommand command2 = connection.CreateCommand();
			command2.Transaction = transaction;
			command2.CommandTimeout = 30;
			command2.CommandText = "SELECT COUNT_BIG(*) FROM dbo." + Quote(pair.Key);
			if (Convert.ToInt64(command2.ExecuteScalar()) != pair.Value)
			{
				throw new InvalidOperationException("Số dòng bảng cấu hình " + pair.Key + " thay đổi; Musven sẽ rollback.");
			}
		}
		using (DbCommand castle = connection.CreateCommand())
		{
			castle.Transaction = transaction;
			castle.CommandTimeout = 30;
			castle.CommandText = "\r\nSELECT COUNT(*) FROM dbo.MuCastle_DATA\r\nWHERE MAP_SVR_GROUP=0 AND CASTLE_OCCUPY=0 AND OWNER_GUILD=''\r\n  AND MONEY=0 AND TAX_RATE_CHAOS=0 AND TAX_RATE_STORE=0 AND TAX_HUNT_ZONE=0";
			if (Convert.ToInt32(castle.ExecuteScalar()) != 1)
			{
				throw new InvalidOperationException("Không xác minh được trạng thái thành trì trắng; Musven sẽ rollback.");
			}
		}
		if (allTables.Count != 63 || resetTables.Count != 56)
		{
			throw new InvalidOperationException("Số lượng bảng thay đổi trong lúc reset; Musven sẽ rollback.");
		}
	}

	private static string CreateAndVerifyBackup(DbConnection connection, string serverDirectory)
	{
		string safeDatabase = string.Concat("Muonline".Select((char c) => (!Path.GetInvalidFileNameChars().Contains(c)) ? c : '_'));
		string backupFile = $"{safeDatabase}_MuSven_PreReset_{DateTime.UtcNow:yyyyMMdd_HHmmss}_{Guid.NewGuid():N}.bak";
		string backupPath = Path.Combine(serverDirectory.Trim(), backupFile);
		if (backupPath.Length > 240)
		{
			throw new InvalidOperationException("Đường dẫn backup trên SQL Server quá dài.");
		}
		using (DbCommand backup = connection.CreateCommand())
		{
			backup.CommandTimeout = 0;
			DbParameter path = backup.CreateParameter();
			path.ParameterName = "@path";
			path.DbType = DbType.String;
			path.Size = 4000;
			path.Value = backupPath;
			backup.Parameters.Add(path);
			backup.CommandText = "\r\nDECLARE @sql nvarchar(max)=N'BACKUP DATABASE [Muonline] TO DISK=@p WITH COPY_ONLY,CHECKSUM,STATS=5';\r\nEXEC sys.sp_executesql @sql,N'@p nvarchar(4000)',@p=@path";
			backup.ExecuteNonQuery();
		}
		using DbCommand verify = connection.CreateCommand();
		verify.CommandTimeout = 0;
		DbParameter path2 = verify.CreateParameter();
		path2.ParameterName = "@path";
		path2.DbType = DbType.String;
		path2.Size = 4000;
		path2.Value = backupPath;
		verify.Parameters.Add(path2);
		verify.CommandText = "\r\nDECLARE @sql nvarchar(max)=N'RESTORE VERIFYONLY FROM DISK=@p WITH CHECKSUM';\r\nEXEC sys.sp_executesql @sql,N'@p nvarchar(4000)',@p=@path";
		verify.ExecuteNonQuery();
		return backupPath;
	}

	private static void Execute(DbConnection connection, string sql, int timeoutSeconds)
	{
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = timeoutSeconds;
		command.CommandText = sql;
		command.ExecuteNonQuery();
	}

	private static string Quote(string identifier)
	{
		return "[" + identifier.Replace("]", "]]", StringComparison.Ordinal) + "]";
	}
}
