namespace MuSven09M.Modules.Management;

public sealed record SqlDatabaseBackupResult(string DatabaseName, string BackupPath);
