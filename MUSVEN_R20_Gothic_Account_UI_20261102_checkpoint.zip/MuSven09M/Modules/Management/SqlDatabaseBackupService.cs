using System;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Management;

public sealed class SqlDatabaseBackupService
{
	private readonly MuSvenDatabase database;

	public SqlDatabaseBackupService(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public SqlDatabaseBackupResult CreateAndVerify(string serverDirectory)
	{
		if (string.IsNullOrWhiteSpace(serverDirectory) || !Path.IsPathRooted(serverDirectory))
		{
			throw new ArgumentException("Hãy nhập đường dẫn tuyệt đối trên máy chạy dịch vụ SQL Server.", "serverDirectory");
		}
		using DbConnection connection = database.OpenConnection();
		string databaseName;
		using (DbCommand command = connection.CreateCommand())
		{
			command.CommandText = "SELECT DB_NAME()";
			command.CommandTimeout = 10;
			databaseName = Convert.ToString(command.ExecuteScalar()) ?? string.Empty;
		}
		if (string.IsNullOrWhiteSpace(databaseName))
		{
			throw new InvalidOperationException("Không xác định được database hiện tại; Musven đã dừng trước khi backup.");
		}
		string safeName = string.Concat(databaseName.Select((char c) => (!Path.GetInvalidFileNameChars().Contains(c)) ? c : '_'));
		string token = Guid.NewGuid().ToString("N").Substring(0, 12);
		string suffix = $"_MuSven_{DateTime.UtcNow:yyyyMMdd_HHmmss}_{token}.bak";
		int maxDatabaseNameLength = Math.Max(1, 180 - suffix.Length);
		if (safeName.Length > maxDatabaseNameLength)
		{
			safeName = safeName.Substring(0, maxDatabaseNameLength);
		}
		string fileName = safeName + suffix;
		string backupPath = Path.Combine(serverDirectory.Trim(), fileName);
		if (backupPath.Length > 240)
		{
			throw new ArgumentException("Đường dẫn backup quá dài. Hãy chọn thư mục SQL Server ngắn hơn.", "serverDirectory");
		}
		ExecuteBackupCommand(connection, backupPath, verify: false);
		ExecuteBackupCommand(connection, backupPath, verify: true);
		return new SqlDatabaseBackupResult(databaseName, backupPath);
	}

	private static void ExecuteBackupCommand(DbConnection connection, string backupPath, bool verify)
	{
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 0;
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = "@BackupPath";
		parameter.DbType = DbType.String;
		parameter.Size = 4000;
		parameter.Value = backupPath;
		command.Parameters.Add(parameter);
		command.CommandText = (verify ? "DECLARE @sql nvarchar(max) = N'RESTORE VERIFYONLY FROM DISK = @path WITH CHECKSUM';\nEXEC sys.sp_executesql @sql, N'@path nvarchar(4000)', @path = @BackupPath;" : "DECLARE @db sysname = DB_NAME();\nDECLARE @sql nvarchar(max) = N'BACKUP DATABASE ' + QUOTENAME(@db) + N' TO DISK = @path WITH COPY_ONLY, CHECKSUM, STATS = 5';\nEXEC sys.sp_executesql @sql, N'@path nvarchar(4000)', @path = @BackupPath;");
		command.ExecuteNonQuery();
	}
}
