namespace MuSven09M.Modules.Management;

public sealed record SqlResetTablePreview(string Name, long Rows);
