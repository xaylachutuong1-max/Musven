using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Management;

public sealed class SqlSchemaAuditRepository
{
	private sealed record ColumnSpec(string Feature, string Table, string Column, string Type, int? Length = null, bool Required = true, bool? Identity = false);

	private sealed record ParameterSpec(string Name, string Type, int Length);

	private sealed record ProcedureSpec(string Feature, string Name, ParameterSpec[] Parameters, string[] Markers, bool Required = true);

	private sealed record ColumnInfo(string Type, int Length, bool Identity);

	private sealed record ParameterInfo(string Name, string Type, int Length, bool IsOutput);

	private sealed class ProcedureInfo
	{
		public string? Definition { get; set; }

		public List<ParameterInfo> Parameters { get; } = new List<ParameterInfo>();
	}

	private readonly MuSvenDatabase database;

	private static readonly ColumnSpec[] Columns = BuildColumnSpecs();

	private static readonly string[] OptionalRankingTables = new string[13]
	{
		"RankingBloodCastle", "RankingBos", "RankingChaosCastle", "RankingDevilSquare", "RankingDuel", "RankingIllusionTemple", "RankingKingGuild", "RankingKingPlayer", "RankingTvT", "CustomQuest",
		"CustomNpcQuest", "EventLeoTheHelper", "EventSantaClaus"
	};

	private static readonly ProcedureSpec[] Procedures = new ProcedureSpec[6]
	{
		new ProcedureSpec("Tạo nhân vật", "WZ_CreateCharacter", new ParameterSpec[3]
		{
			new ParameterSpec("@AccountID", "varchar", 10),
			new ParameterSpec("@Name", "varchar", 10),
			new ParameterSpec("@Class", "tinyint", 1)
		}, new string[5] { "MU SVEN CHARACTER DEFAULTS V03", "dbo.MUSVEN_CharacterCreateDefaults", "SELECT @Result AS Result", "dbo.MasterSkillTree", "dbo.CashShopData" }),
		new ProcedureSpec("Xóa nhân vật", "WZ_DeleteCharacter", new ParameterSpec[2]
		{
			new ParameterSpec("@Account", "varchar", 10),
			new ParameterSpec("@Name", "varchar", 10)
		}, new string[8] { "owner verification", "BEGIN TRANSACTION", "AccountCharacter", "GameID1", "G_Master", "GoblinMix", "T_FriendMail", "SELECT @Result AS Result" }),
		new ProcedureSpec("Gỡ khóa hết hạn", "WZ_DesblocAccount", new ParameterSpec[1]
		{
			new ParameterSpec("@Account", "varchar", 10)
		}, new string[3] { "UPDATE MEMB_INFO SET bloc_code = 0", "bloc_expire < GETDATE()", "UPDATE Character SET CtlCode = 0" }),
		new ProcedureSpec("Cấp thành viên", "WZ_SetAccountLevel", new ParameterSpec[3]
		{
			new ParameterSpec("@Account", "varchar", 10),
			new ParameterSpec("@AccountLevel", "int", 4),
			new ParameterSpec("@AccountExpireTime", "int", 4)
		}, new string[3] { "DATEADD(second,@AccountExpireTime,@CurrentAccountExpireDate)", "DATEADD(second,@AccountExpireTime,GETDATE())", "UPDATE MEMB_INFO SET AccountLevel=@CurrentAccountLevel" }),
		new ProcedureSpec("Đổi tên nhân vật", "WZ_RenameCharacter", new ParameterSpec[3]
		{
			new ParameterSpec("@Account", "varchar", 10),
			new ParameterSpec("@OldName", "varchar", 10),
			new ParameterSpec("@NewName", "varchar", 10)
		}, new string[3] { "IF EXISTS (SELECT Name FROM Character WHERE Name=@NewName)", "UPDATE Character SET Name = @NewName WHERE Name = @OldName AND AccountID = @Account", "UPDATE HelperData SET Name = @NewName WHERE Name = @OldName" }),
		new ProcedureSpec("Tạo vật phẩm trong kho", "WZ_GetItemSerial", Array.Empty<ParameterSpec>(), Array.Empty<string>())
	};

	public SqlSchemaAuditRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public SchemaAuditReport Read()
	{
		using DbConnection connection = database.OpenConnection();
		string server;
		string databaseName;
		string version;
		using (DbCommand context = connection.CreateCommand())
		{
			context.CommandTimeout = 8;
			context.CommandText = "SELECT CONVERT(nvarchar(128), SERVERPROPERTY('ServerName')), DB_NAME(), CONVERT(nvarchar(128), SERVERPROPERTY('ProductVersion'))";
			using DbDataReader reader = context.ExecuteReader();
			if (!reader.Read())
			{
				throw new InvalidOperationException("Không đọc được ngữ cảnh SQL hiện tại.");
			}
			server = Convert.ToString(reader.GetValue(0)) ?? "?";
			databaseName = Convert.ToString(reader.GetValue(1)) ?? "?";
			version = Convert.ToString(reader.GetValue(2)) ?? "?";
		}
		HashSet<string> tableNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		Dictionary<string, ColumnInfo> columns = new Dictionary<string, ColumnInfo>(StringComparer.OrdinalIgnoreCase);
		using (DbCommand metadata = connection.CreateCommand())
		{
			metadata.CommandTimeout = 10;
			metadata.CommandText = "\nSELECT s.name, t.name, c.name, ty.name, c.max_length, c.is_identity\nFROM sys.tables AS t\nJOIN sys.schemas AS s ON s.schema_id=t.schema_id\nJOIN sys.columns AS c ON c.object_id=t.object_id\nJOIN sys.types AS ty ON ty.user_type_id=c.user_type_id\nWHERE s.name=N'dbo'\nORDER BY t.name, c.column_id";
			using DbDataReader reader2 = metadata.ExecuteReader();
			while (reader2.Read())
			{
				string table = Convert.ToString(reader2.GetValue(1)) ?? string.Empty;
				string column = Convert.ToString(reader2.GetValue(2)) ?? string.Empty;
				tableNames.Add(table);
				columns[Key(table, column)] = new ColumnInfo(Convert.ToString(reader2.GetValue(3)) ?? string.Empty, Convert.ToInt32(reader2.GetValue(4)), Convert.ToBoolean(reader2.GetValue(5)));
			}
		}
		List<SchemaAuditRow> output = new List<SchemaAuditRow>();
		ColumnSpec[] columns2 = Columns;
		foreach (ColumnSpec spec in columns2)
		{
			output.Add(CheckColumn(spec, tableNames, columns));
		}
		output.Add(CheckAllowedColumn("Khóa tài khoản tạm thời", "MEMB_INFO", "bloc_code", new string[3] { "tinyint", "smallint", "int" }, tableNames, columns));
		output.Add(CheckAllowedColumn("Khóa tài khoản tạm thời", "MEMB_INFO", "bloc_expire", new string[3] { "smalldatetime", "datetime", "datetime2" }, tableNames, columns));
		Dictionary<string, List<string>> primaryKeyColumns = ReadPrimaryKeyColumns(connection);
		output.Add(CheckPrimaryKey("MUSVEN_CharacterCreateDefaults", "ConfigID", tableNames, primaryKeyColumns));
		HashSet<string> namedConstraints = ReadNamedConstraints(connection);
		output.Add(CheckNamedConstraint("MUSVEN_CharacterCreateDefaults", "CK_MUSVEN_CharacterCreateDefaults_Values", "CHECK constraint", tableNames, namedConstraints));
		output.Add(CheckNamedConstraint("MUSVEN_CharacterCreateDefaults", "DF_MUSVEN_CharacterCreateDefaults_ModifiedAt", "DEFAULT constraint", tableNames, namedConstraints));
		string[] optionalRankingTables = OptionalRankingTables;
		foreach (string table2 in optionalRankingTables)
		{
			bool found = tableNames.Contains(table2);
			output.Add(new SchemaAuditRow("Xếp hạng / sự kiện", "dbo." + table2, "Bảng", "Bảng xem được", found ? "Tồn tại" : "—", found ? "OK" : "TÙY CHỌN • CHƯA CÓ", Required: false));
		}
		if (tableNames.Contains("RankingBos"))
		{
			output.Add(CheckColumn(new ColumnSpec("Xóa nhân vật", "RankingBos", "Name", "varchar", 10, Required: true, false), tableNames, columns));
		}
		Dictionary<string, ProcedureInfo> procedures = ReadProcedures(connection);
		ProcedureSpec[] procedures2 = Procedures;
		for (int i = 0; i < procedures2.Length; i++)
		{
			CheckProcedure(procedures2[i], procedures, output);
		}
		return new SchemaAuditReport(server, databaseName, version, output);
	}

	private static Dictionary<string, ProcedureInfo> ReadProcedures(DbConnection connection)
	{
		Dictionary<string, ProcedureInfo> result = new Dictionary<string, ProcedureInfo>(StringComparer.OrdinalIgnoreCase);
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 10;
		command.CommandText = "\nSELECT p.name, prm.parameter_id, prm.name, ty.name, prm.max_length, prm.is_output, OBJECT_DEFINITION(p.object_id)\nFROM sys.procedures AS p\nJOIN sys.schemas AS s ON s.schema_id=p.schema_id\nLEFT JOIN sys.parameters AS prm ON prm.object_id=p.object_id AND prm.parameter_id>0\nLEFT JOIN sys.types AS ty ON ty.user_type_id=prm.user_type_id\nWHERE s.name=N'dbo'\nORDER BY p.name, prm.parameter_id";
		using DbDataReader reader = command.ExecuteReader();
		while (reader.Read())
		{
			string name = Convert.ToString(reader.GetValue(0)) ?? string.Empty;
			if (!result.TryGetValue(name, out var procedure))
			{
				procedure = new ProcedureInfo
				{
					Definition = (reader.IsDBNull(6) ? null : Convert.ToString(reader.GetValue(6)))
				};
				result.Add(name, procedure);
			}
			if (!reader.IsDBNull(1))
			{
				procedure.Parameters.Add(new ParameterInfo(Convert.ToString(reader.GetValue(2)) ?? string.Empty, Convert.ToString(reader.GetValue(3)) ?? string.Empty, Convert.ToInt32(reader.GetValue(4)), Convert.ToBoolean(reader.GetValue(5))));
			}
		}
		return result;
	}

	private static Dictionary<string, List<string>> ReadPrimaryKeyColumns(DbConnection connection)
	{
		Dictionary<string, List<string>> result = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 10;
		command.CommandText = "\nSELECT t.name, c.name\nFROM sys.key_constraints AS k\nJOIN sys.tables AS t ON t.object_id=k.parent_object_id\nJOIN sys.schemas AS s ON s.schema_id=t.schema_id\nJOIN sys.index_columns AS ic ON ic.object_id=k.parent_object_id AND ic.index_id=k.unique_index_id\nJOIN sys.columns AS c ON c.object_id=ic.object_id AND c.column_id=ic.column_id\nWHERE s.name=N'dbo' AND k.type=N'PK' AND ic.key_ordinal>0 AND ic.index_column_id>0\nORDER BY t.name, ic.key_ordinal";
		using DbDataReader reader = command.ExecuteReader();
		while (reader.Read())
		{
			string table = Convert.ToString(reader.GetValue(0)) ?? string.Empty;
			if (!result.TryGetValue(table, out var columns))
			{
				columns = (result[table] = new List<string>());
			}
			columns.Add(Convert.ToString(reader.GetValue(1)) ?? string.Empty);
		}
		return result;
	}

	private static HashSet<string> ReadNamedConstraints(DbConnection connection)
	{
		HashSet<string> result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		using DbCommand command = connection.CreateCommand();
		command.CommandTimeout = 10;
		command.CommandText = "\nSELECT t.name, dc.name\nFROM sys.default_constraints AS dc\nJOIN sys.tables AS t ON t.object_id=dc.parent_object_id\nJOIN sys.schemas AS s ON s.schema_id=t.schema_id\nWHERE s.name=N'dbo'\nUNION\nSELECT t.name, cc.name\nFROM sys.check_constraints AS cc\nJOIN sys.tables AS t ON t.object_id=cc.parent_object_id\nJOIN sys.schemas AS s ON s.schema_id=t.schema_id\nWHERE s.name=N'dbo'";
		using DbDataReader reader = command.ExecuteReader();
		while (reader.Read())
		{
			result.Add(Key(Convert.ToString(reader.GetValue(0)) ?? string.Empty, Convert.ToString(reader.GetValue(1)) ?? string.Empty));
		}
		return result;
	}

	private static SchemaAuditRow CheckPrimaryKey(string table, string column, HashSet<string> tables, Dictionary<string, List<string>> primaryKeyColumns)
	{
		List<string> columns;
		bool exists = tables.Contains(table) && primaryKeyColumns.TryGetValue(table, out columns) && columns.Count == 1 && columns[0].Equals(column, StringComparison.OrdinalIgnoreCase);
		return new SchemaAuditRow("Tạo nhân vật", "dbo." + table, "PRIMARY KEY", column, exists ? column : "Thiếu / khác cột", exists ? "OK" : (tables.Contains(table) ? "THIẾU / SAI KHÓA" : "THIẾU BẢNG"), Required: true);
	}

	private static SchemaAuditRow CheckNamedConstraint(string table, string constraint, string kind, HashSet<string> tables, HashSet<string> namedConstraints)
	{
		bool exists = tables.Contains(table) && namedConstraints.Contains(Key(table, constraint));
		return new SchemaAuditRow("Tạo nhân vật", "dbo." + table, kind, constraint, exists ? "Tồn tại" : "—", exists ? "OK" : (tables.Contains(table) ? "THIẾU RÀNG BUỘC" : "THIẾU BẢNG"), Required: true);
	}

	private static void CheckProcedure(ProcedureSpec spec, IReadOnlyDictionary<string, ProcedureInfo> procedures, List<SchemaAuditRow> output)
	{
		if (!procedures.TryGetValue(spec.Name, out ProcedureInfo actual))
		{
			output.Add(new SchemaAuditRow(spec.Feature, "dbo." + spec.Name, "Thủ tục", "Stored procedure", "—", spec.Required ? "THIẾU / KHÔNG HIỂN THỊ" : "TÙY CHỌN • CHƯA CÓ", spec.Required));
			return;
		}
		output.Add(new SchemaAuditRow(spec.Feature, "dbo." + spec.Name, "Thủ tục", "Stored procedure", "Tồn tại", "OK", spec.Required));
		bool signatureMatches = actual.Parameters.Count == spec.Parameters.Length;
		int common = Math.Min(actual.Parameters.Count, spec.Parameters.Length);
		for (int i = 0; i < common; i++)
		{
			ParameterSpec expected = spec.Parameters[i];
			ParameterInfo found = actual.Parameters[i];
			bool matches = found.Name.Equals(expected.Name, StringComparison.OrdinalIgnoreCase) && found.Type.Equals(expected.Type, StringComparison.OrdinalIgnoreCase) && found.Length == expected.Length && !found.IsOutput;
			signatureMatches = signatureMatches && matches;
			output.Add(new SchemaAuditRow(spec.Feature, "dbo." + spec.Name, $"Tham số {i + 1}", FormatParameter(expected), FormatParameter(found), matches ? "OK" : "SAI CHỮ KÝ", spec.Required));
		}
		if (actual.Parameters.Count != spec.Parameters.Length)
		{
			output.Add(new SchemaAuditRow(spec.Feature, "dbo." + spec.Name, "Số tham số", spec.Parameters.Length.ToString(), actual.Parameters.Count.ToString(), "SAI CHỮ KÝ", spec.Required));
		}
		if (spec.Parameters.Length == 0 && actual.Parameters.Count == 0)
		{
			output.Add(new SchemaAuditRow(spec.Feature, "dbo." + spec.Name, "Tham số", "Không có", "Không có", "OK", spec.Required));
		}
		string expectedSignature = ((spec.Parameters.Length == 0) ? "Không tham số" : string.Join(", ", spec.Parameters.Select(FormatParameter)));
		string actualSignature = ((actual.Parameters.Count == 0) ? "Không tham số" : string.Join(", ", actual.Parameters.Select(FormatParameter)));
		output.Add(new SchemaAuditRow(spec.Feature, "dbo." + spec.Name, "Chữ ký tổng", expectedSignature, actualSignature, signatureMatches ? "OK" : "SAI CHỮ KÝ", spec.Required));
		if (spec.Markers.Length == 0)
		{
			return;
		}
		string definition = actual.Definition;
		string markerStatus;
		string markerActual;
		if (string.IsNullOrWhiteSpace(definition))
		{
			markerStatus = "THIẾU QUYỀN VIEW DEFINITION";
			markerActual = "Không đọc được định nghĩa";
		}
		else
		{
			string[] missing = spec.Markers.Where((string marker) => !definition.Contains(marker, StringComparison.OrdinalIgnoreCase)).ToArray();
			markerStatus = ((missing.Length == 0) ? "OK" : "SAI VERSION / THIẾU MARKER");
			markerActual = ((missing.Length == 0) ? "Đủ marker" : ("Thiếu: " + string.Join(", ", missing)));
		}
		output.Add(new SchemaAuditRow(spec.Feature, "dbo." + spec.Name, "Định nghĩa / marker", "Đúng bản Musven đã rà soát", markerActual, markerStatus, spec.Required));
	}

	private static SchemaAuditRow CheckColumn(ColumnSpec spec, HashSet<string> tables, IReadOnlyDictionary<string, ColumnInfo> columns)
	{
		string objectName = "dbo." + spec.Table;
		if (!tables.Contains(spec.Table))
		{
			return new SchemaAuditRow(spec.Feature, objectName, spec.Column, ExpectedType(spec), "—", spec.Required ? "THIẾU / KHÔNG HIỂN THỊ" : "TÙY CHỌN • CHƯA CÓ", spec.Required);
		}
		if (!columns.TryGetValue(Key(spec.Table, spec.Column), out ColumnInfo found))
		{
			return new SchemaAuditRow(spec.Feature, objectName, spec.Column, ExpectedType(spec), "—", spec.Required ? "THIẾU CỘT" : "TÙY CHỌN • CHƯA CÓ", spec.Required);
		}
		bool matches = found.Type.Equals(spec.Type, StringComparison.OrdinalIgnoreCase) && (!spec.Length.HasValue || found.Length == spec.Length.Value) && (!spec.Identity.HasValue || found.Identity == spec.Identity.Value);
		string actual = ActualType(found);
		if (found.Identity)
		{
			actual += " IDENTITY";
		}
		string expected = ExpectedType(spec) + ((spec.Identity == true) ? " IDENTITY" : string.Empty);
		return new SchemaAuditRow(spec.Feature, objectName, spec.Column, expected, actual, matches ? "OK" : "SAI KIỂU / THUỘC TÍNH", spec.Required);
	}

	private static SchemaAuditRow CheckAllowedColumn(string feature, string table, string column, string[] allowedTypes, HashSet<string> tables, IReadOnlyDictionary<string, ColumnInfo> columns)
	{
		string objectName = "dbo." + table;
		string expected = string.Join(" / ", allowedTypes);
		if (!tables.Contains(table))
		{
			return new SchemaAuditRow(feature, objectName, column, expected, "—", "THIẾU / KHÔNG HIỂN THỊ", Required: true);
		}
		if (!columns.TryGetValue(Key(table, column), out ColumnInfo actual))
		{
			return new SchemaAuditRow(feature, objectName, column, expected, "—", "THIẾU CỘT", Required: true);
		}
		bool matches = allowedTypes.Contains<string>(actual.Type, StringComparer.OrdinalIgnoreCase);
		return new SchemaAuditRow(feature, objectName, column, expected, ActualType(actual), matches ? "OK" : "SAI KIỂU", Required: true);
	}

	private static string ExpectedType(ColumnSpec spec)
	{
		if (!spec.Length.HasValue)
		{
			return spec.Type;
		}
		return $"{spec.Type}({spec.Length.Value})";
	}

	private static string ActualType(ColumnInfo info)
	{
		bool flag;
		switch (info.Type)
		{
		case "varchar":
		case "char":
		case "varbinary":
		case "binary":
		case "nvarchar":
		case "nchar":
			flag = true;
			break;
		default:
			flag = false;
			break;
		}
		if (!flag)
		{
			return info.Type;
		}
		return $"{info.Type}({info.Length})";
	}

	private static string FormatParameter(ParameterSpec parameter)
	{
		return $"{parameter.Name} {parameter.Type}({parameter.Length})";
	}

	private static string FormatParameter(ParameterInfo parameter)
	{
		return $"{parameter.Name} {parameter.Type}({parameter.Length})" + (parameter.IsOutput ? " OUTPUT" : string.Empty);
	}

	private static string Key(string table, string column)
	{
		return table + "\u001f" + column;
	}

	private static ColumnSpec[] BuildColumnSpecs()
	{
		List<ColumnSpec> specs = new List<ColumnSpec>();
		Add("Tài khoản • tra cứu", "MEMB_INFO", "memb___id", "varchar", 10, required: true, false);
		Add("Tài khoản • tra cứu", "MEMB_INFO", "memb_name", "varchar", 10, required: true, false);
		Add("Cấp thành viên", "MEMB_INFO", "AccountLevel", "int", null, required: true, false);
		Add("Cấp thành viên", "MEMB_INFO", "AccountExpireDate", "smalldatetime", null, required: true, false);
		Add("Phiên đăng nhập", "MEMB_STAT", "memb___id", "varchar", 10, required: true, false);
		Add("Phiên đăng nhập", "MEMB_STAT", "ConnectStat", "tinyint", null, required: true, false);
		Add("Phiên đăng nhập", "MEMB_STAT", "ServerName", "varchar", 50, required: true, false);
		Add("Phiên đăng nhập", "MEMB_STAT", "IP", "varchar", 15, required: true, false);
		Add("Phiên đăng nhập", "MEMB_STAT", "ConnectTM", "smalldatetime", null, required: true, false);
		Add("Phiên đăng nhập", "MEMB_STAT", "DisConnectTM", "smalldatetime", null, required: true, false);
		Add("Phiên đăng nhập", "MEMB_STAT", "OnlineHours", "int", null, required: true, false);
		Add("Nhân vật • tra cứu", "Character", "AccountID", "varchar", 10, required: true, false);
		Add("Nhân vật • tra cứu", "Character", "Name", "varchar", 10, required: true, false);
		Add("Nhân vật • tra cứu", "Character", "cLevel", "int", null, required: false, false);
		Add("Nhân vật • tra cứu", "Character", "ResetCount", "int", null, required: false, false);
		Add("Túi nhân vật", "Character", "AccountID", "varchar", 10, required: true, false);
		Add("Túi nhân vật", "Character", "Name", "varchar", 10, required: true, false);
		Add("Túi nhân vật", "Character", "Inventory", "varbinary", 4080, required: true, false);
		Add("Túi nhân vật", "MEMB_STAT", "memb___id", "varchar", 10, required: true, false);
		Add("Túi nhân vật", "MEMB_STAT", "ConnectStat", "tinyint", null, required: true, false);
		Add("Số đếm nhiệm vụ", "QuestKillCount", "Name", "varchar", 10, required: true, false);
		string[] array = new string[11]
		{
			"QuestIndex", "MonsterClass1", "MonsterClass2", "MonsterClass3", "MonsterClass4", "MonsterClass5", "KillCount1", "KillCount2", "KillCount3", "KillCount4",
			"KillCount5"
		};
		foreach (string column in array)
		{
			Add("Số đếm nhiệm vụ", "QuestKillCount", column, "int", null, required: true, false);
		}
		Add("Số đếm nhiệm vụ", "Character", "AccountID", "varchar", 10, required: true, false);
		Add("Số đếm nhiệm vụ", "Character", "Name", "varchar", 10, required: true, false);
		Add("Số đếm nhiệm vụ", "MEMB_STAT", "memb___id", "varchar", 10, required: true, false);
		Add("Số đếm nhiệm vụ", "MEMB_STAT", "ConnectStat", "tinyint", null, required: true, false);
		Add("Tạo nhân vật", "AccountCharacter", "Id", "varchar", 10, required: true, false);
		bool? identity = true;
		Add("Tạo nhân vật", "AccountCharacter", "Number", "int", null, required: true, identity);
		array = new string[6] { "GameID1", "GameID2", "GameID3", "GameID4", "GameID5", "GameIDC" };
		foreach (string column2 in array)
		{
			Add("Tạo / xóa nhân vật", "AccountCharacter", column2, "varchar", 10, required: true, false);
		}
		Add("Tạo nhân vật", "DefaultClassType", "Class", "tinyint", null, required: true, false);
		array = new string[7] { "Level", "LevelUpPoint", "Strength", "Dexterity", "Vitality", "Energy", "Leadership" };
		foreach (string column3 in array)
		{
			Add("Tạo nhân vật", "DefaultClassType", column3, "smallint", null, required: true, false);
		}
		Add("Tạo nhân vật", "DefaultClassType", "Inventory", "varbinary", 4080, required: true, false);
		Add("Tạo nhân vật", "DefaultClassType", "MagicList", "varbinary", 180, required: true, false);
		array = new string[4] { "Life", "MaxLife", "Mana", "MaxMana" };
		foreach (string column4 in array)
		{
			Add("Tạo nhân vật", "DefaultClassType", column4, "real", null, required: true, false);
		}
		array = new string[3] { "MapNumber", "MapPosX", "MapPosY" };
		foreach (string column5 in array)
		{
			Add("Tạo nhân vật", "DefaultClassType", column5, "smallint", null, required: true, false);
		}
		Add("Tạo nhân vật", "DefaultClassType", "Quest", "varbinary", 50, required: true, false);
		Add("Tạo nhân vật", "DefaultClassType", "DbVersion", "tinyint", null, required: true, false);
		Add("Tạo nhân vật", "DefaultClassType", "EffectList", "varbinary", 208, required: true, false);
		Add("Tạo nhân vật", "Character", "AccountID", "varchar", 10, required: true, false);
		Add("Tạo nhân vật", "Character", "Name", "varchar", 10, required: true, false);
		array = new string[11]
		{
			"cLevel", "LevelUpPoint", "Experience", "Strength", "Dexterity", "Vitality", "Energy", "Leadership", "Money", "ResetCount",
			"MasterResetCount"
		};
		foreach (string column6 in array)
		{
			Add("Tạo nhân vật", "Character", column6, "int", null, required: true, false);
		}
		Add("Tạo nhân vật", "Character", "Class", "tinyint", null, required: true, false);
		Add("Tạo nhân vật", "Character", "Inventory", "varbinary", 4080, required: true, false);
		Add("Tạo nhân vật", "Character", "MagicList", "varbinary", 360, required: true, false);
		array = new string[8] { "Life", "MaxLife", "Mana", "MaxMana", "BP", "MaxBP", "Shield", "MaxShield" };
		foreach (string column7 in array)
		{
			Add("Tạo nhân vật", "Character", column7, "real", null, required: true, false);
		}
		array = new string[3] { "MapNumber", "MapPosX", "MapPosY" };
		foreach (string column8 in array)
		{
			Add("Tạo nhân vật", "Character", column8, "smallint", null, required: true, false);
		}
		Add("Tạo nhân vật", "Character", "PkLevel", "int", null, required: true, false);
		array = new string[2] { "MDate", "LDate" };
		foreach (string column9 in array)
		{
			Add("Tạo nhân vật", "Character", column9, "smalldatetime", null, required: true, false);
		}
		Add("Tạo nhân vật", "Character", "DbVersion", "tinyint", null, required: true, false);
		Add("Tạo nhân vật", "Character", "Quest", "varbinary", 100, required: true, false);
		Add("Tạo nhân vật", "Character", "EffectList", "varbinary", 416, required: true, false);
		array = new string[4] { "AccountID", "WCoinC", "WCoinP", "GoblinPoint" };
		foreach (string column10 in array)
		{
			Add("Tạo / tiền-ngọc", "CashShopData", column10, (column10 == "AccountID") ? "varchar" : "int", (column10 == "AccountID") ? new int?(10) : ((int?)null), required: true, false);
		}
		Add("Tạo nhân vật", "MasterSkillTree", "Name", "varchar", 50, required: true, false);
		Add("Tạo nhân vật", "MasterSkillTree", "MasterLevel", "int", null, required: true, false);
		Add("Tạo nhân vật", "MasterSkillTree", "MasterPoint", "int", null, required: true, false);
		Add("Sửa nhân vật • Master", "MasterSkillTree", "Name", "varchar", 50, required: false, false);
		Add("Sửa nhân vật • Master", "MasterSkillTree", "MasterLevel", "int", null, required: false, false);
		Add("Sửa nhân vật • Master", "MasterSkillTree", "MasterPoint", "int", null, required: false, false);
		Add("Sửa nhân vật • Master", "MasterSkillTree", "MasterExperience", "bigint", null, required: false, false);
		Add("Tiền / ngọc", "CashShopData", "AccountID", "varchar", 10, required: true, false);
		array = new string[3] { "WCoinC", "WCoinP", "GoblinPoint" };
		foreach (string column11 in array)
		{
			Add("Tiền / ngọc", "CashShopData", column11, "int", null, required: true, false);
		}
		Add("Tiền / ngọc", "DATDAT_BANK", "AccountID", "varchar", 10, required: true, false);
		array = new string[10] { "Bless", "Soul", "Life", "Creation", "Guardian", "Harmony", "GemStone", "Chaos", "LowStone", "HighStone" };
		foreach (string column12 in array)
		{
			Add("Tiền / ngọc", "DATDAT_BANK", column12, "int", null, required: true, false);
		}
		array = new string[2] { "warehouse", "ExtWarehouse" };
		foreach (string table in array)
		{
			string feature = ((table == "warehouse") ? "Kho chính" : "Kho mở rộng");
			Add(feature, table, "AccountID", "varchar", 10, required: true, false);
			Add(feature, table, "Items", "varbinary", 3840, required: true, false);
			Add(feature, table, "Money", "int", null, required: true, false);
			if (table == "ExtWarehouse")
			{
				Add(feature, table, "Number", "int", null, required: true, false);
			}
		}
		Add("Tạo vật phẩm trong kho", "MEMB_STAT", "memb___id", "varchar", 10, required: true, false);
		Add("Tạo vật phẩm trong kho", "MEMB_STAT", "ConnectStat", "tinyint", null, required: true, false);
		Add("Xóa nhân vật", "Guild", "G_Master", "varchar", 10, required: true, false);
		array = new string[23]
		{
			"GuildMember", "OptionData", "QuestKillCount", "EventLeoTheHelper", "EventSantaClaus", "QuestWorld", "Gens_Duprian", "Gens_Varnert", "Gens_Rank", "Gens_Reward",
			"RankingDuel", "RankingBloodCastle", "RankingChaosCastle", "RankingDevilSquare", "RankingIllusionTemple", "RankingKingPlayer", "RankingTvT", "HelperData", "CustomAttack", "CustomQuest",
			"CustomNpcQuest", "GoblinMix", "T_FriendMain"
		};
		foreach (string table2 in array)
		{
			Add("Xóa nhân vật", table2, "Name", "varchar", 10, required: true, false);
		}
		Add("Xóa nhân vật", "MasterSkillTree", "Name", "varchar", 50, required: true, false);
		Add("Xóa nhân vật", "Marry", "Character", "varchar", 15, required: true, false);
		Add("Xóa nhân vật", "Marry", "MarryCharacter", "varchar", 15, required: true, false);
		array = new string[3] { "T_FriendList", "T_WaitFriend", "T_FriendMail" };
		foreach (string table3 in array)
		{
			Add("Xóa nhân vật", table3, "FriendName", "varchar", 10, required: true, false);
			Add("Xóa nhân vật", table3, "GUID", "int", null, required: true, false);
		}
		Add("Xóa nhân vật", "T_CGuid", "Name", "varchar", 10, required: true, false);
		Add("Xóa nhân vật", "T_CGuid", "GUID", "int", null, required: true, null);
		Add("Tạo nhân vật", "MUSVEN_CharacterCreateDefaults", "ConfigID", "tinyint", null, required: true, false);
		array = new string[9] { "StartLevel", "StartPoints", "StartZen", "StartReset", "MasterLevel", "MasterPoints", "WCoinC", "WCoinP", "GoblinPoint" };
		foreach (string column13 in array)
		{
			Add("Tạo nhân vật", "MUSVEN_CharacterCreateDefaults", column13, "int", null, required: true, false);
		}
		Add("Tạo nhân vật", "MUSVEN_CharacterCreateDefaults", "ModifiedAt", "datetime", null, required: true, false);
		return specs.ToArray();
		void Add(string feature2, string table4, string column14, string type, int? length = null, bool required = true, bool? identity2 = false)
		{
			specs.Add(new ColumnSpec(feature2, table4, column14, type, length, required, identity2));
		}
	}
}
