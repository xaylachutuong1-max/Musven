namespace MuSven09M.Modules.Warehouse;

public sealed record CurrencyBalanceSnapshot(string AccountId, int WCoinC, int WCoinP, int GoblinPoint, int Bless, int Soul, int Life, int Creation, int Guardian, int Harmony, int GemStone, int Chaos, int LowStone, int HighStone);
