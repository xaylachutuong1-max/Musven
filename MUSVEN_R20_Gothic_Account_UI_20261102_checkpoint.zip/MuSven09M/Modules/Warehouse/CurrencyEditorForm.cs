using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Warehouse;

public sealed class CurrencyEditorForm : Form
{
	private static readonly Color Background = Color.FromArgb(5, 11, 23);

	private static readonly Color Surface = Color.FromArgb(11, 24, 43);

	private static readonly Color Border = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions options;

	private readonly bool writesEnabled;

	private readonly string accountId;

	private readonly TextBox[] fields = new TextBox[13];

	private readonly Label status = new Label
	{
		Dock = DockStyle.Fill,
		ForeColor = Ice,
		TextAlign = ContentAlignment.MiddleLeft,
		AutoEllipsis = true
	};

	private readonly Button saveButton;

	private CurrencyBalanceSnapshot? original;

	public CurrencyEditorForm(SqlAccountLookupOptions options, bool writesEnabled, string accountId)
	{
		this.options = options ?? throw new ArgumentNullException("options");
		this.writesEnabled = writesEnabled;
		this.accountId = (string.IsNullOrWhiteSpace(accountId) ? string.Empty : accountId.Trim());
		Text = "MU SVEN • Tiền và ngân hàng ngọc";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(820, 590);
		base.Size = new Size(920, 690);
		BackColor = Background;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		base.FormBorderStyle = FormBorderStyle.Sizable;
		base.MinimizeBox = false;
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 4,
			Padding = new Padding(12),
			BackColor = Background
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72f));
		base.Controls.Add(root);
		root.Controls.Add(new Label
		{
			Text = "TÀI KHOẢN  " + this.accountId + "     •     CashShopData + DATDAT_BANK",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			Font = new Font("Segoe UI", 12f, FontStyle.Bold),
			TextAlign = ContentAlignment.MiddleLeft
		}, 0, 0);
		TableLayoutPanel groups = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = Padding.Empty
		};
		groups.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 39f));
		groups.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 61f));
		groups.Controls.Add(BuildCashPanel(), 0, 0);
		groups.Controls.Add(BuildJewelPanel(), 1, 0);
		root.Controls.Add(groups, 0, 1);
		root.Controls.Add(status, 0, 2);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = Padding.Empty
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 142f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 116f));
		string modeMessage = (writesEnabled ? "GHI ĐANG MỞ • tài khoản phải offline; lưu tiền/ngọc dùng một giao dịch chung." : "CHỈ ĐỌC • mở khóa riêng trong [MUSVEN_CURRENCY_WRITES] Enabled=1 sau khi cấp quyền SQL.");
		Label notice = new Label
		{
			Text = modeMessage,
			Dock = DockStyle.Fill,
			ForeColor = (writesEnabled ? Gold : Ice),
			TextAlign = ContentAlignment.MiddleLeft,
			AutoEllipsis = true
		};
		footer.Controls.Add(notice, 0, 0);
		Button reload = MakeButton("TẢI LẠI", emphasized: false);
		reload.Click += async delegate
		{
			await LoadSnapshotAsync();
		};
		footer.Controls.Add(reload, 1, 0);
		saveButton = MakeButton("LƯU", emphasized: true);
		saveButton.Enabled = writesEnabled;
		saveButton.Click += async delegate
		{
			await SaveAsync();
		};
		footer.Controls.Add(saveButton, 2, 0);
		root.Controls.Add(footer, 0, 3);
		base.Shown += async delegate
		{
			UiTheme.Apply(this);
			await LoadSnapshotAsync();
		};
	}

	private Control BuildCashPanel()
	{
		Panel panel = MakePanel("ĐIỂM TIỀN TỆ • CASH SHOP DATA");
		TableLayoutPanel layout = new TableLayoutPanel
		{
			Dock = DockStyle.Top,
			ColumnCount = 2,
			RowCount = 4,
			Padding = new Padding(12),
			AutoSize = true
		};
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		string[] names = new string[3] { "WCoin C", "WCoin P", "Goblin Point" };
		int[] indices = new int[3] { 0, 1, 2 };
		for (int i = 0; i < names.Length; i++)
		{
			layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
			layout.Controls.Add(MakeLabel(names[i]), 0, i);
			fields[indices[i]] = MakeField();
			layout.Controls.Add(fields[indices[i]], 1, i);
		}
		layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		Label hint = new Label
		{
			Text = "Chỉ sửa ba cột số đã xác nhận. Dòng CashShopData phải tồn tại; Musven không tự tạo tài khoản.",
			Dock = DockStyle.Fill,
			ForeColor = Color.Gainsboro,
			TextAlign = ContentAlignment.TopLeft,
			Padding = new Padding(0, 12, 0, 0),
			AutoSize = false
		};
		layout.Controls.Add(hint, 0, 3);
		layout.SetColumnSpan(hint, 2);
		panel.Controls.Add(layout);
		return panel;
	}

	private Control BuildJewelPanel()
	{
		Panel panel = MakePanel("NGÂN HÀNG NGỌC • DATDAT_BANK");
		TableLayoutPanel layout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 5,
			Padding = new Padding(8, 4, 8, 8)
		};
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		string[] names = new string[10] { "Bless", "Soul", "Life", "Creation", "Guardian", "Harmony", "GemStone", "Chaos", "LowStone", "HighStone" };
		for (int row = 0; row < 5; row++)
		{
			layout.RowStyles.Add(new RowStyle(SizeType.Percent, 20f));
		}
		for (int i = 0; i < names.Length; i++)
		{
			int index = i + 3;
			TableLayoutPanel cell = new TableLayoutPanel
			{
				Dock = DockStyle.Fill,
				ColumnCount = 2,
				RowCount = 1,
				Margin = new Padding(2)
			};
			cell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46f));
			cell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54f));
			cell.Controls.Add(MakeLabel(names[i]), 0, 0);
			fields[index] = MakeField();
			cell.Controls.Add(fields[index], 1, 0);
			layout.Controls.Add(cell, i % 2, i / 2);
		}
		panel.Controls.Add(layout);
		return panel;
	}

	private async Task LoadSnapshotAsync()
	{
		int length = accountId.Length;
		if ((length < 1 || length > 10) ? true : false)
		{
			status.Text = "AccountID chưa hợp lệ (tối đa 10 ký tự).";
			return;
		}
		SetInputsEnabled(enabled: false);
		status.Text = "ĐANG TẢI SỐ DƯ...";
		try
		{
			string connectionString = options.CreateConnectionString();
			int[] values = Values(original = await Task.Run(() => new CurrencyRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).Load(accountId)));
			for (int i = 0; i < fields.Length; i++)
			{
				fields[i].Text = values[i].ToString("N0", CultureInfo.CurrentCulture);
			}
			status.Text = "ĐÃ TẢI • dữ liệu chỉ thay đổi sau khi bấm Lưu.";
		}
		catch
		{
			original = null;
			status.Text = "Không tải được. Kiểm tra bảng/cột CashShopData, DATDAT_BANK và quyền SELECT.";
		}
		finally
		{
			SetInputsEnabled(writesEnabled && (object)original != null);
			saveButton.Enabled = writesEnabled && (object)original != null;
		}
	}

	private async Task SaveAsync()
	{
		if (!writesEnabled || (object)original == null)
		{
			return;
		}
		int[] parsed = new int[fields.Length];
		for (int i = 0; i < fields.Length; i++)
		{
			if (!int.TryParse(fields[i].Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out parsed[i]) || parsed[i] < 0)
			{
				status.Text = "Mỗi số dư phải là số nguyên không âm trong giới hạn INT.";
				fields[i].Focus();
				return;
			}
		}
		CurrencyBalanceSnapshot updated = new CurrencyBalanceSnapshot(accountId, parsed[0], parsed[1], parsed[2], parsed[3], parsed[4], parsed[5], parsed[6], parsed[7], parsed[8], parsed[9], parsed[10], parsed[11], parsed[12]);
		if (MessageBox.Show(this, "Cập nhật tiền/ngọc cho tài khoản " + accountId + "? Tài khoản phải offline. Nếu số dư trên SQL đã đổi, Musven sẽ từ chối ghi.", "MU SVEN • Xác nhận sửa số dư", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return;
		}
		saveButton.Enabled = false;
		status.Text = "ĐANG LƯU GIAO DỊCH...";
		try
		{
			string connectionString = options.CreateConnectionString(readOnly: false);
			await Task.Run(delegate
			{
				new CurrencyRepository(new MuSvenDatabase(SqlClientFactory.Instance, connectionString)).Save(original, updated, writesEnabled);
			});
			original = updated;
			status.Text = "ĐÃ LƯU • tiền và ngọc đã cập nhật trong cùng giao dịch.";
			base.DialogResult = DialogResult.OK;
		}
		catch (Exception ex)
		{
			status.Text = "LƯU THẤT BẠI • " + ex.Message;
			MessageBox.Show(this, ex.Message, "MU SVEN • Không thể lưu", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}
		finally
		{
			saveButton.Enabled = writesEnabled && (object)original != null;
		}
	}

	private void SetInputsEnabled(bool enabled)
	{
		foreach (TextBox item in fields.Where((TextBox field) => field != null))
		{
			item.Enabled = enabled;
		}
	}

	private static int[] Values(CurrencyBalanceSnapshot value)
	{
		return new int[13]
		{
			value.WCoinC, value.WCoinP, value.GoblinPoint, value.Bless, value.Soul, value.Life, value.Creation, value.Guardian, value.Harmony, value.GemStone,
			value.Chaos, value.LowStone, value.HighStone
		};
	}

	private static Panel MakePanel(string title)
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill,
			BackColor = Surface,
			Margin = new Padding(5),
			Padding = new Padding(8, 42, 8, 8)
		};
		panel.Controls.Add(new Label
		{
			Text = title,
			Location = new Point(12, 7),
			Size = new Size(420, 30),
			ForeColor = Gold,
			Font = new Font("Segoe UI", 10f, FontStyle.Bold),
			AutoEllipsis = true
		});
		panel.Paint += delegate(object? _, PaintEventArgs e)
		{
			using Pen pen = new Pen(Border, 1.3f);
			e.Graphics.DrawRectangle(pen, 1, 1, Math.Max(1, panel.Width - 3), Math.Max(1, panel.Height - 3));
		};
		return panel;
	}

	private static Label MakeLabel(string text)
	{
		return new Label
		{
			Text = text,
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			TextAlign = ContentAlignment.MiddleLeft,
			AutoEllipsis = true
		};
	}

	private static TextBox MakeField()
	{
		return new TextBox
		{
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(18, 37, 58),
			ForeColor = Color.White,
			BorderStyle = BorderStyle.FixedSingle,
			TextAlign = HorizontalAlignment.Right,
			Margin = new Padding(3, 8, 3, 8)
		};
	}

	private static Button MakeButton(string text, bool emphasized)
	{
		Button button = new Button();
		button.Text = text;
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (emphasized ? Gold : Color.FromArgb(18, 51, 82));
		button.ForeColor = (emphasized ? Color.Black : Color.White);
		button.Margin = new Padding(4);
		button.Cursor = Cursors.Hand;
		button.FlatAppearance.BorderColor = (emphasized ? Gold : Border);
		return button;
	}
}
