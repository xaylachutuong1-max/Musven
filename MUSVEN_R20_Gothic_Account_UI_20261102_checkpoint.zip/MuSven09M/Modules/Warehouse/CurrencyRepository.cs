using System;
using System.Data;
using System.Data.Common;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Warehouse;

public sealed class CurrencyRepository
{
	private readonly MuSvenDatabase database;

	public CurrencyRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public CurrencyBalanceSnapshot Load(string accountId)
	{
		string id = ValidateAccount(accountId);
		using DbConnection connection = database.OpenConnection();
		return ReadSnapshot(connection, null, id, lockRows: false);
	}

	public void Save(CurrencyBalanceSnapshot original, CurrencyBalanceSnapshot updated, bool writesEnabled)
	{
		ArgumentNullException.ThrowIfNull(original, "original");
		ArgumentNullException.ThrowIfNull(updated, "updated");
		if (!writesEnabled)
		{
			throw new InvalidOperationException("Sửa tiền/ngọc đang khóa. Bật riêng [MUSVEN_CURRENCY_WRITES] Enabled=1 sau khi cấp quyền SQL phù hợp.");
		}
		string id = ValidateAccount(original.AccountId);
		if (!id.Equals(ValidateAccount(updated.AccountId), StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("AccountID đã thay đổi; hãy tải lại số dư trước khi lưu.");
		}
		ValidateBalances(updated);
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		EnsureOffline(connection, transaction, id);
		if (ReadSnapshot(connection, transaction, id, lockRows: true) != original)
		{
			throw new InvalidOperationException("Số dư đã thay đổi kể từ lúc tải. Musven không ghi đè dữ liệu mới; hãy tải lại rồi thử lại.");
		}
		using (DbCommand command = connection.CreateCommand())
		{
			command.Transaction = transaction;
			command.CommandText = "\nUPDATE dbo.CashShopData\nSET WCoinC = @WCoinC, WCoinP = @WCoinP, GoblinPoint = @GoblinPoint\nWHERE AccountID = @AccountId";
			command.CommandTimeout = 5;
			AddAccount(command, id);
			AddInt(command, "@WCoinC", updated.WCoinC);
			AddInt(command, "@WCoinP", updated.WCoinP);
			AddInt(command, "@GoblinPoint", updated.GoblinPoint);
			if (command.ExecuteNonQuery() != 1)
			{
				throw new InvalidOperationException("Không cập nhật được đúng một dòng dbo.CashShopData; giao dịch đã bị hủy.");
			}
		}
		using (DbCommand command2 = connection.CreateCommand())
		{
			command2.Transaction = transaction;
			command2.CommandText = "\nUPDATE dbo.DATDAT_BANK\nSET Bless = @Bless, Soul = @Soul, Life = @Life, Creation = @Creation,\n    Guardian = @Guardian, Harmony = @Harmony, GemStone = @GemStone,\n    Chaos = @Chaos, LowStone = @LowStone, HighStone = @HighStone\nWHERE AccountID = @AccountId";
			command2.CommandTimeout = 5;
			AddAccount(command2, id);
			AddInt(command2, "@Bless", updated.Bless);
			AddInt(command2, "@Soul", updated.Soul);
			AddInt(command2, "@Life", updated.Life);
			AddInt(command2, "@Creation", updated.Creation);
			AddInt(command2, "@Guardian", updated.Guardian);
			AddInt(command2, "@Harmony", updated.Harmony);
			AddInt(command2, "@GemStone", updated.GemStone);
			AddInt(command2, "@Chaos", updated.Chaos);
			AddInt(command2, "@LowStone", updated.LowStone);
			AddInt(command2, "@HighStone", updated.HighStone);
			if (command2.ExecuteNonQuery() != 1)
			{
				throw new InvalidOperationException("Không cập nhật được đúng một dòng dbo.DATDAT_BANK; giao dịch đã bị hủy.");
			}
		}
		transaction.Commit();
	}

	private static CurrencyBalanceSnapshot ReadSnapshot(DbConnection connection, DbTransaction? transaction, string id, bool lockRows)
	{
		string lockHint = (lockRows ? " WITH (UPDLOCK, HOLDLOCK)" : string.Empty);
		int[] cash;
		using (DbCommand command = connection.CreateCommand())
		{
			command.Transaction = transaction;
			command.CommandText = "\nSELECT TOP (2) WCoinC, WCoinP, GoblinPoint\nFROM dbo.CashShopData" + lockHint + "\nWHERE AccountID = @AccountId";
			command.CommandTimeout = 5;
			AddAccount(command, id);
			using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
			if (!reader.Read())
			{
				throw new InvalidOperationException("Không tìm thấy tài khoản trong dbo.CashShopData; Musven không tự tạo dòng.");
			}
			cash = new int[3]
			{
				NullableInt(reader, 0),
				NullableInt(reader, 1),
				NullableInt(reader, 2)
			};
			if (reader.Read())
			{
				throw new InvalidOperationException("dbo.CashShopData có nhiều dòng cho cùng AccountID; giao dịch bị hủy.");
			}
		}
		int[] jewels;
		using (DbCommand command2 = connection.CreateCommand())
		{
			command2.Transaction = transaction;
			command2.CommandText = "\nSELECT TOP (2) Bless, Soul, Life, Creation, Guardian, Harmony, GemStone, Chaos, LowStone, HighStone\nFROM dbo.DATDAT_BANK" + lockHint + "\nWHERE AccountID = @AccountId";
			command2.CommandTimeout = 5;
			AddAccount(command2, id);
			using DbDataReader reader2 = command2.ExecuteReader(CommandBehavior.SequentialAccess);
			if (!reader2.Read())
			{
				throw new InvalidOperationException("Không tìm thấy tài khoản trong dbo.DATDAT_BANK; Musven không tự tạo dòng.");
			}
			jewels = new int[10];
			for (int i = 0; i < jewels.Length; i++)
			{
				jewels[i] = NullableInt(reader2, i);
			}
			if (reader2.Read())
			{
				throw new InvalidOperationException("dbo.DATDAT_BANK có nhiều dòng cho cùng AccountID; giao dịch bị hủy.");
			}
		}
		return new CurrencyBalanceSnapshot(id, cash[0], cash[1], cash[2], jewels[0], jewels[1], jewels[2], jewels[3], jewels[4], jewels[5], jewels[6], jewels[7], jewels[8], jewels[9]);
	}

	private static void EnsureOffline(DbConnection connection, DbTransaction transaction, string id)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandText = "\nSELECT TOP (2) ConnectStat\nFROM dbo.MEMB_STAT WITH (UPDLOCK, HOLDLOCK)\nWHERE memb___id = @AccountId";
		command.CommandTimeout = 5;
		AddAccount(command, id);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Không xác nhận được trạng thái tài khoản trong dbo.MEMB_STAT; Musven từ chối ghi.");
		}
		if (reader.IsDBNull(0) || Convert.ToInt32(reader.GetValue(0)) != 0)
		{
			throw new InvalidOperationException("Tài khoản đang online hoặc trạng thái chưa rõ; hãy ngắt kết nối trước khi sửa tiền/ngọc.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.MEMB_STAT có nhiều dòng cho cùng tài khoản; Musven từ chối ghi.");
		}
	}

	private static void ValidateBalances(CurrencyBalanceSnapshot value)
	{
		if (Array.Exists(new int[13]
		{
			value.WCoinC, value.WCoinP, value.GoblinPoint, value.Bless, value.Soul, value.Life, value.Creation, value.Guardian, value.Harmony, value.GemStone,
			value.Chaos, value.LowStone, value.HighStone
		}, (int amount) => amount < 0))
		{
			throw new ArgumentOutOfRangeException("value", "Số dư tiền/ngọc không được âm.");
		}
	}

	private static string ValidateAccount(string accountId)
	{
		string obj = accountId?.Trim() ?? string.Empty;
		int length = obj.Length;
		if ((length < 1 || length > 10) ? true : false)
		{
			throw new ArgumentException("AccountID phải có từ 1 đến 10 ký tự.", "accountId");
		}
		return obj;
	}

	private static int NullableInt(DbDataReader reader, int ordinal)
	{
		if (!reader.IsDBNull(ordinal))
		{
			return Convert.ToInt32(reader.GetValue(ordinal));
		}
		return 0;
	}

	private static void AddAccount(DbCommand command, string id)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = "@AccountId";
		parameter.DbType = DbType.String;
		parameter.Size = 10;
		parameter.Value = id;
		command.Parameters.Add(parameter);
	}

	private static void AddInt(DbCommand command, string name, int value)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = DbType.Int32;
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}
}
