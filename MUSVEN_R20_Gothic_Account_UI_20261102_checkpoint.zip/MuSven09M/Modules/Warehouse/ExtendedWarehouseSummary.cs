namespace MuSven09M.Modules.Warehouse;

public sealed record ExtendedWarehouseSummary(string AccountId, int Number, int Money, int? ItemBytes);
