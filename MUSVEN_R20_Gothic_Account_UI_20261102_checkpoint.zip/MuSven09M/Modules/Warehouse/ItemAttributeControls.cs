using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MuSven09M.Modules.Warehouse;

internal sealed class ItemAttributeControls
{
	private static readonly int[] SocketIds = new int[30]
	{
		0, 1, 2, 3, 4, 5, 10, 11, 12, 13,
		14, 16, 17, 18, 19, 20, 21, 22, 23, 24,
		25, 26, 29, 30, 31, 32, 34, 35, 36, 37
	};

	private static readonly string[] SocketNames = new string[30]
	{
		"Tăng sức tấn công/ma lực theo cấp", "Tăng tốc độ tấn công", "Tăng tấn công/ma lực tối đa", "Tăng tấn công/ma lực tối thiểu", "Tăng sức tấn công/ma lực", "Giảm tiêu hao AG", "Tăng phòng thủ hoàn hảo", "Tăng phòng thủ", "Tăng phòng thủ SD", "Giảm sát thương",
		"Phản hồi sát thương", "Hồi HP khi diệt quái", "Hồi Mana khi diệt quái", "Tăng sát thương kỹ năng", "Tăng khả năng tấn công", "Tăng độ bền vật phẩm", "Phục hồi HP", "Tăng HP tối đa", "Tăng Mana tối đa", "Phục hồi Mana",
		"Tăng Nội lực tối đa", "Tăng hồi Nội lực", "Tăng sát thương hoàn hảo", "Tăng tỷ lệ hoàn hảo", "Tăng sát thương chí mạng", "Tăng tỷ lệ chí mạng", "Tăng Sức mạnh", "Tăng Nhanh nhẹn", "Tăng Thể lực", "Tăng Năng lượng"
	};

	public readonly ComboBox Harmony = Combo();

	public readonly NumericUpDown HarmonyLevel = Number(0, 15);

	public readonly ComboBox[] Sockets = (from _ in Enumerable.Range(0, 5)
		select Combo()).ToArray();

	public readonly ComboBox[] SocketLevels = (from _ in Enumerable.Range(0, 5)
		select new ComboBox
		{
			DropDownStyle = ComboBoxStyle.DropDownList,
			Width = 55
		}).ToArray();

	private int harmonyByte;

	private bool harmonyChanged;

	public int HarmonyValue
	{
		get
		{
			if (harmonyChanged)
			{
				NamedOption obj = Harmony.SelectedItem as NamedOption;
				if ((object)obj != null && obj.Id != 0)
				{
					return (((NamedOption)Harmony.SelectedItem).Id << 4) | (int)HarmonyLevel.Value;
				}
				return 0;
			}
			return harmonyByte;
		}
	}

	internal static IReadOnlyList<(int Id, string Name)> GetSocketOptions()
	{
		return new(int, string)[2]
		{
			(255, "Không có Socket"),
			(254, "[Socket] Free Slot — ô trống")
		}.Concat(SocketIds.Select((int id, int i) => (id: id, "[Socket] " + SocketNames[i]))).ToArray();
	}

	internal static IReadOnlyList<(int Id, string Name)> GetHarmonyOptions(int section)
	{
		string[] names = ((section != 5) ? ((section < 6) ? new string[10] { "Tăng lực tấn công thấp nhất", "Tăng lực tấn công cao nhất", "Giảm yêu cầu sức mạnh", "Giảm yêu cầu nhanh nhẹn", "Tăng lực tấn công thấp nhất/cao nhất", "Tăng sát thương chí mạng", "Tăng sát thương kỹ năng", "Tăng tỷ lệ tấn công (PVP)", "Tăng khả năng giảm SD", "Tăng khả năng loại bỏ SD" } : new string[8] { "Tăng phòng thủ", "Tăng AG tối đa", "Tăng HP tối đa", "Tăng hồi HP", "Tăng hồi Mana", "Tăng tỷ lệ phòng thủ (PVP)", "Giảm sát thương", "Tăng tỷ lệ SD" }) : new string[8] { "Tăng ma lực", "Giảm yêu cầu sức mạnh", "Giảm yêu cầu nhanh nhẹn", "Tăng sát thương kỹ năng", "Tăng sát thương chí mạng", "Tăng khả năng giảm SD", "Tăng tỷ lệ tấn công (PVP)", "Tăng khả năng loại bỏ SD" });
		return new(int, string)[1] { (0, "None") }.Concat(names.Select((string name, int i) => (i + 1, name: name))).ToArray();
	}

	private static ComboBox Combo()
	{
		return new ComboBox
		{
			DropDownStyle = ComboBoxStyle.DropDownList,
			Width = 330,
			DropDownWidth = 480
		};
	}

	private static NumericUpDown Number(int min, int max)
	{
		return new NumericUpDown
		{
			Minimum = min,
			Maximum = max,
			Value = min,
			Width = 55
		};
	}

	public ItemAttributeControls()
	{
		for (int i = 0; i < 5; i++)
		{
			for (int level = 1; level <= 5; level++)
			{
				SocketLevels[i].Items.Add(level.ToString());
			}
			SocketLevels[i].SelectedIndex = 0;
			ComboBox c = Sockets[i];
			foreach (var option in GetSocketOptions())
			{
				c.Items.Add(new NamedOption(option.Id, option.Name));
			}
			c.SelectedIndex = 0;
			int row = i;
			c.SelectedIndexChanged += delegate
			{
				ComboBox obj = SocketLevels[row];
				int id = ((NamedOption)c.SelectedItem).Id;
				obj.Enabled = id >= 0 && id < 250;
			};
			SocketLevels[i].Enabled = false;
		}
		Harmony.SelectedIndexChanged += delegate
		{
			NumericUpDown harmonyLevel = HarmonyLevel;
			NamedOption obj = Harmony.SelectedItem as NamedOption;
			harmonyLevel.Enabled = (object)obj != null && obj.Id > 0;
			harmonyChanged = true;
		};
		HarmonyLevel.ValueChanged += delegate
		{
			harmonyChanged = true;
		};
		SetHarmonyGroup(0, 0);
	}

	public void SetHarmonyGroup(int section, int value)
	{
		harmonyByte = value;
		IReadOnlyList<(int Id, string Name)> harmonyOptions = GetHarmonyOptions(section);
		Harmony.Items.Clear();
		foreach (var option in harmonyOptions)
		{
			Harmony.Items.Add(new NamedOption(option.Id, option.Name));
		}
		int id = value >> 4;
		if (id >= Harmony.Items.Count)
		{
			Harmony.Items.Add(new NamedOption(id, $"Giữ thuộc tính chưa nhận diện ({id})"));
		}
		Harmony.SelectedItem = Harmony.Items.Cast<NamedOption>().First((NamedOption x) => x.Id == id);
		HarmonyLevel.Value = value & 0xF;
		harmonyChanged = false;
	}

	public byte[] SocketValues()
	{
		byte[] values = Sockets.Select(delegate(ComboBox c, int i)
		{
			int id = ((NamedOption)c.SelectedItem).Id;
			return (byte)((id < 0) ? (-id - 1) : ((id >= 254) ? id : (id + 50 * SocketLevels[i].SelectedIndex)));
		}).ToArray();
		bool ended = false;
		byte[] array = values;
		for (int num = 0; num < array.Length; num++)
		{
			if (array[num] == byte.MaxValue)
			{
				ended = true;
			}
			else if (ended)
			{
				throw new InvalidOperationException("Socket phải liên tục: không đặt hạt sau ô không có Socket.");
			}
		}
		return values;
	}

	public void LoadSockets(byte[] values)
	{
		for (int i = 0; i < 5; i++)
		{
			int v = values[i];
			int id = ((v >= 250 && v <= 253) ? (-v - 1) : ((v >= 254) ? v : (v % 50)));
			ComboBox c = Sockets[i];
			NamedOption option = c.Items.Cast<NamedOption>().FirstOrDefault((NamedOption x) => x.Id == id);
			if ((object)option == null)
			{
				option = new NamedOption(id, $"Giữ mã Socket {id}");
				c.Items.Add(option);
			}
			c.SelectedItem = option;
			SocketLevels[i].SelectedIndex = ((v < 250) ? (v / 50) : 0);
		}
	}

	public Control HarmonyPanel()
	{
		TableLayoutPanel obj = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 2,
			BackColor = Color.FromArgb(11, 24, 43),
			Margin = Padding.Empty,
			Padding = Padding.Empty,
			RowStyles = 
			{
				new RowStyle(SizeType.Absolute, 21f),
				new RowStyle(SizeType.Percent, 100f)
			},
			Controls = { 
			{
				(Control)new Label
				{
					Text = "HARMONY OPTION",
					Dock = DockStyle.Fill,
					ForeColor = Color.FromArgb(249, 188, 71),
					Font = new Font("Segoe UI", 9f, FontStyle.Bold),
					TextAlign = ContentAlignment.MiddleLeft,
					AutoEllipsis = true
				},
				0,
				0
			} }
		};
		TableLayoutPanel row = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = Padding.Empty,
			Padding = Padding.Empty
		};
		row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 42f));
		row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 70f));
		Harmony.Dock = DockStyle.Fill;
		Harmony.Margin = new Padding(0, 2, 2, 2);
		Harmony.DropDownWidth = 420;
		HarmonyLevel.Dock = DockStyle.Fill;
		HarmonyLevel.Margin = new Padding(0, 2, 0, 2);
		row.Controls.Add(Harmony, 0, 0);
		row.Controls.Add(new Label
		{
			Text = "Cấp",
			Dock = DockStyle.Fill,
			ForeColor = Color.White,
			TextAlign = ContentAlignment.MiddleCenter,
			AutoSize = false
		}, 1, 0);
		row.Controls.Add(HarmonyLevel, 2, 0);
		obj.Controls.Add(row, 0, 1);
		return obj;
	}

	public Control SocketPanel()
	{
		FlowLayoutPanel p = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			AutoScroll = true,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false
		};
		for (int i = 0; i < 5; i++)
		{
			FlowLayoutPanel row = new FlowLayoutPanel
			{
				Width = 520,
				Height = 32,
				WrapContents = false,
				Margin = new Padding(0)
			};
			row.Controls.Add(new Label
			{
				Text = $"{i + 1}",
				Width = 20,
				ForeColor = Color.White,
				Margin = new Padding(3)
			});
			row.Controls.Add(Sockets[i]);
			row.Controls.Add(new Label
			{
				Text = "Cấp",
				AutoSize = true,
				ForeColor = Color.White,
				Padding = new Padding(0, 7, 0, 0)
			});
			row.Controls.Add(SocketLevels[i]);
			p.Controls.Add(row);
		}
		return p;
	}
}
