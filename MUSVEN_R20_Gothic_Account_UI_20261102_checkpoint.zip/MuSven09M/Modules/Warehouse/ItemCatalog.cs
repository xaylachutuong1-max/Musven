using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace MuSven09M.Modules.Warehouse;

public static class ItemCatalog
{
	private static readonly string[] Categories = new string[16]
	{
		"Kiếm", "Rìu", "Chùy", "Giáo", "Cung / nỏ", "Gậy", "Khiên", "Mũ", "Áo giáp", "Quần",
		"Găng", "Chân", "Cánh / phụ kiện", "Vật phẩm đặc biệt", "Ngọc / vật phẩm", "Khác"
	};

	private static readonly Lazy<IReadOnlyList<ItemDefinition>> Loaded = new Lazy<IReadOnlyList<ItemDefinition>>(LoadEmbedded);

	public static IReadOnlyList<ItemDefinition> All => Loaded.Value;

	public static IReadOnlyDictionary<int, ItemDefinition> ByIndex { get; } = All.ToDictionary((ItemDefinition x) => x.ItemIndex);

	public static string CategoryName(int section)
	{
		if (section < 0 || section >= Categories.Length)
		{
			return $"Nhóm {section}";
		}
		return Categories[section];
	}

	private static IReadOnlyList<ItemDefinition> LoadEmbedded()
	{
		using Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("MuSven.Resources.Assets.ItemCatalog.xml") ?? throw new InvalidOperationException("Musven không tìm thấy danh mục vật phẩm của server trong gói ứng dụng.");
		using StreamReader reader = new StreamReader(stream);
		XDocument xDocument = XDocument.Parse(Regex.Replace(reader.ReadToEnd(), "(?s)<!--.*?-->", string.Empty).TrimStart('\ufeff', ' ', '\t', '\r', '\n'), LoadOptions.None);
		List<ItemDefinition> result = new List<ItemDefinition>();
		foreach (XElement section in xDocument.Root?.Elements("Section") ?? Enumerable.Empty<XElement>())
		{
			if (!TryInt(section.Attribute("Index")?.Value, out var sectionIndex))
			{
				continue;
			}
			foreach (XElement item in section.Elements("Item"))
			{
				if (!TryInt(item.Attribute("Index")?.Value, out var id) || !TryInt(item.Attribute("Width")?.Value, out var width) || !TryInt(item.Attribute("Height")?.Value, out var height) || !string.Equals(item.Attribute("WhareHouse")?.Value, "1", StringComparison.Ordinal))
				{
					continue;
				}
				string name = item.Attribute("Name")?.Value.Trim();
				bool flag = string.IsNullOrWhiteSpace(name);
				if (!flag)
				{
					bool flag2 = ((width < 1 || width > 8) ? true : false);
					flag = flag2;
				}
				bool flag3 = flag;
				if (!flag3)
				{
					bool flag2 = ((height < 1 || height > 30) ? true : false);
					flag3 = flag2;
				}
				bool flag4 = flag3;
				if (!flag4)
				{
					bool flag2 = ((sectionIndex < 0 || sectionIndex > 15) ? true : false);
					flag4 = flag2;
				}
				bool flag5 = flag4;
				if (!flag5)
				{
					bool flag2 = ((id < 0 || id > 511) ? true : false);
					flag5 = flag2;
				}
				if (!flag5)
				{
					int index = sectionIndex * 512 + id;
					if (index != 6675 && index != 7232)
					{
						result.Add(new ItemDefinition(sectionIndex, id, index, name, width, height));
					}
				}
			}
		}
		if (result.Count == 0)
		{
			throw new InvalidOperationException("Danh mục vật phẩm của server không có vật phẩm hợp lệ được phép lưu kho.");
		}
		if ((from x in result
			group x by x.ItemIndex).Any((IGrouping<int, ItemDefinition> x) => x.Count() > 1))
		{
			throw new InvalidOperationException("Danh mục vật phẩm có ItemIndex trùng; Musven dừng để tránh tạo sai item.");
		}
		return (from x in result
			orderby x.Section, x.Id
			select x).ToArray();
	}

	private static bool TryInt(string? value, out int result)
	{
		return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out result);
	}
}
