namespace MuSven09M.Modules.Warehouse;

public sealed record ItemCreationOptions(int Level, int Option, int Durability, bool Skill, bool Luck, byte Excellent, int SetOption, int SpecialByte, byte[] Sockets);
