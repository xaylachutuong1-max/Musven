namespace MuSven09M.Modules.Warehouse;

public sealed record ItemDefinition(int Section, int Id, int ItemIndex, string Name, int Width, int Height)
{
	public string Category => ItemCatalog.CategoryName(Section);

	public string DisplayText => $"{Name}  ({Width}×{Height})  •  {Section}:{Id}";

	public override string ToString()
	{
		return $"{Name}  [{Section}:{Id}]";
	}
}
