using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

namespace MuSven09M.Modules.Warehouse;

internal static class ItemImages
{
	private static readonly Dictionary<int, Image?> Images = new Dictionary<int, Image>();

	public static Image? Get(ItemDefinition item)
	{
		if (Images.TryGetValue(item.ItemIndex, out Image cached))
		{
			return cached;
		}
		string path = Path.Combine(AppContext.BaseDirectory, "Assets", "ItemImages", item.Section.ToString(), item.Id + ".jpg");
		Image result = null;
		try
		{
			if (File.Exists(path))
			{
				using Image original = Image.FromFile(path);
				result = new Bitmap(original);
			}
		}
		catch (ArgumentException)
		{
		}
		catch (IOException)
		{
		}
		Images[item.ItemIndex] = result;
		return result;
	}

	public static Rectangle Fit(Image image, Rectangle area)
	{
		float scale = Math.Min((float)area.Width / (float)image.Width, (float)area.Height / (float)image.Height);
		int width = Math.Max(1, (int)((float)image.Width * scale));
		int height = Math.Max(1, (int)((float)image.Height * scale));
		return new Rectangle(area.X + (area.Width - width) / 2, area.Y + (area.Height - height) / 2, width, height);
	}
}
