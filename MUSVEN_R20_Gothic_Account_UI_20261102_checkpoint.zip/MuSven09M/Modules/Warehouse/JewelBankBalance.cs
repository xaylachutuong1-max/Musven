namespace MuSven09M.Modules.Warehouse;

public sealed record JewelBankBalance(string AccountId, int Bless, int Soul, int Life, int Creation, int Guardian, int Harmony, int GemStone, int Chaos, int LowStone, int HighStone);
