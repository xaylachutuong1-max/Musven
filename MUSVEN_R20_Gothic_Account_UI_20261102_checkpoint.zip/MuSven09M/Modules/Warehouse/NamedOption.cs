namespace MuSven09M.Modules.Warehouse;

internal sealed record NamedOption(int Id, string Name)
{
	public override string ToString()
	{
		return Name;
	}
}
