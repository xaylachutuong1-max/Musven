namespace MuSven09M.Modules.Warehouse;

public sealed record StagedWarehouseItem(ItemDefinition Item, ItemCreationOptions Options, int Slot);
