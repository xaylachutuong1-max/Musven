using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MuSven09M.Modules.Warehouse;

internal sealed class WarehouseGridControl : Control
{
	private ItemDefinition? draggedItem;

	private int? hoverSlot;

	private bool hoverValid;

	private IReadOnlyList<WarehousePlacement> placements = Array.Empty<WarehousePlacement>();

	public int? SelectedSlot { get; set; }

	public IReadOnlyList<WarehousePlacement> Placements
	{
		get
		{
			return placements;
		}
		set
		{
			placements = value;
			Invalidate();
		}
	}

	public event Action<WarehousePlacement, Point>? ItemContextRequested;

	public event Action<ItemDefinition, int>? ItemPlacementClicked;

	public event Action<ItemDefinition, int>? ItemDropped;

	public event Action<int?>? SelectedSlotChanged;

	public WarehouseGridControl()
	{
		AllowDrop = true;
		SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		Cursor = Cursors.Hand;
	}

	public void BeginPlacement(ItemDefinition item)
	{
		draggedItem = item;
		Cursor = Cursors.SizeAll;
		Invalidate();
	}

	public void EndPlacement()
	{
		draggedItem = null;
		hoverSlot = null;
		hoverValid = false;
		Cursor = Cursors.Hand;
		Invalidate();
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		if ((object)draggedItem == null)
		{
			return;
		}
		int cellW = Math.Max(1, base.ClientSize.Width / 16);
		int cellH = Math.Max(1, base.ClientSize.Height / 15);
		hoverSlot = ((e.X >= 0 && e.Y >= 0 && e.X < cellW * 16 && e.Y < cellH * 15) ? new int?(e.X / cellW / 8 * 120 + e.Y / cellH * 8 + e.X / cellW % 8) : ((int?)null));
		hoverValid = false;
		int? num = hoverSlot;
		if (num.HasValue)
		{
			int slot = num.GetValueOrDefault();
			try
			{
				WarehouseItemFormat.ValidatePlacement(draggedItem, slot, WarehouseItemFormat.BuildOccupancy(placements));
				hoverValid = true;
			}
			catch (InvalidOperationException)
			{
			}
		}
		Invalidate();
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		Graphics g = e.Graphics;
		g.Clear(Color.FromArgb(4, 9, 16));
		int cellW = Math.Max(1, base.ClientSize.Width / 16);
		int cellH = Math.Max(1, base.ClientSize.Height / 15);
		foreach (WarehousePlacement item in placements)
		{
			using SolidBrush fill = new SolidBrush(item.Pending ? Color.FromArgb(106, 79, 20) : Color.FromArgb(26, 61, 91));
			using Pen outline = new Pen(item.Pending ? Color.FromArgb(255, 195, 64) : Color.FromArgb(78, 145, 189), (!item.Pending) ? 1 : 2);
			int row = item.Slot / 8;
			int col = item.Slot % 8;
			for (int page = 0; page < 2; page++)
			{
				int firstRow = page * 15;
				int top = Math.Max(row, firstRow);
				int bottom = Math.Min(row + item.Item.Height, firstRow + 15);
				if (bottom <= top)
				{
					continue;
				}
				Rectangle rect = new Rectangle((page * 8 + col) * cellW + 1, (top - firstRow) * cellH + 1, Math.Max(1, item.Item.Width * cellW - 2), Math.Max(1, (bottom - top) * cellH - 2));
				g.FillRectangle(fill, rect);
				g.DrawRectangle(outline, rect);
				if (page == row / 15)
				{
					Rectangle labelRect = Rectangle.Inflate(rect, -3, -2);
					Image image = ItemImages.Get(item.Item);
					if (image != null && row + item.Item.Height <= firstRow + 15)
					{
						g.DrawImage(image, ItemImages.Fit(image, labelRect));
					}
					else
					{
						TextRenderer.DrawText(g, item.Item.Name, Font, labelRect, Color.WhiteSmoke, TextFormatFlags.EndEllipsis | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak);
					}
				}
			}
		}
		using Pen gridPen = new Pen(Color.FromArgb(83, 96, 112));
		for (int i = 0; i <= 16; i++)
		{
			g.DrawLine(gridPen, i * cellW, 0, i * cellW, base.ClientSize.Height);
		}
		for (int j = 0; j <= 15; j++)
		{
			g.DrawLine(gridPen, 0, j * cellH, base.ClientSize.Width, j * cellH);
		}
		using Pen separatorPen = new Pen(Color.FromArgb(255, 190, 63), 2f);
		g.DrawLine(separatorPen, 8 * cellW, 0, 8 * cellW, base.ClientSize.Height);
		int? selectedSlot = SelectedSlot;
		if (selectedSlot.HasValue)
		{
			int slot = selectedSlot.GetValueOrDefault();
			int page2 = slot / 120;
			int num = slot % 120;
			int localRow = num / 8;
			int col2 = num % 8;
			using Pen selectedPen = new Pen(Color.FromArgb(255, 211, 92), 2f);
			g.DrawRectangle(selectedPen, (page2 * 8 + col2) * cellW + 1, localRow * cellH + 1, Math.Max(1, cellW - 2), Math.Max(1, cellH - 2));
		}
		using Pen borderPen = new Pen(Color.FromArgb(41, 111, 172));
		g.DrawRectangle(borderPen, 0, 0, Math.Max(0, base.ClientSize.Width - 1), Math.Max(0, base.ClientSize.Height - 1));
		if ((object)draggedItem == null)
		{
			return;
		}
		selectedSlot = hoverSlot;
		if (!selectedSlot.HasValue)
		{
			return;
		}
		int target = selectedSlot.GetValueOrDefault();
		int page3 = target / 120;
		int local = target % 120;
		Rectangle rect2 = new Rectangle((page3 * 8 + local % 8) * cellW + 1, local / 8 * cellH + 1, draggedItem.Width * cellW - 2, draggedItem.Height * cellH - 2);
		using SolidBrush highlight = new SolidBrush(Color.FromArgb(130, hoverValid ? Color.SeaGreen : Color.Firebrick));
		g.FillRectangle(highlight, rect2);
		Image icon = ItemImages.Get(draggedItem);
		if (icon != null)
		{
			g.DrawImage(icon, ItemImages.Fit(icon, Rectangle.Inflate(rect2, -2, -2)));
		}
		using Pen outline2 = new Pen(hoverValid ? Color.LimeGreen : Color.OrangeRed, 2f);
		g.DrawRectangle(outline2, rect2);
	}

	protected override void OnMouseClick(MouseEventArgs e)
	{
		base.OnMouseClick(e);
		if (e.Button == MouseButtons.Left && (object)draggedItem != null)
		{
			OnMouseMove(e);
		}
		int cellW = Math.Max(1, base.ClientSize.Width / 16);
		int cellH = Math.Max(1, base.ClientSize.Height / 15);
		int num = Math.Clamp(e.X / cellW, 0, 15);
		int page = num / 8;
		int col = num % 8;
		int row = Math.Clamp(e.Y / cellH, 0, 14);
		SelectedSlot = page * 120 + row * 8 + col;
		Invalidate();
		this.SelectedSlotChanged?.Invoke(SelectedSlot);
		int? num2;
		if (e.Button == MouseButtons.Left && (object)draggedItem != null)
		{
			num2 = hoverSlot;
			if (num2.HasValue)
			{
				int target = num2.GetValueOrDefault();
				if (hoverValid)
				{
					this.ItemPlacementClicked?.Invoke(draggedItem, target);
				}
			}
		}
		if (e.Button != MouseButtons.Right)
		{
			return;
		}
		num2 = SelectedSlot;
		if (num2.HasValue)
		{
			int clicked = num2.GetValueOrDefault();
			int r = clicked / 8;
			int c = clicked % 8;
			WarehousePlacement hit = placements.LastOrDefault((WarehousePlacement p) => r >= p.Slot / 8 && r < p.Slot / 8 + p.Item.Height && c >= p.Slot % 8 && c < p.Slot % 8 + p.Item.Width);
			if ((object)hit != null)
			{
				this.ItemContextRequested?.Invoke(hit, e.Location);
			}
		}
	}

	protected override void OnDragEnter(DragEventArgs e)
	{
		base.OnDragEnter(e);
		IDataObject? data = e.Data;
		e.Effect = ((data != null && data.GetDataPresent(typeof(ItemDefinition))) ? DragDropEffects.Copy : DragDropEffects.None);
	}

	protected override void OnDragOver(DragEventArgs e)
	{
		base.OnDragOver(e);
		draggedItem = e.Data?.GetData(typeof(ItemDefinition)) as ItemDefinition;
		Point point = PointToClient(new Point(e.X, e.Y));
		int cellW = Math.Max(1, base.ClientSize.Width / 16);
		int cellH = Math.Max(1, base.ClientSize.Height / 15);
		hoverSlot = ((point.X >= 0 && point.Y >= 0 && point.X < cellW * 16 && point.Y < cellH * 15) ? new int?(point.X / cellW / 8 * 120 + point.Y / cellH * 8 + point.X / cellW % 8) : ((int?)null));
		hoverValid = false;
		if ((object)draggedItem != null)
		{
			int? num = hoverSlot;
			if (num.HasValue)
			{
				int slot = num.GetValueOrDefault();
				try
				{
					WarehouseItemFormat.ValidatePlacement(draggedItem, slot, WarehouseItemFormat.BuildOccupancy(placements));
					hoverValid = true;
				}
				catch (InvalidOperationException)
				{
				}
			}
		}
		e.Effect = (hoverValid ? DragDropEffects.Copy : DragDropEffects.None);
		Invalidate();
	}

	protected override void OnDragLeave(EventArgs e)
	{
		base.OnDragLeave(e);
		draggedItem = null;
		hoverSlot = null;
		Invalidate();
	}

	protected override void OnDragDrop(DragEventArgs e)
	{
		base.OnDragDrop(e);
		draggedItem = null;
		hoverSlot = null;
		Invalidate();
		if (e.Data?.GetData(typeof(ItemDefinition)) is ItemDefinition item)
		{
			Point point = PointToClient(new Point(e.X, e.Y));
			int cellW = Math.Max(1, base.ClientSize.Width / 16);
			int cellH = Math.Max(1, base.ClientSize.Height / 15);
			if (point.X >= 0 && point.Y >= 0 && point.X < cellW * 16 && point.Y < cellH * 15)
			{
				int displayCol = point.X / cellW;
				int slot = displayCol / 8 * 120 + point.Y / cellH * 8 + displayCol % 8;
				this.ItemDropped?.Invoke(item, slot);
			}
		}
	}
}
