namespace MuSven09M.Modules.Warehouse;

public sealed record WarehouseItemChange(StagedWarehouseItem Item, bool EditExisting);
