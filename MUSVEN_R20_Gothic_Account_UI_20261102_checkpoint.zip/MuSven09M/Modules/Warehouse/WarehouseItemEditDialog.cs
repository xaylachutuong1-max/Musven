using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace MuSven09M.Modules.Warehouse;

internal sealed class WarehouseItemEditDialog : Form
{
	public ItemCreationOptions Result { get; private set; }

	public WarehouseItemEditDialog(ItemDefinition item, ItemCreationOptions value, uint serial, byte[] raw)
	{
		WarehouseItemEditDialog warehouseItemEditDialog = this;
		Result = value;
		Text = "Chỉnh sửa vật phẩm • " + item.Name;
		base.Size = new Size(550, 650);
		MinimumSize = base.Size;
		base.StartPosition = FormStartPosition.CenterParent;
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			Padding = new Padding(12),
			RowCount = 5,
			ColumnCount = 1
		};
		base.Controls.Add(root);
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 80f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 130f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
		root.Controls.Add(new Label
		{
			Dock = DockStyle.Fill,
			Text = $"{item.Name}\nSerial: {serial} (giữ nguyên)\nCode gốc: {Convert.ToHexString(raw)}",
			AutoEllipsis = true
		}, 0, 0);
		FlowLayoutPanel fields = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill
		};
		root.Controls.Add(fields, 0, 1);
		NumericUpDown level = Add("Level", 0, 15, value.Level);
		NumericUpDown opt = Add("Options", 0, 28, value.Option * 4);
		opt.Increment = 4m;
		NumericUpDown dur = Add("Độ bền", 0, 255, value.Durability);
		NumericUpDown set = Add("Set Num", 0, 15, value.SetOption);
		CheckBox skill = new CheckBox
		{
			Text = "Skill",
			Checked = value.Skill,
			AutoSize = true
		};
		CheckBox luck = new CheckBox
		{
			Text = "Luck",
			Checked = value.Luck,
			AutoSize = true
		};
		fields.Controls.Add(skill);
		fields.Controls.Add(luck);
		TabControl tabs = new TabControl
		{
			Dock = DockStyle.Fill
		};
		root.Controls.Add(tabs, 0, 2);
		TabPage exc = new TabPage("Excellent");
		TabPage sockets = new TabPage("Socket");
		TabPage harmony = new TabPage("Harmony");
		tabs.TabPages.AddRange(new TabPage[3] { exc, sockets, harmony });
		FlowLayoutPanel ep = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false
		};
		exc.Controls.Add(ep);
		string[] names = new string[6] { "Zen +40% / Hồi Mana÷8", "Phản dame +5% / Speed +7", "Tránh đòn +10% / Hồi HP÷8", "Mana +4% / ST Level÷20", "Giảm sát thương 4% / Sát thương +2%", "HP +4% / STHH +10%" };
		CheckBox[] checks = names.Select((string n, int i) => new CheckBox
		{
			Text = n,
			Checked = ((value.Excellent & (1 << i)) != 0),
			AutoSize = true
		}).ToArray();
		CheckBox[] array = checks;
		foreach (CheckBox c in array)
		{
			ep.Controls.Add(c);
		}
		Button all = new Button
		{
			Text = "Chọn tất cả",
			AutoSize = true
		};
		Button empty = new Button
		{
			Text = "Bỏ chọn",
			AutoSize = true
		};
		ep.Controls.Add(all);
		ep.Controls.Add(empty);
		all.Click += delegate
		{
			CheckBox[] array2 = checks;
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i].Checked = true;
			}
		};
		empty.Click += delegate
		{
			CheckBox[] array2 = checks;
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i].Checked = false;
			}
		};
		ItemAttributeControls attrs = new ItemAttributeControls();
		attrs.SetHarmonyGroup(item.Section, value.SpecialByte);
		attrs.LoadSockets(value.Sockets);
		sockets.Controls.Add(attrs.SocketPanel());
		harmony.Controls.Add(attrs.HarmonyPanel());
		if (value.Sockets.Any((byte v) => v != byte.MaxValue))
		{
			attrs.Harmony.Enabled = false;
			attrs.HarmonyLevel.Enabled = false;
			harmony.Controls.Add(new Label
			{
				Dock = DockStyle.Bottom,
				Height = 65,
				Text = $"Vật phẩm Socket: byte này là bonus Socket ({value.SpecialByte}), giữ nguyên. Không chỉnh Harmony cho vật phẩm Socket."
			});
		}
		root.Controls.Add(new Label
		{
			Text = "Áp dụng chỉ vào bản xem trước. Chưa ghi SQL.",
			Dock = DockStyle.Fill
		}, 0, 3);
		FlowLayoutPanel buttons = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.RightToLeft
		};
		root.Controls.Add(buttons, 0, 4);
		Button cancel = new Button
		{
			Text = "Hủy",
			DialogResult = DialogResult.Cancel
		};
		Button save = new Button
		{
			Text = "Áp dụng",
			AutoSize = true
		};
		buttons.Controls.Add(cancel);
		buttons.Controls.Add(save);
		base.CancelButton = cancel;
		save.Click += delegate
		{
			try
			{
				if (opt.Value % 4m != 0m)
				{
					throw new InvalidOperationException("Options phải là bội số của 4.");
				}
				byte b = 0;
				for (int i = 0; i < 6; i++)
				{
					if (checks[i].Checked)
					{
						b |= (byte)(1 << i);
					}
				}
				warehouseItemEditDialog.Result = new ItemCreationOptions((int)level.Value, (int)opt.Value / 4, (int)dur.Value, skill.Checked, luck.Checked, b, (int)set.Value, attrs.HarmonyValue, attrs.SocketValues());
				warehouseItemEditDialog.DialogResult = DialogResult.OK;
				warehouseItemEditDialog.Close();
			}
			catch (InvalidOperationException ex)
			{
				MessageBox.Show(warehouseItemEditDialog, ex.Message);
			}
		};
		UiTheme.Apply(this);
		NumericUpDown Add(string name, int min, int max, int n)
		{
			fields.Controls.Add(new Label
			{
				Text = name,
				Width = 72
			});
			NumericUpDown b = new NumericUpDown
			{
				Minimum = min,
				Maximum = max,
				Value = n,
				Width = 65
			};
			fields.Controls.Add(b);
			return b;
		}
	}
}
