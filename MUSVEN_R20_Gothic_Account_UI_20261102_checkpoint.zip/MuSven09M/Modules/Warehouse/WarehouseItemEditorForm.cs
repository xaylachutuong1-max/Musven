using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Warehouse;

internal sealed class WarehouseItemEditorForm : Form
{
	private static readonly Color Panel = Color.FromArgb(11, 24, 43);

	private static readonly Color Edge = Color.FromArgb(41, 111, 172);

	private static readonly Color Gold = Color.FromArgb(249, 188, 71);

	private static readonly Color Ice = Color.FromArgb(106, 211, 255);

	private readonly SqlAccountLookupOptions databaseOptions;

	private readonly bool writeEnabled;

	private readonly TextBox accountBox = new TextBox
	{
		MaxLength = 10
	};

	private readonly ComboBox warehouseBox = new ComboBox
	{
		DropDownStyle = ComboBoxStyle.DropDownList
	};

	private readonly ComboBox categoryBox = new ComboBox
	{
		DropDownStyle = ComboBoxStyle.DropDownList
	};

	private readonly TextBox searchBox = new TextBox();

	private readonly ListBox itemList = new ListBox();

	private readonly PictureBox itemPreview = new PictureBox
	{
		Dock = DockStyle.Fill,
		SizeMode = PictureBoxSizeMode.Zoom,
		BackColor = Color.FromArgb(4, 9, 16),
		Cursor = Cursors.Hand
	};

	private readonly ListBox stagedList = new ListBox();

	private readonly Label statusLabel = new Label();

	private readonly Label selectedSlotLabel = new Label();

	private readonly Label stagedCountLabel = new Label();

	private readonly Label selectedItemLabel = new Label();

	private readonly Button loadButton = new Button();

	private readonly Button saveButton = new Button();

	private readonly Button addButton = new Button();

	private readonly Button removeButton = new Button();

	private readonly WarehouseGridControl grid = new WarehouseGridControl();

	private readonly TextBox zenBox = new TextBox
	{
		ReadOnly = true,
		Text = "0",
		Width = 130
	};

	private readonly NumericUpDown levelBox = Number(0, 15, 0, 116);

	private readonly NumericUpDown optionBox = Number(0, 28, 0, 116);

	private readonly NumericUpDown durabilityBox = Number(0, 255, 255, 116);

	private readonly NumericUpDown setOptionBox = Number(0, 15, 0, 116);

	private readonly ItemAttributeControls attributes = new ItemAttributeControls();

	private readonly Dictionary<int, ItemCreationOptions> editedExisting = new Dictionary<int, ItemCreationOptions>();

	private readonly CheckBox skillBox = new CheckBox
	{
		Text = "Kỹ năng",
		AutoSize = true,
		ForeColor = Color.White
	};

	private readonly CheckBox luckBox = new CheckBox
	{
		Text = "May mắn",
		AutoSize = true,
		ForeColor = Color.White
	};

	private readonly CheckBox[] excellentBoxes = Enumerable.Range(0, 6).Select((int _, int i) => new CheckBox
	{
		Text = (new string[6] { "Zen +40% / Mana÷8", "Phản dame +5% / Speed +7", "Tránh đòn +10% / HP÷8", "Mana +4% / Level÷20", "Giảm sát thương 4% / Damage +2%", "HP +4% / STHH +10%" })[i],
		AutoSize = true,
		ForeColor = Color.FromArgb(177, 255, 92)
	}).ToArray();

	private readonly List<StagedWarehouseItem> staged = new List<StagedWarehouseItem>();

	private WarehouseSnapshot? snapshot;

	private IReadOnlyList<WarehousePlacement> existingPlacements = Array.Empty<WarehousePlacement>();

	private int? selectedSlot;

	private bool loadingLocations;

	public WarehouseItemEditorForm(SqlAccountLookupOptions options, bool writeEnabled, string accountId, bool allowLoading = true)
	{
		databaseOptions = options;
		this.writeEnabled = writeEnabled;
		Text = "MU SVEN • TẠO VẬT PHẨM VÀO KHO";
		base.StartPosition = FormStartPosition.CenterParent;
		MinimumSize = new Size(1080, 740);
		base.Size = new Size(1380, 1000);
		BackColor = Color.FromArgb(5, 11, 23);
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 9.5f);
		accountBox.Text = accountId;
		BuildLayout();
		PopulateCategories();
		categoryBox.SelectedIndex = 0;
		grid.SelectedSlotChanged += delegate(int? slot)
		{
			selectedSlot = slot;
			selectedSlotLabel.Text = (slot.HasValue ? $"Ô đang chọn: {slot.Value}" : "Ô chưa chọn • tự tìm chỗ trống");
		};
		accountBox.TextChanged += delegate
		{
			UpdateButtons();
		};
		warehouseBox.SelectionChangeCommitted += async delegate
		{
			await LoadSelectedWarehouseAsync();
		};
		loadButton.Click += async delegate
		{
			await LoadWarehousesAsync();
		};
		categoryBox.SelectedIndexChanged += delegate
		{
			RefreshItemList();
		};
		searchBox.TextChanged += delegate
		{
			RefreshItemList();
		};
		itemList.SelectedIndexChanged += delegate
		{
			if (itemList.SelectedItem is ItemDefinition itemDefinition)
			{
				selectedItemLabel.Text = $"{itemDefinition.Name}  •  {itemDefinition.Width}×{itemDefinition.Height} ô  •  Index {itemDefinition.ItemIndex}";
				itemPreview.Image = ItemImages.Get(itemDefinition);
				attributes.SetHarmonyGroup(itemDefinition.Section, 0);
				ShowStatus($"{itemDefinition.Name} • kích thước {itemDefinition.Width}×{itemDefinition.Height} ô • ItemIndex {itemDefinition.ItemIndex}.", error: false);
			}
			else
			{
				selectedItemLabel.Text = "Chưa chọn vật phẩm";
			}
			UpdateButtons();
		};
		addButton.Click += delegate
		{
			AddSelectedItem();
		};
		removeButton.Click += delegate
		{
			RemoveStagedItem();
		};
		stagedList.SelectedIndexChanged += delegate
		{
			UpdateButtons();
		};
		saveButton.Click += async delegate
		{
			await SaveAsync();
		};
		itemList.MouseDown += delegate(object? _, MouseEventArgs e)
		{
			int num = itemList.IndexFromPoint(e.Location);
			if (e.Button == MouseButtons.Left && num >= 0)
			{
				itemList.SelectedIndex = num;
				if (itemList.SelectedItem is ItemDefinition itemDefinition)
				{
					grid.BeginPlacement(itemDefinition);
					ShowStatus(itemDefinition.Name + " đã gắn vào con trỏ • di chuyển vào rương rồi bấm ô muốn đặt.", error: false);
				}
			}
		};
		itemPreview.MouseDown += delegate(object? _, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left && itemList.SelectedItem is ItemDefinition itemDefinition)
			{
				grid.BeginPlacement(itemDefinition);
				ShowStatus(itemDefinition.Name + " đã gắn vào con trỏ • di chuyển vào rương rồi bấm ô muốn đặt.", error: false);
			}
		};
		grid.ItemDropped += delegate(ItemDefinition item, int slot)
		{
			AddSelectedItem(item, slot);
		};
		grid.ItemPlacementClicked += delegate(ItemDefinition item, int slot)
		{
			AddSelectedItem(item, slot);
		};
		grid.ItemContextRequested += ShowItemMenu;
		RefreshItemList();
		Rectangle workingArea = Screen.FromControl(this).WorkingArea;
		base.Size = new Size(Math.Min(1480, workingArea.Width), Math.Min(1260, workingArea.Height));
		UpdateButtons();
		if (!allowLoading)
		{
			loadButton.Enabled = false;
			ShowStatus("Chế độ xem trước ngoại tuyến • chọn vật phẩm rồi bấm ô trong rương • chưa ghi SQL", error: false);
		}
		UiTheme.Apply(this);
	}

	private void BuildLayout()
	{
		MinimumSize = new Size(1120, 720);
		base.Size = new Size(1380, 880);
		TableLayoutPanel root = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 3,
			Padding = new Padding(8),
			BackColor = BackColor
		};
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 60f));
		root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		root.RowStyles.Add(new RowStyle(SizeType.Absolute, 54f));
		base.Controls.Add(root);
		TableLayoutPanel query = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 7,
			RowCount = 1,
			BackColor = Panel,
			Padding = new Padding(8, 5, 8, 5),
			Margin = new Padding(2)
		};
		query.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 86f));
		query.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34f));
		query.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 72f));
		query.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 23f));
		query.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 74f));
		query.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18f));
		query.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 116f));
		query.Controls.Add(TopLabel("TÀI KHOẢN"), 0, 0);
		StyleText(accountBox);
		query.Controls.Add(accountBox, 1, 0);
		query.Controls.Add(TopLabel("KHO SỐ"), 2, 0);
		StyleCombo(warehouseBox);
		query.Controls.Add(warehouseBox, 3, 0);
		query.Controls.Add(TopLabel("ZEN"), 4, 0);
		StyleText(zenBox);
		query.Controls.Add(zenBox, 5, 0);
		StyleButton(loadButton, "TẢI KHO", prominent: true);
		query.Controls.Add(loadButton, 6, 0);
		root.Controls.Add(query, 0, 0);
		TableLayoutPanel main = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = new Padding(2, 7, 2, 7)
		};
		main.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 56f));
		main.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 44f));
		root.Controls.Add(main, 0, 1);
		GroupBox gridGroup = Group("KHO ĐỒ • 240 Ô");
		TableLayoutPanel gridLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 3,
			Padding = new Padding(9, 40, 9, 8)
		};
		gridLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 31f));
		gridLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		gridLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28f));
		TableLayoutPanel gridHeader = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1
		};
		gridHeader.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		gridHeader.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 160f));
		selectedSlotLabel.Text = "Chưa chọn ô • tự xếp vào chỗ trống";
		selectedSlotLabel.ForeColor = Ice;
		selectedSlotLabel.TextAlign = ContentAlignment.MiddleLeft;
		gridHeader.Controls.Add(selectedSlotLabel, 0, 0);
		gridHeader.Controls.Add(new Label
		{
			Text = "■ Đang có   ■ Chờ lưu",
			Dock = DockStyle.Fill,
			ForeColor = Color.LightGray,
			TextAlign = ContentAlignment.MiddleRight
		}, 1, 0);
		gridLayout.Controls.Add(gridHeader, 0, 0);
		grid.BackColor = Color.FromArgb(4, 9, 16);
		grid.Dock = DockStyle.Fill;
		gridLayout.Controls.Add(grid, 0, 1);
		TableLayoutPanel pageLabels = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1
		};
		pageLabels.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		pageLabels.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		pageLabels.Controls.Add(new Label
		{
			Text = "NGĂN TRÁI • ô 0–119",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			TextAlign = ContentAlignment.MiddleCenter
		}, 0, 0);
		pageLabels.Controls.Add(new Label
		{
			Text = "NGĂN PHẢI • ô 120–239",
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			TextAlign = ContentAlignment.MiddleCenter
		}, 1, 0);
		gridLayout.Controls.Add(pageLabels, 0, 2);
		gridGroup.Controls.Add(gridLayout);
		main.Controls.Add(gridGroup, 0, 0);
		Panel rightScroll = new Panel
		{
			Dock = DockStyle.Fill,
			AutoScroll = true,
			Margin = new Padding(7, 0, 0, 0)
		};
		TableLayoutPanel right = new TableLayoutPanel
		{
			Dock = DockStyle.Top,
			Height = 1085,
			ColumnCount = 1,
			RowCount = 3,
			Margin = Padding.Empty
		};
		right.RowStyles.Add(new RowStyle(SizeType.Absolute, 345f));
		right.RowStyles.Add(new RowStyle(SizeType.Absolute, 575f));
		right.RowStyles.Add(new RowStyle(SizeType.Absolute, 165f));
		rightScroll.Controls.Add(right);
		main.Controls.Add(rightScroll, 1, 0);
		GroupBox chooser = Group("CHỌN VẬT PHẨM");
		TableLayoutPanel chooserLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 4,
			Padding = new Padding(8, 40, 8, 7)
		};
		chooserLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 138f));
		chooserLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		chooserLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 34f));
		chooserLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		chooserLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 70f));
		chooserLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40f));
		StyleCombo(categoryBox);
		chooserLayout.Controls.Add(categoryBox, 0, 0);
		searchBox.PlaceholderText = "Tìm vật phẩm...";
		StyleText(searchBox);
		chooserLayout.Controls.Add(searchBox, 1, 0);
		StyleList(itemList);
		itemList.DrawMode = DrawMode.OwnerDrawFixed;
		itemList.ItemHeight = 42;
		itemList.DrawItem += delegate(object? _, DrawItemEventArgs e)
		{
			e.DrawBackground();
			if (e.Index >= 0 && itemList.Items[e.Index] is ItemDefinition itemDefinition)
			{
				bool flag = (e.State & DrawItemState.Selected) != 0;
				Image image = ItemImages.Get(itemDefinition);
				Rectangle area = new Rectangle(e.Bounds.X + 24, e.Bounds.Y + 2, 42, 38);
				if (image != null)
				{
					e.Graphics.DrawImage(image, ItemImages.Fit(image, area));
				}
				TextRenderer.DrawText(e.Graphics, flag ? "☑" : "☐", itemList.Font, new Rectangle(e.Bounds.X + 2, e.Bounds.Y, 22, e.Bounds.Height), flag ? Gold : Ice, TextFormatFlags.VerticalCenter);
				TextRenderer.DrawText(e.Graphics, itemDefinition.DisplayText, itemList.Font, new Rectangle(e.Bounds.X + 72, e.Bounds.Y, Math.Max(1, e.Bounds.Width - 76), e.Bounds.Height), flag ? Color.White : Color.WhiteSmoke, TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter);
				e.DrawFocusRectangle();
			}
		};
		chooserLayout.Controls.Add(itemList, 0, 1);
		chooserLayout.SetColumnSpan(itemList, 2);
		selectedItemLabel.Text = "Chưa chọn vật phẩm";
		selectedItemLabel.Dock = DockStyle.Fill;
		selectedItemLabel.ForeColor = Gold;
		selectedItemLabel.TextAlign = ContentAlignment.MiddleLeft;
		TableLayoutPanel previewRow = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1
		};
		previewRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 58f));
		previewRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		previewRow.Controls.Add(itemPreview, 0, 0);
		previewRow.Controls.Add(selectedItemLabel, 1, 0);
		chooserLayout.Controls.Add(previewRow, 0, 2);
		chooserLayout.SetColumnSpan(previewRow, 2);
		StyleButton(addButton, "THÊM VÀO DANH SÁCH CHỜ", prominent: true);
		chooserLayout.Controls.Add(addButton, 0, 3);
		chooserLayout.SetColumnSpan(addButton, 2);
		chooser.Controls.Add(chooserLayout);
		right.Controls.Add(chooser, 0, 0);
		GroupBox options = Group("THUỘC TÍNH VÀ TÙY CHỌN");
		TableLayoutPanel optionLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 5,
			Padding = new Padding(8, 40, 8, 5)
		};
		optionLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 56f));
		optionLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 44f));
		optionLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		optionLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		optionLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		optionLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		optionLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
		optionBox.Increment = 4m;
		optionLayout.Controls.Add(InputCell("Level", levelBox), 0, 0);
		optionLayout.Controls.Add(InputCell("Options (0–28)", optionBox), 1, 0);
		optionLayout.Controls.Add(InputCell("Độ bền", durabilityBox), 0, 1);
		optionLayout.Controls.Add(InputCell("Set Num", setOptionBox), 1, 1);
		attributes.Harmony.Width = 120;
		optionLayout.Controls.Add(attributes.HarmonyPanel(), 0, 2);
		FlowLayoutPanel flags = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			WrapContents = true,
			BackColor = Panel,
			Padding = new Padding(3, 7, 0, 0)
		};
		flags.Controls.Add(skillBox);
		flags.Controls.Add(luckBox);
		optionLayout.Controls.Add(flags, 1, 2);
		TableLayoutPanel excellent = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 3,
			BackColor = Panel
		};
		excellent.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		excellent.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
		for (int i = 0; i < excellentBoxes.Length; i++)
		{
			excellent.Controls.Add(excellentBoxes[i], i % 2, i / 2);
		}
		optionLayout.Controls.Add(excellent, 0, 3);
		optionLayout.SetColumnSpan(excellent, 2);
		optionLayout.RowStyles[4].Height = 200f;
		Control sockets = attributes.SocketPanel();
		optionLayout.Controls.Add(sockets, 0, 4);
		optionLayout.SetColumnSpan(sockets, 2);
		options.Controls.Add(optionLayout);
		right.Controls.Add(options, 0, 1);
		GroupBox pending = Group("DANH SÁCH CHỜ LƯU");
		TableLayoutPanel pendingLayout = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 2,
			Padding = new Padding(8, 36, 8, 6)
		};
		pendingLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		pendingLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100f));
		pendingLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
		pendingLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		stagedCountLabel.Text = "0 món";
		stagedCountLabel.Dock = DockStyle.Fill;
		stagedCountLabel.ForeColor = Ice;
		stagedCountLabel.TextAlign = ContentAlignment.MiddleLeft;
		pendingLayout.Controls.Add(stagedCountLabel, 0, 0);
		StyleButton(removeButton, "BỎ MÓN", prominent: false);
		pendingLayout.Controls.Add(removeButton, 1, 0);
		StyleList(stagedList);
		pendingLayout.Controls.Add(stagedList, 0, 1);
		pendingLayout.SetColumnSpan(stagedList, 2);
		pending.Controls.Add(pendingLayout);
		right.Controls.Add(pending, 0, 2);
		TableLayoutPanel footer = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = new Padding(2)
		};
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220f));
		footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112f));
		statusLabel.Text = (writeEnabled ? "GHI KHO ĐANG BẬT • chỉ ô trống • tài khoản phải ngoại tuyến • xác nhận trước khi lưu" : "CHỈ XEM • [MUSVEN_ITEM_WRITES] đang tắt • vật phẩm xếp vào chỉ là bản nháp");
		statusLabel.Dock = DockStyle.Fill;
		statusLabel.ForeColor = (writeEnabled ? Color.FromArgb(103, 240, 170) : Color.FromArgb(255, 178, 115));
		statusLabel.TextAlign = ContentAlignment.MiddleLeft;
		footer.Controls.Add(statusLabel, 0, 0);
		StyleButton(saveButton, "LƯU VÀO KHO", prominent: true, gold: true);
		saveButton.Enabled = false;
		footer.Controls.Add(saveButton, 1, 0);
		Button close = new Button();
		StyleButton(close, "ĐÓNG", prominent: false);
		close.Click += delegate
		{
			Close();
		};
		footer.Controls.Add(close, 2, 0);
		root.Controls.Add(footer, 0, 2);
	}

	private void PopulateCategories()
	{
		categoryBox.Items.Clear();
		foreach (string category in ItemCatalog.All.Select((ItemDefinition x) => x.Category).Distinct())
		{
			categoryBox.Items.Add(category);
		}
	}

	private void RefreshItemList()
	{
		string category = categoryBox.SelectedItem?.ToString() ?? string.Empty;
		string search = searchBox.Text.Trim();
		itemList.BeginUpdate();
		itemList.Items.Clear();
		itemList.DisplayMember = "DisplayText";
		foreach (ItemDefinition item in ItemCatalog.All.Where((ItemDefinition x) => x.Category == category && (search.Length == 0 || x.Name.Contains(search, StringComparison.OrdinalIgnoreCase))))
		{
			itemList.Items.Add(item);
		}
		itemList.EndUpdate();
		UpdateButtons();
	}

	private async Task LoadWarehousesAsync()
	{
		string account = accountBox.Text.Trim();
		if (account.Length == 0)
		{
			ShowStatus("Nhập AccountID trước khi tải kho.", error: true);
			return;
		}
		if (account.Length > 10)
		{
			ShowStatus("AccountID tối đa 10 ký tự.", error: true);
			return;
		}
		loadButton.Enabled = false;
		warehouseBox.Enabled = false;
		zenBox.Text = "0";
		ShowStatus("Đang tải danh sách kho…", error: false);
		try
		{
			WarehouseItemRepository repo = ReadRepository();
			IReadOnlyList<WarehouseLocation> obj = await Task.Run(() => repo.ListLocations(account));
			loadingLocations = true;
			warehouseBox.Items.Clear();
			foreach (WarehouseLocation location in obj)
			{
				warehouseBox.Items.Add(location);
			}
			loadingLocations = false;
			if (warehouseBox.Items.Count == 0)
			{
				snapshot = null;
				existingPlacements = Array.Empty<WarehousePlacement>();
				staged.Clear();
				editedExisting.Clear();
				RefreshStageAndGrid();
				ShowStatus("Không tìm thấy dòng kho chính hoặc kho mở rộng cho AccountID này.", error: true);
				UpdateButtons();
			}
			else
			{
				warehouseBox.SelectedIndex = 0;
				await LoadSelectedWarehouseAsync();
			}
		}
		catch (InvalidOperationException ex)
		{
			snapshot = null;
			ShowStatus(ex.Message, error: true);
		}
		catch
		{
			snapshot = null;
			ShowStatus("Không tải được danh sách kho. Kiểm tra kết nối SQL và quyền SELECT.", error: true);
		}
		finally
		{
			loadingLocations = false;
			loadButton.Enabled = true;
			warehouseBox.Enabled = true;
			UpdateButtons();
		}
	}

	private async Task LoadSelectedWarehouseAsync()
	{
		if (loadingLocations)
		{
			return;
		}
		object selectedItem = warehouseBox.SelectedItem;
		WarehouseLocation location = selectedItem as WarehouseLocation;
		if ((object)location == null)
		{
			return;
		}
		string account = accountBox.Text.Trim();
		if (account.Length == 0)
		{
			return;
		}
		loadButton.Enabled = false;
		warehouseBox.Enabled = false;
		snapshot = null;
		existingPlacements = Array.Empty<WarehousePlacement>();
		staged.Clear();
		editedExisting.Clear();
		selectedSlot = null;
		selectedSlotLabel.Text = "Chưa chọn ô • tự xếp vào chỗ trống";
		zenBox.Text = location.Money.ToString("N0");
		RefreshStageAndGrid();
		ShowStatus("Đang đọc Items và kiểm tra các ô kho…", error: false);
		try
		{
			WarehouseItemRepository repo = ReadRepository();
			WarehouseSnapshot loaded = await Task.Run(() => repo.Load(account, location));
			IReadOnlyList<WarehousePlacement> placements = repo.DecodePlacements(loaded.Items);
			snapshot = loaded;
			existingPlacements = placements;
			RefreshStageAndGrid();
			ShowStatus($"Đã tải {loaded.Items.Length / 16} ô • {placements.Count} vật phẩm đã nhận diện.", error: false);
		}
		catch (InvalidOperationException ex)
		{
			ShowStatus(ex.Message, error: true);
		}
		catch
		{
			ShowStatus("Không đọc được Items. Kiểm tra bảng, cột, định dạng kho và quyền SELECT.", error: true);
		}
		finally
		{
			loadButton.Enabled = true;
			warehouseBox.Enabled = true;
			UpdateButtons();
		}
	}

	private void AddSelectedItem(ItemDefinition? droppedItem = null, int? dropSlot = null)
	{
		ItemDefinition item = droppedItem ?? (itemList.SelectedItem as ItemDefinition);
		if ((object)item == null)
		{
			ShowStatus("Chọn vật phẩm trong danh sách trước.", error: true);
			return;
		}
		try
		{
			bool[] occupied = WarehouseItemFormat.BuildOccupancy(existingPlacements);
			foreach (StagedWarehouseItem stagedItem in staged)
			{
				WarehouseItemFormat.ValidatePlacement(stagedItem.Item, stagedItem.Slot, occupied);
				WarehouseItemFormat.Mark(stagedItem.Item, stagedItem.Slot, occupied);
			}
			int? desiredSlot = dropSlot ?? selectedSlot;
			int slot;
			if (desiredSlot.HasValue)
			{
				slot = desiredSlot.Value;
				WarehouseItemFormat.ValidatePlacement(item, slot, occupied);
			}
			else
			{
				slot = WarehouseItemFormat.FindFirstFit(item, occupied);
				if (slot < 0)
				{
					throw new InvalidOperationException("Không còn vùng trống đủ kích thước vật phẩm trong kho này.");
				}
			}
			byte excellent = 0;
			for (int i = 0; i < excellentBoxes.Length; i++)
			{
				if (excellentBoxes[i].Checked)
				{
					excellent |= (byte)(1 << i);
				}
			}
			byte[] sockets = attributes.SocketValues();
			if (sockets.Any((byte x) => x != byte.MaxValue) && attributes.HarmonyValue != 0)
			{
				throw new InvalidOperationException("Vật phẩm Socket dùng byte Harmony cho bonus Socket. Chọn Harmony = None khi tạo vật phẩm Socket.");
			}
			ItemCreationOptions itemOptions = new ItemCreationOptions((int)levelBox.Value, (int)optionBox.Value / 4, (int)durabilityBox.Value, skillBox.Checked, luckBox.Checked, excellent, (int)setOptionBox.Value, attributes.HarmonyValue, sockets);
			staged.Add(new StagedWarehouseItem(item, itemOptions, slot));
			grid.EndPlacement();
			selectedSlot = null;
			RefreshStageAndGrid();
			ShowStatus(((object)snapshot == null) ? $"Xem trước ngoại tuyến: đã xếp {item.Name} tại ô {slot} • {staged.Count} món • chưa ghi SQL." : $"Đã xếp {item.Name} tại ô {slot}. Chưa ghi vào SQL.", error: false);
		}
		catch (InvalidOperationException ex)
		{
			ShowStatus(ex.Message, error: true);
		}
	}

	private void ShowItemMenu(WarehousePlacement placement, Point location)
	{
		ContextMenuStrip menu = new ContextMenuStrip();
		menu.BackColor = Color.FromArgb(19, 29, 44);
		menu.ForeColor = Color.FromArgb(231, 237, 244);
		menu.Font = new Font("Segoe UI", 9.5f);
		Action afterClose = null;
		menu.Items.Add("Chỉnh sửa vật phẩm…", null, delegate
		{
			afterClose = delegate
			{
				EditPlacement(placement);
			};
		});
		if (placement.Pending)
		{
			menu.Items.Add("Bỏ món đang chờ", null, delegate
			{
				afterClose = delegate
				{
					staged.RemoveAll((StagedWarehouseItem x) => x.Slot == placement.Slot);
					RefreshStageAndGrid();
				};
			});
		}
		menu.Items.Add("Đóng", null, delegate
		{
			menu.Close();
		});
		menu.Closed += delegate
		{
			if (!base.IsDisposed && base.IsHandleCreated)
			{
				BeginInvoke(delegate
				{
					menu.Dispose();
					if (!base.IsDisposed)
					{
						afterClose?.Invoke();
					}
				});
			}
			else
			{
				menu.Dispose();
			}
		};
		menu.Show(grid, location);
	}

	private void EditPlacement(WarehousePlacement placement)
	{
		StagedWarehouseItem pending = staged.FirstOrDefault((StagedWarehouseItem x) => x.Slot == placement.Slot);
		ItemCreationOptions value;
		uint serial;
		byte[] raw;
		if ((object)pending != null)
		{
			value = pending.Options;
			serial = 0u;
			raw = WarehouseItemFormat.Encode(placement.Item, value, serial);
		}
		else
		{
			if ((object)snapshot == null)
			{
				return;
			}
			raw = snapshot.Items.AsSpan(placement.Slot * 16, 16).ToArray();
			serial = BinaryPrimitives.ReadUInt32BigEndian(raw.AsSpan(3, 4));
			value = (editedExisting.TryGetValue(placement.Slot, out ItemCreationOptions preview) ? preview : new ItemCreationOptions((raw[1] >> 3) & 0xF, (raw[1] & 3) | ((raw[7] & 0x40) >> 4), raw[2], (raw[1] & 0x80) != 0, (raw[1] & 4) != 0, (byte)(raw[7] & 0x3F), raw[8] & 0xF, raw[10], raw.Skip(11).Take(5).ToArray()));
		}
		using WarehouseItemEditDialog dialog = new WarehouseItemEditDialog(placement.Item, value, serial, raw);
		if (dialog.ShowDialog(this) == DialogResult.OK)
		{
			if ((object)pending != null)
			{
				staged[staged.IndexOf(pending)] = pending with
				{
					Options = dialog.Result
				};
			}
			else
			{
				editedExisting[placement.Slot] = dialog.Result;
			}
			RefreshStageAndGrid();
			ShowStatus("Đã cập nhật bản xem trước " + placement.Item.Name + " • serial giữ nguyên • chưa ghi SQL.", error: false);
		}
	}

	private void RemoveStagedItem()
	{
		int index = stagedList.SelectedIndex;
		if (index < 0)
		{
			return;
		}
		if (index < staged.Count)
		{
			StagedWarehouseItem removed = staged[index];
			staged.RemoveAt(index);
			RefreshStageAndGrid();
			ShowStatus("Đã bỏ " + removed.Item.Name + " khỏi danh sách chờ.", error: false);
			return;
		}
		int editIndex = index - staged.Count;
		if (editIndex >= 0 && editIndex < editedExisting.Count)
		{
			int editSlot = editedExisting.Keys.ElementAt(editIndex);
			if (editedExisting.Remove(editSlot))
			{
				RefreshStageAndGrid();
				ShowStatus($"Đã hủy chỉnh sửa tại ô {editSlot}; dữ liệu gốc vẫn được giữ.", error: false);
			}
		}
	}

	private async Task SaveAsync()
	{
		if (!writeEnabled || (object)snapshot == null || (staged.Count == 0 && editedExisting.Count == 0))
		{
			return;
		}
		if (!accountBox.Text.Trim().Equals(snapshot.AccountId, StringComparison.OrdinalIgnoreCase))
		{
			ShowStatus("AccountID đã đổi sau khi tải. Hãy tải lại kho.", error: true);
			return;
		}
		List<WarehouseItemChange> changes = new List<WarehouseItemChange>(staged.Count + editedExisting.Count);
		changes.AddRange(staged.Select((StagedWarehouseItem item) => new WarehouseItemChange(item, EditExisting: false)));
		foreach (KeyValuePair<int, ItemCreationOptions> edit in editedExisting)
		{
			WarehousePlacement placement = existingPlacements.FirstOrDefault((WarehousePlacement item) => item.Slot == edit.Key);
			if ((object)placement == null)
			{
				ShowStatus($"Không tìm thấy vật phẩm gốc tại ô {edit.Key}. Tải lại kho.", error: true);
				return;
			}
			changes.Add(new WarehouseItemChange(new StagedWarehouseItem(placement.Item, edit.Value, edit.Key), EditExisting: true));
		}
		string target = snapshot.AccountId + " • " + snapshot.Location.DisplayName;
		int addCount = changes.Count((WarehouseItemChange change) => !change.EditExisting);
		int editCount = changes.Count - addCount;
		if (MessageBox.Show(this, $"Lưu thay đổi kho cho {target}?\n\nThêm mới: {addCount}\nChỉnh sửa tại chỗ: {editCount}\n\nMón mới chỉ vào ô trống. Món sửa giữ nguyên ItemIndex và serial. Musven kiểm tra tài khoản ngoại tuyến và đối chiếu lại snapshot trong transaction.", "Xác nhận ghi vật phẩm", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
		{
			return;
		}
		saveButton.Enabled = false;
		loadButton.Enabled = false;
		ShowStatus("Đang xác nhận trạng thái tài khoản và lưu giao dịch…", error: false);
		try
		{
			MuSvenDatabase writeDatabase = new MuSvenDatabase(SqlClientFactory.Instance, databaseOptions.CreateConnectionString(readOnly: false));
			WarehouseItemRepository repo = new WarehouseItemRepository(writeDatabase);
			int count = await Task.Run(() => repo.SaveChanges(snapshot.AccountId, snapshot, changes));
			MessageBox.Show(this, $"Đã lưu {count} thay đổi vào {target}.\nThêm mới: {addCount} • Chỉnh sửa: {editCount}", "MU SVEN • Đã lưu", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			base.DialogResult = DialogResult.OK;
			Close();
		}
		catch (InvalidOperationException ex)
		{
			ShowStatus(ex.Message, error: true);
		}
		catch (SqlException)
		{
			ShowStatus("SQL từ chối giao dịch. Kiểm tra quyền tối thiểu, dbo.WZ_GetItemSerial và trạng thái kết nối; không có nội dung kho nào được ghi nếu giao dịch bị hủy.", error: true);
		}
		catch
		{
			ShowStatus("Không lưu được giao dịch. Kiểm tra cấu hình SQL và schema; Musven không hiển thị thông tin kết nối.", error: true);
		}
		finally
		{
			loadButton.Enabled = true;
			warehouseBox.Enabled = true;
			UpdateButtons();
		}
	}

	private void RefreshStageAndGrid()
	{
		stagedList.BeginUpdate();
		stagedList.Items.Clear();
		foreach (StagedWarehouseItem item in staged)
		{
			stagedList.Items.Add($"Ô {item.Slot}: {item.Item.Name}  •  Lv {item.Options.Level}");
		}
		foreach (KeyValuePair<int, ItemCreationOptions> edit in editedExisting)
		{
			ItemDefinition item2 = existingPlacements.FirstOrDefault((WarehousePlacement value) => value.Slot == edit.Key)?.Item;
			if ((object)item2 != null)
			{
				stagedList.Items.Add($"Sửa ô {edit.Key}: {item2.Name}  •  Lv {edit.Value.Level}");
			}
		}
		stagedList.EndUpdate();
		stagedCountLabel.Text = $"{staged.Count + editedExisting.Count} thay đổi";
		grid.Placements = existingPlacements.Concat(staged.Select((StagedWarehouseItem x) => new WarehousePlacement(x.Item, x.Slot, Pending: true))).ToArray();
		grid.SelectedSlot = selectedSlot;
		grid.Invalidate();
		UpdateButtons();
	}

	private void UpdateButtons()
	{
		bool loaded = (object)snapshot != null;
		addButton.Enabled = itemList.SelectedItem is ItemDefinition;
		removeButton.Enabled = stagedList.SelectedIndex >= 0;
		bool sameAccount = accountBox.Text.Trim().Equals(snapshot?.AccountId, StringComparison.OrdinalIgnoreCase);
		bool hasChanges = staged.Count > 0 || editedExisting.Count > 0;
		bool canSave = writeEnabled && loaded && hasChanges && sameAccount;
		saveButton.Enabled = canSave;
		saveButton.Text = ((!writeEnabled) ? "CHỈ XEM • GHI ĐANG TẮT" : ((!loaded) ? "TẢI KHO TRƯỚC" : ((!sameAccount) ? "TẢI LẠI KHO" : ((!hasChanges) ? "CHƯA CÓ MÓN" : "LƯU VÀO KHO"))));
		saveButton.BackColor = (canSave ? Gold : Color.FromArgb(30, 45, 64));
		saveButton.ForeColor = (canSave ? Color.Black : Color.FromArgb(176, 195, 213));
		saveButton.Cursor = (canSave ? Cursors.Hand : Cursors.Default);
		saveButton.FlatAppearance.BorderColor = (canSave ? Gold : Color.FromArgb(59, 77, 97));
	}

	private WarehouseItemRepository ReadRepository()
	{
		return new WarehouseItemRepository(new MuSvenDatabase(SqlClientFactory.Instance, databaseOptions.CreateConnectionString()));
	}

	private void ShowStatus(string text, bool error)
	{
		statusLabel.Text = text;
		statusLabel.ForeColor = (error ? Color.FromArgb(255, 128, 112) : (writeEnabled ? Color.FromArgb(103, 240, 170) : Color.FromArgb(255, 178, 115)));
	}

	private static GroupBox Group(string title)
	{
		return new GroupBox
		{
			Text = title,
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			BackColor = Panel,
			Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
			Padding = new Padding(8)
		};
	}

	private static Label SectionLabel(string text)
	{
		return new Label
		{
			Text = text,
			Dock = DockStyle.Fill,
			ForeColor = Ice,
			TextAlign = ContentAlignment.MiddleLeft,
			Font = new Font("Segoe UI", 9f, FontStyle.Bold)
		};
	}

	private static Label TopLabel(string text)
	{
		return new Label
		{
			Text = text,
			Dock = DockStyle.Fill,
			ForeColor = Gold,
			TextAlign = ContentAlignment.MiddleLeft,
			Font = new Font("Segoe UI", 9f, FontStyle.Bold)
		};
	}

	private static void StyleText(TextBox box)
	{
		box.Dock = DockStyle.Fill;
		box.BackColor = Color.FromArgb(18, 37, 58);
		box.ForeColor = Color.White;
		box.BorderStyle = BorderStyle.FixedSingle;
		box.Margin = new Padding(4, 4, 4, 4);
	}

	private static void StyleCombo(ComboBox box)
	{
		box.Dock = DockStyle.Fill;
		box.BackColor = Color.FromArgb(18, 37, 58);
		box.ForeColor = Color.White;
		box.FlatStyle = FlatStyle.Flat;
		box.Margin = new Padding(4, 4, 4, 4);
	}

	private static void StyleList(ListBox box)
	{
		box.Dock = DockStyle.Fill;
		box.BackColor = Color.FromArgb(7, 16, 29);
		box.ForeColor = Color.WhiteSmoke;
		box.BorderStyle = BorderStyle.FixedSingle;
		box.IntegralHeight = false;
		box.Font = new Font("Segoe UI", 9.5f);
	}

	private static void StyleButton(Button button, string text, bool prominent, bool gold = false)
	{
		button.Text = text;
		button.Dock = DockStyle.Fill;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = (gold ? Gold : (prominent ? Color.FromArgb(18, 70, 113) : Color.FromArgb(32, 40, 52)));
		button.ForeColor = (gold ? Color.Black : Color.White);
		button.FlatAppearance.BorderColor = (gold ? Gold : Edge);
		button.Margin = new Padding(4, 3, 4, 3);
		button.Cursor = Cursors.Hand;
		if (prominent && !gold)
		{
			button.FlatAppearance.MouseOverBackColor = Color.FromArgb(29, 86, 135);
		}
	}

	private static NumericUpDown Number(int minimum, int maximum, int value, int width)
	{
		return new NumericUpDown
		{
			Minimum = minimum,
			Maximum = maximum,
			Value = value,
			Width = width,
			Height = 25,
			BackColor = Color.FromArgb(18, 37, 58),
			ForeColor = Color.White,
			BorderStyle = BorderStyle.FixedSingle,
			TextAlign = HorizontalAlignment.Center,
			Margin = new Padding(3)
		};
	}

	private static Control InputCell(string label, NumericUpDown input, int width = 144)
	{
		TableLayoutPanel obj = new TableLayoutPanel
		{
			Width = width,
			Height = 54,
			ColumnCount = 1,
			RowCount = 2,
			Margin = new Padding(3),
			BackColor = Panel,
			RowStyles = 
			{
				new RowStyle(SizeType.Absolute, 23f),
				new RowStyle(SizeType.Absolute, 28f)
			},
			Controls = { 
			{
				(Control)new Label
				{
					Text = label,
					Dock = DockStyle.Fill,
					ForeColor = Ice,
					AutoEllipsis = true,
					TextAlign = ContentAlignment.MiddleLeft
				},
				0,
				0
			} }
		};
		input.Dock = DockStyle.Fill;
		obj.Controls.Add(input, 0, 1);
		return obj;
	}
}
