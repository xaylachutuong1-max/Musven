using System;
using System.Buffers.Binary;
using System.Collections.Generic;

namespace MuSven09M.Modules.Warehouse;

internal static class WarehouseItemFormat
{
	public static ItemCreationOptions DecodeOptions(ReadOnlySpan<byte> record)
	{
		if (record.Length != 16)
		{
			throw new InvalidOperationException("Bản ghi vật phẩm phải đúng 16 byte.");
		}
		return new ItemCreationOptions((record[1] >> 3) & 0xF, (record[1] & 3) | ((record[7] & 0x40) >> 4), record[2], (record[1] & 0x80) != 0, (record[1] & 4) != 0, (byte)(record[7] & 0x3F), record[8] & 0xF, record[10], record.Slice(11, 5).ToArray());
	}

	public static IReadOnlyList<WarehousePlacement> DecodePlacements(byte[] items)
	{
		if (items.Length != 3840)
		{
			throw new InvalidOperationException("Kho không có đủ 240 ô × 16 byte theo định dạng server.");
		}
		bool[] occupied = new bool[240];
		List<WarehousePlacement> placements = new List<WarehousePlacement>();
		for (int slot = 0; slot < 240; slot++)
		{
			Span<byte> record = items.AsSpan(slot * 16, 16);
			if (!IsEmpty(record))
			{
				if (occupied[slot])
				{
					throw new InvalidOperationException($"Kho có dữ liệu đè lên ô {slot}; Musven dừng để tránh làm hỏng đồ.");
				}
				int index = record[0] | ((record[7] & 0x80) << 1) | ((record[9] & 0xF0) << 5);
				if (!ItemCatalog.ByIndex.TryGetValue(index, out ItemDefinition item))
				{
					throw new InvalidOperationException($"Không giải mã được vật phẩm ItemIndex {index} ở ô {slot}. Không thể ghi kho an toàn.");
				}
				ValidatePlacement(item, slot, occupied);
				Mark(item, slot, occupied);
				placements.Add(new WarehousePlacement(item, slot, Pending: false));
			}
		}
		return placements;
	}

	public static bool[] BuildOccupancy(IReadOnlyList<WarehousePlacement> placements)
	{
		bool[] occupied = new bool[240];
		foreach (WarehousePlacement placement in placements)
		{
			Mark(placement.Item, placement.Slot, occupied);
		}
		return occupied;
	}

	public static void ValidatePlacement(ItemDefinition item, int slot, bool[] occupied)
	{
		if (slot < 0 || slot >= 240)
		{
			throw new InvalidOperationException("Ô kho phải nằm trong khoảng 0–239.");
		}
		int col = slot % 8;
		int row = slot / 8;
		if (col + item.Width > 8 || row + item.Height > 30)
		{
			throw new InvalidOperationException($"{item.Name} ({item.Width}×{item.Height}) không vừa tại ô {slot}; chọn ô khác.");
		}
		for (int y = row; y < row + item.Height; y++)
		{
			for (int x = col; x < col + item.Width; x++)
			{
				if (occupied[y * 8 + x])
				{
					throw new InvalidOperationException($"Ô {y * 8 + x} đã được sử dụng. Chọn vùng trống đủ {item.Width}×{item.Height}.");
				}
			}
		}
	}

	public static void Mark(ItemDefinition item, int slot, bool[] occupied)
	{
		int col = slot % 8;
		int row = slot / 8;
		for (int y = row; y < row + item.Height && y < 30; y++)
		{
			for (int x = col; x < col + item.Width && x < 8; x++)
			{
				occupied[y * 8 + x] = true;
			}
		}
	}

	public static int FindFirstFit(ItemDefinition item, bool[] occupied)
	{
		for (int slot = 0; slot < 240; slot++)
		{
			try
			{
				ValidatePlacement(item, slot, occupied);
				return slot;
			}
			catch (InvalidOperationException)
			{
			}
		}
		return -1;
	}

	public static byte[] Encode(ItemDefinition item, ItemCreationOptions options, uint serial)
	{
		int level = options.Level;
		bool flag = ((level < 0 || level > 15) ? true : false);
		bool flag2 = flag;
		if (!flag2)
		{
			int option = options.Option;
			bool flag3 = ((option < 0 || option > 7) ? true : false);
			flag2 = flag3;
		}
		bool flag4 = flag2;
		if (!flag4)
		{
			int option = options.Durability;
			bool flag3 = ((option < 0 || option > 255) ? true : false);
			flag4 = flag3;
		}
		bool flag5 = flag4;
		if (!flag5)
		{
			int option = options.SetOption;
			bool flag3 = ((option < 0 || option > 15) ? true : false);
			flag5 = flag3;
		}
		bool flag6 = flag5;
		if (!flag6)
		{
			int option = options.SpecialByte;
			bool flag3 = ((option < 0 || option > 255) ? true : false);
			flag6 = flag3;
		}
		if (flag6 || options.Sockets.Length != 5)
		{
			throw new InvalidOperationException("Một thuộc tính nằm ngoài giới hạn định dạng item của server.");
		}
		level = item.ItemIndex;
		if ((level < 0 || level > 8191) ? true : false)
		{
			throw new InvalidOperationException("ItemIndex vượt giới hạn lưu trữ của server.");
		}
		byte[] result = new byte[16]
		{
			(byte)(item.ItemIndex & 0xFF),
			(byte)((options.Level << 3) | (options.Skill ? 128 : 0) | (options.Luck ? 4 : 0) | (options.Option & 3)),
			(byte)options.Durability,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0
		};
		BinaryPrimitives.WriteUInt32BigEndian(result.AsSpan(3, 4), serial);
		result[7] = (byte)(((item.ItemIndex & 0x100) >> 1) | ((options.Option > 3) ? 64 : 0) | (options.Excellent & 0x3F));
		result[8] = (byte)(options.SetOption & 0xF);
		result[9] = (byte)((item.ItemIndex & 0x1E00) >> 5);
		result[10] = (byte)options.SpecialByte;
		Array.Copy(options.Sockets, 0, result, 11, 5);
		return result;
	}

	private static bool IsEmpty(ReadOnlySpan<byte> item)
	{
		bool allOnes = true;
		bool allZeroes = true;
		for (int i = 0; i < item.Length; i++)
		{
			allOnes &= item[i] == byte.MaxValue;
			allZeroes &= item[i] == 0;
		}
		return allOnes || allZeroes;
	}
}
