using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Warehouse;

public sealed class WarehouseItemRepository
{
	public const int ItemSize = 16;

	public const int SlotCount = 240;

	private readonly MuSvenDatabase database;

	public WarehouseItemRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public IReadOnlyList<WarehouseLocation> ListLocations(string accountId)
	{
		RequireAccount(accountId);
		using DbConnection connection = database.OpenConnection();
		List<WarehouseLocation> locations = new List<WarehouseLocation>();
		using (DbCommand command = connection.CreateCommand())
		{
			command.CommandText = "SELECT TOP (2) Money, DATALENGTH(Items) FROM dbo.warehouse WHERE AccountID=@AccountId";
			command.CommandTimeout = 8;
			AddParameter(command, "@AccountId", DbType.String, 10, accountId.Trim());
			using DbDataReader reader = command.ExecuteReader();
			if (reader.Read())
			{
				locations.Add(new WarehouseLocation(IsExtended: false, 0, (!reader.IsDBNull(0)) ? Convert.ToInt32(reader.GetValue(0)) : 0, (!reader.IsDBNull(1)) ? Convert.ToInt32(reader.GetValue(1)) : 0));
				if (reader.Read())
				{
					throw new InvalidOperationException("dbo.warehouse có nhiều dòng cho một AccountID; dừng để tránh chọn nhầm kho.");
				}
			}
		}
		using (DbCommand command2 = connection.CreateCommand())
		{
			command2.CommandText = "SELECT Number, Money, DATALENGTH(Items) FROM dbo.ExtWarehouse WHERE AccountID=@AccountId ORDER BY Number";
			command2.CommandTimeout = 8;
			AddParameter(command2, "@AccountId", DbType.String, 10, accountId.Trim());
			using DbDataReader reader2 = command2.ExecuteReader();
			HashSet<int> seen = new HashSet<int>();
			while (reader2.Read())
			{
				int number = Convert.ToInt32(reader2.GetValue(0));
				if (!seen.Add(number))
				{
					throw new InvalidOperationException("dbo.ExtWarehouse có Number bị trùng cho tài khoản này; dừng để tránh ghi nhầm kho.");
				}
				locations.Add(new WarehouseLocation(IsExtended: true, number, (!reader2.IsDBNull(1)) ? Convert.ToInt32(reader2.GetValue(1)) : 0, (!reader2.IsDBNull(2)) ? Convert.ToInt32(reader2.GetValue(2)) : 0));
			}
		}
		return locations;
	}

	public WarehouseSnapshot Load(string accountId, WarehouseLocation location)
	{
		RequireAccount(accountId);
		using DbConnection connection = database.OpenConnection();
		using DbCommand command = connection.CreateCommand();
		command.CommandText = (location.IsExtended ? "SELECT TOP (2) Items FROM dbo.ExtWarehouse WHERE AccountID=@AccountId AND Number=@Number" : "SELECT TOP (2) Items FROM dbo.warehouse WHERE AccountID=@AccountId");
		command.CommandTimeout = 8;
		AddParameter(command, "@AccountId", DbType.String, 10, accountId.Trim());
		if (location.IsExtended)
		{
			AddParameter(command, "@Number", DbType.Int32, 0, location.Number);
		}
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			throw new InvalidOperationException("Kho đã chọn không còn tồn tại. Hãy tải lại danh sách kho.");
		}
		if (reader.IsDBNull(0) || !(reader.GetValue(0) is byte[] items))
		{
			throw new InvalidOperationException("Cột Items của kho đang trống hoặc không phải dữ liệu nhị phân.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("Có nhiều dòng trùng cho kho đã chọn; Musven không thể ghi an toàn.");
		}
		if (items.Length != 3840)
		{
			throw new InvalidOperationException($"Kích thước Items là {items.Length} byte; Musven chỉ ghi an toàn khi đúng {3840} byte.");
		}
		return new WarehouseSnapshot(accountId.Trim(), location, items);
	}

	public IReadOnlyList<WarehousePlacement> DecodePlacements(byte[] items)
	{
		return WarehouseItemFormat.DecodePlacements(items);
	}

	public int Save(string accountId, WarehouseSnapshot expected, IReadOnlyList<StagedWarehouseItem> staged)
	{
		return SaveChanges(accountId, expected, staged.Select((StagedWarehouseItem item) => new WarehouseItemChange(item, EditExisting: false)).ToArray());
	}

	public int SaveChanges(string accountId, WarehouseSnapshot expected, IReadOnlyList<WarehouseItemChange> changes)
	{
		RequireAccount(accountId);
		if (changes.Count == 0)
		{
			throw new InvalidOperationException("Chưa có thay đổi vật phẩm nào trong danh sách chờ lưu.");
		}
		if (!accountId.Trim().Equals(expected.AccountId, StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("Tài khoản đã thay đổi; hãy tải lại kho trước khi lưu.");
		}
		using DbConnection connection = database.OpenConnection();
		using DbTransaction transaction = connection.BeginTransaction(IsolationLevel.Serializable);
		try
		{
			EnsureAccountOffline(connection, transaction, accountId.Trim());
			byte[] current = ReadLockedItems(connection, transaction, expected.Location, accountId.Trim());
			if (!current.AsSpan().SequenceEqual(expected.Items))
			{
				throw new InvalidOperationException("Dữ liệu kho đã thay đổi sau khi tải. Musven chưa ghi gì; hãy tải lại rồi thử lại.");
			}
			List<WarehousePlacement> list = WarehouseItemFormat.DecodePlacements(current).ToList();
			bool[] occupied = WarehouseItemFormat.BuildOccupancy(list);
			Dictionary<int, WarehousePlacement> placementsBySlot = list.ToDictionary((WarehousePlacement placement) => placement.Slot);
			HashSet<int> changedSlots = new HashSet<int>();
			foreach (WarehouseItemChange change in changes)
			{
				StagedWarehouseItem stagedItem = change.Item;
				if (!ItemCatalog.ByIndex.TryGetValue(stagedItem.Item.ItemIndex, out ItemDefinition catalogItem) || catalogItem != stagedItem.Item)
				{
					throw new InvalidOperationException("Vật phẩm không thuộc danh mục server hiện tại.");
				}
				if (!changedSlots.Add(stagedItem.Slot))
				{
					throw new InvalidOperationException($"Ô {stagedItem.Slot} có nhiều thay đổi; giao dịch đã hủy.");
				}
				if (change.EditExisting)
				{
					if (!placementsBySlot.TryGetValue(stagedItem.Slot, out var original) || original.Item.ItemIndex != stagedItem.Item.ItemIndex || original.Item.Width != stagedItem.Item.Width || original.Item.Height != stagedItem.Item.Height)
					{
						throw new InvalidOperationException($"Vật phẩm tại ô {stagedItem.Slot} đã đổi hoặc không còn tồn tại. Tải lại kho trước khi sửa.");
					}
					WarehouseItemFormat.Encode(stagedItem.Item, stagedItem.Options, 1u);
				}
				else
				{
					WarehouseItemFormat.ValidatePlacement(stagedItem.Item, stagedItem.Slot, occupied);
					WarehouseItemFormat.Mark(stagedItem.Item, stagedItem.Slot, occupied);
				}
			}
			byte[] updated = (byte[])current.Clone();
			foreach (WarehouseItemChange change2 in changes)
			{
				StagedWarehouseItem stagedItem2 = change2.Item;
				uint serial;
				if (change2.EditExisting)
				{
					serial = BinaryPrimitives.ReadUInt32BigEndian(current.AsSpan(stagedItem2.Slot * 16 + 3, 4));
					if (serial == 0)
					{
						throw new InvalidOperationException($"Vật phẩm tại ô {stagedItem2.Slot} không có serial hợp lệ; giao dịch đã hủy.");
					}
				}
				else
				{
					serial = NextSerial(connection, transaction);
				}
				Buffer.BlockCopy(WarehouseItemFormat.Encode(stagedItem2.Item, stagedItem2.Options, serial), 0, updated, stagedItem2.Slot * 16, 16);
			}
			using DbCommand update = connection.CreateCommand();
			update.Transaction = transaction;
			update.CommandTimeout = 10;
			update.CommandText = (expected.Location.IsExtended ? "UPDATE dbo.ExtWarehouse SET Items=@Items WHERE AccountID=@AccountId AND Number=@Number" : "UPDATE dbo.warehouse SET Items=@Items WHERE AccountID=@AccountId");
			AddParameter(update, "@Items", DbType.Binary, updated.Length, updated);
			AddParameter(update, "@AccountId", DbType.String, 10, accountId.Trim());
			if (expected.Location.IsExtended)
			{
				AddParameter(update, "@Number", DbType.Int32, 0, expected.Location.Number);
			}
			if (update.ExecuteNonQuery() != 1)
			{
				throw new InvalidOperationException("Số dòng kho thay đổi không đúng 1; giao dịch đã hủy.");
			}
			transaction.Commit();
			return changes.Count;
		}
		catch
		{
			try
			{
				transaction.Rollback();
			}
			catch
			{
			}
			throw;
		}
	}

	private static void EnsureAccountOffline(DbConnection connection, DbTransaction transaction, string accountId)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "SELECT TOP (2) ConnectStat FROM dbo.MEMB_STAT WITH (UPDLOCK,HOLDLOCK) WHERE memb___id=@AccountId";
		AddParameter(command, "@AccountId", DbType.String, 10, accountId);
		using DbDataReader reader = command.ExecuteReader();
		if (!reader.Read())
		{
			throw new InvalidOperationException("Tài khoản không có dòng trong dbo.MEMB_STAT; không thể xác nhận trạng thái ngoại tuyến.");
		}
		int num = Convert.ToInt32(reader.GetValue(0));
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.MEMB_STAT có nhiều dòng cho tài khoản này; dừng để tránh ghi không an toàn.");
		}
		if (num != 0)
		{
			throw new InvalidOperationException("Tài khoản đang trực tuyến. Hãy đăng xuất nhân vật và tải lại kho trước khi lưu.");
		}
	}

	private static byte[] ReadLockedItems(DbConnection connection, DbTransaction transaction, WarehouseLocation location, string accountId)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = (location.IsExtended ? "SELECT TOP (2) Items FROM dbo.ExtWarehouse WITH (UPDLOCK,HOLDLOCK) WHERE AccountID=@AccountId AND Number=@Number" : "SELECT TOP (2) Items FROM dbo.warehouse WITH (UPDLOCK,HOLDLOCK) WHERE AccountID=@AccountId");
		AddParameter(command, "@AccountId", DbType.String, 10, accountId);
		if (location.IsExtended)
		{
			AddParameter(command, "@Number", DbType.Int32, 0, location.Number);
		}
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read() || reader.IsDBNull(0) || !(reader.GetValue(0) is byte[] items))
		{
			throw new InvalidOperationException("Không đọc được Items của kho trong giao dịch; chưa ghi dữ liệu.");
		}
		if (reader.Read())
		{
			throw new InvalidOperationException("Kho có nhiều dòng khớp; giao dịch đã hủy.");
		}
		if (items.Length != 3840)
		{
			throw new InvalidOperationException("Kích thước Items không còn đúng 3840 byte; giao dịch đã hủy.");
		}
		return items;
	}

	private static uint NextSerial(DbConnection connection, DbTransaction transaction)
	{
		using DbCommand command = connection.CreateCommand();
		command.Transaction = transaction;
		command.CommandTimeout = 8;
		command.CommandText = "EXEC dbo.WZ_GetItemSerial";
		object value = command.ExecuteScalar();
		if (value == null || value is DBNull || !uint.TryParse(Convert.ToString(value), out var serial) || serial == 0)
		{
			throw new InvalidOperationException("dbo.WZ_GetItemSerial không trả về serial hợp lệ; giao dịch đã hủy.");
		}
		return serial;
	}

	private static void RequireAccount(string accountId)
	{
		if (string.IsNullOrWhiteSpace(accountId) || accountId.Trim().Length > 10)
		{
			throw new ArgumentException("AccountID phải có từ 1 đến 10 ký tự.", "accountId");
		}
	}

	private static void AddParameter(DbCommand command, string name, DbType type, int size, object value)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = name;
		parameter.DbType = type;
		if (size > 0)
		{
			parameter.Size = size;
		}
		parameter.Value = value;
		command.Parameters.Add(parameter);
	}
}
