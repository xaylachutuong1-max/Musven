namespace MuSven09M.Modules.Warehouse;

public sealed record WarehouseLocation(bool IsExtended, int Number, int Money, int ItemBytes)
{
	public string DisplayName
	{
		get
		{
			if (!IsExtended)
			{
				return "Kho chính (0)";
			}
			return $"Kho mở rộng {Number}";
		}
	}

	public override string ToString()
	{
		return $"{DisplayName}  •  {ItemBytes} byte";
	}
}
