namespace MuSven09M.Modules.Warehouse;

public sealed record WarehousePlacement(ItemDefinition Item, int Slot, bool Pending);
