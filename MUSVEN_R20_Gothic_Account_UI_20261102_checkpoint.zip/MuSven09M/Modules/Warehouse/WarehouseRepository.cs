using System;
using System.Data;
using System.Data.Common;
using MuSven09M.Modules.Account;

namespace MuSven09M.Modules.Warehouse;

public sealed class WarehouseRepository
{
	private readonly MuSvenDatabase database;

	public WarehouseRepository(MuSvenDatabase database)
	{
		this.database = database ?? throw new ArgumentNullException("database");
	}

	public JewelBankBalance? FindJewelBank(string accountId)
	{
		if (string.IsNullOrWhiteSpace(accountId))
		{
			throw new ArgumentException("Account ID is required.", "accountId");
		}
		using DbConnection connection = database.OpenConnection();
		using DbCommand command = connection.CreateCommand();
		command.CommandText = "\nSELECT TOP (2) AccountID, Bless, Soul, Life, Creation, Guardian,\n       Harmony, GemStone, Chaos, LowStone, HighStone\nFROM dbo.DATDAT_BANK\nWHERE AccountID = @AccountId";
		command.CommandType = CommandType.Text;
		command.CommandTimeout = 5;
		AddAccountParameter(command, accountId);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			return null;
		}
		JewelBankBalance result = new JewelBankBalance(Text(reader, 0), Int(reader, 1), Int(reader, 2), Int(reader, 3), Int(reader, 4), Int(reader, 5), Int(reader, 6), Int(reader, 7), Int(reader, 8), Int(reader, 9), Int(reader, 10));
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.DATDAT_BANK có nhiều dòng cho cùng một AccountID; Musven không hiển thị số dư mơ hồ.");
		}
		return result;
	}

	public ExtendedWarehouseSummary? FindExtendedWarehouse(string accountId)
	{
		if (string.IsNullOrWhiteSpace(accountId))
		{
			throw new ArgumentException("Account ID is required.", "accountId");
		}
		using DbConnection connection = database.OpenConnection();
		using DbCommand command = connection.CreateCommand();
		command.CommandText = "\nSELECT TOP (2) AccountID, Number, Money, DATALENGTH(Items)\nFROM dbo.ExtWarehouse\nWHERE AccountID = @AccountId";
		command.CommandType = CommandType.Text;
		command.CommandTimeout = 5;
		AddAccountParameter(command, accountId);
		using DbDataReader reader = command.ExecuteReader(CommandBehavior.SequentialAccess);
		if (!reader.Read())
		{
			return null;
		}
		ExtendedWarehouseSummary result = new ExtendedWarehouseSummary(Text(reader, 0), Int(reader, 1), Int(reader, 2), reader.IsDBNull(3) ? ((int?)null) : new int?(Int(reader, 3)));
		if (reader.Read())
		{
			throw new InvalidOperationException("dbo.ExtWarehouse có nhiều dòng cho cùng một AccountID; Musven không hiển thị số liệu mơ hồ.");
		}
		return result;
	}

	private static void AddAccountParameter(DbCommand command, string accountId)
	{
		DbParameter parameter = command.CreateParameter();
		parameter.ParameterName = "@AccountId";
		parameter.DbType = DbType.String;
		parameter.Size = 10;
		parameter.Value = accountId.Trim();
		command.Parameters.Add(parameter);
	}

	private static string Text(DbDataReader reader, int ordinal)
	{
		string text;
		if (!reader.IsDBNull(ordinal))
		{
			text = Convert.ToString(reader.GetValue(ordinal));
			if (text == null)
			{
				return string.Empty;
			}
		}
		else
		{
			text = string.Empty;
		}
		return text;
	}

	private static int Int(DbDataReader reader, int ordinal)
	{
		if (!reader.IsDBNull(ordinal))
		{
			return Convert.ToInt32(reader.GetValue(ordinal));
		}
		return 0;
	}
}
