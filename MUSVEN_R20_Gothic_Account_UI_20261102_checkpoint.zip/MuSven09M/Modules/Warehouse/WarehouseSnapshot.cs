namespace MuSven09M.Modules.Warehouse;

public sealed record WarehouseSnapshot(string AccountId, WarehouseLocation Location, byte[] Items);
