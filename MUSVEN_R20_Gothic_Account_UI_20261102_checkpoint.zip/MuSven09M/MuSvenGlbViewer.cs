using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace MuSven09M;

internal sealed class MuSvenGlbViewer : UserControl
{
	private readonly WebView2 browser = new WebView2
	{
		Dock = DockStyle.Fill,
		DefaultBackgroundColor = Color.FromArgb(6, 16, 34)
	};

	private readonly Label message = new Label
	{
		Dock = DockStyle.Fill,
		TextAlign = ContentAlignment.MiddleCenter,
		ForeColor = Color.FromArgb(106, 211, 255),
		BackColor = Color.FromArgb(6, 16, 34),
		Text = "Đang tải mô hình Dark Knight 3D..."
	};

	private bool started;

	public bool IsReady
	{
		get
		{
			if (browser.CoreWebView2 != null)
			{
				return browser.Visible;
			}
			return false;
		}
	}

	public event Action? ViewerReady;

	public async Task<bool> ToggleEquipmentAsync(string part)
	{
		if (browser.CoreWebView2 == null || !browser.Visible)
		{
			return false;
		}
		if (part != "weapon" && part != "helm" && part != "wings" && part != "armor" && part != "glove" && part != "pant" && part != "boot" && part != "ring" && part != "necklace")
		{
			return false;
		}
		return await browser.CoreWebView2.ExecuteScriptAsync("window.toggleEquipment && window.toggleEquipment('" + part + "')") == "true";
	}

	public async Task<bool> SwitchEquipmentSetAsync(string set)
	{
		if (set != "bronze" && set != "group02")
		{
			return false;
		}
		if (browser.CoreWebView2 == null || !browser.Visible)
		{
			return false;
		}
		return await browser.CoreWebView2.ExecuteScriptAsync("window.switchEquipmentSet && window.switchEquipmentSet('" + set + "')") == "true";
	}

	public MuSvenGlbViewer()
	{
		BackColor = Color.FromArgb(6, 16, 34);
		base.Controls.Add(message);
		base.Controls.Add(browser);
		browser.Visible = false;
		base.Load += async delegate
		{
			if (started)
			{
				return;
			}
			started = true;
			try
			{
				string viewerDir = Path.Combine(AppContext.BaseDirectory, "Viewer");
				ExtractEmbeddedViewerFiles(viewerDir);
				string[] array = new string[6] { "index.html", "three.module.js", "GLTFLoader.js", "OrbitControls.js", "MU_SVEN_DK_BRONZE.glb", "MU_SVEN_DK_GROUP02.glb" };
				foreach (string name in array)
				{
					if (!File.Exists(Path.Combine(viewerDir, name)))
					{
						throw new FileNotFoundException("Thiếu file viewer: " + name);
					}
				}
				string userDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MUSVEN Admin", "WebView2");
				Directory.CreateDirectory(userDataFolder);
				CoreWebView2Environment environment = await CoreWebView2Environment.CreateAsync(null, userDataFolder);
				await browser.EnsureCoreWebView2Async(environment);
				browser.CoreWebView2.SetVirtualHostNameToFolderMapping("musven.local", viewerDir, CoreWebView2HostResourceAccessKind.DenyCors);
				browser.CoreWebView2.Settings.IsStatusBarEnabled = false;
				browser.CoreWebView2.Settings.AreDevToolsEnabled = true;
				browser.CoreWebView2.WebMessageReceived += delegate(object? obj, CoreWebView2WebMessageReceivedEventArgs args)
				{
					string text = args.TryGetWebMessageAsString();
					if (text == "READY")
					{
						browser.Visible = true;
						message.Visible = false;
						this.ViewerReady?.Invoke();
					}
					else if (text.StartsWith("ERROR:"))
					{
						browser.Visible = false;
						message.Text = text;
						message.BringToFront();
					}
				};
				browser.Source = new Uri("https://musven.local/index.html");
			}
			catch (Exception ex)
			{
				browser.Visible = false;
				message.Text = "Không khởi tạo được 3D viewer:\n" + ex.Message;
				message.BringToFront();
			}
		};
	}

	private static void ExtractEmbeddedViewerFiles(string viewerDir)
	{
		(string, string)[] obj = new(string, string)[7]
		{
			("MuSven.Resources.Viewer.index.html", "index.html"),
			("MuSven.Resources.Viewer.three.module.js", "three.module.js"),
			("MuSven.Resources.Viewer.GLTFLoader.js", "GLTFLoader.js"),
			("MuSven.Resources.Viewer.OrbitControls.js", "OrbitControls.js"),
			("MuSven.Resources.Viewer.utils.BufferGeometryUtils.js", Path.Combine("utils", "BufferGeometryUtils.js")),
			("MuSven.Resources.Viewer.MU_SVEN_DK_BRONZE.glb", "MU_SVEN_DK_BRONZE.glb"),
			("MuSven.Resources.Viewer.MU_SVEN_DK_GROUP02.glb", "MU_SVEN_DK_GROUP02.glb")
		};
		Directory.CreateDirectory(viewerDir);
		Assembly assembly = Assembly.GetExecutingAssembly();
		(string, string)[] array = obj;
		for (int i = 0; i < array.Length; i++)
		{
			(string, string) file = array[i];
			string path = Path.Combine(viewerDir, file.Item2);
			Directory.CreateDirectory(Path.GetDirectoryName(path));
			using Stream source = assembly.GetManifestResourceStream(file.Item1) ?? throw new FileNotFoundException("Không tìm thấy tài nguyên 3D được đóng gói: " + file.Item2);
			using FileStream destination = File.Create(path);
			source.CopyTo(destination);
		}
	}
}
