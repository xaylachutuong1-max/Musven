using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace MuSven09M;

internal static class Program
{
	[STAThread]
	private static void Main()
	{
		Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
		Application.ThreadException += delegate(object _, ThreadExceptionEventArgs eventArgs)
		{
			ReportUnhandled(eventArgs.Exception);
		};
		AppDomain.CurrentDomain.UnhandledException += delegate(object _, UnhandledExceptionEventArgs eventArgs)
		{
			if (eventArgs.ExceptionObject is Exception exception2)
			{
				ReportUnhandled(exception2);
			}
		};
		try
		{
			ApplicationConfiguration.Initialize();
			Application.Run(new MainWindow());
		}
		catch (Exception exception)
		{
			ReportUnhandled(exception);
		}
	}

	private static void ReportUnhandled(Exception exception)
	{
		string logPath = Path.Combine(AppContext.BaseDirectory, "MU_SVEN_09Q_error.log");
		try
		{
			File.AppendAllText(logPath, $"{DateTimeOffset.Now:O}{Environment.NewLine}{exception}{Environment.NewLine}{Environment.NewLine}", Encoding.UTF8);
		}
		catch
		{
		}
		try
		{
			MessageBox.Show("MU SVEN gặp lỗi và không thể tiếp tục.\n\n" + exception.Message + "\n\nChi tiết: " + logPath, "MU SVEN • Lỗi khởi động", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		catch
		{
		}
	}
}
