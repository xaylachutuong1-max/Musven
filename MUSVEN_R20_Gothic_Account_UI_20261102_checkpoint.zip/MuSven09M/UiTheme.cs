using System.Drawing;
using System.Windows.Forms;

namespace MuSven09M;

internal static class UiTheme
{
	private static readonly Color Background = Color.FromArgb(11, 17, 27);

	private static readonly Color Surface = Color.FromArgb(19, 29, 44);

	private static readonly Color Input = Color.FromArgb(22, 36, 54);

	private static readonly Color Border = Color.FromArgb(43, 59, 78);

	private static readonly Color Text = Color.FromArgb(231, 237, 244);

	private static readonly Color Gold = Color.FromArgb(237, 190, 95);

	private static readonly Color Blue = Color.FromArgb(28, 68, 103);

	public static void Apply(Form form)
	{
		form.BackColor = Background;
		form.ForeColor = Text;
		form.Font = new Font("Segoe UI", 9.5f);
		ApplyToChildren(form.Controls);
	}

	public static void ApplyToChildren(Control.ControlCollection controls)
	{
		foreach (Control control in controls)
		{
			Control control2 = control;
			if (!(control2 is Button button))
			{
				if (!(control2 is TextBox textBox))
				{
					if (!(control2 is ComboBox comboBox))
					{
						if (!(control2 is NumericUpDown numeric))
						{
							if (!(control2 is ListBox list))
							{
								if (!(control2 is Label label))
								{
									if (!(control2 is CheckBox checkBox))
									{
										if (!(control2 is RadioButton radio))
										{
											if (control2 is TabPage tabPage)
											{
												tabPage.BackColor = Surface;
												tabPage.ForeColor = Text;
											}
										}
										else if (radio.ForeColor == SystemColors.ControlText)
										{
											radio.ForeColor = Text;
										}
									}
									else if (checkBox.ForeColor == SystemColors.ControlText)
									{
										checkBox.ForeColor = Text;
									}
								}
								else if (label.ForeColor == SystemColors.ControlText)
								{
									label.ForeColor = Text;
								}
							}
							else
							{
								list.BackColor = Input;
								list.ForeColor = Text;
								list.BorderStyle = BorderStyle.None;
							}
						}
						else
						{
							numeric.BackColor = Input;
							numeric.ForeColor = Text;
							numeric.BorderStyle = BorderStyle.FixedSingle;
						}
					}
					else
					{
						comboBox.BackColor = Input;
						comboBox.ForeColor = Text;
						comboBox.FlatStyle = FlatStyle.Flat;
					}
				}
				else
				{
					textBox.BackColor = Input;
					textBox.ForeColor = Text;
					textBox.BorderStyle = BorderStyle.FixedSingle;
				}
			}
			else
			{
				button.FlatStyle = FlatStyle.Flat;
				bool emphasized = button.BackColor == Color.FromArgb(249, 188, 71) || button.BackColor == Gold;
				button.FlatAppearance.BorderColor = (emphasized ? Gold : Border);
				button.FlatAppearance.BorderSize = ((!emphasized) ? 1 : 0);
				button.FlatAppearance.MouseOverBackColor = (emphasized ? Color.FromArgb(255, 214, 119) : Color.FromArgb(37, 87, 128));
				if (button.BackColor == SystemColors.Control)
				{
					button.BackColor = Blue;
				}
				if (button.ForeColor == SystemColors.ControlText)
				{
					button.ForeColor = Text;
				}
				button.UseVisualStyleBackColor = false;
			}
			if (control.BackColor == SystemColors.Control && !(control is Label) && !(control is Button) && !(control is TextBox) && !(control is ComboBox) && !(control is NumericUpDown) && !(control is ListBox) && !(control is CheckBox) && !(control is RadioButton))
			{
				control.BackColor = Surface;
			}
			ApplyToChildren(control.Controls);
		}
	}
}
