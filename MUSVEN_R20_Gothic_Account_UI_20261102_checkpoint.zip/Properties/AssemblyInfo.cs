using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: SupportedOSPlatform("windows")]
[assembly: AssemblyVersion("0.0.0.0")]
