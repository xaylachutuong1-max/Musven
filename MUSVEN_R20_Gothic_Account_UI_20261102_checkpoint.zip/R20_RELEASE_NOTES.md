# MUSVEN Gothic Admin R20

## Cơ sở bản phát hành

- Dùng R17 làm chuẩn đầy đủ theo yêu cầu của người dùng.
- Khôi phục trực tiếp 99 tệp C# từ DLL R17 bằng ILSpy; R20 giữ lại toàn bộ các tệp đó trừ `ApplicationConfiguration.cs`, vì SDK Windows Forms tự sinh lớp này. Các thay đổi cần để biên dịch gồm chỉ rõ `System.Windows.Forms.Timer`, giữ tên cột tuple khi kiểm tra schema tạo tài khoản, và bỏ thuộc tính compiler-reserved do decompiler xuất ra.
- Không sửa thư mục, DLL, cấu hình hoặc checkpoint R17.
- Gothic UI giữ giao diện R17 đã nhúng; R20 bổ sung cuộn cho danh sách 14 thao tác nâng cao và trạng thái tải/lỗi/thử lại của trình sửa nhân vật. Bố cục kho đã được chỉnh để đặt Kho đồ, Túi nhân vật và Tạo vật phẩm cạnh nhau trên màn hình desktop, rồi xếp dọc ở viewport hẹp.
- Giữ toàn bộ 924 ảnh vật phẩm, 2 mô hình 3D, catalog item từ resource R17, và các repository/guard nghiệp vụ đã có.
- Trên ứng dụng chính, nút `GOTHIC UI` nằm cạnh `KIỂM TRA KẾT NỐI`; không thay giao diện gốc thành Gothic.

## Kiểm tra đã chạy

- `dotnet build` Release thành công: 0 lỗi, 0 cảnh báo.
- `dotnet publish` self-contained `win-x86`, .NET 8.0.32 thành công từ feed package nội bộ.
- `node --check` qua `GothicUi/app.js`, `api.js`, `options.js`.
- Contract audit: 27 method UI, 27 route backend, 24 lời gọi trực tiếp trong UI; không có route thiếu khai báo hoặc thiếu trong tài liệu.
- Đối chiếu nguồn: đủ 99 tệp C# khôi phục từ R17, ngoài lớp `ApplicationConfiguration` do SDK sinh tự động.
- Đủ 924 ảnh item được đưa vào gói publish.

## Trạng thái nghiệm thu

- Ngày 2026-11-01: mở R20 bằng nút Gothic trong ứng dụng chính ở VM; cửa sổ Gothic phủ vùng làm việc, trang Account và preview nhân vật 3D hiển thị. Các trang Chỉnh sửa nhân vật, Kho đồ, Item Catalog và Máy chủ cũng mở được.
- Ngày 2026-11-01: mở lại DLL mới nhất trong VM và xác nhận trực quan trang Kho đồ hiển thị ba vùng Kho đồ, Túi nhân vật, Tạo vật phẩm theo cột cạnh nhau; danh mục đọc chỉ hiển thị 941 mục. Chưa chọn tài khoản nên lưới kho thực chưa tải; không tạo, kéo hoặc lưu item.
- Cửa sổ cấu hình tạo nhân vật đọc và hiển thị các trường cấu hình; Master Level và Điểm Master có mức tối đa 400. Đã đóng cửa sổ, không lưu.
- Nghiệm thu đọc chỉ: báo cáo R20 trước đó ghi nhận AccountID `pincheck` và 5 nhân vật. Trong lượt quan sát mới này không lặp lại tìm kiếm được vì bàn phím không truyền vào guest qua console VirtualBox.
- Không dùng lệnh ghi SQL để thử. Ghi database, migration, lưu tiền/ngọc, Harmony/Socket, kéo thả kho và lưu item vẫn ở trạng thái **CHƯA NGHIỆM THU**.
- Trạng thái dịch vụ GameServer/DataServer/ConnectServer tiếp tục là chưa xác minh; chưa có API/probe được xác thực cho các endpoint này.
- Các tính năng ghi giữ nguyên kiểm tra schema, tài khoản offline, snapshot, transaction, xác nhận và feature flag riêng.
- Kick player, gửi thông báo broadcast, điều khiển GameServer/ConnectServer vẫn không được báo là đã xong: rà source hiện có không tìm thấy listener/protocol desktop được xác thực. `WZ_DISCONNECT_MEMB` chỉ cập nhật trường SQL, không ngắt socket. Không thêm hành vi giả hoặc lệnh dừng/khởi động server.
- Lưu stats tùy biến vào catalog item vẫn không có schema/API server được xác minh. Hiển thị danh mục và mã item đã có; không tự tạo cấu trúc ghi mới vào database.

## Cập nhật nghiệm thu tiếp — 2026-11-02

- Thêm viền vát nổi, góc trang trí và nền đá tối cho các panel Gothic của Dashboard tài khoản trong `GothicUi/styles.css`; vẫn dùng CSS, không dùng ảnh chụp giao diện làm nền. Không sửa hợp đồng API, SQL, schema hoặc mã dịch vụ.
- Build Release lặp lại thành công: 0 warning, 0 error. `node --check` thành công cho `app.js`, `api.js`, `options.js`; `Verify-GothicContracts.ps1` thành công với 27 khai báo API, 27 route backend, 24 lời gọi UI.
- Mở lại đúng bản R20 qua nút `GOTHIC UI` trong ứng dụng MUSVEN chính trên VM. Đã thấy Dashboard tài khoản Gothic, mô hình 3D mẫu, trang chỉnh sửa nhân vật ở trạng thái chưa chọn, trang kho ba vùng và Item Catalog 941 mục chỉ đọc.
- Mô hình 3D đang là mẫu xem trước; chưa xác minh việc đồng bộ hình nhân vật/trang bị thật theo người chơi đang online. Các thẻ trạng thái dịch vụ vẫn hiện `KHÔNG THỂ XÁC MINH`.
- Lần tìm `pincheck` mới không thành công do VirtualBox không truyền chuỗi bàn phím vào ô tìm kiếm. Báo cáo đọc tài khoản trước đó vẫn được giữ như kết quả cũ, không gán thành kết quả kiểm tra lần này.
- DLL nguồn và VM khớp SHA-256 `2FC62F84FDE9C630DFD76DDCB9DCF27DCB95899BDA80BAA33798EF36DCBC9B8D`.
- Nghiệm thu ghi dữ liệu SQL, currency, Harmony/Socket, kéo thả kho và lưu item vẫn ở trạng thái **CHƯA NGHIỆM THU**. Không ghi database, đổi Config.ini hoặc dừng/khởi động lại dịch vụ.

## Khôi phục

Giữ nguyên và chạy R17 từ thư mục R17 nếu cần quay lại. R20 được đặt ở thư mục riêng; `work\backups\MUSVEN_Gothic_R20_checkpoint_20261031.zip` là checkpoint nguồn + binary, có SHA-256 ở file `.txt` cùng tên.
