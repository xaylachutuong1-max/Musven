# MU SVEN 09Q

## R20 — chuẩn nguồn R17

R20 được dựng từ 99 tệp C# khôi phục trực tiếp từ `MU_SVEN_09Q.dll` của bản R17; không dùng nhánh R14 làm lõi. 98 tệp được biên dịch trực tiếp và `ApplicationConfiguration` được sinh bởi Windows Forms SDK để tránh định nghĩa trùng. Các tài nguyên Gothic và danh mục vật phẩm trùng với resource đã đóng gói trong R17. Bản UI R20 bổ sung cuộn danh sách thao tác nâng cao và trạng thái tải/sửa nhân vật; R17 gốc vẫn nguyên vẹn.

Mở MUSVEN Admin, bấm **GOTHIC UI** cạnh **KIỂM TRA KẾT NỐI** để vào giao diện mới. Xem `R20_RELEASE_NOTES.md` và `DEPLOYMENT_STATUS.txt` để biết kết quả build/contract và phần còn chờ nghiệm thu trong VM.

Ứng dụng quản trị WinForms x86, self-contained. Giao diện dùng header, thanh điều hướng và các thẻ chức năng native đồng bộ; không dùng ảnh banner làm giao diện. Gói phát hành có một EXE chính và các DLL native đi kèm trong cùng thư mục. **Giải nén toàn bộ ZIP vào một thư mục trên ổ D hoặc E rồi chạy EXE ở đó; không chạy trực tiếp bên trong cửa sổ ZIP hoặc chỉ chép riêng EXE**, vì các DLL native cần nằm cạnh chương trình. Mẫu cấu hình, thông báo giấy phép và dữ liệu 3D được đóng gói bên trong. Khi mở trang xem 3D, Musven giải nén các tài nguyên vào thư mục `Viewer` nằm cạnh EXE.

## Các mục trên giao diện

| Mục | Dùng để làm gì |
| --- | --- |
| **Tài khoản** | Tìm tài khoản theo tiền tố; tạo account với mật khẩu trống; xem nhân vật/trạng thái; sửa tên/email bằng schema đã xác minh, yêu cầu offline, snapshot và transaction; gỡ khóa hết hạn hoặc khóa tạm thời theo hợp đồng đã rà soát. |
| **Nhân vật** | Tìm nhân vật theo AccountID, xem Level/Reset; tạo, sửa trường số, sửa bộ đếm quái nhiệm vụ đã có dòng, và xóa nhân vật theo từng cờ ghi riêng. |
| **Vật phẩm** | Tìm tên vật phẩm theo nhóm từ danh mục server, tự điền Type/ID/ItemIndex và sao chép mã; vẫn có thể tính thủ công. |
| **Kho đồ** | Xem/sửa có điều kiện WCoin, Goblin Point và số dư ngân hàng ngọc; tải kho chính/kho mở rộng, tìm vật phẩm theo nhóm và xếp vật phẩm mới vào ô trống. |
| **Quản lý** | Tập trung các nhóm tài khoản, nhân vật, tiền/ngọc, xếp hạng, sự kiện, máy chủ và VIP/mốc nạp. Có trình duyệt ranking/sự kiện chỉ đọc tối đa 100 dòng; tác vụ xóa/ghi chưa được xác nhận schema/quyền sẽ bị khóa. |
| **Công cụ** | ItemIndex, backup SQL thủ công và xóa trắng dữ liệu server có xem trước/backup bắt buộc. Dọn log/file database và backup tự động chưa bật. |
| **Cài đặt** | Tạo/mở `Config.ini`, mở thư mục chương trình, kiểm tra kết nối và kiểm kê schema Musven. |

Tạo đồ vào kho dùng danh mục `Item.xml` của chính server được đóng gói trong Musven. Công cụ lưu vào kho tài khoản để nhân vật rút trong game; không sửa túi đang mang trực tiếp. Mẫu cấu hình source khóa ghi an toàn; gói dành cho VM bật riêng các thao tác đã triển khai. Trang Nhân vật có thể cấu hình giá trị mặc định mà người chơi nhận khi tự tạo nhân vật trong game; Musven lưu vào database, không tạo nhân vật riêng. Trang này cũng sửa các trường số cho phép và xóa qua `WZ_DeleteCharacter`; mỗi thao tác có công tắc riêng. Sửa trường không chạm inventory/skill. Xóa yêu cầu tài khoản offline, tên nhân vật duy nhất toàn bảng, nhập đúng tên và xác nhận lần cuối. Backup thủ công có công tắc riêng. Xóa trắng dữ liệu cần đúng schema, máy SQL đã ghim, không còn session game, backup thành công và xác nhận gõ lại; thao tác thu hồi dung lượng file log vẫn khóa.

Khu vực 3D ở trang Tài khoản là mô hình minh họa Dark Knight, không đọc trang bị của nhân vật và không thể thay đổi nhân vật trong game. Năm nút Mũ/Giáp/Găng/Quần/Giày chỉ ẩn/hiện mesh trên mô hình mẫu; các vị trí chưa có mesh sẽ bị khóa. Xoay, phóng to và đổi bộ Bronze/Group 02 cũng chỉ tác động bản xem trước.

## Kết nối SQL chỉ đọc

1. Khi Musven chạy trên máy chính còn SQL Server chạy trong VM, dùng địa chỉ chuyển tiếp VirtualBox. Trong cấu hình hiện tại là `127.0.0.1,11433` → cổng `1433` của VM.
2. Có thể dùng `Authentication=Sql` với `User` và `Password`, hoặc `Authentication=Windows` nếu máy chủ SQL hỗ trợ xác thực Windows từ máy chính. File `Config.ini` lưu mật khẩu dạng văn bản; giữ quyền riêng tư và không gửi file qua chat.
3. `TrustServerCertificate=1` chỉ dành cho chứng chỉ tự ký trong VM cô lập; với SQL từ xa, dùng chứng chỉ hợp lệ và đặt giá trị này thành `0`.
4. Đặt `Config.ini` cạnh EXE Musven, lưu file, đóng rồi mở lại ứng dụng. Bấm **Kiểm tra kết nối SQL**. Nếu Config.ini trong gói VM bị mất, phục hồi từ `Config.ini.vm.template`; profile đó dùng Windows Authentication cho `Muonline` và bật riêng các cờ đã triển khai. `Config.ini.template` thường vẫn khóa ghi an toàn cho máy khác.

Để đối chiếu cấu trúc database đang chạy, vào **Cài đặt → Kiểm tra schema Musven**. Báo cáo chỉ đọc catalog SQL Server, liệt kê bảng/cột/thủ tục, kiểu dữ liệu, độ dài, cờ IDENTITY và marker của procedure; nút **Sao chép báo cáo** giúp gửi kết quả kiểm tra. Báo cáo không truy vấn dữ liệu người chơi và không tự sinh/chạy DDL. `DatabaseScripts\MUSVEN_VerifyCharacterCreateDefaults.sql` là truy vấn chỉ đọc bổ sung để đối chiếu marker V03, chữ ký, bảng/ràng buộc và dòng cấu hình tạo nhân vật. Tài khoản SQL cần nhìn thấy metadata của các đối tượng này; trạng thái `THIẾU / KHÔNG HIỂN THỊ` cần được phân biệt với việc object thực sự chưa có trước khi thêm SQL.

Giao diện chính dùng thanh điều hướng native cho bảy mục. Trong **Kho đồ → Tiền / Ngọc**, Musven đọc WCoin/Goblin Point từ `CashShopData` và 10 loại ngọc từ `DATDAT_BANK`. Bật cờ ghi chỉ có tác dụng trong profile VM đã cấu hình; luôn cần đúng quyền SQL và tài khoản offline.

Để sao lưu database thủ công, bật `[MUSVEN_SQL_BACKUP] Enabled=1` và điền `ServerPath` là đường dẫn tuyệt đối trên máy chạy SQL Server. Tài khoản SQL cần quyền `BACKUP DATABASE`; tài khoản dịch vụ SQL Server cần quyền ghi thư mục. Musven tạo file mới bằng `COPY_ONLY` và `CHECKSUM`, sau đó chạy `RESTORE VERIFYONLY`. Tác vụ tự động chưa bật.

Để sửa WCoin/Goblin Point và ngân hàng ngọc, chỉ bật `Enabled=1` riêng trong `[MUSVEN_CURRENCY_WRITES]`. Cần `SELECT` trên `dbo.MEMB_STAT`, `dbo.CashShopData`, `dbo.DATDAT_BANK` và `UPDATE` trên hai bảng số dư. Musven yêu cầu tài khoản ngoại tuyến, dòng số dư tồn tại, so sánh số liệu đã tải với dữ liệu hiện tại và cập nhật hai bảng trong một transaction. Musven không tự tạo dòng tài khoản hoặc số dư.

Để lưu vật phẩm, chỉ bật `Enabled=1` riêng trong mục `[MUSVEN_ITEM_WRITES]` sau khi đã kiểm tra quyền SQL. Quyền tối thiểu cần đọc `dbo.MEMB_STAT`, `dbo.warehouse`, `dbo.ExtWarehouse`; cập nhật cột `Items` ở hai bảng kho; và thực thi `dbo.WZ_GetItemSerial`. Musven yêu cầu tài khoản ngoại tuyến, chỉ thêm vào ô trống, kiểm tra kho không đổi kể từ lúc tải và hủy toàn bộ giao dịch khi có dữ liệu không nhận diện được. Musven không tự tạo dòng kho còn thiếu.

Để sửa nhân vật, bật riêng `Enabled=1` trong `[MUSVEN_CHARACTER_WRITES]`; cần `SELECT` trên `dbo.MEMB_STAT`/`dbo.Character` và quyền `UPDATE dbo.Character`. Các trường Master cần thêm `SELECT` và `UPDATE` trên `dbo.MasterSkillTree`. Musven chỉ cho sửa các trường số trong danh sách cho phép khi các cột tương ứng có trong schema, kiểm tra tài khoản ngoại tuyến, khóa dòng và từ chối lưu nếu dữ liệu đã đổi từ lúc mở. Không sửa inventory/skill.

Đổi tên nhân vật dùng `[MUSVEN_CHARACTER_RENAME] Enabled=1` và `dbo.WZ_RenameCharacter(@Account varchar(10), @OldName varchar(10), @NewName varchar(10))`. Musven kiểm tra toàn bộ body procedure với whitelist các bảng tham chiếu đã thấy trên VM, yêu cầu đúng chữ ký và đủ 28 lệnh UPDATE, tài khoản offline, tên mới chưa có, transaction và hậu kiểm. Cần `VIEW DEFINITION`, `EXECUTE`, đọc/ghi các bảng mà procedure cập nhật. Chỉ tài khoản VM bật cờ này; mẫu chung tắt.

Cấp thành viên dùng `[MUSVEN_ACCOUNT_LEVEL] Enabled=1` và `dbo.WZ_SetAccountLevel`. Musven xác minh `MEMB_INFO.AccountLevel int`, `AccountExpireDate smalldatetime`, đúng chữ ký và toàn bộ body procedure; tài khoản phải offline. Thời hạn nhập theo ngày rồi đổi thành giây. Cùng cấp cộng thời gian vào hạn hiện tại; đổi cấp tính lại từ giờ SQL. Cần `VIEW DEFINITION`, `EXECUTE`, `SELECT` trên MEMB_INFO/MEMB_STAT và quyền ghi qua procedure. Mọi lần lưu đều xác nhận và so snapshot.

Để gỡ khóa hết hạn, bật riêng `Enabled=1` trong `[MUSVEN_ACCOUNT_MODERATION]`. Musven kiểm tra mỗi lần dùng định nghĩa đầy đủ và chữ ký `dbo.WZ_DesblocAccount`; thủ tục chỉ được phép gỡ `bloc_code`/`CtlCode` bằng 0 khi giá trị hiện tại là 1 và `bloc_expire < GETDATE()`. Cần quyền đọc metadata, `MEMB_INFO`, `MEMB_STAT`, `Character` và `EXECUTE` trên procedure. Tài khoản phải offline; người vận hành nhập đúng AccountID và xác nhận lần cuối. Khóa còn hạn không bị đổi. Không cần migration SQL vì procedure đã có trong database đang chạy.

Để đặt khóa tài khoản tạm thời, bật riêng `Enabled=1` trong `[MUSVEN_ACCOUNT_BAN]`. Musven dùng `MEMB_INFO.bloc_code` và `bloc_expire` đã có trong hợp đồng `WZ_DesblocAccount`; không tạo procedure hoặc thay đổi schema. Cần quyền xem metadata, `SELECT` trên `dbo.MEMB_INFO`/`dbo.MEMB_STAT` và `UPDATE` chỉ cho cột `bloc_code`/`bloc_expire` của `dbo.MEMB_INFO`. Trước khi ghi, Musven xác nhận schema, trạng thái offline và snapshot; khóa còn hạn hoặc vĩnh viễn không bị ghi đè. Người vận hành chọn hạn tối đa 365 ngày, nhập đúng AccountID và xác nhận. Việc ghi diễn ra trong transaction, sau đó kiểm tra lại giá trị đã lưu. Mẫu chung tắt; profile VM bật riêng cờ này.

Tạo tài khoản có cờ riêng `[MUSVEN_ACCOUNT_CREATE]`: cần `SELECT/INSERT` trên `dbo.MEMB_INFO`. Musven kiểm tra kiểu/độ dài/nullability của schema, từ chối cột bắt buộc không hỗ trợ, khóa chống AccountID trùng, dùng transaction và hậu kiểm. Không cần nhập mật khẩu; `memb__pwd` được ghi chuỗi trống. Tên hiển thị mặc định là AccountID, email tùy chọn. Không tạo session hoặc nhân vật thay người chơi. GameServer phải cho phép đăng nhập với mật khẩu trống; Musven không thể đảm bảo điều đó nếu máy chủ yêu cầu hash/mật khẩu. Mẫu chung tắt; profile VM bật.

Sửa hồ sơ tài khoản có cờ riêng `[MUSVEN_ACCOUNT_PROFILE]`: chỉ cập nhật `MEMB_INFO.memb_name` và `mail_addr`, yêu cầu `SELECT/UPDATE` giới hạn hai cột đó cùng `SELECT MEMB_STAT`. Password, ID và thông tin khôi phục không bị thay đổi. Mẫu chung tắt; profile VM bật.

Để xóa nhân vật, chỉ bật riêng `Enabled=1` trong `[MUSVEN_CHARACTER_DELETE]` sau khi đã sao lưu database và kiểm tra thủ tục đúng bản cài. Cần `SELECT` trên `dbo.MEMB_STAT`/`dbo.Character`, `EXECUTE` và `VIEW DEFINITION` trên `dbo.WZ_DeleteCharacter`. Musven kiểm tra chữ ký `@Account varchar(10), @Name varchar(10)` cùng marker V02 mỗi lần gọi; giữ transaction, khóa trạng thái offline, xác nhận nhân vật thuộc tài khoản và tên không trùng ở tài khoản khác. Người vận hành phải nhập đúng tên và xác nhận lần cuối. Thủ tục từ chối xóa Guild Master. Nếu định nghĩa procedure không đọc được hoặc không khớp, thao tác dừng. Đây là thao tác không thể hoàn tác; hãy backup trước.

Để cấu hình quà tạo nhân vật, chạy `MUSVEN_CharacterCreateDefaults.sql` trên database `Muonline`, sau đó bật `Enabled=1` trong `[MUSVEN_CHARACTER_CREATE]`. Script có guard chữ ký/procedure/schema: V02 được nâng lên V03; nếu V03 đã tồn tại, script xác minh cấu trúc và không sửa procedure lần nữa. Chỉ phục hồi dòng cấu hình chuẩn nếu bảng V03 đúng schema nhưng thiếu dòng đó. Tài khoản Musven cần `SELECT` và `UPDATE` trên `dbo.MUSVEN_CharacterCreateDefaults`, cùng `VIEW DEFINITION` trên `dbo.WZ_CreateCharacter`. Form sửa Level, Point, Zen, Reset, Master Level/Point (Master tối đa 400) và WCoin C/P/G. Procedure V03 đọc cấu hình trong transaction mỗi khi người chơi tạo nhân vật; nhân vật cũ không đổi. WCoin/Goblin là số dư chung của tài khoản và được cộng theo mỗi lượt tạo nhân vật. Không cần chọn Class, tài khoản, tên hay tạo nhân vật trong Musven.

Kết nối yêu cầu mã hóa và chứng chỉ SQL được Windows tin cậy. Nếu SQL đang chạy trong VM, `Server` phải là địa chỉ/instance mà máy chạy Musven truy cập được và SQL Server phải cho phép kết nối mạng. Một truy vấn chạy trong SSMS trên VM chưa xác nhận ứng dụng trên máy chính kết nối được.

## Những điểm schema đã xác nhận

- `dbo.MEMB_INFO`: tra cứu tài khoản chỉ lấy `memb___id` và `memb_name`.
- `dbo.Character`: ứng dụng dò cột từ metadata, cần `Name` và `AccountID`; Level/Reset là tùy chọn.
- `dbo.DATDAT_BANK`: `AccountID` cùng 10 cột ngọc số nguyên.
- `dbo.ExtWarehouse`: `AccountID`, `Items varbinary(3840)`, `Money`, `Number`.
- `dbo.warehouse`: kho chính số 0, được thêm vào danh sách nếu đã có dòng cho tài khoản.
- `dbo.MEMB_STAT.ConnectStat`: dùng để chặn lưu khi tài khoản đang trực tuyến.
- `dbo.MasterSkillTree`: `Name`, `MasterLevel`, `MasterPoint`, `MasterExperience` và blob skill; Musven chỉ sửa ba trường số, không chạm `MasterSkill`.
- `dbo.QuestKillCount`: editor nhiệm vụ chỉ cập nhật năm `KillCount`; giữ nguyên `QuestIndex`/`MonsterClass`, không tạo dòng thiếu, yêu cầu offline và kiểm tra snapshot/hậu kiểm.
- `dbo.QuestKillCount`: editor nhiệm vụ chỉ cập nhật năm `KillCount`; giữ nguyên QuestIndex/MonsterClass, từ chối nếu thiếu dòng, yêu cầu offline và kiểm tra snapshot/hậu kiểm.
- `dbo.WZ_GetItemSerial`: cấp serial cho vật phẩm mới; nếu thủ tục không tồn tại hoặc không trả serial hợp lệ, lệnh lưu bị hủy.
- `dbo.WZ_CreateCharacter` dùng chữ ký ba tham số `@AccountID`, `@Name`, `@Class` do game gọi; sau khi áp dụng script V03, Musven chỉ đọc/cập nhật dòng cấu hình, không gọi procedure và không tạo nhân vật.
- Kết quả SSMS người vận hành gửi xác nhận `dbo.WZ_DeleteCharacter` tồn tại, có marker chủ sở hữu/giao dịch và chữ ký `@Account varchar(10)`, `@Name varchar(10)`; `GoblinMix`, `RankingBos`, `CustomQuest` và `CustomNpcQuest` cũng tồn tại. Musven yêu cầu thêm các marker dọn dữ liệu liên quan trước khi gọi, kiểm tra tên nhân vật là duy nhất và giữ cờ xóa tắt mặc định.

Đã rà soát thêm source Titan và source C++ GameServer ở `E:\MUSVEN_GOC_SOURCE`; các ví dụ cũ giúp xác định trường dữ liệu nhưng một số luồng bỏ sót bảng phụ, không có transaction hoặc gọi procedure mã hóa mật khẩu chưa có định nghĩa đi kèm. MUSVEN chỉ bật phần đã chuyển thành hợp đồng có kiểm tra runtime. Xem [LEGACY_SOURCE_CONTRACT_AUDIT.md](LEGACY_SOURCE_CONTRACT_AUDIT.md) để biết source nào đã đối chiếu, phần nào đã chuyển sang MUSVEN và phần nào vẫn chưa có protocol/schema đủ an toàn.
- Nút kiểm kê schema bao phủ các cột dùng trực tiếp trong tra cứu tài khoản/phiên/nhân vật, tạo/sửa/xóa nhân vật, tiền-ngọc, kho chính/kho mở rộng và toàn bộ bảng phụ được `WZ_DeleteCharacter` gọi. Các bảng ranking được liệt kê tùy chọn; bảng custom chưa dùng trong Musven không bị tạo thêm.

Không tự tạo bảng hoặc suy đoán nội dung nhị phân của Items. Giấy phép các thư viện đóng gói được ghi trong `THIRD_PARTY_NOTICES.md` và `licenses/` ở thư mục nguồn.

Editor số đếm nhiệm vụ được mở từ nút ⚑ trên từng nhân vật. Nó đọc `dbo.QuestKillCount` và chỉ cập nhật năm cột `KillCount1..5`; `QuestIndex`/`MonsterClass` giữ nguyên. Bật `[MUSVEN_CHARACTER_QUEST_COUNTS] Enabled=1` trong cấu hình VM để cho phép lưu; tài khoản phải offline. Nếu không có dòng nhiệm vụ cho nhân vật, công cụ báo rõ và không tự thêm dòng.

### Xóa trắng dữ liệu để mở server mới

Trong **Công cụ → Xóa trắng dữ liệu server**, nút **Xem trước** chỉ đọc số dòng và schema. Bản reset sau migration V03 được rà cho SQL Server 2008 R2 10.50, database `Muonline`, đúng 63 bảng và 76 procedure. Nó xóa 56 bảng dữ liệu, gồm tài khoản, nhân vật, kho, tiền, guild, sự kiện và ranking; giữ bảy bảng cấu hình (`DefaultClassType`, `GameServerInfo`, `MK_Server`, `MuCastle_DATA`, `MuCastle_NPC`, `WZ_CW_INFO`, `MUSVEN_CharacterCreateDefaults`), đồng thời trả trạng thái thành trì về mặc định.

Để mở nút xóa, đặt `[MUSVEN_DATA_RESET] Enabled=1`, `ExpectedServer` đúng với tên SQL Server thấy trong bản xem trước, và `BackupPath` là thư mục tuyệt đối trên ổ D:/E: hoặc đúng thư mục chuyên dụng `C:\MUSVEN_TITAN_BACKUP` đã tồn tại trên máy chạy dịch vụ SQL Server. SQL Server service cần quyền ghi thư mục; Windows user chạy Musven cần quyền xem trạng thái phiên, backup, xóa dữ liệu và đổi chế độ truy cập database. Hãy dừng game server, đóng các kết nối SQL khác tới `Muonline`, xem kỹ bảng/số dòng, gõ chính xác `XOA TRANG Muonline` rồi xác nhận lần cuối. Musven khóa database, tạo backup `COPY_ONLY + CHECKSUM`, chạy `RESTORE VERIFYONLY`, xóa trong một transaction, kiểm tra toàn bộ bảng đích rỗng và khôi phục chế độ `MULTI_USER`. Nếu schema, khóa ngoại, trigger, số seed hoặc trạng thái phiên khác bản đã rà, thao tác dừng trước khi xóa. Không có lệnh shrink file/log trong chức năng này.

