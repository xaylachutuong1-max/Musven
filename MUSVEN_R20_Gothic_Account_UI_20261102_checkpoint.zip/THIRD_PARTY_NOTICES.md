# Third-party notices

The application bundles these direct NuGet dependencies:

| Package | Version | License |
| --- | ---: | --- |
| Microsoft.Data.SqlClient | 7.1.1 | MIT |
| Microsoft.Web.WebView2 | 1.0.2903.40 | See the included package license text |

NuGet transitive dependencies are resolved in `MU_SVEN_09Q.csproj` restore metadata. Their license terms remain in the application bundle where provided by the packages. The SNI runtime and WebView2 license texts are included with the source and embedded into the release EXE. Open **Cài đặt → Thư viện & giấy phép** in the application to view the embedded notices.

The Windows .NET 8 x86 runtime is self-contained in the deployment folder. Native runtime DLLs remain beside the EXE so the .NET single-file host does not extract them into Windows `%TEMP%` on C:. Copy the complete folder to D: or E: and run `MU_SVEN_09Q.exe` there. WebView2 Runtime remains a Windows prerequisite for the 3D viewer.
