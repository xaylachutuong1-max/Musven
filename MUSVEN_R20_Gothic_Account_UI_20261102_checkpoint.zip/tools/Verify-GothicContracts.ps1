$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$apiPath = Join-Path $root 'GothicUi\api.js'
$appPath = Join-Path $root 'GothicUi\app.js'
$bridgePath = Join-Path $root 'MuSven09M\GothicBackendBridge.cs'
$contractPath = Join-Path $root 'API_SCHEMA_CONTRACT.md'

$apiSource = Get-Content -LiteralPath $apiPath -Raw
$methodsBlock = [regex]::Match($apiSource, 'const methods = \[(?<body>[\s\S]*?)\];')
if (-not $methodsBlock.Success) { throw 'Could not find the Gothic API method declaration.' }
$declared = @([regex]::Matches($methodsBlock.Groups['body'].Value, "'(?<name>[A-Za-z]\w*)'") | ForEach-Object { $_.Groups['name'].Value } | Sort-Object -Unique)

$bridgeSource = Get-Content -LiteralPath $bridgePath -Raw
$routes = @([regex]::Matches($bridgeSource, '(?m)^\s*"(?<name>\w+)"\s*=>') | ForEach-Object { $_.Groups['name'].Value } | Sort-Object -Unique)

$appSource = Get-Content -LiteralPath $appPath -Raw
$calls = @([regex]::Matches($appSource, "api\(\s*'(?<name>\w+)'") | ForEach-Object { $_.Groups['name'].Value } | Sort-Object -Unique)
$contract = Get-Content -LiteralPath $contractPath -Raw

$missingRoutes = @($declared | Where-Object { $_ -notin $routes })
$undeclaredRoutes = @($routes | Where-Object { $_ -notin $declared })
$unroutedCalls = @($calls | Where-Object { $_ -notin $routes })
$undocumentedRoutes = @($routes | Where-Object { -not $contract.Contains('`' + $_ + '`') })

if ($missingRoutes.Count -or $undeclaredRoutes.Count -or $unroutedCalls.Count -or $undocumentedRoutes.Count) {
    $details = @(
        'API methods without backend route: ' + ($missingRoutes -join ', '),
        'Backend routes missing from API declaration: ' + ($undeclaredRoutes -join ', '),
        'UI API calls without backend route: ' + ($unroutedCalls -join ', '),
        'Backend routes missing from API_SCHEMA_CONTRACT.md: ' + ($undocumentedRoutes -join ', ')
    ) -join [Environment]::NewLine
    throw $details
}

Write-Output "Gothic contract check passed: $($declared.Count) API declarations, $($routes.Count) backend routes, $($calls.Count) UI API calls."
